#' Create a new ResponseReturnStatusListResult
#'
#' @description
#' ResponseReturnStatusListResult Class
#'
#' @docType class
#' @title ResponseReturnStatusListResult
#' @description ResponseReturnStatusListResult Class
#' @format An \code{R6Class} generator object
#' @field return_statuses  list(\link{Status}) [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ResponseReturnStatusListResult <- R6::R6Class(
  "ResponseReturnStatusListResult",
  public = list(
    `return_statuses` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new ResponseReturnStatusListResult class.
    #'
    #' @param return_statuses return_statuses
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`return_statuses` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`return_statuses`)) {
        stopifnot(is.vector(`return_statuses`), length(`return_statuses`) != 0)
        sapply(`return_statuses`, function(x) stopifnot(R6::is.R6(x)))
        self$`return_statuses` <- `return_statuses`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ResponseReturnStatusListResult as a base R list.
    #' @examples
    #' # convert array of ResponseReturnStatusListResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ResponseReturnStatusListResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ResponseReturnStatusListResultObject <- list()
      if (!is.null(self$`return_statuses`)) {
        ResponseReturnStatusListResultObject[["return_statuses"]] <-
          lapply(self$`return_statuses`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`additional_fields`)) {
        ResponseReturnStatusListResultObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        ResponseReturnStatusListResultObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(ResponseReturnStatusListResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ResponseReturnStatusListResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ResponseReturnStatusListResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`return_statuses`)) {
        self$`return_statuses` <- ApiClient$new()$deserializeObj(this_object$`return_statuses`, "array[Status]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ResponseReturnStatusListResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ResponseReturnStatusListResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ResponseReturnStatusListResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`return_statuses` <- ApiClient$new()$deserializeObj(this_object$`return_statuses`, "array[Status]", loadNamespace("openapi"))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to ResponseReturnStatusListResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ResponseReturnStatusListResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ResponseReturnStatusListResult$unlock()
#
## Below is an example to define the print function
# ResponseReturnStatusListResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ResponseReturnStatusListResult$lock()

