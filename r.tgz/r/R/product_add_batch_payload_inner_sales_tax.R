#' Create a new ProductAddBatchPayloadInnerSalesTax
#'
#' @description
#' ProductAddBatchPayloadInnerSalesTax Class
#'
#' @docType class
#' @title ProductAddBatchPayloadInnerSalesTax
#' @description ProductAddBatchPayloadInnerSalesTax Class
#' @format An \code{R6Class} generator object
#' @field tax_percent  numeric [optional]
#' @field taxable  character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductAddBatchPayloadInnerSalesTax <- R6::R6Class(
  "ProductAddBatchPayloadInnerSalesTax",
  public = list(
    `tax_percent` = NULL,
    `taxable` = NULL,

    #' @description
    #' Initialize a new ProductAddBatchPayloadInnerSalesTax class.
    #'
    #' @param tax_percent tax_percent
    #' @param taxable taxable
    #' @param ... Other optional arguments.
    initialize = function(`tax_percent` = NULL, `taxable` = NULL, ...) {
      if (!is.null(`tax_percent`)) {
        self$`tax_percent` <- `tax_percent`
      }
      if (!is.null(`taxable`)) {
        if (!(is.logical(`taxable`) && length(`taxable`) == 1)) {
          stop(paste("Error! Invalid data for `taxable`. Must be a boolean:", `taxable`))
        }
        self$`taxable` <- `taxable`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductAddBatchPayloadInnerSalesTax as a base R list.
    #' @examples
    #' # convert array of ProductAddBatchPayloadInnerSalesTax (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductAddBatchPayloadInnerSalesTax to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductAddBatchPayloadInnerSalesTaxObject <- list()
      if (!is.null(self$`tax_percent`)) {
        ProductAddBatchPayloadInnerSalesTaxObject[["tax_percent"]] <-
          self$`tax_percent`
      }
      if (!is.null(self$`taxable`)) {
        ProductAddBatchPayloadInnerSalesTaxObject[["taxable"]] <-
          self$`taxable`
      }
      return(ProductAddBatchPayloadInnerSalesTaxObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductAddBatchPayloadInnerSalesTax
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductAddBatchPayloadInnerSalesTax
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`tax_percent`)) {
        self$`tax_percent` <- this_object$`tax_percent`
      }
      if (!is.null(this_object$`taxable`)) {
        self$`taxable` <- this_object$`taxable`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductAddBatchPayloadInnerSalesTax in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductAddBatchPayloadInnerSalesTax
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductAddBatchPayloadInnerSalesTax
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`tax_percent` <- this_object$`tax_percent`
      self$`taxable` <- this_object$`taxable`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductAddBatchPayloadInnerSalesTax and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductAddBatchPayloadInnerSalesTax
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      if (self$`tax_percent` < 0) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      if (self$`tax_percent` < 0) {
        invalid_fields["tax_percent"] <- "Invalid value for `tax_percent`, must be bigger than or equal to 0."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductAddBatchPayloadInnerSalesTax$unlock()
#
## Below is an example to define the print function
# ProductAddBatchPayloadInnerSalesTax$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductAddBatchPayloadInnerSalesTax$lock()

