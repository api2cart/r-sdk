#' Create a new ProductPriceAdd
#'
#' @description
#' ProductPriceAdd Class
#'
#' @docType class
#' @title ProductPriceAdd
#' @description ProductPriceAdd Class
#' @format An \code{R6Class} generator object
#' @field product_id Defines the product to which the price has to be added character [optional]
#' @field group_prices Defines product's group prices list(\link{ProductAddGroupPricesInner}) [optional]
#' @field store_id Store Id character [optional]
#' @field idempotency_key A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong> character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductPriceAdd <- R6::R6Class(
  "ProductPriceAdd",
  public = list(
    `product_id` = NULL,
    `group_prices` = NULL,
    `store_id` = NULL,
    `idempotency_key` = NULL,

    #' @description
    #' Initialize a new ProductPriceAdd class.
    #'
    #' @param product_id Defines the product to which the price has to be added
    #' @param group_prices Defines product's group prices
    #' @param store_id Store Id
    #' @param idempotency_key A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong>
    #' @param ... Other optional arguments.
    initialize = function(`product_id` = NULL, `group_prices` = NULL, `store_id` = NULL, `idempotency_key` = NULL, ...) {
      if (!is.null(`product_id`)) {
        if (!(is.character(`product_id`) && length(`product_id`) == 1)) {
          stop(paste("Error! Invalid data for `product_id`. Must be a string:", `product_id`))
        }
        self$`product_id` <- `product_id`
      }
      if (!is.null(`group_prices`)) {
        stopifnot(is.vector(`group_prices`), length(`group_prices`) != 0)
        sapply(`group_prices`, function(x) stopifnot(R6::is.R6(x)))
        self$`group_prices` <- `group_prices`
      }
      if (!is.null(`store_id`)) {
        if (!(is.character(`store_id`) && length(`store_id`) == 1)) {
          stop(paste("Error! Invalid data for `store_id`. Must be a string:", `store_id`))
        }
        self$`store_id` <- `store_id`
      }
      if (!is.null(`idempotency_key`)) {
        if (!(is.character(`idempotency_key`) && length(`idempotency_key`) == 1)) {
          stop(paste("Error! Invalid data for `idempotency_key`. Must be a string:", `idempotency_key`))
        }
        self$`idempotency_key` <- `idempotency_key`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductPriceAdd as a base R list.
    #' @examples
    #' # convert array of ProductPriceAdd (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductPriceAdd to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductPriceAddObject <- list()
      if (!is.null(self$`product_id`)) {
        ProductPriceAddObject[["product_id"]] <-
          self$`product_id`
      }
      if (!is.null(self$`group_prices`)) {
        ProductPriceAddObject[["group_prices"]] <-
          lapply(self$`group_prices`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`store_id`)) {
        ProductPriceAddObject[["store_id"]] <-
          self$`store_id`
      }
      if (!is.null(self$`idempotency_key`)) {
        ProductPriceAddObject[["idempotency_key"]] <-
          self$`idempotency_key`
      }
      return(ProductPriceAddObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductPriceAdd
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductPriceAdd
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`product_id`)) {
        self$`product_id` <- this_object$`product_id`
      }
      if (!is.null(this_object$`group_prices`)) {
        self$`group_prices` <- ApiClient$new()$deserializeObj(this_object$`group_prices`, "array[ProductAddGroupPricesInner]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`store_id`)) {
        self$`store_id` <- this_object$`store_id`
      }
      if (!is.null(this_object$`idempotency_key`)) {
        self$`idempotency_key` <- this_object$`idempotency_key`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductPriceAdd in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductPriceAdd
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductPriceAdd
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`product_id` <- this_object$`product_id`
      self$`group_prices` <- ApiClient$new()$deserializeObj(this_object$`group_prices`, "array[ProductAddGroupPricesInner]", loadNamespace("openapi"))
      self$`store_id` <- this_object$`store_id`
      self$`idempotency_key` <- this_object$`idempotency_key`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductPriceAdd and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductPriceAdd
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductPriceAdd$unlock()
#
## Below is an example to define the print function
# ProductPriceAdd$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductPriceAdd$lock()

