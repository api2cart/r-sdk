#' Create a new ResponseCustomerFindResult
#'
#' @description
#' ResponseCustomerFindResult Class
#'
#' @docType class
#' @title ResponseCustomerFindResult
#' @description ResponseCustomerFindResult Class
#' @format An \code{R6Class} generator object
#' @field customers_count  integer [optional]
#' @field customer  list(\link{Customer}) [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ResponseCustomerFindResult <- R6::R6Class(
  "ResponseCustomerFindResult",
  public = list(
    `customers_count` = NULL,
    `customer` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new ResponseCustomerFindResult class.
    #'
    #' @param customers_count customers_count
    #' @param customer customer
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`customers_count` = NULL, `customer` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`customers_count`)) {
        if (!(is.numeric(`customers_count`) && length(`customers_count`) == 1)) {
          stop(paste("Error! Invalid data for `customers_count`. Must be an integer:", `customers_count`))
        }
        self$`customers_count` <- `customers_count`
      }
      if (!is.null(`customer`)) {
        stopifnot(is.vector(`customer`), length(`customer`) != 0)
        sapply(`customer`, function(x) stopifnot(R6::is.R6(x)))
        self$`customer` <- `customer`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ResponseCustomerFindResult as a base R list.
    #' @examples
    #' # convert array of ResponseCustomerFindResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ResponseCustomerFindResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ResponseCustomerFindResultObject <- list()
      if (!is.null(self$`customers_count`)) {
        ResponseCustomerFindResultObject[["customers_count"]] <-
          self$`customers_count`
      }
      if (!is.null(self$`customer`)) {
        ResponseCustomerFindResultObject[["customer"]] <-
          lapply(self$`customer`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`additional_fields`)) {
        ResponseCustomerFindResultObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        ResponseCustomerFindResultObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(ResponseCustomerFindResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ResponseCustomerFindResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ResponseCustomerFindResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`customers_count`)) {
        self$`customers_count` <- this_object$`customers_count`
      }
      if (!is.null(this_object$`customer`)) {
        self$`customer` <- ApiClient$new()$deserializeObj(this_object$`customer`, "array[Customer]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ResponseCustomerFindResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ResponseCustomerFindResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ResponseCustomerFindResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`customers_count` <- this_object$`customers_count`
      self$`customer` <- ApiClient$new()$deserializeObj(this_object$`customer`, "array[Customer]", loadNamespace("openapi"))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to ResponseCustomerFindResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ResponseCustomerFindResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ResponseCustomerFindResult$unlock()
#
## Below is an example to define the print function
# ResponseCustomerFindResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ResponseCustomerFindResult$lock()

