#' Create a new ResponseOrderPreestimateShippingListResult
#'
#' @description
#' ResponseOrderPreestimateShippingListResult Class
#'
#' @docType class
#' @title ResponseOrderPreestimateShippingListResult
#' @description ResponseOrderPreestimateShippingListResult Class
#' @format An \code{R6Class} generator object
#' @field preestimate_shippings_count  integer [optional]
#' @field preestimate_shippings  list(\link{OrderPreestimateShipping}) [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ResponseOrderPreestimateShippingListResult <- R6::R6Class(
  "ResponseOrderPreestimateShippingListResult",
  public = list(
    `preestimate_shippings_count` = NULL,
    `preestimate_shippings` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new ResponseOrderPreestimateShippingListResult class.
    #'
    #' @param preestimate_shippings_count preestimate_shippings_count
    #' @param preestimate_shippings preestimate_shippings
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`preestimate_shippings_count` = NULL, `preestimate_shippings` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`preestimate_shippings_count`)) {
        if (!(is.numeric(`preestimate_shippings_count`) && length(`preestimate_shippings_count`) == 1)) {
          stop(paste("Error! Invalid data for `preestimate_shippings_count`. Must be an integer:", `preestimate_shippings_count`))
        }
        self$`preestimate_shippings_count` <- `preestimate_shippings_count`
      }
      if (!is.null(`preestimate_shippings`)) {
        stopifnot(is.vector(`preestimate_shippings`), length(`preestimate_shippings`) != 0)
        sapply(`preestimate_shippings`, function(x) stopifnot(R6::is.R6(x)))
        self$`preestimate_shippings` <- `preestimate_shippings`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ResponseOrderPreestimateShippingListResult as a base R list.
    #' @examples
    #' # convert array of ResponseOrderPreestimateShippingListResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ResponseOrderPreestimateShippingListResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ResponseOrderPreestimateShippingListResultObject <- list()
      if (!is.null(self$`preestimate_shippings_count`)) {
        ResponseOrderPreestimateShippingListResultObject[["preestimate_shippings_count"]] <-
          self$`preestimate_shippings_count`
      }
      if (!is.null(self$`preestimate_shippings`)) {
        ResponseOrderPreestimateShippingListResultObject[["preestimate_shippings"]] <-
          lapply(self$`preestimate_shippings`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`additional_fields`)) {
        ResponseOrderPreestimateShippingListResultObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        ResponseOrderPreestimateShippingListResultObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(ResponseOrderPreestimateShippingListResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ResponseOrderPreestimateShippingListResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ResponseOrderPreestimateShippingListResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`preestimate_shippings_count`)) {
        self$`preestimate_shippings_count` <- this_object$`preestimate_shippings_count`
      }
      if (!is.null(this_object$`preestimate_shippings`)) {
        self$`preestimate_shippings` <- ApiClient$new()$deserializeObj(this_object$`preestimate_shippings`, "array[OrderPreestimateShipping]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ResponseOrderPreestimateShippingListResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ResponseOrderPreestimateShippingListResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ResponseOrderPreestimateShippingListResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`preestimate_shippings_count` <- this_object$`preestimate_shippings_count`
      self$`preestimate_shippings` <- ApiClient$new()$deserializeObj(this_object$`preestimate_shippings`, "array[OrderPreestimateShipping]", loadNamespace("openapi"))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to ResponseOrderPreestimateShippingListResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ResponseOrderPreestimateShippingListResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ResponseOrderPreestimateShippingListResult$unlock()
#
## Below is an example to define the print function
# ResponseOrderPreestimateShippingListResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ResponseOrderPreestimateShippingListResult$lock()

