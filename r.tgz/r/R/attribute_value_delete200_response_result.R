#' Create a new AttributeValueDelete200ResponseResult
#'
#' @description
#' AttributeValueDelete200ResponseResult Class
#'
#' @docType class
#' @title AttributeValueDelete200ResponseResult
#' @description AttributeValueDelete200ResponseResult Class
#' @format An \code{R6Class} generator object
#' @field deleted  character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
AttributeValueDelete200ResponseResult <- R6::R6Class(
  "AttributeValueDelete200ResponseResult",
  public = list(
    `deleted` = NULL,

    #' @description
    #' Initialize a new AttributeValueDelete200ResponseResult class.
    #'
    #' @param deleted deleted
    #' @param ... Other optional arguments.
    initialize = function(`deleted` = NULL, ...) {
      if (!is.null(`deleted`)) {
        if (!(is.logical(`deleted`) && length(`deleted`) == 1)) {
          stop(paste("Error! Invalid data for `deleted`. Must be a boolean:", `deleted`))
        }
        self$`deleted` <- `deleted`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return AttributeValueDelete200ResponseResult as a base R list.
    #' @examples
    #' # convert array of AttributeValueDelete200ResponseResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert AttributeValueDelete200ResponseResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      AttributeValueDelete200ResponseResultObject <- list()
      if (!is.null(self$`deleted`)) {
        AttributeValueDelete200ResponseResultObject[["deleted"]] <-
          self$`deleted`
      }
      return(AttributeValueDelete200ResponseResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of AttributeValueDelete200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of AttributeValueDelete200ResponseResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`deleted`)) {
        self$`deleted` <- this_object$`deleted`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return AttributeValueDelete200ResponseResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of AttributeValueDelete200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of AttributeValueDelete200ResponseResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`deleted` <- this_object$`deleted`
      self
    },

    #' @description
    #' Validate JSON input with respect to AttributeValueDelete200ResponseResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of AttributeValueDelete200ResponseResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# AttributeValueDelete200ResponseResult$unlock()
#
## Below is an example to define the print function
# AttributeValueDelete200ResponseResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# AttributeValueDelete200ResponseResult$lock()

