#' Create a new Image
#'
#' @description
#' Image Class
#'
#' @docType class
#' @title Image
#' @description Image Class
#' @format An \code{R6Class} generator object
#' @field id  character [optional]
#' @field http_path  character [optional]
#' @field file_name  character [optional]
#' @field mime-type  character [optional]
#' @field size  integer [optional]
#' @field create_at  \link{A2CDateTime} [optional]
#' @field modified_at  \link{A2CDateTime} [optional]
#' @field alt  character [optional]
#' @field avail  character [optional]
#' @field sort_order  integer [optional]
#' @field type  character [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
Image <- R6::R6Class(
  "Image",
  public = list(
    `id` = NULL,
    `http_path` = NULL,
    `file_name` = NULL,
    `mime-type` = NULL,
    `size` = NULL,
    `create_at` = NULL,
    `modified_at` = NULL,
    `alt` = NULL,
    `avail` = NULL,
    `sort_order` = NULL,
    `type` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new Image class.
    #'
    #' @param id id
    #' @param http_path http_path
    #' @param file_name file_name
    #' @param mime-type mime-type
    #' @param size size
    #' @param create_at create_at
    #' @param modified_at modified_at
    #' @param alt alt
    #' @param avail avail
    #' @param sort_order sort_order
    #' @param type type
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `http_path` = NULL, `file_name` = NULL, `mime-type` = NULL, `size` = NULL, `create_at` = NULL, `modified_at` = NULL, `alt` = NULL, `avail` = NULL, `sort_order` = NULL, `type` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`http_path`)) {
        if (!(is.character(`http_path`) && length(`http_path`) == 1)) {
          stop(paste("Error! Invalid data for `http_path`. Must be a string:", `http_path`))
        }
        self$`http_path` <- `http_path`
      }
      if (!is.null(`file_name`)) {
        if (!(is.character(`file_name`) && length(`file_name`) == 1)) {
          stop(paste("Error! Invalid data for `file_name`. Must be a string:", `file_name`))
        }
        self$`file_name` <- `file_name`
      }
      if (!is.null(`mime-type`)) {
        if (!(is.character(`mime-type`) && length(`mime-type`) == 1)) {
          stop(paste("Error! Invalid data for `mime-type`. Must be a string:", `mime-type`))
        }
        self$`mime-type` <- `mime-type`
      }
      if (!is.null(`size`)) {
        if (!(is.numeric(`size`) && length(`size`) == 1)) {
          stop(paste("Error! Invalid data for `size`. Must be an integer:", `size`))
        }
        self$`size` <- `size`
      }
      if (!is.null(`create_at`)) {
        stopifnot(R6::is.R6(`create_at`))
        self$`create_at` <- `create_at`
      }
      if (!is.null(`modified_at`)) {
        stopifnot(R6::is.R6(`modified_at`))
        self$`modified_at` <- `modified_at`
      }
      if (!is.null(`alt`)) {
        if (!(is.character(`alt`) && length(`alt`) == 1)) {
          stop(paste("Error! Invalid data for `alt`. Must be a string:", `alt`))
        }
        self$`alt` <- `alt`
      }
      if (!is.null(`avail`)) {
        if (!(is.logical(`avail`) && length(`avail`) == 1)) {
          stop(paste("Error! Invalid data for `avail`. Must be a boolean:", `avail`))
        }
        self$`avail` <- `avail`
      }
      if (!is.null(`sort_order`)) {
        if (!(is.numeric(`sort_order`) && length(`sort_order`) == 1)) {
          stop(paste("Error! Invalid data for `sort_order`. Must be an integer:", `sort_order`))
        }
        self$`sort_order` <- `sort_order`
      }
      if (!is.null(`type`)) {
        if (!(is.character(`type`) && length(`type`) == 1)) {
          stop(paste("Error! Invalid data for `type`. Must be a string:", `type`))
        }
        self$`type` <- `type`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return Image as a base R list.
    #' @examples
    #' # convert array of Image (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert Image to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ImageObject <- list()
      if (!is.null(self$`id`)) {
        ImageObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`http_path`)) {
        ImageObject[["http_path"]] <-
          self$`http_path`
      }
      if (!is.null(self$`file_name`)) {
        ImageObject[["file_name"]] <-
          self$`file_name`
      }
      if (!is.null(self$`mime-type`)) {
        ImageObject[["mime-type"]] <-
          self$`mime-type`
      }
      if (!is.null(self$`size`)) {
        ImageObject[["size"]] <-
          self$`size`
      }
      if (!is.null(self$`create_at`)) {
        ImageObject[["create_at"]] <-
          self$`create_at`$toSimpleType()
      }
      if (!is.null(self$`modified_at`)) {
        ImageObject[["modified_at"]] <-
          self$`modified_at`$toSimpleType()
      }
      if (!is.null(self$`alt`)) {
        ImageObject[["alt"]] <-
          self$`alt`
      }
      if (!is.null(self$`avail`)) {
        ImageObject[["avail"]] <-
          self$`avail`
      }
      if (!is.null(self$`sort_order`)) {
        ImageObject[["sort_order"]] <-
          self$`sort_order`
      }
      if (!is.null(self$`type`)) {
        ImageObject[["type"]] <-
          self$`type`
      }
      if (!is.null(self$`additional_fields`)) {
        ImageObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        ImageObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(ImageObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of Image
    #'
    #' @param input_json the JSON input
    #' @return the instance of Image
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`http_path`)) {
        self$`http_path` <- this_object$`http_path`
      }
      if (!is.null(this_object$`file_name`)) {
        self$`file_name` <- this_object$`file_name`
      }
      if (!is.null(this_object$`mime-type`)) {
        self$`mime-type` <- this_object$`mime-type`
      }
      if (!is.null(this_object$`size`)) {
        self$`size` <- this_object$`size`
      }
      if (!is.null(this_object$`create_at`)) {
        `create_at_object` <- A2CDateTime$new()
        `create_at_object`$fromJSON(jsonlite::toJSON(this_object$`create_at`, auto_unbox = TRUE, digits = NA))
        self$`create_at` <- `create_at_object`
      }
      if (!is.null(this_object$`modified_at`)) {
        `modified_at_object` <- A2CDateTime$new()
        `modified_at_object`$fromJSON(jsonlite::toJSON(this_object$`modified_at`, auto_unbox = TRUE, digits = NA))
        self$`modified_at` <- `modified_at_object`
      }
      if (!is.null(this_object$`alt`)) {
        self$`alt` <- this_object$`alt`
      }
      if (!is.null(this_object$`avail`)) {
        self$`avail` <- this_object$`avail`
      }
      if (!is.null(this_object$`sort_order`)) {
        self$`sort_order` <- this_object$`sort_order`
      }
      if (!is.null(this_object$`type`)) {
        self$`type` <- this_object$`type`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return Image in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of Image
    #'
    #' @param input_json the JSON input
    #' @return the instance of Image
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`http_path` <- this_object$`http_path`
      self$`file_name` <- this_object$`file_name`
      self$`mime-type` <- this_object$`mime-type`
      self$`size` <- this_object$`size`
      self$`create_at` <- A2CDateTime$new()$fromJSON(jsonlite::toJSON(this_object$`create_at`, auto_unbox = TRUE, digits = NA))
      self$`modified_at` <- A2CDateTime$new()$fromJSON(jsonlite::toJSON(this_object$`modified_at`, auto_unbox = TRUE, digits = NA))
      self$`alt` <- this_object$`alt`
      self$`avail` <- this_object$`avail`
      self$`sort_order` <- this_object$`sort_order`
      self$`type` <- this_object$`type`
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to Image and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of Image
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# Image$unlock()
#
## Below is an example to define the print function
# Image$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# Image$lock()

