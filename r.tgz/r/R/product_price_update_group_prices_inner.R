#' Create a new ProductPriceUpdateGroupPricesInner
#'
#' @description
#' ProductPriceUpdateGroupPricesInner Class
#'
#' @docType class
#' @title ProductPriceUpdateGroupPricesInner
#' @description ProductPriceUpdateGroupPricesInner Class
#' @format An \code{R6Class} generator object
#' @field id  integer [optional]
#' @field group_id  character [optional]
#' @field price  numeric [optional]
#' @field qty  integer [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductPriceUpdateGroupPricesInner <- R6::R6Class(
  "ProductPriceUpdateGroupPricesInner",
  public = list(
    `id` = NULL,
    `group_id` = NULL,
    `price` = NULL,
    `qty` = NULL,

    #' @description
    #' Initialize a new ProductPriceUpdateGroupPricesInner class.
    #'
    #' @param id id
    #' @param group_id group_id
    #' @param price price
    #' @param qty qty
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `group_id` = NULL, `price` = NULL, `qty` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.numeric(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be an integer:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`group_id`)) {
        if (!(is.character(`group_id`) && length(`group_id`) == 1)) {
          stop(paste("Error! Invalid data for `group_id`. Must be a string:", `group_id`))
        }
        self$`group_id` <- `group_id`
      }
      if (!is.null(`price`)) {
        self$`price` <- `price`
      }
      if (!is.null(`qty`)) {
        if (!(is.numeric(`qty`) && length(`qty`) == 1)) {
          stop(paste("Error! Invalid data for `qty`. Must be an integer:", `qty`))
        }
        self$`qty` <- `qty`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductPriceUpdateGroupPricesInner as a base R list.
    #' @examples
    #' # convert array of ProductPriceUpdateGroupPricesInner (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductPriceUpdateGroupPricesInner to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductPriceUpdateGroupPricesInnerObject <- list()
      if (!is.null(self$`id`)) {
        ProductPriceUpdateGroupPricesInnerObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`group_id`)) {
        ProductPriceUpdateGroupPricesInnerObject[["group_id"]] <-
          self$`group_id`
      }
      if (!is.null(self$`price`)) {
        ProductPriceUpdateGroupPricesInnerObject[["price"]] <-
          self$`price`
      }
      if (!is.null(self$`qty`)) {
        ProductPriceUpdateGroupPricesInnerObject[["qty"]] <-
          self$`qty`
      }
      return(ProductPriceUpdateGroupPricesInnerObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductPriceUpdateGroupPricesInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductPriceUpdateGroupPricesInner
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`group_id`)) {
        self$`group_id` <- this_object$`group_id`
      }
      if (!is.null(this_object$`price`)) {
        self$`price` <- this_object$`price`
      }
      if (!is.null(this_object$`qty`)) {
        self$`qty` <- this_object$`qty`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductPriceUpdateGroupPricesInner in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductPriceUpdateGroupPricesInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductPriceUpdateGroupPricesInner
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`group_id` <- this_object$`group_id`
      self$`price` <- this_object$`price`
      self$`qty` <- this_object$`qty`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductPriceUpdateGroupPricesInner and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductPriceUpdateGroupPricesInner
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductPriceUpdateGroupPricesInner$unlock()
#
## Below is an example to define the print function
# ProductPriceUpdateGroupPricesInner$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductPriceUpdateGroupPricesInner$lock()

