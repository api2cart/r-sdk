#' Create a new AccountCartList200ResponseResult
#'
#' @description
#' AccountCartList200ResponseResult Class
#'
#' @docType class
#' @title AccountCartList200ResponseResult
#' @description AccountCartList200ResponseResult Class
#' @format An \code{R6Class} generator object
#' @field carts_count  integer [optional]
#' @field carts  list(\link{AccountCartList200ResponseResultCartsInner}) [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
AccountCartList200ResponseResult <- R6::R6Class(
  "AccountCartList200ResponseResult",
  public = list(
    `carts_count` = NULL,
    `carts` = NULL,

    #' @description
    #' Initialize a new AccountCartList200ResponseResult class.
    #'
    #' @param carts_count carts_count
    #' @param carts carts
    #' @param ... Other optional arguments.
    initialize = function(`carts_count` = NULL, `carts` = NULL, ...) {
      if (!is.null(`carts_count`)) {
        if (!(is.numeric(`carts_count`) && length(`carts_count`) == 1)) {
          stop(paste("Error! Invalid data for `carts_count`. Must be an integer:", `carts_count`))
        }
        self$`carts_count` <- `carts_count`
      }
      if (!is.null(`carts`)) {
        stopifnot(is.vector(`carts`), length(`carts`) != 0)
        sapply(`carts`, function(x) stopifnot(R6::is.R6(x)))
        self$`carts` <- `carts`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return AccountCartList200ResponseResult as a base R list.
    #' @examples
    #' # convert array of AccountCartList200ResponseResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert AccountCartList200ResponseResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      AccountCartList200ResponseResultObject <- list()
      if (!is.null(self$`carts_count`)) {
        AccountCartList200ResponseResultObject[["carts_count"]] <-
          self$`carts_count`
      }
      if (!is.null(self$`carts`)) {
        AccountCartList200ResponseResultObject[["carts"]] <-
          lapply(self$`carts`, function(x) x$toSimpleType())
      }
      return(AccountCartList200ResponseResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of AccountCartList200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of AccountCartList200ResponseResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`carts_count`)) {
        self$`carts_count` <- this_object$`carts_count`
      }
      if (!is.null(this_object$`carts`)) {
        self$`carts` <- ApiClient$new()$deserializeObj(this_object$`carts`, "array[AccountCartList200ResponseResultCartsInner]", loadNamespace("openapi"))
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return AccountCartList200ResponseResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of AccountCartList200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of AccountCartList200ResponseResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`carts_count` <- this_object$`carts_count`
      self$`carts` <- ApiClient$new()$deserializeObj(this_object$`carts`, "array[AccountCartList200ResponseResultCartsInner]", loadNamespace("openapi"))
      self
    },

    #' @description
    #' Validate JSON input with respect to AccountCartList200ResponseResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of AccountCartList200ResponseResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# AccountCartList200ResponseResult$unlock()
#
## Below is an example to define the print function
# AccountCartList200ResponseResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# AccountCartList200ResponseResult$lock()

