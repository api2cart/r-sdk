#' Create a new ResponseOrderStatusListResult
#'
#' @description
#' ResponseOrderStatusListResult Class
#'
#' @docType class
#' @title ResponseOrderStatusListResult
#' @description ResponseOrderStatusListResult Class
#' @format An \code{R6Class} generator object
#' @field cart_order_statuses  list(\link{Status}) [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ResponseOrderStatusListResult <- R6::R6Class(
  "ResponseOrderStatusListResult",
  public = list(
    `cart_order_statuses` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new ResponseOrderStatusListResult class.
    #'
    #' @param cart_order_statuses cart_order_statuses
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`cart_order_statuses` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`cart_order_statuses`)) {
        stopifnot(is.vector(`cart_order_statuses`), length(`cart_order_statuses`) != 0)
        sapply(`cart_order_statuses`, function(x) stopifnot(R6::is.R6(x)))
        self$`cart_order_statuses` <- `cart_order_statuses`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ResponseOrderStatusListResult as a base R list.
    #' @examples
    #' # convert array of ResponseOrderStatusListResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ResponseOrderStatusListResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ResponseOrderStatusListResultObject <- list()
      if (!is.null(self$`cart_order_statuses`)) {
        ResponseOrderStatusListResultObject[["cart_order_statuses"]] <-
          lapply(self$`cart_order_statuses`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`additional_fields`)) {
        ResponseOrderStatusListResultObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        ResponseOrderStatusListResultObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(ResponseOrderStatusListResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ResponseOrderStatusListResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ResponseOrderStatusListResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`cart_order_statuses`)) {
        self$`cart_order_statuses` <- ApiClient$new()$deserializeObj(this_object$`cart_order_statuses`, "array[Status]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ResponseOrderStatusListResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ResponseOrderStatusListResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ResponseOrderStatusListResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`cart_order_statuses` <- ApiClient$new()$deserializeObj(this_object$`cart_order_statuses`, "array[Status]", loadNamespace("openapi"))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to ResponseOrderStatusListResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ResponseOrderStatusListResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ResponseOrderStatusListResult$unlock()
#
## Below is an example to define the print function
# ResponseOrderStatusListResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ResponseOrderStatusListResult$lock()

