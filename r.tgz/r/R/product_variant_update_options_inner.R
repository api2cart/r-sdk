#' Create a new ProductVariantUpdateOptionsInner
#'
#' @description
#' ProductVariantUpdateOptionsInner Class
#'
#' @docType class
#' @title ProductVariantUpdateOptionsInner
#' @description ProductVariantUpdateOptionsInner Class
#' @format An \code{R6Class} generator object
#' @field option_name  character [optional]
#' @field option_value  character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductVariantUpdateOptionsInner <- R6::R6Class(
  "ProductVariantUpdateOptionsInner",
  public = list(
    `option_name` = NULL,
    `option_value` = NULL,

    #' @description
    #' Initialize a new ProductVariantUpdateOptionsInner class.
    #'
    #' @param option_name option_name
    #' @param option_value option_value
    #' @param ... Other optional arguments.
    initialize = function(`option_name` = NULL, `option_value` = NULL, ...) {
      if (!is.null(`option_name`)) {
        if (!(is.character(`option_name`) && length(`option_name`) == 1)) {
          stop(paste("Error! Invalid data for `option_name`. Must be a string:", `option_name`))
        }
        self$`option_name` <- `option_name`
      }
      if (!is.null(`option_value`)) {
        if (!(is.character(`option_value`) && length(`option_value`) == 1)) {
          stop(paste("Error! Invalid data for `option_value`. Must be a string:", `option_value`))
        }
        self$`option_value` <- `option_value`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductVariantUpdateOptionsInner as a base R list.
    #' @examples
    #' # convert array of ProductVariantUpdateOptionsInner (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductVariantUpdateOptionsInner to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductVariantUpdateOptionsInnerObject <- list()
      if (!is.null(self$`option_name`)) {
        ProductVariantUpdateOptionsInnerObject[["option_name"]] <-
          self$`option_name`
      }
      if (!is.null(self$`option_value`)) {
        ProductVariantUpdateOptionsInnerObject[["option_value"]] <-
          self$`option_value`
      }
      return(ProductVariantUpdateOptionsInnerObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductVariantUpdateOptionsInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductVariantUpdateOptionsInner
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`option_name`)) {
        self$`option_name` <- this_object$`option_name`
      }
      if (!is.null(this_object$`option_value`)) {
        self$`option_value` <- this_object$`option_value`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductVariantUpdateOptionsInner in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductVariantUpdateOptionsInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductVariantUpdateOptionsInner
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`option_name` <- this_object$`option_name`
      self$`option_value` <- this_object$`option_value`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductVariantUpdateOptionsInner and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductVariantUpdateOptionsInner
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductVariantUpdateOptionsInner$unlock()
#
## Below is an example to define the print function
# ProductVariantUpdateOptionsInner$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductVariantUpdateOptionsInner$lock()

