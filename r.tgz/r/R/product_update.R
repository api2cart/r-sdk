#' Create a new ProductUpdate
#'
#' @description
#' ProductUpdate Class
#'
#' @docType class
#' @title ProductUpdate
#' @description ProductUpdate Class
#' @format An \code{R6Class} generator object
#' @field id Defines product id that has to be updated character [optional]
#' @field model Defines product model that has to be updated character [optional]
#' @field sku Defines new product's sku character [optional]
#' @field name Defines product's name that has to be updated character [optional]
#' @field description Defines new product's description character [optional]
#' @field short_description Defines short description character [optional]
#' @field prices_inc_tax Indicates whether prices include tax. character [optional]
#' @field price Defines new product's price numeric [optional]
#' @field old_price Defines product's old price numeric [optional]
#' @field special_price Defines new product's special price numeric [optional]
#' @field sprice_create Defines the date of special price creation character [optional]
#' @field sprice_expire Defines the term of special price offer duration character [optional]
#' @field cost_price Defines new product's cost price numeric [optional]
#' @field fixed_cost_shipping_price Specifies product's fixed cost shipping price numeric [optional]
#' @field retail_price Defines new product's retail price numeric [optional]
#' @field tier_prices Defines product's tier prices list(\link{ProductAddTierPricesInner}) [optional]
#' @field reserve_price Defines reserve price value numeric [optional]
#' @field buyitnow_price Defines buy it now value numeric [optional]
#' @field taxable Specifies whether a tax is charged character [optional]
#' @field tax_class_id Defines tax classes where entity has to be added character [optional]
#' @field type Defines product's type character [optional]
#' @field status Defines product's status character [optional]
#' @field condition The human-readable label for the condition (e.g., \"New\"). character [optional]
#' @field visible Set visibility status character [optional]
#' @field in_stock Set stock status. Effective only when manage_stock is false — when stock is managed, the status is derived from quantity automatically and this parameter is ignored. character [optional]
#' @field avail Defines category's visibility status character [optional]
#' @field avail_from Allows to schedule a time in the future that the item becomes available. The value should be greater than the current date and time. character [optional]
#' @field product_class A categorization for the product character [optional]
#' @field brand_name Retrieves brands specified by brand name character [optional]
#' @field available_for_view Specifies the set of visible/invisible products for users character [optional]
#' @field measure_unit Unit for the price per unit. Must be in allowed list character [optional]
#' @field unit_price Defines new product's unit price numeric [optional]
#' @field stores_ids Assign product to the stores that is specified by comma-separated stores' id character [optional]
#' @field store_id Defines store id where the product should be found character [optional]
#' @field lang_id Language id character [optional]
#' @field quantity Defines new product's quantity. Effective only when manage_stock is true — otherwise the value is ignored. To enable stock tracking and set a quantity in one call, pass manage_stock=true together with quantity. numeric [optional]
#' @field reserve_quantity This parameter allows to reserve/unreserve product quantity. numeric [optional]
#' @field manage_stock Defines inventory tracking for product. When true, quantity sets the stock level and the stock status is derived from it; when false, quantity is ignored and in_stock sets the status directly. character [optional]
#' @field backorder_status Set backorder status character [optional]
#' @field increase_quantity Defines the incremental changes in product quantity. Effective only when manage_stock is true — otherwise the value is ignored. numeric [optional]
#' @field reduce_quantity Defines the decrement changes in product quantity. Effective only when manage_stock is true — otherwise the value is ignored. numeric [optional]
#' @field low_stock_threshold Specify the quantity threshold below which the product is considered low in stock numeric [optional]
#' @field min_order_quantity The minimum quantity an order must contain, to be eligible to purchase this product. numeric [optional]
#' @field max_order_quantity The maximum quantity an order can contain when purchasing the product. numeric [optional]
#' @field warehouse_id This parameter is used for selecting a warehouse where you need to set/modify a product quantity. character [optional]
#' @field weight Weight numeric [optional]
#' @field weight_unit Weight Unit character [optional]
#' @field height Defines product's height numeric [optional]
#' @field length Defines product's length numeric [optional]
#' @field width Defines product's width numeric [optional]
#' @field dimensions_unit Weight Unit character [optional]
#' @field is_virtual Defines whether the product is virtual character [optional]
#' @field is_free_shipping Specifies product free shipping flag that has to be updated character [optional]
#' @field gtin Global Trade Item Number. An GTIN is an identifier for trade items. character [optional]
#' @field upc Universal Product Code. A UPC (UPC-A) is a commonly used identifer for many different products. character [optional]
#' @field mpn Manufacturer Part Number. A MPN is an identifier of a particular part design or material used. character [optional]
#' @field ean European Article Number. An EAN is a unique 8 or 13-digit identifier that many industries (such as book publishers) use to identify products. character [optional]
#' @field isbn International Standard Book Number. An ISBN is a unique identifier for books. character [optional]
#' @field barcode A barcode is a unique code composed of numbers used as a product identifier. character [optional]
#' @field manufacturer Defines product's manufacturer character [optional]
#' @field manufacturer_id Defines product's manufacturer by manufacturer_id character [optional]
#' @field vendor_id Vendor Id character [optional]
#' @field categories_ids Defines product add that is specified by comma-separated categories id character [optional]
#' @field related_products_ids Defines product related products ids that has to be updated character [optional]
#' @field up_sell_products_ids Defines product up-sell products ids that has to be updated character [optional]
#' @field cross_sell_products_ids Defines product cross-sells products ids that has to be updated character [optional]
#' @field meta_title Defines unique meta title for each entity character [optional]
#' @field meta_keywords Defines unique meta keywords for each entity character [optional]
#' @field meta_description Defines unique meta description of a entity character [optional]
#' @field seo_url Defines unique URL for SEO character [optional]
#' @field search_keywords Defines unique search keywords character [optional]
#' @field tags Product tags character [optional]
#' @field delivery_code The delivery promise that applies to offer character [optional]
#' @field package_details  \link{ProductAddPackageDetails} [optional]
#' @field country_of_origin The country where the inventory item was made character [optional]
#' @field harmonized_system_code Harmonized System Code. An HSC is a 6-digit identifier that allows participating countries to classify traded goods on a common basis for customs purposes character [optional]
#' @field shipping_template_id The numeric ID of the shipping template associated with the products in Etsy. You can find possible values in the \"cart.info\" API method response, in the field shipping_zones[]->id. integer [optional]
#' @field processing_profile_id The numeric ID of the processing profile (readiness state) for physical products in Etsy. You can find possible values in the \"cart.info\" API method response, in the field processing_profiles[]->readiness_state_id. integer [optional]
#' @field when_made An enumerated string for the era in which the maker made the product. character [optional]
#' @field is_supply If true, it indicates the product as a supply, otherwise it indicates that it is a finished product. character [optional]
#' @field downloadable Defines whether the product is downloadable character [optional]
#' @field materials A list of material strings for materials used in the product. list(character) [optional]
#' @field auto_renew When true, automatically renews a listing upon its expiration. character [optional]
#' @field on_sale Set whether the product on sale character [optional]
#' @field production_partner_ids Defines product production partner ids that has to be updated character [optional]
#' @field manufacturer_info  \link{ProductAddManufacturerInfo} [optional]
#' @field report_request_id Report request id character [optional]
#' @field disable_report_cache Disable report cache for current request character [optional]
#' @field reindex Is reindex required character [optional]
#' @field clear_cache Is cache clear required character [optional]
#' @field check_process_status Disable or enable check process status. Please note that the response will be slower due to additional requests to the store. character [optional]
#' @field specifics An array of Item Specific Name/Value pairs used by the seller to provide descriptive details of an item in a structured manner.         The list of possible specifications can be obtained using the category.info method (additional_fields->product_specifics).         <b>The structure of the parameter is different for specific platforms.</b> list(\link{ProductAddSpecificsInner}) [optional]
#' @field shop_section_id Add Shop Section Id integer [optional]
#' @field personalization_details  \link{ProductAddPersonalizationDetails} [optional]
#' @field personalization_questions Defines personalization questions for the listing as an array of question objects. Each question object supports the following fields: question_id (integer, nullable), question_text (string, 1-45 chars), instructions (string, nullable), question_type (string), required (boolean), max_allowed_characters (integer, nullable), max_allowed_files (integer, nullable), options (array, nullable). Cannot be used together with <strong>personalization_details</strong>. list(\link{ProductAddPersonalizationQuestionsInner}) [optional]
#' @field external_product_link External product link character [optional]
#' @field marketplace_item_properties String containing the JSON representation of the supplied data character [optional]
#' @field manufacturer_ids A comma-separated list of manufacturer IDs. Retrieve the IDs from the cart.info method. character [optional]
#' @field responsible_person_ids A comma-separated list of responsible person IDs. Retrieve the IDs from the cart.info method. character [optional]
#' @field idempotency_key A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong> character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductUpdate <- R6::R6Class(
  "ProductUpdate",
  public = list(
    `id` = NULL,
    `model` = NULL,
    `sku` = NULL,
    `name` = NULL,
    `description` = NULL,
    `short_description` = NULL,
    `prices_inc_tax` = NULL,
    `price` = NULL,
    `old_price` = NULL,
    `special_price` = NULL,
    `sprice_create` = NULL,
    `sprice_expire` = NULL,
    `cost_price` = NULL,
    `fixed_cost_shipping_price` = NULL,
    `retail_price` = NULL,
    `tier_prices` = NULL,
    `reserve_price` = NULL,
    `buyitnow_price` = NULL,
    `taxable` = NULL,
    `tax_class_id` = NULL,
    `type` = NULL,
    `status` = NULL,
    `condition` = NULL,
    `visible` = NULL,
    `in_stock` = NULL,
    `avail` = NULL,
    `avail_from` = NULL,
    `product_class` = NULL,
    `brand_name` = NULL,
    `available_for_view` = NULL,
    `measure_unit` = NULL,
    `unit_price` = NULL,
    `stores_ids` = NULL,
    `store_id` = NULL,
    `lang_id` = NULL,
    `quantity` = NULL,
    `reserve_quantity` = NULL,
    `manage_stock` = NULL,
    `backorder_status` = NULL,
    `increase_quantity` = NULL,
    `reduce_quantity` = NULL,
    `low_stock_threshold` = NULL,
    `min_order_quantity` = NULL,
    `max_order_quantity` = NULL,
    `warehouse_id` = NULL,
    `weight` = NULL,
    `weight_unit` = NULL,
    `height` = NULL,
    `length` = NULL,
    `width` = NULL,
    `dimensions_unit` = NULL,
    `is_virtual` = NULL,
    `is_free_shipping` = NULL,
    `gtin` = NULL,
    `upc` = NULL,
    `mpn` = NULL,
    `ean` = NULL,
    `isbn` = NULL,
    `barcode` = NULL,
    `manufacturer` = NULL,
    `manufacturer_id` = NULL,
    `vendor_id` = NULL,
    `categories_ids` = NULL,
    `related_products_ids` = NULL,
    `up_sell_products_ids` = NULL,
    `cross_sell_products_ids` = NULL,
    `meta_title` = NULL,
    `meta_keywords` = NULL,
    `meta_description` = NULL,
    `seo_url` = NULL,
    `search_keywords` = NULL,
    `tags` = NULL,
    `delivery_code` = NULL,
    `package_details` = NULL,
    `country_of_origin` = NULL,
    `harmonized_system_code` = NULL,
    `shipping_template_id` = NULL,
    `processing_profile_id` = NULL,
    `when_made` = NULL,
    `is_supply` = NULL,
    `downloadable` = NULL,
    `materials` = NULL,
    `auto_renew` = NULL,
    `on_sale` = NULL,
    `production_partner_ids` = NULL,
    `manufacturer_info` = NULL,
    `report_request_id` = NULL,
    `disable_report_cache` = NULL,
    `reindex` = NULL,
    `clear_cache` = NULL,
    `check_process_status` = NULL,
    `specifics` = NULL,
    `shop_section_id` = NULL,
    `personalization_details` = NULL,
    `personalization_questions` = NULL,
    `external_product_link` = NULL,
    `marketplace_item_properties` = NULL,
    `manufacturer_ids` = NULL,
    `responsible_person_ids` = NULL,
    `idempotency_key` = NULL,

    #' @description
    #' Initialize a new ProductUpdate class.
    #'
    #' @param id Defines product id that has to be updated
    #' @param model Defines product model that has to be updated
    #' @param sku Defines new product's sku
    #' @param name Defines product's name that has to be updated
    #' @param description Defines new product's description
    #' @param short_description Defines short description
    #' @param prices_inc_tax Indicates whether prices include tax.. Default to FALSE.
    #' @param price Defines new product's price
    #' @param old_price Defines product's old price
    #' @param special_price Defines new product's special price
    #' @param sprice_create Defines the date of special price creation
    #' @param sprice_expire Defines the term of special price offer duration
    #' @param cost_price Defines new product's cost price
    #' @param fixed_cost_shipping_price Specifies product's fixed cost shipping price
    #' @param retail_price Defines new product's retail price
    #' @param tier_prices Defines product's tier prices
    #' @param reserve_price Defines reserve price value
    #' @param buyitnow_price Defines buy it now value
    #' @param taxable Specifies whether a tax is charged
    #' @param tax_class_id Defines tax classes where entity has to be added
    #' @param type Defines product's type
    #' @param status Defines product's status
    #' @param condition The human-readable label for the condition (e.g., \"New\").
    #' @param visible Set visibility status
    #' @param in_stock Set stock status. Effective only when manage_stock is false — when stock is managed, the status is derived from quantity automatically and this parameter is ignored.
    #' @param avail Defines category's visibility status. Default to TRUE.
    #' @param avail_from Allows to schedule a time in the future that the item becomes available. The value should be greater than the current date and time.
    #' @param product_class A categorization for the product
    #' @param brand_name Retrieves brands specified by brand name
    #' @param available_for_view Specifies the set of visible/invisible products for users
    #' @param measure_unit Unit for the price per unit. Must be in allowed list
    #' @param unit_price Defines new product's unit price
    #' @param stores_ids Assign product to the stores that is specified by comma-separated stores' id
    #' @param store_id Defines store id where the product should be found
    #' @param lang_id Language id
    #' @param quantity Defines new product's quantity. Effective only when manage_stock is true — otherwise the value is ignored. To enable stock tracking and set a quantity in one call, pass manage_stock=true together with quantity.
    #' @param reserve_quantity This parameter allows to reserve/unreserve product quantity.
    #' @param manage_stock Defines inventory tracking for product. When true, quantity sets the stock level and the stock status is derived from it; when false, quantity is ignored and in_stock sets the status directly.
    #' @param backorder_status Set backorder status
    #' @param increase_quantity Defines the incremental changes in product quantity. Effective only when manage_stock is true — otherwise the value is ignored.
    #' @param reduce_quantity Defines the decrement changes in product quantity. Effective only when manage_stock is true — otherwise the value is ignored.
    #' @param low_stock_threshold Specify the quantity threshold below which the product is considered low in stock
    #' @param min_order_quantity The minimum quantity an order must contain, to be eligible to purchase this product.
    #' @param max_order_quantity The maximum quantity an order can contain when purchasing the product.
    #' @param warehouse_id This parameter is used for selecting a warehouse where you need to set/modify a product quantity.
    #' @param weight Weight
    #' @param weight_unit Weight Unit
    #' @param height Defines product's height
    #' @param length Defines product's length
    #' @param width Defines product's width
    #' @param dimensions_unit Weight Unit
    #' @param is_virtual Defines whether the product is virtual. Default to FALSE.
    #' @param is_free_shipping Specifies product free shipping flag that has to be updated
    #' @param gtin Global Trade Item Number. An GTIN is an identifier for trade items.
    #' @param upc Universal Product Code. A UPC (UPC-A) is a commonly used identifer for many different products.
    #' @param mpn Manufacturer Part Number. A MPN is an identifier of a particular part design or material used.
    #' @param ean European Article Number. An EAN is a unique 8 or 13-digit identifier that many industries (such as book publishers) use to identify products.
    #' @param isbn International Standard Book Number. An ISBN is a unique identifier for books.
    #' @param barcode A barcode is a unique code composed of numbers used as a product identifier.
    #' @param manufacturer Defines product's manufacturer
    #' @param manufacturer_id Defines product's manufacturer by manufacturer_id
    #' @param vendor_id Vendor Id
    #' @param categories_ids Defines product add that is specified by comma-separated categories id
    #' @param related_products_ids Defines product related products ids that has to be updated
    #' @param up_sell_products_ids Defines product up-sell products ids that has to be updated
    #' @param cross_sell_products_ids Defines product cross-sells products ids that has to be updated
    #' @param meta_title Defines unique meta title for each entity
    #' @param meta_keywords Defines unique meta keywords for each entity
    #' @param meta_description Defines unique meta description of a entity
    #' @param seo_url Defines unique URL for SEO
    #' @param search_keywords Defines unique search keywords
    #' @param tags Product tags
    #' @param delivery_code The delivery promise that applies to offer
    #' @param package_details package_details
    #' @param country_of_origin The country where the inventory item was made
    #' @param harmonized_system_code Harmonized System Code. An HSC is a 6-digit identifier that allows participating countries to classify traded goods on a common basis for customs purposes
    #' @param shipping_template_id The numeric ID of the shipping template associated with the products in Etsy. You can find possible values in the \"cart.info\" API method response, in the field shipping_zones[]->id.. Default to 0.
    #' @param processing_profile_id The numeric ID of the processing profile (readiness state) for physical products in Etsy. You can find possible values in the \"cart.info\" API method response, in the field processing_profiles[]->readiness_state_id.
    #' @param when_made An enumerated string for the era in which the maker made the product.. Default to "made_to_order".
    #' @param is_supply If true, it indicates the product as a supply, otherwise it indicates that it is a finished product.. Default to TRUE.
    #' @param downloadable Defines whether the product is downloadable. Default to FALSE.
    #' @param materials A list of material strings for materials used in the product.
    #' @param auto_renew When true, automatically renews a listing upon its expiration.. Default to FALSE.
    #' @param on_sale Set whether the product on sale. Default to FALSE.
    #' @param production_partner_ids Defines product production partner ids that has to be updated
    #' @param manufacturer_info manufacturer_info
    #' @param report_request_id Report request id
    #' @param disable_report_cache Disable report cache for current request. Default to FALSE.
    #' @param reindex Is reindex required. Default to TRUE.
    #' @param clear_cache Is cache clear required. Default to TRUE.
    #' @param check_process_status Disable or enable check process status. Please note that the response will be slower due to additional requests to the store.. Default to FALSE.
    #' @param specifics An array of Item Specific Name/Value pairs used by the seller to provide descriptive details of an item in a structured manner.         The list of possible specifications can be obtained using the category.info method (additional_fields->product_specifics).         <b>The structure of the parameter is different for specific platforms.</b>
    #' @param shop_section_id Add Shop Section Id
    #' @param personalization_details personalization_details
    #' @param personalization_questions Defines personalization questions for the listing as an array of question objects. Each question object supports the following fields: question_id (integer, nullable), question_text (string, 1-45 chars), instructions (string, nullable), question_type (string), required (boolean), max_allowed_characters (integer, nullable), max_allowed_files (integer, nullable), options (array, nullable). Cannot be used together with <strong>personalization_details</strong>.
    #' @param external_product_link External product link
    #' @param marketplace_item_properties String containing the JSON representation of the supplied data
    #' @param manufacturer_ids A comma-separated list of manufacturer IDs. Retrieve the IDs from the cart.info method.
    #' @param responsible_person_ids A comma-separated list of responsible person IDs. Retrieve the IDs from the cart.info method.
    #' @param idempotency_key A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong>
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `model` = NULL, `sku` = NULL, `name` = NULL, `description` = NULL, `short_description` = NULL, `prices_inc_tax` = FALSE, `price` = NULL, `old_price` = NULL, `special_price` = NULL, `sprice_create` = NULL, `sprice_expire` = NULL, `cost_price` = NULL, `fixed_cost_shipping_price` = NULL, `retail_price` = NULL, `tier_prices` = NULL, `reserve_price` = NULL, `buyitnow_price` = NULL, `taxable` = NULL, `tax_class_id` = NULL, `type` = NULL, `status` = NULL, `condition` = NULL, `visible` = NULL, `in_stock` = NULL, `avail` = TRUE, `avail_from` = NULL, `product_class` = NULL, `brand_name` = NULL, `available_for_view` = NULL, `measure_unit` = NULL, `unit_price` = NULL, `stores_ids` = NULL, `store_id` = NULL, `lang_id` = NULL, `quantity` = NULL, `reserve_quantity` = NULL, `manage_stock` = NULL, `backorder_status` = NULL, `increase_quantity` = NULL, `reduce_quantity` = NULL, `low_stock_threshold` = NULL, `min_order_quantity` = NULL, `max_order_quantity` = NULL, `warehouse_id` = NULL, `weight` = NULL, `weight_unit` = NULL, `height` = NULL, `length` = NULL, `width` = NULL, `dimensions_unit` = NULL, `is_virtual` = FALSE, `is_free_shipping` = NULL, `gtin` = NULL, `upc` = NULL, `mpn` = NULL, `ean` = NULL, `isbn` = NULL, `barcode` = NULL, `manufacturer` = NULL, `manufacturer_id` = NULL, `vendor_id` = NULL, `categories_ids` = NULL, `related_products_ids` = NULL, `up_sell_products_ids` = NULL, `cross_sell_products_ids` = NULL, `meta_title` = NULL, `meta_keywords` = NULL, `meta_description` = NULL, `seo_url` = NULL, `search_keywords` = NULL, `tags` = NULL, `delivery_code` = NULL, `package_details` = NULL, `country_of_origin` = NULL, `harmonized_system_code` = NULL, `shipping_template_id` = 0, `processing_profile_id` = NULL, `when_made` = "made_to_order", `is_supply` = TRUE, `downloadable` = FALSE, `materials` = NULL, `auto_renew` = FALSE, `on_sale` = FALSE, `production_partner_ids` = NULL, `manufacturer_info` = NULL, `report_request_id` = NULL, `disable_report_cache` = FALSE, `reindex` = TRUE, `clear_cache` = TRUE, `check_process_status` = FALSE, `specifics` = NULL, `shop_section_id` = NULL, `personalization_details` = NULL, `personalization_questions` = NULL, `external_product_link` = NULL, `marketplace_item_properties` = NULL, `manufacturer_ids` = NULL, `responsible_person_ids` = NULL, `idempotency_key` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`model`)) {
        if (!(is.character(`model`) && length(`model`) == 1)) {
          stop(paste("Error! Invalid data for `model`. Must be a string:", `model`))
        }
        self$`model` <- `model`
      }
      if (!is.null(`sku`)) {
        if (!(is.character(`sku`) && length(`sku`) == 1)) {
          stop(paste("Error! Invalid data for `sku`. Must be a string:", `sku`))
        }
        self$`sku` <- `sku`
      }
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`description`)) {
        if (!(is.character(`description`) && length(`description`) == 1)) {
          stop(paste("Error! Invalid data for `description`. Must be a string:", `description`))
        }
        self$`description` <- `description`
      }
      if (!is.null(`short_description`)) {
        if (!(is.character(`short_description`) && length(`short_description`) == 1)) {
          stop(paste("Error! Invalid data for `short_description`. Must be a string:", `short_description`))
        }
        self$`short_description` <- `short_description`
      }
      if (!is.null(`prices_inc_tax`)) {
        if (!(is.logical(`prices_inc_tax`) && length(`prices_inc_tax`) == 1)) {
          stop(paste("Error! Invalid data for `prices_inc_tax`. Must be a boolean:", `prices_inc_tax`))
        }
        self$`prices_inc_tax` <- `prices_inc_tax`
      }
      if (!is.null(`price`)) {
        self$`price` <- `price`
      }
      if (!is.null(`old_price`)) {
        self$`old_price` <- `old_price`
      }
      if (!is.null(`special_price`)) {
        self$`special_price` <- `special_price`
      }
      if (!is.null(`sprice_create`)) {
        if (!(is.character(`sprice_create`) && length(`sprice_create`) == 1)) {
          stop(paste("Error! Invalid data for `sprice_create`. Must be a string:", `sprice_create`))
        }
        self$`sprice_create` <- `sprice_create`
      }
      if (!is.null(`sprice_expire`)) {
        if (!(is.character(`sprice_expire`) && length(`sprice_expire`) == 1)) {
          stop(paste("Error! Invalid data for `sprice_expire`. Must be a string:", `sprice_expire`))
        }
        self$`sprice_expire` <- `sprice_expire`
      }
      if (!is.null(`cost_price`)) {
        self$`cost_price` <- `cost_price`
      }
      if (!is.null(`fixed_cost_shipping_price`)) {
        self$`fixed_cost_shipping_price` <- `fixed_cost_shipping_price`
      }
      if (!is.null(`retail_price`)) {
        self$`retail_price` <- `retail_price`
      }
      if (!is.null(`tier_prices`)) {
        stopifnot(is.vector(`tier_prices`), length(`tier_prices`) != 0)
        sapply(`tier_prices`, function(x) stopifnot(R6::is.R6(x)))
        self$`tier_prices` <- `tier_prices`
      }
      if (!is.null(`reserve_price`)) {
        self$`reserve_price` <- `reserve_price`
      }
      if (!is.null(`buyitnow_price`)) {
        self$`buyitnow_price` <- `buyitnow_price`
      }
      if (!is.null(`taxable`)) {
        if (!(is.logical(`taxable`) && length(`taxable`) == 1)) {
          stop(paste("Error! Invalid data for `taxable`. Must be a boolean:", `taxable`))
        }
        self$`taxable` <- `taxable`
      }
      if (!is.null(`tax_class_id`)) {
        if (!(is.character(`tax_class_id`) && length(`tax_class_id`) == 1)) {
          stop(paste("Error! Invalid data for `tax_class_id`. Must be a string:", `tax_class_id`))
        }
        self$`tax_class_id` <- `tax_class_id`
      }
      if (!is.null(`type`)) {
        if (!(is.character(`type`) && length(`type`) == 1)) {
          stop(paste("Error! Invalid data for `type`. Must be a string:", `type`))
        }
        self$`type` <- `type`
      }
      if (!is.null(`status`)) {
        if (!(is.character(`status`) && length(`status`) == 1)) {
          stop(paste("Error! Invalid data for `status`. Must be a string:", `status`))
        }
        self$`status` <- `status`
      }
      if (!is.null(`condition`)) {
        if (!(is.character(`condition`) && length(`condition`) == 1)) {
          stop(paste("Error! Invalid data for `condition`. Must be a string:", `condition`))
        }
        self$`condition` <- `condition`
      }
      if (!is.null(`visible`)) {
        if (!(is.character(`visible`) && length(`visible`) == 1)) {
          stop(paste("Error! Invalid data for `visible`. Must be a string:", `visible`))
        }
        self$`visible` <- `visible`
      }
      if (!is.null(`in_stock`)) {
        if (!(is.logical(`in_stock`) && length(`in_stock`) == 1)) {
          stop(paste("Error! Invalid data for `in_stock`. Must be a boolean:", `in_stock`))
        }
        self$`in_stock` <- `in_stock`
      }
      if (!is.null(`avail`)) {
        if (!(is.logical(`avail`) && length(`avail`) == 1)) {
          stop(paste("Error! Invalid data for `avail`. Must be a boolean:", `avail`))
        }
        self$`avail` <- `avail`
      }
      if (!is.null(`avail_from`)) {
        if (!(is.character(`avail_from`) && length(`avail_from`) == 1)) {
          stop(paste("Error! Invalid data for `avail_from`. Must be a string:", `avail_from`))
        }
        self$`avail_from` <- `avail_from`
      }
      if (!is.null(`product_class`)) {
        if (!(is.character(`product_class`) && length(`product_class`) == 1)) {
          stop(paste("Error! Invalid data for `product_class`. Must be a string:", `product_class`))
        }
        self$`product_class` <- `product_class`
      }
      if (!is.null(`brand_name`)) {
        if (!(is.character(`brand_name`) && length(`brand_name`) == 1)) {
          stop(paste("Error! Invalid data for `brand_name`. Must be a string:", `brand_name`))
        }
        self$`brand_name` <- `brand_name`
      }
      if (!is.null(`available_for_view`)) {
        if (!(is.logical(`available_for_view`) && length(`available_for_view`) == 1)) {
          stop(paste("Error! Invalid data for `available_for_view`. Must be a boolean:", `available_for_view`))
        }
        self$`available_for_view` <- `available_for_view`
      }
      if (!is.null(`measure_unit`)) {
        if (!(is.character(`measure_unit`) && length(`measure_unit`) == 1)) {
          stop(paste("Error! Invalid data for `measure_unit`. Must be a string:", `measure_unit`))
        }
        self$`measure_unit` <- `measure_unit`
      }
      if (!is.null(`unit_price`)) {
        self$`unit_price` <- `unit_price`
      }
      if (!is.null(`stores_ids`)) {
        if (!(is.character(`stores_ids`) && length(`stores_ids`) == 1)) {
          stop(paste("Error! Invalid data for `stores_ids`. Must be a string:", `stores_ids`))
        }
        self$`stores_ids` <- `stores_ids`
      }
      if (!is.null(`store_id`)) {
        if (!(is.character(`store_id`) && length(`store_id`) == 1)) {
          stop(paste("Error! Invalid data for `store_id`. Must be a string:", `store_id`))
        }
        self$`store_id` <- `store_id`
      }
      if (!is.null(`lang_id`)) {
        if (!(is.character(`lang_id`) && length(`lang_id`) == 1)) {
          stop(paste("Error! Invalid data for `lang_id`. Must be a string:", `lang_id`))
        }
        self$`lang_id` <- `lang_id`
      }
      if (!is.null(`quantity`)) {
        self$`quantity` <- `quantity`
      }
      if (!is.null(`reserve_quantity`)) {
        self$`reserve_quantity` <- `reserve_quantity`
      }
      if (!is.null(`manage_stock`)) {
        if (!(is.logical(`manage_stock`) && length(`manage_stock`) == 1)) {
          stop(paste("Error! Invalid data for `manage_stock`. Must be a boolean:", `manage_stock`))
        }
        self$`manage_stock` <- `manage_stock`
      }
      if (!is.null(`backorder_status`)) {
        if (!(is.character(`backorder_status`) && length(`backorder_status`) == 1)) {
          stop(paste("Error! Invalid data for `backorder_status`. Must be a string:", `backorder_status`))
        }
        self$`backorder_status` <- `backorder_status`
      }
      if (!is.null(`increase_quantity`)) {
        self$`increase_quantity` <- `increase_quantity`
      }
      if (!is.null(`reduce_quantity`)) {
        self$`reduce_quantity` <- `reduce_quantity`
      }
      if (!is.null(`low_stock_threshold`)) {
        self$`low_stock_threshold` <- `low_stock_threshold`
      }
      if (!is.null(`min_order_quantity`)) {
        self$`min_order_quantity` <- `min_order_quantity`
      }
      if (!is.null(`max_order_quantity`)) {
        self$`max_order_quantity` <- `max_order_quantity`
      }
      if (!is.null(`warehouse_id`)) {
        if (!(is.character(`warehouse_id`) && length(`warehouse_id`) == 1)) {
          stop(paste("Error! Invalid data for `warehouse_id`. Must be a string:", `warehouse_id`))
        }
        self$`warehouse_id` <- `warehouse_id`
      }
      if (!is.null(`weight`)) {
        self$`weight` <- `weight`
      }
      if (!is.null(`weight_unit`)) {
        if (!(is.character(`weight_unit`) && length(`weight_unit`) == 1)) {
          stop(paste("Error! Invalid data for `weight_unit`. Must be a string:", `weight_unit`))
        }
        self$`weight_unit` <- `weight_unit`
      }
      if (!is.null(`height`)) {
        self$`height` <- `height`
      }
      if (!is.null(`length`)) {
        self$`length` <- `length`
      }
      if (!is.null(`width`)) {
        self$`width` <- `width`
      }
      if (!is.null(`dimensions_unit`)) {
        if (!(is.character(`dimensions_unit`) && length(`dimensions_unit`) == 1)) {
          stop(paste("Error! Invalid data for `dimensions_unit`. Must be a string:", `dimensions_unit`))
        }
        self$`dimensions_unit` <- `dimensions_unit`
      }
      if (!is.null(`is_virtual`)) {
        if (!(is.logical(`is_virtual`) && length(`is_virtual`) == 1)) {
          stop(paste("Error! Invalid data for `is_virtual`. Must be a boolean:", `is_virtual`))
        }
        self$`is_virtual` <- `is_virtual`
      }
      if (!is.null(`is_free_shipping`)) {
        if (!(is.logical(`is_free_shipping`) && length(`is_free_shipping`) == 1)) {
          stop(paste("Error! Invalid data for `is_free_shipping`. Must be a boolean:", `is_free_shipping`))
        }
        self$`is_free_shipping` <- `is_free_shipping`
      }
      if (!is.null(`gtin`)) {
        if (!(is.character(`gtin`) && length(`gtin`) == 1)) {
          stop(paste("Error! Invalid data for `gtin`. Must be a string:", `gtin`))
        }
        self$`gtin` <- `gtin`
      }
      if (!is.null(`upc`)) {
        if (!(is.character(`upc`) && length(`upc`) == 1)) {
          stop(paste("Error! Invalid data for `upc`. Must be a string:", `upc`))
        }
        self$`upc` <- `upc`
      }
      if (!is.null(`mpn`)) {
        if (!(is.character(`mpn`) && length(`mpn`) == 1)) {
          stop(paste("Error! Invalid data for `mpn`. Must be a string:", `mpn`))
        }
        self$`mpn` <- `mpn`
      }
      if (!is.null(`ean`)) {
        if (!(is.character(`ean`) && length(`ean`) == 1)) {
          stop(paste("Error! Invalid data for `ean`. Must be a string:", `ean`))
        }
        self$`ean` <- `ean`
      }
      if (!is.null(`isbn`)) {
        if (!(is.character(`isbn`) && length(`isbn`) == 1)) {
          stop(paste("Error! Invalid data for `isbn`. Must be a string:", `isbn`))
        }
        self$`isbn` <- `isbn`
      }
      if (!is.null(`barcode`)) {
        if (!(is.character(`barcode`) && length(`barcode`) == 1)) {
          stop(paste("Error! Invalid data for `barcode`. Must be a string:", `barcode`))
        }
        self$`barcode` <- `barcode`
      }
      if (!is.null(`manufacturer`)) {
        if (!(is.character(`manufacturer`) && length(`manufacturer`) == 1)) {
          stop(paste("Error! Invalid data for `manufacturer`. Must be a string:", `manufacturer`))
        }
        self$`manufacturer` <- `manufacturer`
      }
      if (!is.null(`manufacturer_id`)) {
        if (!(is.character(`manufacturer_id`) && length(`manufacturer_id`) == 1)) {
          stop(paste("Error! Invalid data for `manufacturer_id`. Must be a string:", `manufacturer_id`))
        }
        self$`manufacturer_id` <- `manufacturer_id`
      }
      if (!is.null(`vendor_id`)) {
        if (!(is.character(`vendor_id`) && length(`vendor_id`) == 1)) {
          stop(paste("Error! Invalid data for `vendor_id`. Must be a string:", `vendor_id`))
        }
        self$`vendor_id` <- `vendor_id`
      }
      if (!is.null(`categories_ids`)) {
        if (!(is.character(`categories_ids`) && length(`categories_ids`) == 1)) {
          stop(paste("Error! Invalid data for `categories_ids`. Must be a string:", `categories_ids`))
        }
        self$`categories_ids` <- `categories_ids`
      }
      if (!is.null(`related_products_ids`)) {
        if (!(is.character(`related_products_ids`) && length(`related_products_ids`) == 1)) {
          stop(paste("Error! Invalid data for `related_products_ids`. Must be a string:", `related_products_ids`))
        }
        self$`related_products_ids` <- `related_products_ids`
      }
      if (!is.null(`up_sell_products_ids`)) {
        if (!(is.character(`up_sell_products_ids`) && length(`up_sell_products_ids`) == 1)) {
          stop(paste("Error! Invalid data for `up_sell_products_ids`. Must be a string:", `up_sell_products_ids`))
        }
        self$`up_sell_products_ids` <- `up_sell_products_ids`
      }
      if (!is.null(`cross_sell_products_ids`)) {
        if (!(is.character(`cross_sell_products_ids`) && length(`cross_sell_products_ids`) == 1)) {
          stop(paste("Error! Invalid data for `cross_sell_products_ids`. Must be a string:", `cross_sell_products_ids`))
        }
        self$`cross_sell_products_ids` <- `cross_sell_products_ids`
      }
      if (!is.null(`meta_title`)) {
        if (!(is.character(`meta_title`) && length(`meta_title`) == 1)) {
          stop(paste("Error! Invalid data for `meta_title`. Must be a string:", `meta_title`))
        }
        self$`meta_title` <- `meta_title`
      }
      if (!is.null(`meta_keywords`)) {
        if (!(is.character(`meta_keywords`) && length(`meta_keywords`) == 1)) {
          stop(paste("Error! Invalid data for `meta_keywords`. Must be a string:", `meta_keywords`))
        }
        self$`meta_keywords` <- `meta_keywords`
      }
      if (!is.null(`meta_description`)) {
        if (!(is.character(`meta_description`) && length(`meta_description`) == 1)) {
          stop(paste("Error! Invalid data for `meta_description`. Must be a string:", `meta_description`))
        }
        self$`meta_description` <- `meta_description`
      }
      if (!is.null(`seo_url`)) {
        if (!(is.character(`seo_url`) && length(`seo_url`) == 1)) {
          stop(paste("Error! Invalid data for `seo_url`. Must be a string:", `seo_url`))
        }
        self$`seo_url` <- `seo_url`
      }
      if (!is.null(`search_keywords`)) {
        if (!(is.character(`search_keywords`) && length(`search_keywords`) == 1)) {
          stop(paste("Error! Invalid data for `search_keywords`. Must be a string:", `search_keywords`))
        }
        self$`search_keywords` <- `search_keywords`
      }
      if (!is.null(`tags`)) {
        if (!(is.character(`tags`) && length(`tags`) == 1)) {
          stop(paste("Error! Invalid data for `tags`. Must be a string:", `tags`))
        }
        self$`tags` <- `tags`
      }
      if (!is.null(`delivery_code`)) {
        if (!(is.character(`delivery_code`) && length(`delivery_code`) == 1)) {
          stop(paste("Error! Invalid data for `delivery_code`. Must be a string:", `delivery_code`))
        }
        self$`delivery_code` <- `delivery_code`
      }
      if (!is.null(`package_details`)) {
        stopifnot(R6::is.R6(`package_details`))
        self$`package_details` <- `package_details`
      }
      if (!is.null(`country_of_origin`)) {
        if (!(is.character(`country_of_origin`) && length(`country_of_origin`) == 1)) {
          stop(paste("Error! Invalid data for `country_of_origin`. Must be a string:", `country_of_origin`))
        }
        self$`country_of_origin` <- `country_of_origin`
      }
      if (!is.null(`harmonized_system_code`)) {
        if (!(is.character(`harmonized_system_code`) && length(`harmonized_system_code`) == 1)) {
          stop(paste("Error! Invalid data for `harmonized_system_code`. Must be a string:", `harmonized_system_code`))
        }
        self$`harmonized_system_code` <- `harmonized_system_code`
      }
      if (!is.null(`shipping_template_id`)) {
        if (!(is.numeric(`shipping_template_id`) && length(`shipping_template_id`) == 1)) {
          stop(paste("Error! Invalid data for `shipping_template_id`. Must be an integer:", `shipping_template_id`))
        }
        self$`shipping_template_id` <- `shipping_template_id`
      }
      if (!is.null(`processing_profile_id`)) {
        if (!(is.numeric(`processing_profile_id`) && length(`processing_profile_id`) == 1)) {
          stop(paste("Error! Invalid data for `processing_profile_id`. Must be an integer:", `processing_profile_id`))
        }
        self$`processing_profile_id` <- `processing_profile_id`
      }
      if (!is.null(`when_made`)) {
        if (!(is.character(`when_made`) && length(`when_made`) == 1)) {
          stop(paste("Error! Invalid data for `when_made`. Must be a string:", `when_made`))
        }
        self$`when_made` <- `when_made`
      }
      if (!is.null(`is_supply`)) {
        if (!(is.logical(`is_supply`) && length(`is_supply`) == 1)) {
          stop(paste("Error! Invalid data for `is_supply`. Must be a boolean:", `is_supply`))
        }
        self$`is_supply` <- `is_supply`
      }
      if (!is.null(`downloadable`)) {
        if (!(is.logical(`downloadable`) && length(`downloadable`) == 1)) {
          stop(paste("Error! Invalid data for `downloadable`. Must be a boolean:", `downloadable`))
        }
        self$`downloadable` <- `downloadable`
      }
      if (!is.null(`materials`)) {
        stopifnot(is.vector(`materials`), length(`materials`) != 0)
        sapply(`materials`, function(x) stopifnot(is.character(x)))
        self$`materials` <- `materials`
      }
      if (!is.null(`auto_renew`)) {
        if (!(is.logical(`auto_renew`) && length(`auto_renew`) == 1)) {
          stop(paste("Error! Invalid data for `auto_renew`. Must be a boolean:", `auto_renew`))
        }
        self$`auto_renew` <- `auto_renew`
      }
      if (!is.null(`on_sale`)) {
        if (!(is.logical(`on_sale`) && length(`on_sale`) == 1)) {
          stop(paste("Error! Invalid data for `on_sale`. Must be a boolean:", `on_sale`))
        }
        self$`on_sale` <- `on_sale`
      }
      if (!is.null(`production_partner_ids`)) {
        if (!(is.character(`production_partner_ids`) && length(`production_partner_ids`) == 1)) {
          stop(paste("Error! Invalid data for `production_partner_ids`. Must be a string:", `production_partner_ids`))
        }
        self$`production_partner_ids` <- `production_partner_ids`
      }
      if (!is.null(`manufacturer_info`)) {
        stopifnot(R6::is.R6(`manufacturer_info`))
        self$`manufacturer_info` <- `manufacturer_info`
      }
      if (!is.null(`report_request_id`)) {
        if (!(is.character(`report_request_id`) && length(`report_request_id`) == 1)) {
          stop(paste("Error! Invalid data for `report_request_id`. Must be a string:", `report_request_id`))
        }
        self$`report_request_id` <- `report_request_id`
      }
      if (!is.null(`disable_report_cache`)) {
        if (!(is.logical(`disable_report_cache`) && length(`disable_report_cache`) == 1)) {
          stop(paste("Error! Invalid data for `disable_report_cache`. Must be a boolean:", `disable_report_cache`))
        }
        self$`disable_report_cache` <- `disable_report_cache`
      }
      if (!is.null(`reindex`)) {
        if (!(is.logical(`reindex`) && length(`reindex`) == 1)) {
          stop(paste("Error! Invalid data for `reindex`. Must be a boolean:", `reindex`))
        }
        self$`reindex` <- `reindex`
      }
      if (!is.null(`clear_cache`)) {
        if (!(is.logical(`clear_cache`) && length(`clear_cache`) == 1)) {
          stop(paste("Error! Invalid data for `clear_cache`. Must be a boolean:", `clear_cache`))
        }
        self$`clear_cache` <- `clear_cache`
      }
      if (!is.null(`check_process_status`)) {
        if (!(is.logical(`check_process_status`) && length(`check_process_status`) == 1)) {
          stop(paste("Error! Invalid data for `check_process_status`. Must be a boolean:", `check_process_status`))
        }
        self$`check_process_status` <- `check_process_status`
      }
      if (!is.null(`specifics`)) {
        stopifnot(is.vector(`specifics`), length(`specifics`) != 0)
        sapply(`specifics`, function(x) stopifnot(R6::is.R6(x)))
        self$`specifics` <- `specifics`
      }
      if (!is.null(`shop_section_id`)) {
        if (!(is.numeric(`shop_section_id`) && length(`shop_section_id`) == 1)) {
          stop(paste("Error! Invalid data for `shop_section_id`. Must be an integer:", `shop_section_id`))
        }
        self$`shop_section_id` <- `shop_section_id`
      }
      if (!is.null(`personalization_details`)) {
        stopifnot(R6::is.R6(`personalization_details`))
        self$`personalization_details` <- `personalization_details`
      }
      if (!is.null(`personalization_questions`)) {
        stopifnot(is.vector(`personalization_questions`), length(`personalization_questions`) != 0)
        sapply(`personalization_questions`, function(x) stopifnot(R6::is.R6(x)))
        self$`personalization_questions` <- `personalization_questions`
      }
      if (!is.null(`external_product_link`)) {
        if (!(is.character(`external_product_link`) && length(`external_product_link`) == 1)) {
          stop(paste("Error! Invalid data for `external_product_link`. Must be a string:", `external_product_link`))
        }
        self$`external_product_link` <- `external_product_link`
      }
      if (!is.null(`marketplace_item_properties`)) {
        if (!(is.character(`marketplace_item_properties`) && length(`marketplace_item_properties`) == 1)) {
          stop(paste("Error! Invalid data for `marketplace_item_properties`. Must be a string:", `marketplace_item_properties`))
        }
        self$`marketplace_item_properties` <- `marketplace_item_properties`
      }
      if (!is.null(`manufacturer_ids`)) {
        if (!(is.character(`manufacturer_ids`) && length(`manufacturer_ids`) == 1)) {
          stop(paste("Error! Invalid data for `manufacturer_ids`. Must be a string:", `manufacturer_ids`))
        }
        self$`manufacturer_ids` <- `manufacturer_ids`
      }
      if (!is.null(`responsible_person_ids`)) {
        if (!(is.character(`responsible_person_ids`) && length(`responsible_person_ids`) == 1)) {
          stop(paste("Error! Invalid data for `responsible_person_ids`. Must be a string:", `responsible_person_ids`))
        }
        self$`responsible_person_ids` <- `responsible_person_ids`
      }
      if (!is.null(`idempotency_key`)) {
        if (!(is.character(`idempotency_key`) && length(`idempotency_key`) == 1)) {
          stop(paste("Error! Invalid data for `idempotency_key`. Must be a string:", `idempotency_key`))
        }
        self$`idempotency_key` <- `idempotency_key`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductUpdate as a base R list.
    #' @examples
    #' # convert array of ProductUpdate (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductUpdate to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductUpdateObject <- list()
      if (!is.null(self$`id`)) {
        ProductUpdateObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`model`)) {
        ProductUpdateObject[["model"]] <-
          self$`model`
      }
      if (!is.null(self$`sku`)) {
        ProductUpdateObject[["sku"]] <-
          self$`sku`
      }
      if (!is.null(self$`name`)) {
        ProductUpdateObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`description`)) {
        ProductUpdateObject[["description"]] <-
          self$`description`
      }
      if (!is.null(self$`short_description`)) {
        ProductUpdateObject[["short_description"]] <-
          self$`short_description`
      }
      if (!is.null(self$`prices_inc_tax`)) {
        ProductUpdateObject[["prices_inc_tax"]] <-
          self$`prices_inc_tax`
      }
      if (!is.null(self$`price`)) {
        ProductUpdateObject[["price"]] <-
          self$`price`
      }
      if (!is.null(self$`old_price`)) {
        ProductUpdateObject[["old_price"]] <-
          self$`old_price`
      }
      if (!is.null(self$`special_price`)) {
        ProductUpdateObject[["special_price"]] <-
          self$`special_price`
      }
      if (!is.null(self$`sprice_create`)) {
        ProductUpdateObject[["sprice_create"]] <-
          self$`sprice_create`
      }
      if (!is.null(self$`sprice_expire`)) {
        ProductUpdateObject[["sprice_expire"]] <-
          self$`sprice_expire`
      }
      if (!is.null(self$`cost_price`)) {
        ProductUpdateObject[["cost_price"]] <-
          self$`cost_price`
      }
      if (!is.null(self$`fixed_cost_shipping_price`)) {
        ProductUpdateObject[["fixed_cost_shipping_price"]] <-
          self$`fixed_cost_shipping_price`
      }
      if (!is.null(self$`retail_price`)) {
        ProductUpdateObject[["retail_price"]] <-
          self$`retail_price`
      }
      if (!is.null(self$`tier_prices`)) {
        ProductUpdateObject[["tier_prices"]] <-
          lapply(self$`tier_prices`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`reserve_price`)) {
        ProductUpdateObject[["reserve_price"]] <-
          self$`reserve_price`
      }
      if (!is.null(self$`buyitnow_price`)) {
        ProductUpdateObject[["buyitnow_price"]] <-
          self$`buyitnow_price`
      }
      if (!is.null(self$`taxable`)) {
        ProductUpdateObject[["taxable"]] <-
          self$`taxable`
      }
      if (!is.null(self$`tax_class_id`)) {
        ProductUpdateObject[["tax_class_id"]] <-
          self$`tax_class_id`
      }
      if (!is.null(self$`type`)) {
        ProductUpdateObject[["type"]] <-
          self$`type`
      }
      if (!is.null(self$`status`)) {
        ProductUpdateObject[["status"]] <-
          self$`status`
      }
      if (!is.null(self$`condition`)) {
        ProductUpdateObject[["condition"]] <-
          self$`condition`
      }
      if (!is.null(self$`visible`)) {
        ProductUpdateObject[["visible"]] <-
          self$`visible`
      }
      if (!is.null(self$`in_stock`)) {
        ProductUpdateObject[["in_stock"]] <-
          self$`in_stock`
      }
      if (!is.null(self$`avail`)) {
        ProductUpdateObject[["avail"]] <-
          self$`avail`
      }
      if (!is.null(self$`avail_from`)) {
        ProductUpdateObject[["avail_from"]] <-
          self$`avail_from`
      }
      if (!is.null(self$`product_class`)) {
        ProductUpdateObject[["product_class"]] <-
          self$`product_class`
      }
      if (!is.null(self$`brand_name`)) {
        ProductUpdateObject[["brand_name"]] <-
          self$`brand_name`
      }
      if (!is.null(self$`available_for_view`)) {
        ProductUpdateObject[["available_for_view"]] <-
          self$`available_for_view`
      }
      if (!is.null(self$`measure_unit`)) {
        ProductUpdateObject[["measure_unit"]] <-
          self$`measure_unit`
      }
      if (!is.null(self$`unit_price`)) {
        ProductUpdateObject[["unit_price"]] <-
          self$`unit_price`
      }
      if (!is.null(self$`stores_ids`)) {
        ProductUpdateObject[["stores_ids"]] <-
          self$`stores_ids`
      }
      if (!is.null(self$`store_id`)) {
        ProductUpdateObject[["store_id"]] <-
          self$`store_id`
      }
      if (!is.null(self$`lang_id`)) {
        ProductUpdateObject[["lang_id"]] <-
          self$`lang_id`
      }
      if (!is.null(self$`quantity`)) {
        ProductUpdateObject[["quantity"]] <-
          self$`quantity`
      }
      if (!is.null(self$`reserve_quantity`)) {
        ProductUpdateObject[["reserve_quantity"]] <-
          self$`reserve_quantity`
      }
      if (!is.null(self$`manage_stock`)) {
        ProductUpdateObject[["manage_stock"]] <-
          self$`manage_stock`
      }
      if (!is.null(self$`backorder_status`)) {
        ProductUpdateObject[["backorder_status"]] <-
          self$`backorder_status`
      }
      if (!is.null(self$`increase_quantity`)) {
        ProductUpdateObject[["increase_quantity"]] <-
          self$`increase_quantity`
      }
      if (!is.null(self$`reduce_quantity`)) {
        ProductUpdateObject[["reduce_quantity"]] <-
          self$`reduce_quantity`
      }
      if (!is.null(self$`low_stock_threshold`)) {
        ProductUpdateObject[["low_stock_threshold"]] <-
          self$`low_stock_threshold`
      }
      if (!is.null(self$`min_order_quantity`)) {
        ProductUpdateObject[["min_order_quantity"]] <-
          self$`min_order_quantity`
      }
      if (!is.null(self$`max_order_quantity`)) {
        ProductUpdateObject[["max_order_quantity"]] <-
          self$`max_order_quantity`
      }
      if (!is.null(self$`warehouse_id`)) {
        ProductUpdateObject[["warehouse_id"]] <-
          self$`warehouse_id`
      }
      if (!is.null(self$`weight`)) {
        ProductUpdateObject[["weight"]] <-
          self$`weight`
      }
      if (!is.null(self$`weight_unit`)) {
        ProductUpdateObject[["weight_unit"]] <-
          self$`weight_unit`
      }
      if (!is.null(self$`height`)) {
        ProductUpdateObject[["height"]] <-
          self$`height`
      }
      if (!is.null(self$`length`)) {
        ProductUpdateObject[["length"]] <-
          self$`length`
      }
      if (!is.null(self$`width`)) {
        ProductUpdateObject[["width"]] <-
          self$`width`
      }
      if (!is.null(self$`dimensions_unit`)) {
        ProductUpdateObject[["dimensions_unit"]] <-
          self$`dimensions_unit`
      }
      if (!is.null(self$`is_virtual`)) {
        ProductUpdateObject[["is_virtual"]] <-
          self$`is_virtual`
      }
      if (!is.null(self$`is_free_shipping`)) {
        ProductUpdateObject[["is_free_shipping"]] <-
          self$`is_free_shipping`
      }
      if (!is.null(self$`gtin`)) {
        ProductUpdateObject[["gtin"]] <-
          self$`gtin`
      }
      if (!is.null(self$`upc`)) {
        ProductUpdateObject[["upc"]] <-
          self$`upc`
      }
      if (!is.null(self$`mpn`)) {
        ProductUpdateObject[["mpn"]] <-
          self$`mpn`
      }
      if (!is.null(self$`ean`)) {
        ProductUpdateObject[["ean"]] <-
          self$`ean`
      }
      if (!is.null(self$`isbn`)) {
        ProductUpdateObject[["isbn"]] <-
          self$`isbn`
      }
      if (!is.null(self$`barcode`)) {
        ProductUpdateObject[["barcode"]] <-
          self$`barcode`
      }
      if (!is.null(self$`manufacturer`)) {
        ProductUpdateObject[["manufacturer"]] <-
          self$`manufacturer`
      }
      if (!is.null(self$`manufacturer_id`)) {
        ProductUpdateObject[["manufacturer_id"]] <-
          self$`manufacturer_id`
      }
      if (!is.null(self$`vendor_id`)) {
        ProductUpdateObject[["vendor_id"]] <-
          self$`vendor_id`
      }
      if (!is.null(self$`categories_ids`)) {
        ProductUpdateObject[["categories_ids"]] <-
          self$`categories_ids`
      }
      if (!is.null(self$`related_products_ids`)) {
        ProductUpdateObject[["related_products_ids"]] <-
          self$`related_products_ids`
      }
      if (!is.null(self$`up_sell_products_ids`)) {
        ProductUpdateObject[["up_sell_products_ids"]] <-
          self$`up_sell_products_ids`
      }
      if (!is.null(self$`cross_sell_products_ids`)) {
        ProductUpdateObject[["cross_sell_products_ids"]] <-
          self$`cross_sell_products_ids`
      }
      if (!is.null(self$`meta_title`)) {
        ProductUpdateObject[["meta_title"]] <-
          self$`meta_title`
      }
      if (!is.null(self$`meta_keywords`)) {
        ProductUpdateObject[["meta_keywords"]] <-
          self$`meta_keywords`
      }
      if (!is.null(self$`meta_description`)) {
        ProductUpdateObject[["meta_description"]] <-
          self$`meta_description`
      }
      if (!is.null(self$`seo_url`)) {
        ProductUpdateObject[["seo_url"]] <-
          self$`seo_url`
      }
      if (!is.null(self$`search_keywords`)) {
        ProductUpdateObject[["search_keywords"]] <-
          self$`search_keywords`
      }
      if (!is.null(self$`tags`)) {
        ProductUpdateObject[["tags"]] <-
          self$`tags`
      }
      if (!is.null(self$`delivery_code`)) {
        ProductUpdateObject[["delivery_code"]] <-
          self$`delivery_code`
      }
      if (!is.null(self$`package_details`)) {
        ProductUpdateObject[["package_details"]] <-
          self$`package_details`$toSimpleType()
      }
      if (!is.null(self$`country_of_origin`)) {
        ProductUpdateObject[["country_of_origin"]] <-
          self$`country_of_origin`
      }
      if (!is.null(self$`harmonized_system_code`)) {
        ProductUpdateObject[["harmonized_system_code"]] <-
          self$`harmonized_system_code`
      }
      if (!is.null(self$`shipping_template_id`)) {
        ProductUpdateObject[["shipping_template_id"]] <-
          self$`shipping_template_id`
      }
      if (!is.null(self$`processing_profile_id`)) {
        ProductUpdateObject[["processing_profile_id"]] <-
          self$`processing_profile_id`
      }
      if (!is.null(self$`when_made`)) {
        ProductUpdateObject[["when_made"]] <-
          self$`when_made`
      }
      if (!is.null(self$`is_supply`)) {
        ProductUpdateObject[["is_supply"]] <-
          self$`is_supply`
      }
      if (!is.null(self$`downloadable`)) {
        ProductUpdateObject[["downloadable"]] <-
          self$`downloadable`
      }
      if (!is.null(self$`materials`)) {
        ProductUpdateObject[["materials"]] <-
          self$`materials`
      }
      if (!is.null(self$`auto_renew`)) {
        ProductUpdateObject[["auto_renew"]] <-
          self$`auto_renew`
      }
      if (!is.null(self$`on_sale`)) {
        ProductUpdateObject[["on_sale"]] <-
          self$`on_sale`
      }
      if (!is.null(self$`production_partner_ids`)) {
        ProductUpdateObject[["production_partner_ids"]] <-
          self$`production_partner_ids`
      }
      if (!is.null(self$`manufacturer_info`)) {
        ProductUpdateObject[["manufacturer_info"]] <-
          self$`manufacturer_info`$toSimpleType()
      }
      if (!is.null(self$`report_request_id`)) {
        ProductUpdateObject[["report_request_id"]] <-
          self$`report_request_id`
      }
      if (!is.null(self$`disable_report_cache`)) {
        ProductUpdateObject[["disable_report_cache"]] <-
          self$`disable_report_cache`
      }
      if (!is.null(self$`reindex`)) {
        ProductUpdateObject[["reindex"]] <-
          self$`reindex`
      }
      if (!is.null(self$`clear_cache`)) {
        ProductUpdateObject[["clear_cache"]] <-
          self$`clear_cache`
      }
      if (!is.null(self$`check_process_status`)) {
        ProductUpdateObject[["check_process_status"]] <-
          self$`check_process_status`
      }
      if (!is.null(self$`specifics`)) {
        ProductUpdateObject[["specifics"]] <-
          lapply(self$`specifics`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`shop_section_id`)) {
        ProductUpdateObject[["shop_section_id"]] <-
          self$`shop_section_id`
      }
      if (!is.null(self$`personalization_details`)) {
        ProductUpdateObject[["personalization_details"]] <-
          self$`personalization_details`$toSimpleType()
      }
      if (!is.null(self$`personalization_questions`)) {
        ProductUpdateObject[["personalization_questions"]] <-
          lapply(self$`personalization_questions`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`external_product_link`)) {
        ProductUpdateObject[["external_product_link"]] <-
          self$`external_product_link`
      }
      if (!is.null(self$`marketplace_item_properties`)) {
        ProductUpdateObject[["marketplace_item_properties"]] <-
          self$`marketplace_item_properties`
      }
      if (!is.null(self$`manufacturer_ids`)) {
        ProductUpdateObject[["manufacturer_ids"]] <-
          self$`manufacturer_ids`
      }
      if (!is.null(self$`responsible_person_ids`)) {
        ProductUpdateObject[["responsible_person_ids"]] <-
          self$`responsible_person_ids`
      }
      if (!is.null(self$`idempotency_key`)) {
        ProductUpdateObject[["idempotency_key"]] <-
          self$`idempotency_key`
      }
      return(ProductUpdateObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductUpdate
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductUpdate
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`model`)) {
        self$`model` <- this_object$`model`
      }
      if (!is.null(this_object$`sku`)) {
        self$`sku` <- this_object$`sku`
      }
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`description`)) {
        self$`description` <- this_object$`description`
      }
      if (!is.null(this_object$`short_description`)) {
        self$`short_description` <- this_object$`short_description`
      }
      if (!is.null(this_object$`prices_inc_tax`)) {
        self$`prices_inc_tax` <- this_object$`prices_inc_tax`
      }
      if (!is.null(this_object$`price`)) {
        self$`price` <- this_object$`price`
      }
      if (!is.null(this_object$`old_price`)) {
        self$`old_price` <- this_object$`old_price`
      }
      if (!is.null(this_object$`special_price`)) {
        self$`special_price` <- this_object$`special_price`
      }
      if (!is.null(this_object$`sprice_create`)) {
        self$`sprice_create` <- this_object$`sprice_create`
      }
      if (!is.null(this_object$`sprice_expire`)) {
        self$`sprice_expire` <- this_object$`sprice_expire`
      }
      if (!is.null(this_object$`cost_price`)) {
        self$`cost_price` <- this_object$`cost_price`
      }
      if (!is.null(this_object$`fixed_cost_shipping_price`)) {
        self$`fixed_cost_shipping_price` <- this_object$`fixed_cost_shipping_price`
      }
      if (!is.null(this_object$`retail_price`)) {
        self$`retail_price` <- this_object$`retail_price`
      }
      if (!is.null(this_object$`tier_prices`)) {
        self$`tier_prices` <- ApiClient$new()$deserializeObj(this_object$`tier_prices`, "array[ProductAddTierPricesInner]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`reserve_price`)) {
        self$`reserve_price` <- this_object$`reserve_price`
      }
      if (!is.null(this_object$`buyitnow_price`)) {
        self$`buyitnow_price` <- this_object$`buyitnow_price`
      }
      if (!is.null(this_object$`taxable`)) {
        self$`taxable` <- this_object$`taxable`
      }
      if (!is.null(this_object$`tax_class_id`)) {
        self$`tax_class_id` <- this_object$`tax_class_id`
      }
      if (!is.null(this_object$`type`)) {
        self$`type` <- this_object$`type`
      }
      if (!is.null(this_object$`status`)) {
        self$`status` <- this_object$`status`
      }
      if (!is.null(this_object$`condition`)) {
        self$`condition` <- this_object$`condition`
      }
      if (!is.null(this_object$`visible`)) {
        self$`visible` <- this_object$`visible`
      }
      if (!is.null(this_object$`in_stock`)) {
        self$`in_stock` <- this_object$`in_stock`
      }
      if (!is.null(this_object$`avail`)) {
        self$`avail` <- this_object$`avail`
      }
      if (!is.null(this_object$`avail_from`)) {
        self$`avail_from` <- this_object$`avail_from`
      }
      if (!is.null(this_object$`product_class`)) {
        self$`product_class` <- this_object$`product_class`
      }
      if (!is.null(this_object$`brand_name`)) {
        self$`brand_name` <- this_object$`brand_name`
      }
      if (!is.null(this_object$`available_for_view`)) {
        self$`available_for_view` <- this_object$`available_for_view`
      }
      if (!is.null(this_object$`measure_unit`)) {
        self$`measure_unit` <- this_object$`measure_unit`
      }
      if (!is.null(this_object$`unit_price`)) {
        self$`unit_price` <- this_object$`unit_price`
      }
      if (!is.null(this_object$`stores_ids`)) {
        self$`stores_ids` <- this_object$`stores_ids`
      }
      if (!is.null(this_object$`store_id`)) {
        self$`store_id` <- this_object$`store_id`
      }
      if (!is.null(this_object$`lang_id`)) {
        self$`lang_id` <- this_object$`lang_id`
      }
      if (!is.null(this_object$`quantity`)) {
        self$`quantity` <- this_object$`quantity`
      }
      if (!is.null(this_object$`reserve_quantity`)) {
        self$`reserve_quantity` <- this_object$`reserve_quantity`
      }
      if (!is.null(this_object$`manage_stock`)) {
        self$`manage_stock` <- this_object$`manage_stock`
      }
      if (!is.null(this_object$`backorder_status`)) {
        self$`backorder_status` <- this_object$`backorder_status`
      }
      if (!is.null(this_object$`increase_quantity`)) {
        self$`increase_quantity` <- this_object$`increase_quantity`
      }
      if (!is.null(this_object$`reduce_quantity`)) {
        self$`reduce_quantity` <- this_object$`reduce_quantity`
      }
      if (!is.null(this_object$`low_stock_threshold`)) {
        self$`low_stock_threshold` <- this_object$`low_stock_threshold`
      }
      if (!is.null(this_object$`min_order_quantity`)) {
        self$`min_order_quantity` <- this_object$`min_order_quantity`
      }
      if (!is.null(this_object$`max_order_quantity`)) {
        self$`max_order_quantity` <- this_object$`max_order_quantity`
      }
      if (!is.null(this_object$`warehouse_id`)) {
        self$`warehouse_id` <- this_object$`warehouse_id`
      }
      if (!is.null(this_object$`weight`)) {
        self$`weight` <- this_object$`weight`
      }
      if (!is.null(this_object$`weight_unit`)) {
        self$`weight_unit` <- this_object$`weight_unit`
      }
      if (!is.null(this_object$`height`)) {
        self$`height` <- this_object$`height`
      }
      if (!is.null(this_object$`length`)) {
        self$`length` <- this_object$`length`
      }
      if (!is.null(this_object$`width`)) {
        self$`width` <- this_object$`width`
      }
      if (!is.null(this_object$`dimensions_unit`)) {
        self$`dimensions_unit` <- this_object$`dimensions_unit`
      }
      if (!is.null(this_object$`is_virtual`)) {
        self$`is_virtual` <- this_object$`is_virtual`
      }
      if (!is.null(this_object$`is_free_shipping`)) {
        self$`is_free_shipping` <- this_object$`is_free_shipping`
      }
      if (!is.null(this_object$`gtin`)) {
        self$`gtin` <- this_object$`gtin`
      }
      if (!is.null(this_object$`upc`)) {
        self$`upc` <- this_object$`upc`
      }
      if (!is.null(this_object$`mpn`)) {
        self$`mpn` <- this_object$`mpn`
      }
      if (!is.null(this_object$`ean`)) {
        self$`ean` <- this_object$`ean`
      }
      if (!is.null(this_object$`isbn`)) {
        self$`isbn` <- this_object$`isbn`
      }
      if (!is.null(this_object$`barcode`)) {
        self$`barcode` <- this_object$`barcode`
      }
      if (!is.null(this_object$`manufacturer`)) {
        self$`manufacturer` <- this_object$`manufacturer`
      }
      if (!is.null(this_object$`manufacturer_id`)) {
        self$`manufacturer_id` <- this_object$`manufacturer_id`
      }
      if (!is.null(this_object$`vendor_id`)) {
        self$`vendor_id` <- this_object$`vendor_id`
      }
      if (!is.null(this_object$`categories_ids`)) {
        self$`categories_ids` <- this_object$`categories_ids`
      }
      if (!is.null(this_object$`related_products_ids`)) {
        self$`related_products_ids` <- this_object$`related_products_ids`
      }
      if (!is.null(this_object$`up_sell_products_ids`)) {
        self$`up_sell_products_ids` <- this_object$`up_sell_products_ids`
      }
      if (!is.null(this_object$`cross_sell_products_ids`)) {
        self$`cross_sell_products_ids` <- this_object$`cross_sell_products_ids`
      }
      if (!is.null(this_object$`meta_title`)) {
        self$`meta_title` <- this_object$`meta_title`
      }
      if (!is.null(this_object$`meta_keywords`)) {
        self$`meta_keywords` <- this_object$`meta_keywords`
      }
      if (!is.null(this_object$`meta_description`)) {
        self$`meta_description` <- this_object$`meta_description`
      }
      if (!is.null(this_object$`seo_url`)) {
        self$`seo_url` <- this_object$`seo_url`
      }
      if (!is.null(this_object$`search_keywords`)) {
        self$`search_keywords` <- this_object$`search_keywords`
      }
      if (!is.null(this_object$`tags`)) {
        self$`tags` <- this_object$`tags`
      }
      if (!is.null(this_object$`delivery_code`)) {
        self$`delivery_code` <- this_object$`delivery_code`
      }
      if (!is.null(this_object$`package_details`)) {
        `package_details_object` <- ProductAddPackageDetails$new()
        `package_details_object`$fromJSON(jsonlite::toJSON(this_object$`package_details`, auto_unbox = TRUE, digits = NA))
        self$`package_details` <- `package_details_object`
      }
      if (!is.null(this_object$`country_of_origin`)) {
        self$`country_of_origin` <- this_object$`country_of_origin`
      }
      if (!is.null(this_object$`harmonized_system_code`)) {
        self$`harmonized_system_code` <- this_object$`harmonized_system_code`
      }
      if (!is.null(this_object$`shipping_template_id`)) {
        self$`shipping_template_id` <- this_object$`shipping_template_id`
      }
      if (!is.null(this_object$`processing_profile_id`)) {
        self$`processing_profile_id` <- this_object$`processing_profile_id`
      }
      if (!is.null(this_object$`when_made`)) {
        self$`when_made` <- this_object$`when_made`
      }
      if (!is.null(this_object$`is_supply`)) {
        self$`is_supply` <- this_object$`is_supply`
      }
      if (!is.null(this_object$`downloadable`)) {
        self$`downloadable` <- this_object$`downloadable`
      }
      if (!is.null(this_object$`materials`)) {
        self$`materials` <- ApiClient$new()$deserializeObj(this_object$`materials`, "array[character]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`auto_renew`)) {
        self$`auto_renew` <- this_object$`auto_renew`
      }
      if (!is.null(this_object$`on_sale`)) {
        self$`on_sale` <- this_object$`on_sale`
      }
      if (!is.null(this_object$`production_partner_ids`)) {
        self$`production_partner_ids` <- this_object$`production_partner_ids`
      }
      if (!is.null(this_object$`manufacturer_info`)) {
        `manufacturer_info_object` <- ProductAddManufacturerInfo$new()
        `manufacturer_info_object`$fromJSON(jsonlite::toJSON(this_object$`manufacturer_info`, auto_unbox = TRUE, digits = NA))
        self$`manufacturer_info` <- `manufacturer_info_object`
      }
      if (!is.null(this_object$`report_request_id`)) {
        self$`report_request_id` <- this_object$`report_request_id`
      }
      if (!is.null(this_object$`disable_report_cache`)) {
        self$`disable_report_cache` <- this_object$`disable_report_cache`
      }
      if (!is.null(this_object$`reindex`)) {
        self$`reindex` <- this_object$`reindex`
      }
      if (!is.null(this_object$`clear_cache`)) {
        self$`clear_cache` <- this_object$`clear_cache`
      }
      if (!is.null(this_object$`check_process_status`)) {
        self$`check_process_status` <- this_object$`check_process_status`
      }
      if (!is.null(this_object$`specifics`)) {
        self$`specifics` <- ApiClient$new()$deserializeObj(this_object$`specifics`, "array[ProductAddSpecificsInner]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`shop_section_id`)) {
        self$`shop_section_id` <- this_object$`shop_section_id`
      }
      if (!is.null(this_object$`personalization_details`)) {
        `personalization_details_object` <- ProductAddPersonalizationDetails$new()
        `personalization_details_object`$fromJSON(jsonlite::toJSON(this_object$`personalization_details`, auto_unbox = TRUE, digits = NA))
        self$`personalization_details` <- `personalization_details_object`
      }
      if (!is.null(this_object$`personalization_questions`)) {
        self$`personalization_questions` <- ApiClient$new()$deserializeObj(this_object$`personalization_questions`, "array[ProductAddPersonalizationQuestionsInner]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`external_product_link`)) {
        self$`external_product_link` <- this_object$`external_product_link`
      }
      if (!is.null(this_object$`marketplace_item_properties`)) {
        self$`marketplace_item_properties` <- this_object$`marketplace_item_properties`
      }
      if (!is.null(this_object$`manufacturer_ids`)) {
        self$`manufacturer_ids` <- this_object$`manufacturer_ids`
      }
      if (!is.null(this_object$`responsible_person_ids`)) {
        self$`responsible_person_ids` <- this_object$`responsible_person_ids`
      }
      if (!is.null(this_object$`idempotency_key`)) {
        self$`idempotency_key` <- this_object$`idempotency_key`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductUpdate in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductUpdate
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductUpdate
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`model` <- this_object$`model`
      self$`sku` <- this_object$`sku`
      self$`name` <- this_object$`name`
      self$`description` <- this_object$`description`
      self$`short_description` <- this_object$`short_description`
      self$`prices_inc_tax` <- this_object$`prices_inc_tax`
      self$`price` <- this_object$`price`
      self$`old_price` <- this_object$`old_price`
      self$`special_price` <- this_object$`special_price`
      self$`sprice_create` <- this_object$`sprice_create`
      self$`sprice_expire` <- this_object$`sprice_expire`
      self$`cost_price` <- this_object$`cost_price`
      self$`fixed_cost_shipping_price` <- this_object$`fixed_cost_shipping_price`
      self$`retail_price` <- this_object$`retail_price`
      self$`tier_prices` <- ApiClient$new()$deserializeObj(this_object$`tier_prices`, "array[ProductAddTierPricesInner]", loadNamespace("openapi"))
      self$`reserve_price` <- this_object$`reserve_price`
      self$`buyitnow_price` <- this_object$`buyitnow_price`
      self$`taxable` <- this_object$`taxable`
      self$`tax_class_id` <- this_object$`tax_class_id`
      self$`type` <- this_object$`type`
      self$`status` <- this_object$`status`
      self$`condition` <- this_object$`condition`
      self$`visible` <- this_object$`visible`
      self$`in_stock` <- this_object$`in_stock`
      self$`avail` <- this_object$`avail`
      self$`avail_from` <- this_object$`avail_from`
      self$`product_class` <- this_object$`product_class`
      self$`brand_name` <- this_object$`brand_name`
      self$`available_for_view` <- this_object$`available_for_view`
      self$`measure_unit` <- this_object$`measure_unit`
      self$`unit_price` <- this_object$`unit_price`
      self$`stores_ids` <- this_object$`stores_ids`
      self$`store_id` <- this_object$`store_id`
      self$`lang_id` <- this_object$`lang_id`
      self$`quantity` <- this_object$`quantity`
      self$`reserve_quantity` <- this_object$`reserve_quantity`
      self$`manage_stock` <- this_object$`manage_stock`
      self$`backorder_status` <- this_object$`backorder_status`
      self$`increase_quantity` <- this_object$`increase_quantity`
      self$`reduce_quantity` <- this_object$`reduce_quantity`
      self$`low_stock_threshold` <- this_object$`low_stock_threshold`
      self$`min_order_quantity` <- this_object$`min_order_quantity`
      self$`max_order_quantity` <- this_object$`max_order_quantity`
      self$`warehouse_id` <- this_object$`warehouse_id`
      self$`weight` <- this_object$`weight`
      self$`weight_unit` <- this_object$`weight_unit`
      self$`height` <- this_object$`height`
      self$`length` <- this_object$`length`
      self$`width` <- this_object$`width`
      self$`dimensions_unit` <- this_object$`dimensions_unit`
      self$`is_virtual` <- this_object$`is_virtual`
      self$`is_free_shipping` <- this_object$`is_free_shipping`
      self$`gtin` <- this_object$`gtin`
      self$`upc` <- this_object$`upc`
      self$`mpn` <- this_object$`mpn`
      self$`ean` <- this_object$`ean`
      self$`isbn` <- this_object$`isbn`
      self$`barcode` <- this_object$`barcode`
      self$`manufacturer` <- this_object$`manufacturer`
      self$`manufacturer_id` <- this_object$`manufacturer_id`
      self$`vendor_id` <- this_object$`vendor_id`
      self$`categories_ids` <- this_object$`categories_ids`
      self$`related_products_ids` <- this_object$`related_products_ids`
      self$`up_sell_products_ids` <- this_object$`up_sell_products_ids`
      self$`cross_sell_products_ids` <- this_object$`cross_sell_products_ids`
      self$`meta_title` <- this_object$`meta_title`
      self$`meta_keywords` <- this_object$`meta_keywords`
      self$`meta_description` <- this_object$`meta_description`
      self$`seo_url` <- this_object$`seo_url`
      self$`search_keywords` <- this_object$`search_keywords`
      self$`tags` <- this_object$`tags`
      self$`delivery_code` <- this_object$`delivery_code`
      self$`package_details` <- ProductAddPackageDetails$new()$fromJSON(jsonlite::toJSON(this_object$`package_details`, auto_unbox = TRUE, digits = NA))
      self$`country_of_origin` <- this_object$`country_of_origin`
      self$`harmonized_system_code` <- this_object$`harmonized_system_code`
      self$`shipping_template_id` <- this_object$`shipping_template_id`
      self$`processing_profile_id` <- this_object$`processing_profile_id`
      self$`when_made` <- this_object$`when_made`
      self$`is_supply` <- this_object$`is_supply`
      self$`downloadable` <- this_object$`downloadable`
      self$`materials` <- ApiClient$new()$deserializeObj(this_object$`materials`, "array[character]", loadNamespace("openapi"))
      self$`auto_renew` <- this_object$`auto_renew`
      self$`on_sale` <- this_object$`on_sale`
      self$`production_partner_ids` <- this_object$`production_partner_ids`
      self$`manufacturer_info` <- ProductAddManufacturerInfo$new()$fromJSON(jsonlite::toJSON(this_object$`manufacturer_info`, auto_unbox = TRUE, digits = NA))
      self$`report_request_id` <- this_object$`report_request_id`
      self$`disable_report_cache` <- this_object$`disable_report_cache`
      self$`reindex` <- this_object$`reindex`
      self$`clear_cache` <- this_object$`clear_cache`
      self$`check_process_status` <- this_object$`check_process_status`
      self$`specifics` <- ApiClient$new()$deserializeObj(this_object$`specifics`, "array[ProductAddSpecificsInner]", loadNamespace("openapi"))
      self$`shop_section_id` <- this_object$`shop_section_id`
      self$`personalization_details` <- ProductAddPersonalizationDetails$new()$fromJSON(jsonlite::toJSON(this_object$`personalization_details`, auto_unbox = TRUE, digits = NA))
      self$`personalization_questions` <- ApiClient$new()$deserializeObj(this_object$`personalization_questions`, "array[ProductAddPersonalizationQuestionsInner]", loadNamespace("openapi"))
      self$`external_product_link` <- this_object$`external_product_link`
      self$`marketplace_item_properties` <- this_object$`marketplace_item_properties`
      self$`manufacturer_ids` <- this_object$`manufacturer_ids`
      self$`responsible_person_ids` <- this_object$`responsible_person_ids`
      self$`idempotency_key` <- this_object$`idempotency_key`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductUpdate and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductUpdate
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      if (length(self$`personalization_questions`) > 5) {
        return(FALSE)
      }
      if (length(self$`personalization_questions`) < 1) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      if (length(self$`personalization_questions`) > 5) {
        invalid_fields["personalization_questions"] <- "Invalid length for `personalization_questions`, number of items must be less than or equal to 5."
      }
      if (length(self$`personalization_questions`) < 1) {
        invalid_fields["personalization_questions"] <- "Invalid length for ``, number of items must be greater than or equal to 1."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductUpdate$unlock()
#
## Below is an example to define the print function
# ProductUpdate$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductUpdate$lock()

