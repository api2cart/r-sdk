#' Create a new ProductAddSalesTax
#'
#' @description
#' Percent of an item's price to be charged as the sales tax for the order. Look at cart.info method response for allowed values.<hr><div style=\"font-style:normal\">Param structure:<div style=\"margin-left: 2%;\"><code style=\"padding:0; background-color:#ffffff;font-size:85%;font-family:monospace;\">sales_tax[<b>tax_percent</b>] = decimal (##.###)</br>sales_tax[<b>tax_state</b>] = string</br>sales_tax[<b>shipping_inc_in_tax</b>] = bool</br></code></div></div>
#'
#' @docType class
#' @title ProductAddSalesTax
#' @description ProductAddSalesTax Class
#' @format An \code{R6Class} generator object
#' @field tax_percent  numeric [optional]
#' @field tax_state  character [optional]
#' @field shipping_inc_in_tax  character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductAddSalesTax <- R6::R6Class(
  "ProductAddSalesTax",
  public = list(
    `tax_percent` = NULL,
    `tax_state` = NULL,
    `shipping_inc_in_tax` = NULL,

    #' @description
    #' Initialize a new ProductAddSalesTax class.
    #'
    #' @param tax_percent tax_percent
    #' @param tax_state tax_state
    #' @param shipping_inc_in_tax shipping_inc_in_tax
    #' @param ... Other optional arguments.
    initialize = function(`tax_percent` = NULL, `tax_state` = NULL, `shipping_inc_in_tax` = NULL, ...) {
      if (!is.null(`tax_percent`)) {
        self$`tax_percent` <- `tax_percent`
      }
      if (!is.null(`tax_state`)) {
        if (!(is.character(`tax_state`) && length(`tax_state`) == 1)) {
          stop(paste("Error! Invalid data for `tax_state`. Must be a string:", `tax_state`))
        }
        self$`tax_state` <- `tax_state`
      }
      if (!is.null(`shipping_inc_in_tax`)) {
        if (!(is.logical(`shipping_inc_in_tax`) && length(`shipping_inc_in_tax`) == 1)) {
          stop(paste("Error! Invalid data for `shipping_inc_in_tax`. Must be a boolean:", `shipping_inc_in_tax`))
        }
        self$`shipping_inc_in_tax` <- `shipping_inc_in_tax`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductAddSalesTax as a base R list.
    #' @examples
    #' # convert array of ProductAddSalesTax (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductAddSalesTax to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductAddSalesTaxObject <- list()
      if (!is.null(self$`tax_percent`)) {
        ProductAddSalesTaxObject[["tax_percent"]] <-
          self$`tax_percent`
      }
      if (!is.null(self$`tax_state`)) {
        ProductAddSalesTaxObject[["tax_state"]] <-
          self$`tax_state`
      }
      if (!is.null(self$`shipping_inc_in_tax`)) {
        ProductAddSalesTaxObject[["shipping_inc_in_tax"]] <-
          self$`shipping_inc_in_tax`
      }
      return(ProductAddSalesTaxObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductAddSalesTax
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductAddSalesTax
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`tax_percent`)) {
        self$`tax_percent` <- this_object$`tax_percent`
      }
      if (!is.null(this_object$`tax_state`)) {
        self$`tax_state` <- this_object$`tax_state`
      }
      if (!is.null(this_object$`shipping_inc_in_tax`)) {
        self$`shipping_inc_in_tax` <- this_object$`shipping_inc_in_tax`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductAddSalesTax in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductAddSalesTax
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductAddSalesTax
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`tax_percent` <- this_object$`tax_percent`
      self$`tax_state` <- this_object$`tax_state`
      self$`shipping_inc_in_tax` <- this_object$`shipping_inc_in_tax`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductAddSalesTax and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductAddSalesTax
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductAddSalesTax$unlock()
#
## Below is an example to define the print function
# ProductAddSalesTax$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductAddSalesTax$lock()

