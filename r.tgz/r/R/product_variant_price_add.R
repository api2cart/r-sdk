#' Create a new ProductVariantPriceAdd
#'
#' @description
#' ProductVariantPriceAdd Class
#'
#' @docType class
#' @title ProductVariantPriceAdd
#' @description ProductVariantPriceAdd Class
#' @format An \code{R6Class} generator object
#' @field id Defines the variant to which the price has to be added character [optional]
#' @field product_id Product id character [optional]
#' @field group_prices Defines variants's group prices list(\link{ProductAddGroupPricesInner})
#' @field store_id Store Id character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductVariantPriceAdd <- R6::R6Class(
  "ProductVariantPriceAdd",
  public = list(
    `id` = NULL,
    `product_id` = NULL,
    `group_prices` = NULL,
    `store_id` = NULL,

    #' @description
    #' Initialize a new ProductVariantPriceAdd class.
    #'
    #' @param group_prices Defines variants's group prices
    #' @param id Defines the variant to which the price has to be added
    #' @param product_id Product id
    #' @param store_id Store Id
    #' @param ... Other optional arguments.
    initialize = function(`group_prices`, `id` = NULL, `product_id` = NULL, `store_id` = NULL, ...) {
      if (!missing(`group_prices`)) {
        stopifnot(is.vector(`group_prices`), length(`group_prices`) != 0)
        sapply(`group_prices`, function(x) stopifnot(R6::is.R6(x)))
        self$`group_prices` <- `group_prices`
      }
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`product_id`)) {
        if (!(is.character(`product_id`) && length(`product_id`) == 1)) {
          stop(paste("Error! Invalid data for `product_id`. Must be a string:", `product_id`))
        }
        self$`product_id` <- `product_id`
      }
      if (!is.null(`store_id`)) {
        if (!(is.character(`store_id`) && length(`store_id`) == 1)) {
          stop(paste("Error! Invalid data for `store_id`. Must be a string:", `store_id`))
        }
        self$`store_id` <- `store_id`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductVariantPriceAdd as a base R list.
    #' @examples
    #' # convert array of ProductVariantPriceAdd (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductVariantPriceAdd to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductVariantPriceAddObject <- list()
      if (!is.null(self$`id`)) {
        ProductVariantPriceAddObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`product_id`)) {
        ProductVariantPriceAddObject[["product_id"]] <-
          self$`product_id`
      }
      if (!is.null(self$`group_prices`)) {
        ProductVariantPriceAddObject[["group_prices"]] <-
          lapply(self$`group_prices`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`store_id`)) {
        ProductVariantPriceAddObject[["store_id"]] <-
          self$`store_id`
      }
      return(ProductVariantPriceAddObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductVariantPriceAdd
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductVariantPriceAdd
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`product_id`)) {
        self$`product_id` <- this_object$`product_id`
      }
      if (!is.null(this_object$`group_prices`)) {
        self$`group_prices` <- ApiClient$new()$deserializeObj(this_object$`group_prices`, "array[ProductAddGroupPricesInner]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`store_id`)) {
        self$`store_id` <- this_object$`store_id`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductVariantPriceAdd in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductVariantPriceAdd
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductVariantPriceAdd
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`product_id` <- this_object$`product_id`
      self$`group_prices` <- ApiClient$new()$deserializeObj(this_object$`group_prices`, "array[ProductAddGroupPricesInner]", loadNamespace("openapi"))
      self$`store_id` <- this_object$`store_id`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductVariantPriceAdd and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
      # check the required field `group_prices`
      if (!is.null(input_json$`group_prices`)) {
        stopifnot(is.vector(input_json$`group_prices`), length(input_json$`group_prices`) != 0)
        tmp <- sapply(input_json$`group_prices`, function(x) stopifnot(R6::is.R6(x)))
      } else {
        stop(paste("The JSON input `", input, "` is invalid for ProductVariantPriceAdd: the required field `group_prices` is missing."))
      }
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductVariantPriceAdd
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      # check if the required `group_prices` is null
      if (is.null(self$`group_prices`)) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      # check if the required `group_prices` is null
      if (is.null(self$`group_prices`)) {
        invalid_fields["group_prices"] <- "Non-nullable required field `group_prices` cannot be null."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductVariantPriceAdd$unlock()
#
## Below is an example to define the print function
# ProductVariantPriceAdd$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductVariantPriceAdd$lock()

