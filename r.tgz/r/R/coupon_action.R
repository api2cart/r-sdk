#' Create a new CouponAction
#'
#' @description
#' CouponAction Class
#'
#' @docType class
#' @title CouponAction
#' @description CouponAction Class
#' @format An \code{R6Class} generator object
#' @field scope  character [optional]
#' @field apply_to  character [optional]
#' @field amount  numeric [optional]
#' @field currency_code  character [optional]
#' @field include_tax  character [optional]
#' @field type  character [optional]
#' @field discounted_quantity  numeric [optional]
#' @field discount_quantity_step  integer [optional]
#' @field logic_operator  character [optional]
#' @field conditions  list(\link{CouponCondition}) [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
CouponAction <- R6::R6Class(
  "CouponAction",
  public = list(
    `scope` = NULL,
    `apply_to` = NULL,
    `amount` = NULL,
    `currency_code` = NULL,
    `include_tax` = NULL,
    `type` = NULL,
    `discounted_quantity` = NULL,
    `discount_quantity_step` = NULL,
    `logic_operator` = NULL,
    `conditions` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new CouponAction class.
    #'
    #' @param scope scope
    #' @param apply_to apply_to
    #' @param amount amount
    #' @param currency_code currency_code
    #' @param include_tax include_tax
    #' @param type type
    #' @param discounted_quantity discounted_quantity
    #' @param discount_quantity_step discount_quantity_step
    #' @param logic_operator logic_operator
    #' @param conditions conditions
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`scope` = NULL, `apply_to` = NULL, `amount` = NULL, `currency_code` = NULL, `include_tax` = NULL, `type` = NULL, `discounted_quantity` = NULL, `discount_quantity_step` = NULL, `logic_operator` = NULL, `conditions` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`scope`)) {
        if (!(is.character(`scope`) && length(`scope`) == 1)) {
          stop(paste("Error! Invalid data for `scope`. Must be a string:", `scope`))
        }
        self$`scope` <- `scope`
      }
      if (!is.null(`apply_to`)) {
        if (!(is.character(`apply_to`) && length(`apply_to`) == 1)) {
          stop(paste("Error! Invalid data for `apply_to`. Must be a string:", `apply_to`))
        }
        self$`apply_to` <- `apply_to`
      }
      if (!is.null(`amount`)) {
        self$`amount` <- `amount`
      }
      if (!is.null(`currency_code`)) {
        if (!(is.character(`currency_code`) && length(`currency_code`) == 1)) {
          stop(paste("Error! Invalid data for `currency_code`. Must be a string:", `currency_code`))
        }
        self$`currency_code` <- `currency_code`
      }
      if (!is.null(`include_tax`)) {
        if (!(is.logical(`include_tax`) && length(`include_tax`) == 1)) {
          stop(paste("Error! Invalid data for `include_tax`. Must be a boolean:", `include_tax`))
        }
        self$`include_tax` <- `include_tax`
      }
      if (!is.null(`type`)) {
        if (!(is.character(`type`) && length(`type`) == 1)) {
          stop(paste("Error! Invalid data for `type`. Must be a string:", `type`))
        }
        self$`type` <- `type`
      }
      if (!is.null(`discounted_quantity`)) {
        self$`discounted_quantity` <- `discounted_quantity`
      }
      if (!is.null(`discount_quantity_step`)) {
        if (!(is.numeric(`discount_quantity_step`) && length(`discount_quantity_step`) == 1)) {
          stop(paste("Error! Invalid data for `discount_quantity_step`. Must be an integer:", `discount_quantity_step`))
        }
        self$`discount_quantity_step` <- `discount_quantity_step`
      }
      if (!is.null(`logic_operator`)) {
        if (!(is.character(`logic_operator`) && length(`logic_operator`) == 1)) {
          stop(paste("Error! Invalid data for `logic_operator`. Must be a string:", `logic_operator`))
        }
        self$`logic_operator` <- `logic_operator`
      }
      if (!is.null(`conditions`)) {
        stopifnot(is.vector(`conditions`), length(`conditions`) != 0)
        sapply(`conditions`, function(x) stopifnot(R6::is.R6(x)))
        self$`conditions` <- `conditions`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return CouponAction as a base R list.
    #' @examples
    #' # convert array of CouponAction (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert CouponAction to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      CouponActionObject <- list()
      if (!is.null(self$`scope`)) {
        CouponActionObject[["scope"]] <-
          self$`scope`
      }
      if (!is.null(self$`apply_to`)) {
        CouponActionObject[["apply_to"]] <-
          self$`apply_to`
      }
      if (!is.null(self$`amount`)) {
        CouponActionObject[["amount"]] <-
          self$`amount`
      }
      if (!is.null(self$`currency_code`)) {
        CouponActionObject[["currency_code"]] <-
          self$`currency_code`
      }
      if (!is.null(self$`include_tax`)) {
        CouponActionObject[["include_tax"]] <-
          self$`include_tax`
      }
      if (!is.null(self$`type`)) {
        CouponActionObject[["type"]] <-
          self$`type`
      }
      if (!is.null(self$`discounted_quantity`)) {
        CouponActionObject[["discounted_quantity"]] <-
          self$`discounted_quantity`
      }
      if (!is.null(self$`discount_quantity_step`)) {
        CouponActionObject[["discount_quantity_step"]] <-
          self$`discount_quantity_step`
      }
      if (!is.null(self$`logic_operator`)) {
        CouponActionObject[["logic_operator"]] <-
          self$`logic_operator`
      }
      if (!is.null(self$`conditions`)) {
        CouponActionObject[["conditions"]] <-
          lapply(self$`conditions`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`additional_fields`)) {
        CouponActionObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        CouponActionObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(CouponActionObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of CouponAction
    #'
    #' @param input_json the JSON input
    #' @return the instance of CouponAction
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`scope`)) {
        self$`scope` <- this_object$`scope`
      }
      if (!is.null(this_object$`apply_to`)) {
        self$`apply_to` <- this_object$`apply_to`
      }
      if (!is.null(this_object$`amount`)) {
        self$`amount` <- this_object$`amount`
      }
      if (!is.null(this_object$`currency_code`)) {
        self$`currency_code` <- this_object$`currency_code`
      }
      if (!is.null(this_object$`include_tax`)) {
        self$`include_tax` <- this_object$`include_tax`
      }
      if (!is.null(this_object$`type`)) {
        self$`type` <- this_object$`type`
      }
      if (!is.null(this_object$`discounted_quantity`)) {
        self$`discounted_quantity` <- this_object$`discounted_quantity`
      }
      if (!is.null(this_object$`discount_quantity_step`)) {
        self$`discount_quantity_step` <- this_object$`discount_quantity_step`
      }
      if (!is.null(this_object$`logic_operator`)) {
        self$`logic_operator` <- this_object$`logic_operator`
      }
      if (!is.null(this_object$`conditions`)) {
        self$`conditions` <- ApiClient$new()$deserializeObj(this_object$`conditions`, "array[CouponCondition]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return CouponAction in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of CouponAction
    #'
    #' @param input_json the JSON input
    #' @return the instance of CouponAction
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`scope` <- this_object$`scope`
      self$`apply_to` <- this_object$`apply_to`
      self$`amount` <- this_object$`amount`
      self$`currency_code` <- this_object$`currency_code`
      self$`include_tax` <- this_object$`include_tax`
      self$`type` <- this_object$`type`
      self$`discounted_quantity` <- this_object$`discounted_quantity`
      self$`discount_quantity_step` <- this_object$`discount_quantity_step`
      self$`logic_operator` <- this_object$`logic_operator`
      self$`conditions` <- ApiClient$new()$deserializeObj(this_object$`conditions`, "array[CouponCondition]", loadNamespace("openapi"))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to CouponAction and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of CouponAction
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# CouponAction$unlock()
#
## Below is an example to define the print function
# CouponAction$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# CouponAction$lock()

