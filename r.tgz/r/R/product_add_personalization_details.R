#' Create a new ProductAddPersonalizationDetails
#'
#' @description
#' <strong>Deprecated.</strong> Use <strong>personalization_questions</strong> instead for setting personalization questions. Defines legacy personalization settings for the listing. To enable personalization, is_personalizable must be set to true. When enabled, additional fields may be used to configure the personalization experience, including whether it is required (personalization_is_required), the maximum character limit (personalization_char_count_max), and buyer instructions (personalization_instructions). All related fields are only applicable if personalization is enabled.
#'
#' @docType class
#' @title ProductAddPersonalizationDetails
#' @description ProductAddPersonalizationDetails Class
#' @format An \code{R6Class} generator object
#' @field is_personalizable  character
#' @field personalization_is_required  character [optional]
#' @field personalization_char_count_max  integer [optional]
#' @field personalization_instructions  character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductAddPersonalizationDetails <- R6::R6Class(
  "ProductAddPersonalizationDetails",
  public = list(
    `is_personalizable` = NULL,
    `personalization_is_required` = NULL,
    `personalization_char_count_max` = NULL,
    `personalization_instructions` = NULL,

    #' @description
    #' Initialize a new ProductAddPersonalizationDetails class.
    #'
    #' @param is_personalizable is_personalizable
    #' @param personalization_is_required personalization_is_required
    #' @param personalization_char_count_max personalization_char_count_max
    #' @param personalization_instructions personalization_instructions
    #' @param ... Other optional arguments.
    initialize = function(`is_personalizable`, `personalization_is_required` = NULL, `personalization_char_count_max` = NULL, `personalization_instructions` = NULL, ...) {
      if (!missing(`is_personalizable`)) {
        if (!(is.logical(`is_personalizable`) && length(`is_personalizable`) == 1)) {
          stop(paste("Error! Invalid data for `is_personalizable`. Must be a boolean:", `is_personalizable`))
        }
        self$`is_personalizable` <- `is_personalizable`
      }
      if (!is.null(`personalization_is_required`)) {
        if (!(is.logical(`personalization_is_required`) && length(`personalization_is_required`) == 1)) {
          stop(paste("Error! Invalid data for `personalization_is_required`. Must be a boolean:", `personalization_is_required`))
        }
        self$`personalization_is_required` <- `personalization_is_required`
      }
      if (!is.null(`personalization_char_count_max`)) {
        if (!(is.numeric(`personalization_char_count_max`) && length(`personalization_char_count_max`) == 1)) {
          stop(paste("Error! Invalid data for `personalization_char_count_max`. Must be an integer:", `personalization_char_count_max`))
        }
        self$`personalization_char_count_max` <- `personalization_char_count_max`
      }
      if (!is.null(`personalization_instructions`)) {
        if (!(is.character(`personalization_instructions`) && length(`personalization_instructions`) == 1)) {
          stop(paste("Error! Invalid data for `personalization_instructions`. Must be a string:", `personalization_instructions`))
        }
        self$`personalization_instructions` <- `personalization_instructions`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductAddPersonalizationDetails as a base R list.
    #' @examples
    #' # convert array of ProductAddPersonalizationDetails (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductAddPersonalizationDetails to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductAddPersonalizationDetailsObject <- list()
      if (!is.null(self$`is_personalizable`)) {
        ProductAddPersonalizationDetailsObject[["is_personalizable"]] <-
          self$`is_personalizable`
      }
      if (!is.null(self$`personalization_is_required`)) {
        ProductAddPersonalizationDetailsObject[["personalization_is_required"]] <-
          self$`personalization_is_required`
      }
      if (!is.null(self$`personalization_char_count_max`)) {
        ProductAddPersonalizationDetailsObject[["personalization_char_count_max"]] <-
          self$`personalization_char_count_max`
      }
      if (!is.null(self$`personalization_instructions`)) {
        ProductAddPersonalizationDetailsObject[["personalization_instructions"]] <-
          self$`personalization_instructions`
      }
      return(ProductAddPersonalizationDetailsObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductAddPersonalizationDetails
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductAddPersonalizationDetails
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`is_personalizable`)) {
        self$`is_personalizable` <- this_object$`is_personalizable`
      }
      if (!is.null(this_object$`personalization_is_required`)) {
        self$`personalization_is_required` <- this_object$`personalization_is_required`
      }
      if (!is.null(this_object$`personalization_char_count_max`)) {
        self$`personalization_char_count_max` <- this_object$`personalization_char_count_max`
      }
      if (!is.null(this_object$`personalization_instructions`)) {
        self$`personalization_instructions` <- this_object$`personalization_instructions`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductAddPersonalizationDetails in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductAddPersonalizationDetails
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductAddPersonalizationDetails
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`is_personalizable` <- this_object$`is_personalizable`
      self$`personalization_is_required` <- this_object$`personalization_is_required`
      self$`personalization_char_count_max` <- this_object$`personalization_char_count_max`
      self$`personalization_instructions` <- this_object$`personalization_instructions`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductAddPersonalizationDetails and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
      # check the required field `is_personalizable`
      if (!is.null(input_json$`is_personalizable`)) {
        if (!(is.logical(input_json$`is_personalizable`) && length(input_json$`is_personalizable`) == 1)) {
          stop(paste("Error! Invalid data for `is_personalizable`. Must be a boolean:", input_json$`is_personalizable`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for ProductAddPersonalizationDetails: the required field `is_personalizable` is missing."))
      }
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductAddPersonalizationDetails
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      # check if the required `is_personalizable` is null
      if (is.null(self$`is_personalizable`)) {
        return(FALSE)
      }

      if (nchar(self$`personalization_instructions`) > 256) {
        return(FALSE)
      }
      if (nchar(self$`personalization_instructions`) < 1) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      # check if the required `is_personalizable` is null
      if (is.null(self$`is_personalizable`)) {
        invalid_fields["is_personalizable"] <- "Non-nullable required field `is_personalizable` cannot be null."
      }

      if (nchar(self$`personalization_instructions`) > 256) {
        invalid_fields["personalization_instructions"] <- "Invalid length for `personalization_instructions`, must be smaller than or equal to 256."
      }
      if (nchar(self$`personalization_instructions`) < 1) {
        invalid_fields["personalization_instructions"] <- "Invalid length for `personalization_instructions`, must be bigger than or equal to 1."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductAddPersonalizationDetails$unlock()
#
## Below is an example to define the print function
# ProductAddPersonalizationDetails$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductAddPersonalizationDetails$lock()

