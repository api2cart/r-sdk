#' Create a new ProductTaxAddTaxRatesInner
#'
#' @description
#' ProductTaxAddTaxRatesInner Class
#'
#' @docType class
#' @title ProductTaxAddTaxRatesInner
#' @description ProductTaxAddTaxRatesInner Class
#' @format An \code{R6Class} generator object
#' @field name  character [optional]
#' @field type  character [optional]
#' @field value  numeric [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductTaxAddTaxRatesInner <- R6::R6Class(
  "ProductTaxAddTaxRatesInner",
  public = list(
    `name` = NULL,
    `type` = NULL,
    `value` = NULL,

    #' @description
    #' Initialize a new ProductTaxAddTaxRatesInner class.
    #'
    #' @param name name
    #' @param type type
    #' @param value value
    #' @param ... Other optional arguments.
    initialize = function(`name` = NULL, `type` = NULL, `value` = NULL, ...) {
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`type`)) {
        if (!(is.character(`type`) && length(`type`) == 1)) {
          stop(paste("Error! Invalid data for `type`. Must be a string:", `type`))
        }
        self$`type` <- `type`
      }
      if (!is.null(`value`)) {
        self$`value` <- `value`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductTaxAddTaxRatesInner as a base R list.
    #' @examples
    #' # convert array of ProductTaxAddTaxRatesInner (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductTaxAddTaxRatesInner to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductTaxAddTaxRatesInnerObject <- list()
      if (!is.null(self$`name`)) {
        ProductTaxAddTaxRatesInnerObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`type`)) {
        ProductTaxAddTaxRatesInnerObject[["type"]] <-
          self$`type`
      }
      if (!is.null(self$`value`)) {
        ProductTaxAddTaxRatesInnerObject[["value"]] <-
          self$`value`
      }
      return(ProductTaxAddTaxRatesInnerObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductTaxAddTaxRatesInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductTaxAddTaxRatesInner
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`type`)) {
        self$`type` <- this_object$`type`
      }
      if (!is.null(this_object$`value`)) {
        self$`value` <- this_object$`value`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductTaxAddTaxRatesInner in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductTaxAddTaxRatesInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductTaxAddTaxRatesInner
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`name` <- this_object$`name`
      self$`type` <- this_object$`type`
      self$`value` <- this_object$`value`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductTaxAddTaxRatesInner and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductTaxAddTaxRatesInner
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductTaxAddTaxRatesInner$unlock()
#
## Below is an example to define the print function
# ProductTaxAddTaxRatesInner$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductTaxAddTaxRatesInner$lock()

