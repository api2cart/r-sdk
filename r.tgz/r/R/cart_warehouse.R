#' Create a new CartWarehouse
#'
#' @description
#' CartWarehouse Class
#'
#' @docType class
#' @title CartWarehouse
#' @description CartWarehouse Class
#' @format An \code{R6Class} generator object
#' @field id  character [optional]
#' @field name  character [optional]
#' @field description  character [optional]
#' @field avail  character [optional]
#' @field address  \link{CustomerAddress} [optional]
#' @field carriers_ids  list(character) [optional]
#' @field stores_ids  list(character) [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
CartWarehouse <- R6::R6Class(
  "CartWarehouse",
  public = list(
    `id` = NULL,
    `name` = NULL,
    `description` = NULL,
    `avail` = NULL,
    `address` = NULL,
    `carriers_ids` = NULL,
    `stores_ids` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new CartWarehouse class.
    #'
    #' @param id id
    #' @param name name
    #' @param description description
    #' @param avail avail
    #' @param address address
    #' @param carriers_ids carriers_ids
    #' @param stores_ids stores_ids
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `name` = NULL, `description` = NULL, `avail` = NULL, `address` = NULL, `carriers_ids` = NULL, `stores_ids` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`description`)) {
        if (!(is.character(`description`) && length(`description`) == 1)) {
          stop(paste("Error! Invalid data for `description`. Must be a string:", `description`))
        }
        self$`description` <- `description`
      }
      if (!is.null(`avail`)) {
        if (!(is.logical(`avail`) && length(`avail`) == 1)) {
          stop(paste("Error! Invalid data for `avail`. Must be a boolean:", `avail`))
        }
        self$`avail` <- `avail`
      }
      if (!is.null(`address`)) {
        stopifnot(R6::is.R6(`address`))
        self$`address` <- `address`
      }
      if (!is.null(`carriers_ids`)) {
        stopifnot(is.vector(`carriers_ids`), length(`carriers_ids`) != 0)
        sapply(`carriers_ids`, function(x) stopifnot(is.character(x)))
        self$`carriers_ids` <- `carriers_ids`
      }
      if (!is.null(`stores_ids`)) {
        stopifnot(is.vector(`stores_ids`), length(`stores_ids`) != 0)
        sapply(`stores_ids`, function(x) stopifnot(is.character(x)))
        self$`stores_ids` <- `stores_ids`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return CartWarehouse as a base R list.
    #' @examples
    #' # convert array of CartWarehouse (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert CartWarehouse to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      CartWarehouseObject <- list()
      if (!is.null(self$`id`)) {
        CartWarehouseObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`name`)) {
        CartWarehouseObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`description`)) {
        CartWarehouseObject[["description"]] <-
          self$`description`
      }
      if (!is.null(self$`avail`)) {
        CartWarehouseObject[["avail"]] <-
          self$`avail`
      }
      if (!is.null(self$`address`)) {
        CartWarehouseObject[["address"]] <-
          self$`address`$toSimpleType()
      }
      if (!is.null(self$`carriers_ids`)) {
        CartWarehouseObject[["carriers_ids"]] <-
          self$`carriers_ids`
      }
      if (!is.null(self$`stores_ids`)) {
        CartWarehouseObject[["stores_ids"]] <-
          self$`stores_ids`
      }
      if (!is.null(self$`additional_fields`)) {
        CartWarehouseObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        CartWarehouseObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(CartWarehouseObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of CartWarehouse
    #'
    #' @param input_json the JSON input
    #' @return the instance of CartWarehouse
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`description`)) {
        self$`description` <- this_object$`description`
      }
      if (!is.null(this_object$`avail`)) {
        self$`avail` <- this_object$`avail`
      }
      if (!is.null(this_object$`address`)) {
        `address_object` <- CustomerAddress$new()
        `address_object`$fromJSON(jsonlite::toJSON(this_object$`address`, auto_unbox = TRUE, digits = NA))
        self$`address` <- `address_object`
      }
      if (!is.null(this_object$`carriers_ids`)) {
        self$`carriers_ids` <- ApiClient$new()$deserializeObj(this_object$`carriers_ids`, "array[character]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`stores_ids`)) {
        self$`stores_ids` <- ApiClient$new()$deserializeObj(this_object$`stores_ids`, "array[character]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return CartWarehouse in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of CartWarehouse
    #'
    #' @param input_json the JSON input
    #' @return the instance of CartWarehouse
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`name` <- this_object$`name`
      self$`description` <- this_object$`description`
      self$`avail` <- this_object$`avail`
      self$`address` <- CustomerAddress$new()$fromJSON(jsonlite::toJSON(this_object$`address`, auto_unbox = TRUE, digits = NA))
      self$`carriers_ids` <- ApiClient$new()$deserializeObj(this_object$`carriers_ids`, "array[character]", loadNamespace("openapi"))
      self$`stores_ids` <- ApiClient$new()$deserializeObj(this_object$`stores_ids`, "array[character]", loadNamespace("openapi"))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to CartWarehouse and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of CartWarehouse
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# CartWarehouse$unlock()
#
## Below is an example to define the print function
# CartWarehouse$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# CartWarehouse$lock()

