#' Create a new ResponseCategoryFindResult
#'
#' @description
#' ResponseCategoryFindResult Class
#'
#' @docType class
#' @title ResponseCategoryFindResult
#' @description ResponseCategoryFindResult Class
#' @format An \code{R6Class} generator object
#' @field categories_count  integer [optional]
#' @field category  list(\link{Category}) [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ResponseCategoryFindResult <- R6::R6Class(
  "ResponseCategoryFindResult",
  public = list(
    `categories_count` = NULL,
    `category` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new ResponseCategoryFindResult class.
    #'
    #' @param categories_count categories_count
    #' @param category category
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`categories_count` = NULL, `category` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`categories_count`)) {
        if (!(is.numeric(`categories_count`) && length(`categories_count`) == 1)) {
          stop(paste("Error! Invalid data for `categories_count`. Must be an integer:", `categories_count`))
        }
        self$`categories_count` <- `categories_count`
      }
      if (!is.null(`category`)) {
        stopifnot(is.vector(`category`), length(`category`) != 0)
        sapply(`category`, function(x) stopifnot(R6::is.R6(x)))
        self$`category` <- `category`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ResponseCategoryFindResult as a base R list.
    #' @examples
    #' # convert array of ResponseCategoryFindResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ResponseCategoryFindResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ResponseCategoryFindResultObject <- list()
      if (!is.null(self$`categories_count`)) {
        ResponseCategoryFindResultObject[["categories_count"]] <-
          self$`categories_count`
      }
      if (!is.null(self$`category`)) {
        ResponseCategoryFindResultObject[["category"]] <-
          lapply(self$`category`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`additional_fields`)) {
        ResponseCategoryFindResultObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        ResponseCategoryFindResultObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(ResponseCategoryFindResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ResponseCategoryFindResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ResponseCategoryFindResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`categories_count`)) {
        self$`categories_count` <- this_object$`categories_count`
      }
      if (!is.null(this_object$`category`)) {
        self$`category` <- ApiClient$new()$deserializeObj(this_object$`category`, "array[Category]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ResponseCategoryFindResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ResponseCategoryFindResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ResponseCategoryFindResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`categories_count` <- this_object$`categories_count`
      self$`category` <- ApiClient$new()$deserializeObj(this_object$`category`, "array[Category]", loadNamespace("openapi"))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to ResponseCategoryFindResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ResponseCategoryFindResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ResponseCategoryFindResult$unlock()
#
## Below is an example to define the print function
# ResponseCategoryFindResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ResponseCategoryFindResult$lock()

