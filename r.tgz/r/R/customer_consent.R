#' Create a new CustomerConsent
#'
#' @description
#' CustomerConsent Class
#'
#' @docType class
#' @title CustomerConsent
#' @description CustomerConsent Class
#' @format An \code{R6Class} generator object
#' @field id  character [optional]
#' @field type  character [optional]
#' @field status  character [optional]
#' @field source  character [optional]
#' @field opt_in_level  character [optional]
#' @field modified_time  character [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
CustomerConsent <- R6::R6Class(
  "CustomerConsent",
  public = list(
    `id` = NULL,
    `type` = NULL,
    `status` = NULL,
    `source` = NULL,
    `opt_in_level` = NULL,
    `modified_time` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new CustomerConsent class.
    #'
    #' @param id id
    #' @param type type
    #' @param status status
    #' @param source source
    #' @param opt_in_level opt_in_level
    #' @param modified_time modified_time
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `type` = NULL, `status` = NULL, `source` = NULL, `opt_in_level` = NULL, `modified_time` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`type`)) {
        if (!(is.character(`type`) && length(`type`) == 1)) {
          stop(paste("Error! Invalid data for `type`. Must be a string:", `type`))
        }
        self$`type` <- `type`
      }
      if (!is.null(`status`)) {
        if (!(is.character(`status`) && length(`status`) == 1)) {
          stop(paste("Error! Invalid data for `status`. Must be a string:", `status`))
        }
        self$`status` <- `status`
      }
      if (!is.null(`source`)) {
        if (!(is.character(`source`) && length(`source`) == 1)) {
          stop(paste("Error! Invalid data for `source`. Must be a string:", `source`))
        }
        self$`source` <- `source`
      }
      if (!is.null(`opt_in_level`)) {
        if (!(is.character(`opt_in_level`) && length(`opt_in_level`) == 1)) {
          stop(paste("Error! Invalid data for `opt_in_level`. Must be a string:", `opt_in_level`))
        }
        self$`opt_in_level` <- `opt_in_level`
      }
      if (!is.null(`modified_time`)) {
        if (!(is.character(`modified_time`) && length(`modified_time`) == 1)) {
          stop(paste("Error! Invalid data for `modified_time`. Must be a string:", `modified_time`))
        }
        self$`modified_time` <- `modified_time`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return CustomerConsent as a base R list.
    #' @examples
    #' # convert array of CustomerConsent (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert CustomerConsent to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      CustomerConsentObject <- list()
      if (!is.null(self$`id`)) {
        CustomerConsentObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`type`)) {
        CustomerConsentObject[["type"]] <-
          self$`type`
      }
      if (!is.null(self$`status`)) {
        CustomerConsentObject[["status"]] <-
          self$`status`
      }
      if (!is.null(self$`source`)) {
        CustomerConsentObject[["source"]] <-
          self$`source`
      }
      if (!is.null(self$`opt_in_level`)) {
        CustomerConsentObject[["opt_in_level"]] <-
          self$`opt_in_level`
      }
      if (!is.null(self$`modified_time`)) {
        CustomerConsentObject[["modified_time"]] <-
          self$`modified_time`
      }
      if (!is.null(self$`additional_fields`)) {
        CustomerConsentObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        CustomerConsentObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(CustomerConsentObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of CustomerConsent
    #'
    #' @param input_json the JSON input
    #' @return the instance of CustomerConsent
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`type`)) {
        self$`type` <- this_object$`type`
      }
      if (!is.null(this_object$`status`)) {
        self$`status` <- this_object$`status`
      }
      if (!is.null(this_object$`source`)) {
        self$`source` <- this_object$`source`
      }
      if (!is.null(this_object$`opt_in_level`)) {
        self$`opt_in_level` <- this_object$`opt_in_level`
      }
      if (!is.null(this_object$`modified_time`)) {
        self$`modified_time` <- this_object$`modified_time`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return CustomerConsent in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of CustomerConsent
    #'
    #' @param input_json the JSON input
    #' @return the instance of CustomerConsent
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`type` <- this_object$`type`
      self$`status` <- this_object$`status`
      self$`source` <- this_object$`source`
      self$`opt_in_level` <- this_object$`opt_in_level`
      self$`modified_time` <- this_object$`modified_time`
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to CustomerConsent and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of CustomerConsent
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# CustomerConsent$unlock()
#
## Below is an example to define the print function
# CustomerConsent$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# CustomerConsent$lock()

