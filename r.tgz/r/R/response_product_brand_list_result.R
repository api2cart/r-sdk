#' Create a new ResponseProductBrandListResult
#'
#' @description
#' ResponseProductBrandListResult Class
#'
#' @docType class
#' @title ResponseProductBrandListResult
#' @description ResponseProductBrandListResult Class
#' @format An \code{R6Class} generator object
#' @field total_count  integer [optional]
#' @field brands  list(\link{Brand}) [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ResponseProductBrandListResult <- R6::R6Class(
  "ResponseProductBrandListResult",
  public = list(
    `total_count` = NULL,
    `brands` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new ResponseProductBrandListResult class.
    #'
    #' @param total_count total_count
    #' @param brands brands
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`total_count` = NULL, `brands` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`total_count`)) {
        if (!(is.numeric(`total_count`) && length(`total_count`) == 1)) {
          stop(paste("Error! Invalid data for `total_count`. Must be an integer:", `total_count`))
        }
        self$`total_count` <- `total_count`
      }
      if (!is.null(`brands`)) {
        stopifnot(is.vector(`brands`), length(`brands`) != 0)
        sapply(`brands`, function(x) stopifnot(R6::is.R6(x)))
        self$`brands` <- `brands`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ResponseProductBrandListResult as a base R list.
    #' @examples
    #' # convert array of ResponseProductBrandListResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ResponseProductBrandListResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ResponseProductBrandListResultObject <- list()
      if (!is.null(self$`total_count`)) {
        ResponseProductBrandListResultObject[["total_count"]] <-
          self$`total_count`
      }
      if (!is.null(self$`brands`)) {
        ResponseProductBrandListResultObject[["brands"]] <-
          lapply(self$`brands`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`additional_fields`)) {
        ResponseProductBrandListResultObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        ResponseProductBrandListResultObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(ResponseProductBrandListResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ResponseProductBrandListResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ResponseProductBrandListResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`total_count`)) {
        self$`total_count` <- this_object$`total_count`
      }
      if (!is.null(this_object$`brands`)) {
        self$`brands` <- ApiClient$new()$deserializeObj(this_object$`brands`, "array[Brand]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ResponseProductBrandListResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ResponseProductBrandListResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ResponseProductBrandListResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`total_count` <- this_object$`total_count`
      self$`brands` <- ApiClient$new()$deserializeObj(this_object$`brands`, "array[Brand]", loadNamespace("openapi"))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to ResponseProductBrandListResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ResponseProductBrandListResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ResponseProductBrandListResult$unlock()
#
## Below is an example to define the print function
# ResponseProductBrandListResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ResponseProductBrandListResult$lock()

