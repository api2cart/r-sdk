#' Create a new OrderShipmentAdd
#'
#' @description
#' OrderShipmentAdd Class
#'
#' @docType class
#' @title OrderShipmentAdd
#' @description OrderShipmentAdd Class
#' @format An \code{R6Class} generator object
#' @field order_id Defines the order for which the shipment will be created character [optional]
#' @field warehouse_id This parameter is used for selecting a warehouse where you need to set/modify a product quantity. character [optional]
#' @field store_id Store Id character [optional]
#' @field shipment_provider Defines company name that provide tracking of shipment character [optional]
#' @field shipping_method Define shipping method character [optional]
#' @field items Defines items in the order that will be shipped list(\link{OrderShipmentAddItemsInner}) [optional]
#' @field tracking_numbers Defines shipment's tracking numbers that have to be added</br> How set tracking numbers to appropriate carrier:<ul><li>tracking_numbers[]=a2c.demo1,a2c.demo2 - set default carrier</li><li>tracking_numbers[<b>carrier_id</b>]=a2c.demo - set appropriate carrier</li></ul>To get the list of carriers IDs that are available in your store, use the <a href = \"https://api2cart.com/docs/#/cart/CartInfo\">cart.info</a > method list(\link{OrderShipmentAddTrackingNumbersInner}) [optional]
#' @field tracking_link Defines custom tracking link character [optional]
#' @field is_shipped Defines shipment's status character [optional]
#' @field send_notifications Send notifications to customer after shipment was created character [optional]
#' @field adjust_stock This parameter is used for adjust stock. character [optional]
#' @field check_process_status Disable or enable check process status. Please note that the response will be slower due to additional requests to the store. character [optional]
#' @field tracking_provider Defines name of the company which provides shipment tracking character [optional]
#' @field admin_comment Specifies admin's order comment character [optional]
#' @field mail_class Mail class for the shipment (e.g., priority, express). character [optional]
#' @field ship_date Ship date. character [optional]
#' @field weight Weight numeric [optional]
#' @field weight_unit Weight Unit character [optional]
#' @field length Defines product's length numeric [optional]
#' @field width Defines product's width numeric [optional]
#' @field height Defines product's height numeric [optional]
#' @field dimensions_unit Weight Unit character [optional]
#' @field shipping_label_cost Cost of the shipping label. numeric [optional]
#' @field shipping_label_currency Currency code for the shipping label cost (3-letter ISO code). character [optional]
#' @field revenue_eligibility Revenue eligibility flag. character [optional]
#' @field ship_from_country Country code the shipment is sent from (2-letter ISO code). character [optional]
#' @field ship_to_country Country code the shipment is sent to (2-letter ISO code). character [optional]
#' @field incoterm International commercial term for the shipment (e.g., DAP, DDP). character [optional]
#' @field duty_amount Duty amount for international shipment. numeric [optional]
#' @field duty_currency Currency code for the duty amount (3-letter ISO code). character [optional]
#' @field enable_cache If the value is 'true' and order exist in our cache, we will use order.info from cache to prepare shipment items. character [optional]
#' @field use_latest_api_version Use the latest platform API version character [optional]
#' @field idempotency_key A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong> character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
OrderShipmentAdd <- R6::R6Class(
  "OrderShipmentAdd",
  public = list(
    `order_id` = NULL,
    `warehouse_id` = NULL,
    `store_id` = NULL,
    `shipment_provider` = NULL,
    `shipping_method` = NULL,
    `items` = NULL,
    `tracking_numbers` = NULL,
    `tracking_link` = NULL,
    `is_shipped` = NULL,
    `send_notifications` = NULL,
    `adjust_stock` = NULL,
    `check_process_status` = NULL,
    `tracking_provider` = NULL,
    `admin_comment` = NULL,
    `mail_class` = NULL,
    `ship_date` = NULL,
    `weight` = NULL,
    `weight_unit` = NULL,
    `length` = NULL,
    `width` = NULL,
    `height` = NULL,
    `dimensions_unit` = NULL,
    `shipping_label_cost` = NULL,
    `shipping_label_currency` = NULL,
    `revenue_eligibility` = NULL,
    `ship_from_country` = NULL,
    `ship_to_country` = NULL,
    `incoterm` = NULL,
    `duty_amount` = NULL,
    `duty_currency` = NULL,
    `enable_cache` = NULL,
    `use_latest_api_version` = NULL,
    `idempotency_key` = NULL,

    #' @description
    #' Initialize a new OrderShipmentAdd class.
    #'
    #' @param order_id Defines the order for which the shipment will be created
    #' @param warehouse_id This parameter is used for selecting a warehouse where you need to set/modify a product quantity.
    #' @param store_id Store Id
    #' @param shipment_provider Defines company name that provide tracking of shipment
    #' @param shipping_method Define shipping method
    #' @param items Defines items in the order that will be shipped
    #' @param tracking_numbers Defines shipment's tracking numbers that have to be added</br> How set tracking numbers to appropriate carrier:<ul><li>tracking_numbers[]=a2c.demo1,a2c.demo2 - set default carrier</li><li>tracking_numbers[<b>carrier_id</b>]=a2c.demo - set appropriate carrier</li></ul>To get the list of carriers IDs that are available in your store, use the <a href = \"https://api2cart.com/docs/#/cart/CartInfo\">cart.info</a > method
    #' @param tracking_link Defines custom tracking link
    #' @param is_shipped Defines shipment's status. Default to TRUE.
    #' @param send_notifications Send notifications to customer after shipment was created. Default to FALSE.
    #' @param adjust_stock This parameter is used for adjust stock.. Default to FALSE.
    #' @param check_process_status Disable or enable check process status. Please note that the response will be slower due to additional requests to the store.. Default to FALSE.
    #' @param tracking_provider Defines name of the company which provides shipment tracking
    #' @param admin_comment Specifies admin's order comment
    #' @param mail_class Mail class for the shipment (e.g., priority, express).
    #' @param ship_date Ship date.
    #' @param weight Weight
    #' @param weight_unit Weight Unit
    #' @param length Defines product's length
    #' @param width Defines product's width
    #' @param height Defines product's height
    #' @param dimensions_unit Weight Unit
    #' @param shipping_label_cost Cost of the shipping label.
    #' @param shipping_label_currency Currency code for the shipping label cost (3-letter ISO code).
    #' @param revenue_eligibility Revenue eligibility flag.
    #' @param ship_from_country Country code the shipment is sent from (2-letter ISO code).
    #' @param ship_to_country Country code the shipment is sent to (2-letter ISO code).
    #' @param incoterm International commercial term for the shipment (e.g., DAP, DDP).
    #' @param duty_amount Duty amount for international shipment.
    #' @param duty_currency Currency code for the duty amount (3-letter ISO code).
    #' @param enable_cache If the value is 'true' and order exist in our cache, we will use order.info from cache to prepare shipment items.. Default to FALSE.
    #' @param use_latest_api_version Use the latest platform API version. Default to FALSE.
    #' @param idempotency_key A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong>
    #' @param ... Other optional arguments.
    initialize = function(`order_id` = NULL, `warehouse_id` = NULL, `store_id` = NULL, `shipment_provider` = NULL, `shipping_method` = NULL, `items` = NULL, `tracking_numbers` = NULL, `tracking_link` = NULL, `is_shipped` = TRUE, `send_notifications` = FALSE, `adjust_stock` = FALSE, `check_process_status` = FALSE, `tracking_provider` = NULL, `admin_comment` = NULL, `mail_class` = NULL, `ship_date` = NULL, `weight` = NULL, `weight_unit` = NULL, `length` = NULL, `width` = NULL, `height` = NULL, `dimensions_unit` = NULL, `shipping_label_cost` = NULL, `shipping_label_currency` = NULL, `revenue_eligibility` = NULL, `ship_from_country` = NULL, `ship_to_country` = NULL, `incoterm` = NULL, `duty_amount` = NULL, `duty_currency` = NULL, `enable_cache` = FALSE, `use_latest_api_version` = FALSE, `idempotency_key` = NULL, ...) {
      if (!is.null(`order_id`)) {
        if (!(is.character(`order_id`) && length(`order_id`) == 1)) {
          stop(paste("Error! Invalid data for `order_id`. Must be a string:", `order_id`))
        }
        self$`order_id` <- `order_id`
      }
      if (!is.null(`warehouse_id`)) {
        if (!(is.character(`warehouse_id`) && length(`warehouse_id`) == 1)) {
          stop(paste("Error! Invalid data for `warehouse_id`. Must be a string:", `warehouse_id`))
        }
        self$`warehouse_id` <- `warehouse_id`
      }
      if (!is.null(`store_id`)) {
        if (!(is.character(`store_id`) && length(`store_id`) == 1)) {
          stop(paste("Error! Invalid data for `store_id`. Must be a string:", `store_id`))
        }
        self$`store_id` <- `store_id`
      }
      if (!is.null(`shipment_provider`)) {
        if (!(is.character(`shipment_provider`) && length(`shipment_provider`) == 1)) {
          stop(paste("Error! Invalid data for `shipment_provider`. Must be a string:", `shipment_provider`))
        }
        self$`shipment_provider` <- `shipment_provider`
      }
      if (!is.null(`shipping_method`)) {
        if (!(is.character(`shipping_method`) && length(`shipping_method`) == 1)) {
          stop(paste("Error! Invalid data for `shipping_method`. Must be a string:", `shipping_method`))
        }
        self$`shipping_method` <- `shipping_method`
      }
      if (!is.null(`items`)) {
        stopifnot(is.vector(`items`), length(`items`) != 0)
        sapply(`items`, function(x) stopifnot(R6::is.R6(x)))
        self$`items` <- `items`
      }
      if (!is.null(`tracking_numbers`)) {
        stopifnot(is.vector(`tracking_numbers`), length(`tracking_numbers`) != 0)
        sapply(`tracking_numbers`, function(x) stopifnot(R6::is.R6(x)))
        self$`tracking_numbers` <- `tracking_numbers`
      }
      if (!is.null(`tracking_link`)) {
        if (!(is.character(`tracking_link`) && length(`tracking_link`) == 1)) {
          stop(paste("Error! Invalid data for `tracking_link`. Must be a string:", `tracking_link`))
        }
        self$`tracking_link` <- `tracking_link`
      }
      if (!is.null(`is_shipped`)) {
        if (!(is.logical(`is_shipped`) && length(`is_shipped`) == 1)) {
          stop(paste("Error! Invalid data for `is_shipped`. Must be a boolean:", `is_shipped`))
        }
        self$`is_shipped` <- `is_shipped`
      }
      if (!is.null(`send_notifications`)) {
        if (!(is.logical(`send_notifications`) && length(`send_notifications`) == 1)) {
          stop(paste("Error! Invalid data for `send_notifications`. Must be a boolean:", `send_notifications`))
        }
        self$`send_notifications` <- `send_notifications`
      }
      if (!is.null(`adjust_stock`)) {
        if (!(is.logical(`adjust_stock`) && length(`adjust_stock`) == 1)) {
          stop(paste("Error! Invalid data for `adjust_stock`. Must be a boolean:", `adjust_stock`))
        }
        self$`adjust_stock` <- `adjust_stock`
      }
      if (!is.null(`check_process_status`)) {
        if (!(is.logical(`check_process_status`) && length(`check_process_status`) == 1)) {
          stop(paste("Error! Invalid data for `check_process_status`. Must be a boolean:", `check_process_status`))
        }
        self$`check_process_status` <- `check_process_status`
      }
      if (!is.null(`tracking_provider`)) {
        if (!(is.character(`tracking_provider`) && length(`tracking_provider`) == 1)) {
          stop(paste("Error! Invalid data for `tracking_provider`. Must be a string:", `tracking_provider`))
        }
        self$`tracking_provider` <- `tracking_provider`
      }
      if (!is.null(`admin_comment`)) {
        if (!(is.character(`admin_comment`) && length(`admin_comment`) == 1)) {
          stop(paste("Error! Invalid data for `admin_comment`. Must be a string:", `admin_comment`))
        }
        self$`admin_comment` <- `admin_comment`
      }
      if (!is.null(`mail_class`)) {
        if (!(is.character(`mail_class`) && length(`mail_class`) == 1)) {
          stop(paste("Error! Invalid data for `mail_class`. Must be a string:", `mail_class`))
        }
        self$`mail_class` <- `mail_class`
      }
      if (!is.null(`ship_date`)) {
        if (!(is.character(`ship_date`) && length(`ship_date`) == 1)) {
          stop(paste("Error! Invalid data for `ship_date`. Must be a string:", `ship_date`))
        }
        self$`ship_date` <- `ship_date`
      }
      if (!is.null(`weight`)) {
        self$`weight` <- `weight`
      }
      if (!is.null(`weight_unit`)) {
        if (!(is.character(`weight_unit`) && length(`weight_unit`) == 1)) {
          stop(paste("Error! Invalid data for `weight_unit`. Must be a string:", `weight_unit`))
        }
        self$`weight_unit` <- `weight_unit`
      }
      if (!is.null(`length`)) {
        self$`length` <- `length`
      }
      if (!is.null(`width`)) {
        self$`width` <- `width`
      }
      if (!is.null(`height`)) {
        self$`height` <- `height`
      }
      if (!is.null(`dimensions_unit`)) {
        if (!(is.character(`dimensions_unit`) && length(`dimensions_unit`) == 1)) {
          stop(paste("Error! Invalid data for `dimensions_unit`. Must be a string:", `dimensions_unit`))
        }
        self$`dimensions_unit` <- `dimensions_unit`
      }
      if (!is.null(`shipping_label_cost`)) {
        self$`shipping_label_cost` <- `shipping_label_cost`
      }
      if (!is.null(`shipping_label_currency`)) {
        if (!(is.character(`shipping_label_currency`) && length(`shipping_label_currency`) == 1)) {
          stop(paste("Error! Invalid data for `shipping_label_currency`. Must be a string:", `shipping_label_currency`))
        }
        self$`shipping_label_currency` <- `shipping_label_currency`
      }
      if (!is.null(`revenue_eligibility`)) {
        if (!(is.logical(`revenue_eligibility`) && length(`revenue_eligibility`) == 1)) {
          stop(paste("Error! Invalid data for `revenue_eligibility`. Must be a boolean:", `revenue_eligibility`))
        }
        self$`revenue_eligibility` <- `revenue_eligibility`
      }
      if (!is.null(`ship_from_country`)) {
        if (!(is.character(`ship_from_country`) && length(`ship_from_country`) == 1)) {
          stop(paste("Error! Invalid data for `ship_from_country`. Must be a string:", `ship_from_country`))
        }
        self$`ship_from_country` <- `ship_from_country`
      }
      if (!is.null(`ship_to_country`)) {
        if (!(is.character(`ship_to_country`) && length(`ship_to_country`) == 1)) {
          stop(paste("Error! Invalid data for `ship_to_country`. Must be a string:", `ship_to_country`))
        }
        self$`ship_to_country` <- `ship_to_country`
      }
      if (!is.null(`incoterm`)) {
        if (!(is.character(`incoterm`) && length(`incoterm`) == 1)) {
          stop(paste("Error! Invalid data for `incoterm`. Must be a string:", `incoterm`))
        }
        self$`incoterm` <- `incoterm`
      }
      if (!is.null(`duty_amount`)) {
        self$`duty_amount` <- `duty_amount`
      }
      if (!is.null(`duty_currency`)) {
        if (!(is.character(`duty_currency`) && length(`duty_currency`) == 1)) {
          stop(paste("Error! Invalid data for `duty_currency`. Must be a string:", `duty_currency`))
        }
        self$`duty_currency` <- `duty_currency`
      }
      if (!is.null(`enable_cache`)) {
        if (!(is.logical(`enable_cache`) && length(`enable_cache`) == 1)) {
          stop(paste("Error! Invalid data for `enable_cache`. Must be a boolean:", `enable_cache`))
        }
        self$`enable_cache` <- `enable_cache`
      }
      if (!is.null(`use_latest_api_version`)) {
        if (!(is.logical(`use_latest_api_version`) && length(`use_latest_api_version`) == 1)) {
          stop(paste("Error! Invalid data for `use_latest_api_version`. Must be a boolean:", `use_latest_api_version`))
        }
        self$`use_latest_api_version` <- `use_latest_api_version`
      }
      if (!is.null(`idempotency_key`)) {
        if (!(is.character(`idempotency_key`) && length(`idempotency_key`) == 1)) {
          stop(paste("Error! Invalid data for `idempotency_key`. Must be a string:", `idempotency_key`))
        }
        self$`idempotency_key` <- `idempotency_key`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return OrderShipmentAdd as a base R list.
    #' @examples
    #' # convert array of OrderShipmentAdd (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert OrderShipmentAdd to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      OrderShipmentAddObject <- list()
      if (!is.null(self$`order_id`)) {
        OrderShipmentAddObject[["order_id"]] <-
          self$`order_id`
      }
      if (!is.null(self$`warehouse_id`)) {
        OrderShipmentAddObject[["warehouse_id"]] <-
          self$`warehouse_id`
      }
      if (!is.null(self$`store_id`)) {
        OrderShipmentAddObject[["store_id"]] <-
          self$`store_id`
      }
      if (!is.null(self$`shipment_provider`)) {
        OrderShipmentAddObject[["shipment_provider"]] <-
          self$`shipment_provider`
      }
      if (!is.null(self$`shipping_method`)) {
        OrderShipmentAddObject[["shipping_method"]] <-
          self$`shipping_method`
      }
      if (!is.null(self$`items`)) {
        OrderShipmentAddObject[["items"]] <-
          lapply(self$`items`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`tracking_numbers`)) {
        OrderShipmentAddObject[["tracking_numbers"]] <-
          lapply(self$`tracking_numbers`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`tracking_link`)) {
        OrderShipmentAddObject[["tracking_link"]] <-
          self$`tracking_link`
      }
      if (!is.null(self$`is_shipped`)) {
        OrderShipmentAddObject[["is_shipped"]] <-
          self$`is_shipped`
      }
      if (!is.null(self$`send_notifications`)) {
        OrderShipmentAddObject[["send_notifications"]] <-
          self$`send_notifications`
      }
      if (!is.null(self$`adjust_stock`)) {
        OrderShipmentAddObject[["adjust_stock"]] <-
          self$`adjust_stock`
      }
      if (!is.null(self$`check_process_status`)) {
        OrderShipmentAddObject[["check_process_status"]] <-
          self$`check_process_status`
      }
      if (!is.null(self$`tracking_provider`)) {
        OrderShipmentAddObject[["tracking_provider"]] <-
          self$`tracking_provider`
      }
      if (!is.null(self$`admin_comment`)) {
        OrderShipmentAddObject[["admin_comment"]] <-
          self$`admin_comment`
      }
      if (!is.null(self$`mail_class`)) {
        OrderShipmentAddObject[["mail_class"]] <-
          self$`mail_class`
      }
      if (!is.null(self$`ship_date`)) {
        OrderShipmentAddObject[["ship_date"]] <-
          self$`ship_date`
      }
      if (!is.null(self$`weight`)) {
        OrderShipmentAddObject[["weight"]] <-
          self$`weight`
      }
      if (!is.null(self$`weight_unit`)) {
        OrderShipmentAddObject[["weight_unit"]] <-
          self$`weight_unit`
      }
      if (!is.null(self$`length`)) {
        OrderShipmentAddObject[["length"]] <-
          self$`length`
      }
      if (!is.null(self$`width`)) {
        OrderShipmentAddObject[["width"]] <-
          self$`width`
      }
      if (!is.null(self$`height`)) {
        OrderShipmentAddObject[["height"]] <-
          self$`height`
      }
      if (!is.null(self$`dimensions_unit`)) {
        OrderShipmentAddObject[["dimensions_unit"]] <-
          self$`dimensions_unit`
      }
      if (!is.null(self$`shipping_label_cost`)) {
        OrderShipmentAddObject[["shipping_label_cost"]] <-
          self$`shipping_label_cost`
      }
      if (!is.null(self$`shipping_label_currency`)) {
        OrderShipmentAddObject[["shipping_label_currency"]] <-
          self$`shipping_label_currency`
      }
      if (!is.null(self$`revenue_eligibility`)) {
        OrderShipmentAddObject[["revenue_eligibility"]] <-
          self$`revenue_eligibility`
      }
      if (!is.null(self$`ship_from_country`)) {
        OrderShipmentAddObject[["ship_from_country"]] <-
          self$`ship_from_country`
      }
      if (!is.null(self$`ship_to_country`)) {
        OrderShipmentAddObject[["ship_to_country"]] <-
          self$`ship_to_country`
      }
      if (!is.null(self$`incoterm`)) {
        OrderShipmentAddObject[["incoterm"]] <-
          self$`incoterm`
      }
      if (!is.null(self$`duty_amount`)) {
        OrderShipmentAddObject[["duty_amount"]] <-
          self$`duty_amount`
      }
      if (!is.null(self$`duty_currency`)) {
        OrderShipmentAddObject[["duty_currency"]] <-
          self$`duty_currency`
      }
      if (!is.null(self$`enable_cache`)) {
        OrderShipmentAddObject[["enable_cache"]] <-
          self$`enable_cache`
      }
      if (!is.null(self$`use_latest_api_version`)) {
        OrderShipmentAddObject[["use_latest_api_version"]] <-
          self$`use_latest_api_version`
      }
      if (!is.null(self$`idempotency_key`)) {
        OrderShipmentAddObject[["idempotency_key"]] <-
          self$`idempotency_key`
      }
      return(OrderShipmentAddObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderShipmentAdd
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderShipmentAdd
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`order_id`)) {
        self$`order_id` <- this_object$`order_id`
      }
      if (!is.null(this_object$`warehouse_id`)) {
        self$`warehouse_id` <- this_object$`warehouse_id`
      }
      if (!is.null(this_object$`store_id`)) {
        self$`store_id` <- this_object$`store_id`
      }
      if (!is.null(this_object$`shipment_provider`)) {
        self$`shipment_provider` <- this_object$`shipment_provider`
      }
      if (!is.null(this_object$`shipping_method`)) {
        self$`shipping_method` <- this_object$`shipping_method`
      }
      if (!is.null(this_object$`items`)) {
        self$`items` <- ApiClient$new()$deserializeObj(this_object$`items`, "array[OrderShipmentAddItemsInner]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`tracking_numbers`)) {
        self$`tracking_numbers` <- ApiClient$new()$deserializeObj(this_object$`tracking_numbers`, "array[OrderShipmentAddTrackingNumbersInner]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`tracking_link`)) {
        self$`tracking_link` <- this_object$`tracking_link`
      }
      if (!is.null(this_object$`is_shipped`)) {
        self$`is_shipped` <- this_object$`is_shipped`
      }
      if (!is.null(this_object$`send_notifications`)) {
        self$`send_notifications` <- this_object$`send_notifications`
      }
      if (!is.null(this_object$`adjust_stock`)) {
        self$`adjust_stock` <- this_object$`adjust_stock`
      }
      if (!is.null(this_object$`check_process_status`)) {
        self$`check_process_status` <- this_object$`check_process_status`
      }
      if (!is.null(this_object$`tracking_provider`)) {
        self$`tracking_provider` <- this_object$`tracking_provider`
      }
      if (!is.null(this_object$`admin_comment`)) {
        self$`admin_comment` <- this_object$`admin_comment`
      }
      if (!is.null(this_object$`mail_class`)) {
        self$`mail_class` <- this_object$`mail_class`
      }
      if (!is.null(this_object$`ship_date`)) {
        self$`ship_date` <- this_object$`ship_date`
      }
      if (!is.null(this_object$`weight`)) {
        self$`weight` <- this_object$`weight`
      }
      if (!is.null(this_object$`weight_unit`)) {
        self$`weight_unit` <- this_object$`weight_unit`
      }
      if (!is.null(this_object$`length`)) {
        self$`length` <- this_object$`length`
      }
      if (!is.null(this_object$`width`)) {
        self$`width` <- this_object$`width`
      }
      if (!is.null(this_object$`height`)) {
        self$`height` <- this_object$`height`
      }
      if (!is.null(this_object$`dimensions_unit`)) {
        self$`dimensions_unit` <- this_object$`dimensions_unit`
      }
      if (!is.null(this_object$`shipping_label_cost`)) {
        self$`shipping_label_cost` <- this_object$`shipping_label_cost`
      }
      if (!is.null(this_object$`shipping_label_currency`)) {
        self$`shipping_label_currency` <- this_object$`shipping_label_currency`
      }
      if (!is.null(this_object$`revenue_eligibility`)) {
        self$`revenue_eligibility` <- this_object$`revenue_eligibility`
      }
      if (!is.null(this_object$`ship_from_country`)) {
        self$`ship_from_country` <- this_object$`ship_from_country`
      }
      if (!is.null(this_object$`ship_to_country`)) {
        self$`ship_to_country` <- this_object$`ship_to_country`
      }
      if (!is.null(this_object$`incoterm`)) {
        self$`incoterm` <- this_object$`incoterm`
      }
      if (!is.null(this_object$`duty_amount`)) {
        self$`duty_amount` <- this_object$`duty_amount`
      }
      if (!is.null(this_object$`duty_currency`)) {
        self$`duty_currency` <- this_object$`duty_currency`
      }
      if (!is.null(this_object$`enable_cache`)) {
        self$`enable_cache` <- this_object$`enable_cache`
      }
      if (!is.null(this_object$`use_latest_api_version`)) {
        self$`use_latest_api_version` <- this_object$`use_latest_api_version`
      }
      if (!is.null(this_object$`idempotency_key`)) {
        self$`idempotency_key` <- this_object$`idempotency_key`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return OrderShipmentAdd in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderShipmentAdd
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderShipmentAdd
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`order_id` <- this_object$`order_id`
      self$`warehouse_id` <- this_object$`warehouse_id`
      self$`store_id` <- this_object$`store_id`
      self$`shipment_provider` <- this_object$`shipment_provider`
      self$`shipping_method` <- this_object$`shipping_method`
      self$`items` <- ApiClient$new()$deserializeObj(this_object$`items`, "array[OrderShipmentAddItemsInner]", loadNamespace("openapi"))
      self$`tracking_numbers` <- ApiClient$new()$deserializeObj(this_object$`tracking_numbers`, "array[OrderShipmentAddTrackingNumbersInner]", loadNamespace("openapi"))
      self$`tracking_link` <- this_object$`tracking_link`
      self$`is_shipped` <- this_object$`is_shipped`
      self$`send_notifications` <- this_object$`send_notifications`
      self$`adjust_stock` <- this_object$`adjust_stock`
      self$`check_process_status` <- this_object$`check_process_status`
      self$`tracking_provider` <- this_object$`tracking_provider`
      self$`admin_comment` <- this_object$`admin_comment`
      self$`mail_class` <- this_object$`mail_class`
      self$`ship_date` <- this_object$`ship_date`
      self$`weight` <- this_object$`weight`
      self$`weight_unit` <- this_object$`weight_unit`
      self$`length` <- this_object$`length`
      self$`width` <- this_object$`width`
      self$`height` <- this_object$`height`
      self$`dimensions_unit` <- this_object$`dimensions_unit`
      self$`shipping_label_cost` <- this_object$`shipping_label_cost`
      self$`shipping_label_currency` <- this_object$`shipping_label_currency`
      self$`revenue_eligibility` <- this_object$`revenue_eligibility`
      self$`ship_from_country` <- this_object$`ship_from_country`
      self$`ship_to_country` <- this_object$`ship_to_country`
      self$`incoterm` <- this_object$`incoterm`
      self$`duty_amount` <- this_object$`duty_amount`
      self$`duty_currency` <- this_object$`duty_currency`
      self$`enable_cache` <- this_object$`enable_cache`
      self$`use_latest_api_version` <- this_object$`use_latest_api_version`
      self$`idempotency_key` <- this_object$`idempotency_key`
      self
    },

    #' @description
    #' Validate JSON input with respect to OrderShipmentAdd and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of OrderShipmentAdd
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# OrderShipmentAdd$unlock()
#
## Below is an example to define the print function
# OrderShipmentAdd$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# OrderShipmentAdd$lock()

