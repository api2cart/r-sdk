#' Create a new ProductOption
#'
#' @description
#' ProductOption Class
#'
#' @docType class
#' @title ProductOption
#' @description ProductOption Class
#' @format An \code{R6Class} generator object
#' @field id  character [optional]
#' @field product_option_id  character [optional]
#' @field name  character [optional]
#' @field description  character [optional]
#' @field sort_order  integer [optional]
#' @field type  character [optional]
#' @field required  character [optional]
#' @field available  character [optional]
#' @field used_in_combination  character [optional]
#' @field option_items  list(\link{ProductOptionItem}) [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductOption <- R6::R6Class(
  "ProductOption",
  public = list(
    `id` = NULL,
    `product_option_id` = NULL,
    `name` = NULL,
    `description` = NULL,
    `sort_order` = NULL,
    `type` = NULL,
    `required` = NULL,
    `available` = NULL,
    `used_in_combination` = NULL,
    `option_items` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new ProductOption class.
    #'
    #' @param id id
    #' @param product_option_id product_option_id
    #' @param name name
    #' @param description description
    #' @param sort_order sort_order
    #' @param type type
    #' @param required required
    #' @param available available
    #' @param used_in_combination used_in_combination
    #' @param option_items option_items
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `product_option_id` = NULL, `name` = NULL, `description` = NULL, `sort_order` = NULL, `type` = NULL, `required` = NULL, `available` = NULL, `used_in_combination` = NULL, `option_items` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`product_option_id`)) {
        if (!(is.character(`product_option_id`) && length(`product_option_id`) == 1)) {
          stop(paste("Error! Invalid data for `product_option_id`. Must be a string:", `product_option_id`))
        }
        self$`product_option_id` <- `product_option_id`
      }
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`description`)) {
        if (!(is.character(`description`) && length(`description`) == 1)) {
          stop(paste("Error! Invalid data for `description`. Must be a string:", `description`))
        }
        self$`description` <- `description`
      }
      if (!is.null(`sort_order`)) {
        if (!(is.numeric(`sort_order`) && length(`sort_order`) == 1)) {
          stop(paste("Error! Invalid data for `sort_order`. Must be an integer:", `sort_order`))
        }
        self$`sort_order` <- `sort_order`
      }
      if (!is.null(`type`)) {
        if (!(is.character(`type`) && length(`type`) == 1)) {
          stop(paste("Error! Invalid data for `type`. Must be a string:", `type`))
        }
        self$`type` <- `type`
      }
      if (!is.null(`required`)) {
        if (!(is.logical(`required`) && length(`required`) == 1)) {
          stop(paste("Error! Invalid data for `required`. Must be a boolean:", `required`))
        }
        self$`required` <- `required`
      }
      if (!is.null(`available`)) {
        if (!(is.logical(`available`) && length(`available`) == 1)) {
          stop(paste("Error! Invalid data for `available`. Must be a boolean:", `available`))
        }
        self$`available` <- `available`
      }
      if (!is.null(`used_in_combination`)) {
        if (!(is.logical(`used_in_combination`) && length(`used_in_combination`) == 1)) {
          stop(paste("Error! Invalid data for `used_in_combination`. Must be a boolean:", `used_in_combination`))
        }
        self$`used_in_combination` <- `used_in_combination`
      }
      if (!is.null(`option_items`)) {
        stopifnot(is.vector(`option_items`), length(`option_items`) != 0)
        sapply(`option_items`, function(x) stopifnot(R6::is.R6(x)))
        self$`option_items` <- `option_items`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductOption as a base R list.
    #' @examples
    #' # convert array of ProductOption (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductOption to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductOptionObject <- list()
      if (!is.null(self$`id`)) {
        ProductOptionObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`product_option_id`)) {
        ProductOptionObject[["product_option_id"]] <-
          self$`product_option_id`
      }
      if (!is.null(self$`name`)) {
        ProductOptionObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`description`)) {
        ProductOptionObject[["description"]] <-
          self$`description`
      }
      if (!is.null(self$`sort_order`)) {
        ProductOptionObject[["sort_order"]] <-
          self$`sort_order`
      }
      if (!is.null(self$`type`)) {
        ProductOptionObject[["type"]] <-
          self$`type`
      }
      if (!is.null(self$`required`)) {
        ProductOptionObject[["required"]] <-
          self$`required`
      }
      if (!is.null(self$`available`)) {
        ProductOptionObject[["available"]] <-
          self$`available`
      }
      if (!is.null(self$`used_in_combination`)) {
        ProductOptionObject[["used_in_combination"]] <-
          self$`used_in_combination`
      }
      if (!is.null(self$`option_items`)) {
        ProductOptionObject[["option_items"]] <-
          lapply(self$`option_items`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`additional_fields`)) {
        ProductOptionObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        ProductOptionObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(ProductOptionObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductOption
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductOption
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`product_option_id`)) {
        self$`product_option_id` <- this_object$`product_option_id`
      }
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`description`)) {
        self$`description` <- this_object$`description`
      }
      if (!is.null(this_object$`sort_order`)) {
        self$`sort_order` <- this_object$`sort_order`
      }
      if (!is.null(this_object$`type`)) {
        self$`type` <- this_object$`type`
      }
      if (!is.null(this_object$`required`)) {
        self$`required` <- this_object$`required`
      }
      if (!is.null(this_object$`available`)) {
        self$`available` <- this_object$`available`
      }
      if (!is.null(this_object$`used_in_combination`)) {
        self$`used_in_combination` <- this_object$`used_in_combination`
      }
      if (!is.null(this_object$`option_items`)) {
        self$`option_items` <- ApiClient$new()$deserializeObj(this_object$`option_items`, "array[ProductOptionItem]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductOption in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductOption
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductOption
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`product_option_id` <- this_object$`product_option_id`
      self$`name` <- this_object$`name`
      self$`description` <- this_object$`description`
      self$`sort_order` <- this_object$`sort_order`
      self$`type` <- this_object$`type`
      self$`required` <- this_object$`required`
      self$`available` <- this_object$`available`
      self$`used_in_combination` <- this_object$`used_in_combination`
      self$`option_items` <- ApiClient$new()$deserializeObj(this_object$`option_items`, "array[ProductOptionItem]", loadNamespace("openapi"))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductOption and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductOption
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductOption$unlock()
#
## Below is an example to define the print function
# ProductOption$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductOption$lock()

