#' Create a new OrderShipmentEventAdd
#'
#' @description
#' OrderShipmentEventAdd Class
#'
#' @docType class
#' @title OrderShipmentEventAdd
#' @description OrderShipmentEventAdd Class
#' @format An \code{R6Class} generator object
#' @field shipment_id Defines the shipment to which the tracking event will be added character
#' @field order_id Defines the order to which the shipment belongs character [optional]
#' @field status Defines the tracking event status (e.g. in_transit, delivered, out_for_delivery) character
#' @field store_id Store Id character [optional]
#' @field address_1 Specifies the street address of the event location character [optional]
#' @field city Specifies city character [optional]
#' @field country Specifies ISO code or name of country character [optional]
#' @field state Specifies ISO code or name of state character [optional]
#' @field postcode Specifies postcode character [optional]
#' @field message Defines a message associated with the tracking event. character [optional]
#' @field latitude Latitude coordinate of the event location. numeric [optional]
#' @field longitude Longitude coordinate of the event location. numeric [optional]
#' @field created_at Defines the date of entity creation character [optional]
#' @field estimated_delivery_at Estimated delivery date and time in ISO 8601 format. character [optional]
#' @field idempotency_key A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong> character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
OrderShipmentEventAdd <- R6::R6Class(
  "OrderShipmentEventAdd",
  public = list(
    `shipment_id` = NULL,
    `order_id` = NULL,
    `status` = NULL,
    `store_id` = NULL,
    `address_1` = NULL,
    `city` = NULL,
    `country` = NULL,
    `state` = NULL,
    `postcode` = NULL,
    `message` = NULL,
    `latitude` = NULL,
    `longitude` = NULL,
    `created_at` = NULL,
    `estimated_delivery_at` = NULL,
    `idempotency_key` = NULL,

    #' @description
    #' Initialize a new OrderShipmentEventAdd class.
    #'
    #' @param shipment_id Defines the shipment to which the tracking event will be added
    #' @param status Defines the tracking event status (e.g. in_transit, delivered, out_for_delivery)
    #' @param order_id Defines the order to which the shipment belongs
    #' @param store_id Store Id
    #' @param address_1 Specifies the street address of the event location
    #' @param city Specifies city
    #' @param country Specifies ISO code or name of country
    #' @param state Specifies ISO code or name of state
    #' @param postcode Specifies postcode
    #' @param message Defines a message associated with the tracking event.
    #' @param latitude Latitude coordinate of the event location.
    #' @param longitude Longitude coordinate of the event location.
    #' @param created_at Defines the date of entity creation
    #' @param estimated_delivery_at Estimated delivery date and time in ISO 8601 format.
    #' @param idempotency_key A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong>
    #' @param ... Other optional arguments.
    initialize = function(`shipment_id`, `status`, `order_id` = NULL, `store_id` = NULL, `address_1` = NULL, `city` = NULL, `country` = NULL, `state` = NULL, `postcode` = NULL, `message` = NULL, `latitude` = NULL, `longitude` = NULL, `created_at` = NULL, `estimated_delivery_at` = NULL, `idempotency_key` = NULL, ...) {
      if (!missing(`shipment_id`)) {
        if (!(is.character(`shipment_id`) && length(`shipment_id`) == 1)) {
          stop(paste("Error! Invalid data for `shipment_id`. Must be a string:", `shipment_id`))
        }
        self$`shipment_id` <- `shipment_id`
      }
      if (!missing(`status`)) {
        if (!(is.character(`status`) && length(`status`) == 1)) {
          stop(paste("Error! Invalid data for `status`. Must be a string:", `status`))
        }
        self$`status` <- `status`
      }
      if (!is.null(`order_id`)) {
        if (!(is.character(`order_id`) && length(`order_id`) == 1)) {
          stop(paste("Error! Invalid data for `order_id`. Must be a string:", `order_id`))
        }
        self$`order_id` <- `order_id`
      }
      if (!is.null(`store_id`)) {
        if (!(is.character(`store_id`) && length(`store_id`) == 1)) {
          stop(paste("Error! Invalid data for `store_id`. Must be a string:", `store_id`))
        }
        self$`store_id` <- `store_id`
      }
      if (!is.null(`address_1`)) {
        if (!(is.character(`address_1`) && length(`address_1`) == 1)) {
          stop(paste("Error! Invalid data for `address_1`. Must be a string:", `address_1`))
        }
        self$`address_1` <- `address_1`
      }
      if (!is.null(`city`)) {
        if (!(is.character(`city`) && length(`city`) == 1)) {
          stop(paste("Error! Invalid data for `city`. Must be a string:", `city`))
        }
        self$`city` <- `city`
      }
      if (!is.null(`country`)) {
        if (!(is.character(`country`) && length(`country`) == 1)) {
          stop(paste("Error! Invalid data for `country`. Must be a string:", `country`))
        }
        self$`country` <- `country`
      }
      if (!is.null(`state`)) {
        if (!(is.character(`state`) && length(`state`) == 1)) {
          stop(paste("Error! Invalid data for `state`. Must be a string:", `state`))
        }
        self$`state` <- `state`
      }
      if (!is.null(`postcode`)) {
        if (!(is.character(`postcode`) && length(`postcode`) == 1)) {
          stop(paste("Error! Invalid data for `postcode`. Must be a string:", `postcode`))
        }
        self$`postcode` <- `postcode`
      }
      if (!is.null(`message`)) {
        if (!(is.character(`message`) && length(`message`) == 1)) {
          stop(paste("Error! Invalid data for `message`. Must be a string:", `message`))
        }
        self$`message` <- `message`
      }
      if (!is.null(`latitude`)) {
        self$`latitude` <- `latitude`
      }
      if (!is.null(`longitude`)) {
        self$`longitude` <- `longitude`
      }
      if (!is.null(`created_at`)) {
        if (!(is.character(`created_at`) && length(`created_at`) == 1)) {
          stop(paste("Error! Invalid data for `created_at`. Must be a string:", `created_at`))
        }
        self$`created_at` <- `created_at`
      }
      if (!is.null(`estimated_delivery_at`)) {
        if (!(is.character(`estimated_delivery_at`) && length(`estimated_delivery_at`) == 1)) {
          stop(paste("Error! Invalid data for `estimated_delivery_at`. Must be a string:", `estimated_delivery_at`))
        }
        self$`estimated_delivery_at` <- `estimated_delivery_at`
      }
      if (!is.null(`idempotency_key`)) {
        if (!(is.character(`idempotency_key`) && length(`idempotency_key`) == 1)) {
          stop(paste("Error! Invalid data for `idempotency_key`. Must be a string:", `idempotency_key`))
        }
        self$`idempotency_key` <- `idempotency_key`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return OrderShipmentEventAdd as a base R list.
    #' @examples
    #' # convert array of OrderShipmentEventAdd (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert OrderShipmentEventAdd to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      OrderShipmentEventAddObject <- list()
      if (!is.null(self$`shipment_id`)) {
        OrderShipmentEventAddObject[["shipment_id"]] <-
          self$`shipment_id`
      }
      if (!is.null(self$`order_id`)) {
        OrderShipmentEventAddObject[["order_id"]] <-
          self$`order_id`
      }
      if (!is.null(self$`status`)) {
        OrderShipmentEventAddObject[["status"]] <-
          self$`status`
      }
      if (!is.null(self$`store_id`)) {
        OrderShipmentEventAddObject[["store_id"]] <-
          self$`store_id`
      }
      if (!is.null(self$`address_1`)) {
        OrderShipmentEventAddObject[["address_1"]] <-
          self$`address_1`
      }
      if (!is.null(self$`city`)) {
        OrderShipmentEventAddObject[["city"]] <-
          self$`city`
      }
      if (!is.null(self$`country`)) {
        OrderShipmentEventAddObject[["country"]] <-
          self$`country`
      }
      if (!is.null(self$`state`)) {
        OrderShipmentEventAddObject[["state"]] <-
          self$`state`
      }
      if (!is.null(self$`postcode`)) {
        OrderShipmentEventAddObject[["postcode"]] <-
          self$`postcode`
      }
      if (!is.null(self$`message`)) {
        OrderShipmentEventAddObject[["message"]] <-
          self$`message`
      }
      if (!is.null(self$`latitude`)) {
        OrderShipmentEventAddObject[["latitude"]] <-
          self$`latitude`
      }
      if (!is.null(self$`longitude`)) {
        OrderShipmentEventAddObject[["longitude"]] <-
          self$`longitude`
      }
      if (!is.null(self$`created_at`)) {
        OrderShipmentEventAddObject[["created_at"]] <-
          self$`created_at`
      }
      if (!is.null(self$`estimated_delivery_at`)) {
        OrderShipmentEventAddObject[["estimated_delivery_at"]] <-
          self$`estimated_delivery_at`
      }
      if (!is.null(self$`idempotency_key`)) {
        OrderShipmentEventAddObject[["idempotency_key"]] <-
          self$`idempotency_key`
      }
      return(OrderShipmentEventAddObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderShipmentEventAdd
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderShipmentEventAdd
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`shipment_id`)) {
        self$`shipment_id` <- this_object$`shipment_id`
      }
      if (!is.null(this_object$`order_id`)) {
        self$`order_id` <- this_object$`order_id`
      }
      if (!is.null(this_object$`status`)) {
        self$`status` <- this_object$`status`
      }
      if (!is.null(this_object$`store_id`)) {
        self$`store_id` <- this_object$`store_id`
      }
      if (!is.null(this_object$`address_1`)) {
        self$`address_1` <- this_object$`address_1`
      }
      if (!is.null(this_object$`city`)) {
        self$`city` <- this_object$`city`
      }
      if (!is.null(this_object$`country`)) {
        self$`country` <- this_object$`country`
      }
      if (!is.null(this_object$`state`)) {
        self$`state` <- this_object$`state`
      }
      if (!is.null(this_object$`postcode`)) {
        self$`postcode` <- this_object$`postcode`
      }
      if (!is.null(this_object$`message`)) {
        self$`message` <- this_object$`message`
      }
      if (!is.null(this_object$`latitude`)) {
        self$`latitude` <- this_object$`latitude`
      }
      if (!is.null(this_object$`longitude`)) {
        self$`longitude` <- this_object$`longitude`
      }
      if (!is.null(this_object$`created_at`)) {
        self$`created_at` <- this_object$`created_at`
      }
      if (!is.null(this_object$`estimated_delivery_at`)) {
        self$`estimated_delivery_at` <- this_object$`estimated_delivery_at`
      }
      if (!is.null(this_object$`idempotency_key`)) {
        self$`idempotency_key` <- this_object$`idempotency_key`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return OrderShipmentEventAdd in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderShipmentEventAdd
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderShipmentEventAdd
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`shipment_id` <- this_object$`shipment_id`
      self$`order_id` <- this_object$`order_id`
      self$`status` <- this_object$`status`
      self$`store_id` <- this_object$`store_id`
      self$`address_1` <- this_object$`address_1`
      self$`city` <- this_object$`city`
      self$`country` <- this_object$`country`
      self$`state` <- this_object$`state`
      self$`postcode` <- this_object$`postcode`
      self$`message` <- this_object$`message`
      self$`latitude` <- this_object$`latitude`
      self$`longitude` <- this_object$`longitude`
      self$`created_at` <- this_object$`created_at`
      self$`estimated_delivery_at` <- this_object$`estimated_delivery_at`
      self$`idempotency_key` <- this_object$`idempotency_key`
      self
    },

    #' @description
    #' Validate JSON input with respect to OrderShipmentEventAdd and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
      # check the required field `shipment_id`
      if (!is.null(input_json$`shipment_id`)) {
        if (!(is.character(input_json$`shipment_id`) && length(input_json$`shipment_id`) == 1)) {
          stop(paste("Error! Invalid data for `shipment_id`. Must be a string:", input_json$`shipment_id`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for OrderShipmentEventAdd: the required field `shipment_id` is missing."))
      }
      # check the required field `status`
      if (!is.null(input_json$`status`)) {
        if (!(is.character(input_json$`status`) && length(input_json$`status`) == 1)) {
          stop(paste("Error! Invalid data for `status`. Must be a string:", input_json$`status`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for OrderShipmentEventAdd: the required field `status` is missing."))
      }
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of OrderShipmentEventAdd
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      # check if the required `shipment_id` is null
      if (is.null(self$`shipment_id`)) {
        return(FALSE)
      }

      # check if the required `status` is null
      if (is.null(self$`status`)) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      # check if the required `shipment_id` is null
      if (is.null(self$`shipment_id`)) {
        invalid_fields["shipment_id"] <- "Non-nullable required field `shipment_id` cannot be null."
      }

      # check if the required `status` is null
      if (is.null(self$`status`)) {
        invalid_fields["status"] <- "Non-nullable required field `status` cannot be null."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# OrderShipmentEventAdd$unlock()
#
## Below is an example to define the print function
# OrderShipmentEventAdd$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# OrderShipmentEventAdd$lock()

