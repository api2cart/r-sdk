#' Create a new AnalyticsCustomerMetric
#'
#' @description
#' AnalyticsCustomerMetric Class
#'
#' @docType class
#' @title AnalyticsCustomerMetric
#' @description AnalyticsCustomerMetric Class
#' @format An \code{R6Class} generator object
#' @field orders_count  integer [optional]
#' @field total_spend  numeric [optional]
#' @field avg_order_value  numeric [optional]
#' @field currency_id  character [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
AnalyticsCustomerMetric <- R6::R6Class(
  "AnalyticsCustomerMetric",
  public = list(
    `orders_count` = NULL,
    `total_spend` = NULL,
    `avg_order_value` = NULL,
    `currency_id` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new AnalyticsCustomerMetric class.
    #'
    #' @param orders_count orders_count
    #' @param total_spend total_spend
    #' @param avg_order_value avg_order_value
    #' @param currency_id currency_id
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`orders_count` = NULL, `total_spend` = NULL, `avg_order_value` = NULL, `currency_id` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`orders_count`)) {
        if (!(is.numeric(`orders_count`) && length(`orders_count`) == 1)) {
          stop(paste("Error! Invalid data for `orders_count`. Must be an integer:", `orders_count`))
        }
        self$`orders_count` <- `orders_count`
      }
      if (!is.null(`total_spend`)) {
        self$`total_spend` <- `total_spend`
      }
      if (!is.null(`avg_order_value`)) {
        self$`avg_order_value` <- `avg_order_value`
      }
      if (!is.null(`currency_id`)) {
        if (!(is.character(`currency_id`) && length(`currency_id`) == 1)) {
          stop(paste("Error! Invalid data for `currency_id`. Must be a string:", `currency_id`))
        }
        self$`currency_id` <- `currency_id`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return AnalyticsCustomerMetric as a base R list.
    #' @examples
    #' # convert array of AnalyticsCustomerMetric (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert AnalyticsCustomerMetric to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      AnalyticsCustomerMetricObject <- list()
      if (!is.null(self$`orders_count`)) {
        AnalyticsCustomerMetricObject[["orders_count"]] <-
          self$`orders_count`
      }
      if (!is.null(self$`total_spend`)) {
        AnalyticsCustomerMetricObject[["total_spend"]] <-
          self$`total_spend`
      }
      if (!is.null(self$`avg_order_value`)) {
        AnalyticsCustomerMetricObject[["avg_order_value"]] <-
          self$`avg_order_value`
      }
      if (!is.null(self$`currency_id`)) {
        AnalyticsCustomerMetricObject[["currency_id"]] <-
          self$`currency_id`
      }
      if (!is.null(self$`additional_fields`)) {
        AnalyticsCustomerMetricObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        AnalyticsCustomerMetricObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(AnalyticsCustomerMetricObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of AnalyticsCustomerMetric
    #'
    #' @param input_json the JSON input
    #' @return the instance of AnalyticsCustomerMetric
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`orders_count`)) {
        self$`orders_count` <- this_object$`orders_count`
      }
      if (!is.null(this_object$`total_spend`)) {
        self$`total_spend` <- this_object$`total_spend`
      }
      if (!is.null(this_object$`avg_order_value`)) {
        self$`avg_order_value` <- this_object$`avg_order_value`
      }
      if (!is.null(this_object$`currency_id`)) {
        self$`currency_id` <- this_object$`currency_id`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return AnalyticsCustomerMetric in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of AnalyticsCustomerMetric
    #'
    #' @param input_json the JSON input
    #' @return the instance of AnalyticsCustomerMetric
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`orders_count` <- this_object$`orders_count`
      self$`total_spend` <- this_object$`total_spend`
      self$`avg_order_value` <- this_object$`avg_order_value`
      self$`currency_id` <- this_object$`currency_id`
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to AnalyticsCustomerMetric and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of AnalyticsCustomerMetric
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# AnalyticsCustomerMetric$unlock()
#
## Below is an example to define the print function
# AnalyticsCustomerMetric$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# AnalyticsCustomerMetric$lock()

