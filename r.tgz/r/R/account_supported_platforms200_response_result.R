#' Create a new AccountSupportedPlatforms200ResponseResult
#'
#' @description
#' AccountSupportedPlatforms200ResponseResult Class
#'
#' @docType class
#' @title AccountSupportedPlatforms200ResponseResult
#' @description AccountSupportedPlatforms200ResponseResult Class
#' @format An \code{R6Class} generator object
#' @field supported_platforms  list(\link{AccountSupportedPlatforms200ResponseResultSupportedPlatformsInner}) [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
AccountSupportedPlatforms200ResponseResult <- R6::R6Class(
  "AccountSupportedPlatforms200ResponseResult",
  public = list(
    `supported_platforms` = NULL,

    #' @description
    #' Initialize a new AccountSupportedPlatforms200ResponseResult class.
    #'
    #' @param supported_platforms supported_platforms
    #' @param ... Other optional arguments.
    initialize = function(`supported_platforms` = NULL, ...) {
      if (!is.null(`supported_platforms`)) {
        stopifnot(is.vector(`supported_platforms`), length(`supported_platforms`) != 0)
        sapply(`supported_platforms`, function(x) stopifnot(R6::is.R6(x)))
        self$`supported_platforms` <- `supported_platforms`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return AccountSupportedPlatforms200ResponseResult as a base R list.
    #' @examples
    #' # convert array of AccountSupportedPlatforms200ResponseResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert AccountSupportedPlatforms200ResponseResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      AccountSupportedPlatforms200ResponseResultObject <- list()
      if (!is.null(self$`supported_platforms`)) {
        AccountSupportedPlatforms200ResponseResultObject[["supported_platforms"]] <-
          lapply(self$`supported_platforms`, function(x) x$toSimpleType())
      }
      return(AccountSupportedPlatforms200ResponseResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of AccountSupportedPlatforms200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of AccountSupportedPlatforms200ResponseResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`supported_platforms`)) {
        self$`supported_platforms` <- ApiClient$new()$deserializeObj(this_object$`supported_platforms`, "array[AccountSupportedPlatforms200ResponseResultSupportedPlatformsInner]", loadNamespace("openapi"))
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return AccountSupportedPlatforms200ResponseResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of AccountSupportedPlatforms200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of AccountSupportedPlatforms200ResponseResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`supported_platforms` <- ApiClient$new()$deserializeObj(this_object$`supported_platforms`, "array[AccountSupportedPlatforms200ResponseResultSupportedPlatformsInner]", loadNamespace("openapi"))
      self
    },

    #' @description
    #' Validate JSON input with respect to AccountSupportedPlatforms200ResponseResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of AccountSupportedPlatforms200ResponseResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# AccountSupportedPlatforms200ResponseResult$unlock()
#
## Below is an example to define the print function
# AccountSupportedPlatforms200ResponseResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# AccountSupportedPlatforms200ResponseResult$lock()

