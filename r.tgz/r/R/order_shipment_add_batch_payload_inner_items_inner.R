#' Create a new OrderShipmentAddBatchPayloadInnerItemsInner
#'
#' @description
#' OrderShipmentAddBatchPayloadInnerItemsInner Class
#'
#' @docType class
#' @title OrderShipmentAddBatchPayloadInnerItemsInner
#' @description OrderShipmentAddBatchPayloadInnerItemsInner Class
#' @format An \code{R6Class} generator object
#' @field order_product_id  character
#' @field quantity  numeric
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
OrderShipmentAddBatchPayloadInnerItemsInner <- R6::R6Class(
  "OrderShipmentAddBatchPayloadInnerItemsInner",
  public = list(
    `order_product_id` = NULL,
    `quantity` = NULL,

    #' @description
    #' Initialize a new OrderShipmentAddBatchPayloadInnerItemsInner class.
    #'
    #' @param order_product_id order_product_id
    #' @param quantity quantity
    #' @param ... Other optional arguments.
    initialize = function(`order_product_id`, `quantity`, ...) {
      if (!missing(`order_product_id`)) {
        if (!(is.character(`order_product_id`) && length(`order_product_id`) == 1)) {
          stop(paste("Error! Invalid data for `order_product_id`. Must be a string:", `order_product_id`))
        }
        self$`order_product_id` <- `order_product_id`
      }
      if (!missing(`quantity`)) {
        self$`quantity` <- `quantity`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return OrderShipmentAddBatchPayloadInnerItemsInner as a base R list.
    #' @examples
    #' # convert array of OrderShipmentAddBatchPayloadInnerItemsInner (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert OrderShipmentAddBatchPayloadInnerItemsInner to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      OrderShipmentAddBatchPayloadInnerItemsInnerObject <- list()
      if (!is.null(self$`order_product_id`)) {
        OrderShipmentAddBatchPayloadInnerItemsInnerObject[["order_product_id"]] <-
          self$`order_product_id`
      }
      if (!is.null(self$`quantity`)) {
        OrderShipmentAddBatchPayloadInnerItemsInnerObject[["quantity"]] <-
          self$`quantity`
      }
      return(OrderShipmentAddBatchPayloadInnerItemsInnerObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderShipmentAddBatchPayloadInnerItemsInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderShipmentAddBatchPayloadInnerItemsInner
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`order_product_id`)) {
        self$`order_product_id` <- this_object$`order_product_id`
      }
      if (!is.null(this_object$`quantity`)) {
        self$`quantity` <- this_object$`quantity`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return OrderShipmentAddBatchPayloadInnerItemsInner in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderShipmentAddBatchPayloadInnerItemsInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderShipmentAddBatchPayloadInnerItemsInner
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`order_product_id` <- this_object$`order_product_id`
      self$`quantity` <- this_object$`quantity`
      self
    },

    #' @description
    #' Validate JSON input with respect to OrderShipmentAddBatchPayloadInnerItemsInner and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
      # check the required field `order_product_id`
      if (!is.null(input_json$`order_product_id`)) {
        if (!(is.character(input_json$`order_product_id`) && length(input_json$`order_product_id`) == 1)) {
          stop(paste("Error! Invalid data for `order_product_id`. Must be a string:", input_json$`order_product_id`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for OrderShipmentAddBatchPayloadInnerItemsInner: the required field `order_product_id` is missing."))
      }
      # check the required field `quantity`
      if (!is.null(input_json$`quantity`)) {
      } else {
        stop(paste("The JSON input `", input, "` is invalid for OrderShipmentAddBatchPayloadInnerItemsInner: the required field `quantity` is missing."))
      }
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of OrderShipmentAddBatchPayloadInnerItemsInner
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      # check if the required `order_product_id` is null
      if (is.null(self$`order_product_id`)) {
        return(FALSE)
      }

      # check if the required `quantity` is null
      if (is.null(self$`quantity`)) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      # check if the required `order_product_id` is null
      if (is.null(self$`order_product_id`)) {
        invalid_fields["order_product_id"] <- "Non-nullable required field `order_product_id` cannot be null."
      }

      # check if the required `quantity` is null
      if (is.null(self$`quantity`)) {
        invalid_fields["quantity"] <- "Non-nullable required field `quantity` cannot be null."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# OrderShipmentAddBatchPayloadInnerItemsInner$unlock()
#
## Below is an example to define the print function
# OrderShipmentAddBatchPayloadInnerItemsInner$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# OrderShipmentAddBatchPayloadInnerItemsInner$lock()

