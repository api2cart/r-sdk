#' Create a new AttributeAdd200Response
#'
#' @description
#' AttributeAdd200Response Class
#'
#' @docType class
#' @title AttributeAdd200Response
#' @description AttributeAdd200Response Class
#' @format An \code{R6Class} generator object
#' @field return_code  integer [optional]
#' @field return_message  character [optional]
#' @field result  \link{AttributeAdd200ResponseResult} [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
AttributeAdd200Response <- R6::R6Class(
  "AttributeAdd200Response",
  public = list(
    `return_code` = NULL,
    `return_message` = NULL,
    `result` = NULL,

    #' @description
    #' Initialize a new AttributeAdd200Response class.
    #'
    #' @param return_code return_code
    #' @param return_message return_message
    #' @param result result
    #' @param ... Other optional arguments.
    initialize = function(`return_code` = NULL, `return_message` = NULL, `result` = NULL, ...) {
      if (!is.null(`return_code`)) {
        if (!(is.numeric(`return_code`) && length(`return_code`) == 1)) {
          stop(paste("Error! Invalid data for `return_code`. Must be an integer:", `return_code`))
        }
        self$`return_code` <- `return_code`
      }
      if (!is.null(`return_message`)) {
        if (!(is.character(`return_message`) && length(`return_message`) == 1)) {
          stop(paste("Error! Invalid data for `return_message`. Must be a string:", `return_message`))
        }
        self$`return_message` <- `return_message`
      }
      if (!is.null(`result`)) {
        stopifnot(R6::is.R6(`result`))
        self$`result` <- `result`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return AttributeAdd200Response as a base R list.
    #' @examples
    #' # convert array of AttributeAdd200Response (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert AttributeAdd200Response to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      AttributeAdd200ResponseObject <- list()
      if (!is.null(self$`return_code`)) {
        AttributeAdd200ResponseObject[["return_code"]] <-
          self$`return_code`
      }
      if (!is.null(self$`return_message`)) {
        AttributeAdd200ResponseObject[["return_message"]] <-
          self$`return_message`
      }
      if (!is.null(self$`result`)) {
        AttributeAdd200ResponseObject[["result"]] <-
          self$`result`$toSimpleType()
      }
      return(AttributeAdd200ResponseObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of AttributeAdd200Response
    #'
    #' @param input_json the JSON input
    #' @return the instance of AttributeAdd200Response
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`return_code`)) {
        self$`return_code` <- this_object$`return_code`
      }
      if (!is.null(this_object$`return_message`)) {
        self$`return_message` <- this_object$`return_message`
      }
      if (!is.null(this_object$`result`)) {
        `result_object` <- AttributeAdd200ResponseResult$new()
        `result_object`$fromJSON(jsonlite::toJSON(this_object$`result`, auto_unbox = TRUE, digits = NA))
        self$`result` <- `result_object`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return AttributeAdd200Response in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of AttributeAdd200Response
    #'
    #' @param input_json the JSON input
    #' @return the instance of AttributeAdd200Response
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`return_code` <- this_object$`return_code`
      self$`return_message` <- this_object$`return_message`
      self$`result` <- AttributeAdd200ResponseResult$new()$fromJSON(jsonlite::toJSON(this_object$`result`, auto_unbox = TRUE, digits = NA))
      self
    },

    #' @description
    #' Validate JSON input with respect to AttributeAdd200Response and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of AttributeAdd200Response
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# AttributeAdd200Response$unlock()
#
## Below is an example to define the print function
# AttributeAdd200Response$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# AttributeAdd200Response$lock()

