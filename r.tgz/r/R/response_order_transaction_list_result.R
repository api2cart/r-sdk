#' Create a new ResponseOrderTransactionListResult
#'
#' @description
#' ResponseOrderTransactionListResult Class
#'
#' @docType class
#' @title ResponseOrderTransactionListResult
#' @description ResponseOrderTransactionListResult Class
#' @format An \code{R6Class} generator object
#' @field transactions_count  integer [optional]
#' @field transactions  list(\link{OrderTransaction}) [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ResponseOrderTransactionListResult <- R6::R6Class(
  "ResponseOrderTransactionListResult",
  public = list(
    `transactions_count` = NULL,
    `transactions` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new ResponseOrderTransactionListResult class.
    #'
    #' @param transactions_count transactions_count
    #' @param transactions transactions
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`transactions_count` = NULL, `transactions` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`transactions_count`)) {
        if (!(is.numeric(`transactions_count`) && length(`transactions_count`) == 1)) {
          stop(paste("Error! Invalid data for `transactions_count`. Must be an integer:", `transactions_count`))
        }
        self$`transactions_count` <- `transactions_count`
      }
      if (!is.null(`transactions`)) {
        stopifnot(is.vector(`transactions`), length(`transactions`) != 0)
        sapply(`transactions`, function(x) stopifnot(R6::is.R6(x)))
        self$`transactions` <- `transactions`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ResponseOrderTransactionListResult as a base R list.
    #' @examples
    #' # convert array of ResponseOrderTransactionListResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ResponseOrderTransactionListResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ResponseOrderTransactionListResultObject <- list()
      if (!is.null(self$`transactions_count`)) {
        ResponseOrderTransactionListResultObject[["transactions_count"]] <-
          self$`transactions_count`
      }
      if (!is.null(self$`transactions`)) {
        ResponseOrderTransactionListResultObject[["transactions"]] <-
          lapply(self$`transactions`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`additional_fields`)) {
        ResponseOrderTransactionListResultObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        ResponseOrderTransactionListResultObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(ResponseOrderTransactionListResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ResponseOrderTransactionListResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ResponseOrderTransactionListResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`transactions_count`)) {
        self$`transactions_count` <- this_object$`transactions_count`
      }
      if (!is.null(this_object$`transactions`)) {
        self$`transactions` <- ApiClient$new()$deserializeObj(this_object$`transactions`, "array[OrderTransaction]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ResponseOrderTransactionListResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ResponseOrderTransactionListResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ResponseOrderTransactionListResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`transactions_count` <- this_object$`transactions_count`
      self$`transactions` <- ApiClient$new()$deserializeObj(this_object$`transactions`, "array[OrderTransaction]", loadNamespace("openapi"))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to ResponseOrderTransactionListResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ResponseOrderTransactionListResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ResponseOrderTransactionListResult$unlock()
#
## Below is an example to define the print function
# ResponseOrderTransactionListResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ResponseOrderTransactionListResult$lock()

