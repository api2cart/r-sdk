#' Create a new ProductTaxAdd
#'
#' @description
#' ProductTaxAdd Class
#'
#' @docType class
#' @title ProductTaxAdd
#' @description ProductTaxAdd Class
#' @format An \code{R6Class} generator object
#' @field product_id Defines products specified by product id character [optional]
#' @field name Defines tax class name where tax has to be added character
#' @field tax_rates Defines tax rates of specified tax classes list(\link{ProductTaxAddTaxRatesInner})
#' @field idempotency_key A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong> character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductTaxAdd <- R6::R6Class(
  "ProductTaxAdd",
  public = list(
    `product_id` = NULL,
    `name` = NULL,
    `tax_rates` = NULL,
    `idempotency_key` = NULL,

    #' @description
    #' Initialize a new ProductTaxAdd class.
    #'
    #' @param name Defines tax class name where tax has to be added
    #' @param tax_rates Defines tax rates of specified tax classes
    #' @param product_id Defines products specified by product id
    #' @param idempotency_key A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong>
    #' @param ... Other optional arguments.
    initialize = function(`name`, `tax_rates`, `product_id` = NULL, `idempotency_key` = NULL, ...) {
      if (!missing(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!missing(`tax_rates`)) {
        stopifnot(is.vector(`tax_rates`), length(`tax_rates`) != 0)
        sapply(`tax_rates`, function(x) stopifnot(R6::is.R6(x)))
        self$`tax_rates` <- `tax_rates`
      }
      if (!is.null(`product_id`)) {
        if (!(is.character(`product_id`) && length(`product_id`) == 1)) {
          stop(paste("Error! Invalid data for `product_id`. Must be a string:", `product_id`))
        }
        self$`product_id` <- `product_id`
      }
      if (!is.null(`idempotency_key`)) {
        if (!(is.character(`idempotency_key`) && length(`idempotency_key`) == 1)) {
          stop(paste("Error! Invalid data for `idempotency_key`. Must be a string:", `idempotency_key`))
        }
        self$`idempotency_key` <- `idempotency_key`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductTaxAdd as a base R list.
    #' @examples
    #' # convert array of ProductTaxAdd (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductTaxAdd to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductTaxAddObject <- list()
      if (!is.null(self$`product_id`)) {
        ProductTaxAddObject[["product_id"]] <-
          self$`product_id`
      }
      if (!is.null(self$`name`)) {
        ProductTaxAddObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`tax_rates`)) {
        ProductTaxAddObject[["tax_rates"]] <-
          lapply(self$`tax_rates`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`idempotency_key`)) {
        ProductTaxAddObject[["idempotency_key"]] <-
          self$`idempotency_key`
      }
      return(ProductTaxAddObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductTaxAdd
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductTaxAdd
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`product_id`)) {
        self$`product_id` <- this_object$`product_id`
      }
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`tax_rates`)) {
        self$`tax_rates` <- ApiClient$new()$deserializeObj(this_object$`tax_rates`, "array[ProductTaxAddTaxRatesInner]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`idempotency_key`)) {
        self$`idempotency_key` <- this_object$`idempotency_key`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductTaxAdd in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductTaxAdd
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductTaxAdd
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`product_id` <- this_object$`product_id`
      self$`name` <- this_object$`name`
      self$`tax_rates` <- ApiClient$new()$deserializeObj(this_object$`tax_rates`, "array[ProductTaxAddTaxRatesInner]", loadNamespace("openapi"))
      self$`idempotency_key` <- this_object$`idempotency_key`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductTaxAdd and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
      # check the required field `name`
      if (!is.null(input_json$`name`)) {
        if (!(is.character(input_json$`name`) && length(input_json$`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", input_json$`name`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for ProductTaxAdd: the required field `name` is missing."))
      }
      # check the required field `tax_rates`
      if (!is.null(input_json$`tax_rates`)) {
        stopifnot(is.vector(input_json$`tax_rates`), length(input_json$`tax_rates`) != 0)
        tmp <- sapply(input_json$`tax_rates`, function(x) stopifnot(R6::is.R6(x)))
      } else {
        stop(paste("The JSON input `", input, "` is invalid for ProductTaxAdd: the required field `tax_rates` is missing."))
      }
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductTaxAdd
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      # check if the required `name` is null
      if (is.null(self$`name`)) {
        return(FALSE)
      }

      # check if the required `tax_rates` is null
      if (is.null(self$`tax_rates`)) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      # check if the required `name` is null
      if (is.null(self$`name`)) {
        invalid_fields["name"] <- "Non-nullable required field `name` cannot be null."
      }

      # check if the required `tax_rates` is null
      if (is.null(self$`tax_rates`)) {
        invalid_fields["tax_rates"] <- "Non-nullable required field `tax_rates` cannot be null."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductTaxAdd$unlock()
#
## Below is an example to define the print function
# ProductTaxAdd$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductTaxAdd$lock()

