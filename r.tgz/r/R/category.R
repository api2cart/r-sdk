#' Create a new Category
#'
#' @description
#' Category Class
#'
#' @docType class
#' @title Category
#' @description Category Class
#' @format An \code{R6Class} generator object
#' @field id  character [optional]
#' @field parent_id  character [optional]
#' @field created_at  \link{A2CDateTime} [optional]
#' @field modified_at  \link{A2CDateTime} [optional]
#' @field name  character [optional]
#' @field short_description  character [optional]
#' @field description  character [optional]
#' @field stores_ids  list(character) [optional]
#' @field keywords  character [optional]
#' @field meta_description  character [optional]
#' @field meta_title  character [optional]
#' @field avail  character [optional]
#' @field path  character [optional]
#' @field seo_url  character [optional]
#' @field sort_order  integer [optional]
#' @field images  list(\link{Image}) [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
Category <- R6::R6Class(
  "Category",
  public = list(
    `id` = NULL,
    `parent_id` = NULL,
    `created_at` = NULL,
    `modified_at` = NULL,
    `name` = NULL,
    `short_description` = NULL,
    `description` = NULL,
    `stores_ids` = NULL,
    `keywords` = NULL,
    `meta_description` = NULL,
    `meta_title` = NULL,
    `avail` = NULL,
    `path` = NULL,
    `seo_url` = NULL,
    `sort_order` = NULL,
    `images` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new Category class.
    #'
    #' @param id id
    #' @param parent_id parent_id
    #' @param created_at created_at
    #' @param modified_at modified_at
    #' @param name name
    #' @param short_description short_description
    #' @param description description
    #' @param stores_ids stores_ids
    #' @param keywords keywords
    #' @param meta_description meta_description
    #' @param meta_title meta_title
    #' @param avail avail
    #' @param path path
    #' @param seo_url seo_url
    #' @param sort_order sort_order
    #' @param images images
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `parent_id` = NULL, `created_at` = NULL, `modified_at` = NULL, `name` = NULL, `short_description` = NULL, `description` = NULL, `stores_ids` = NULL, `keywords` = NULL, `meta_description` = NULL, `meta_title` = NULL, `avail` = NULL, `path` = NULL, `seo_url` = NULL, `sort_order` = NULL, `images` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`parent_id`)) {
        if (!(is.character(`parent_id`) && length(`parent_id`) == 1)) {
          stop(paste("Error! Invalid data for `parent_id`. Must be a string:", `parent_id`))
        }
        self$`parent_id` <- `parent_id`
      }
      if (!is.null(`created_at`)) {
        stopifnot(R6::is.R6(`created_at`))
        self$`created_at` <- `created_at`
      }
      if (!is.null(`modified_at`)) {
        stopifnot(R6::is.R6(`modified_at`))
        self$`modified_at` <- `modified_at`
      }
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`short_description`)) {
        if (!(is.character(`short_description`) && length(`short_description`) == 1)) {
          stop(paste("Error! Invalid data for `short_description`. Must be a string:", `short_description`))
        }
        self$`short_description` <- `short_description`
      }
      if (!is.null(`description`)) {
        if (!(is.character(`description`) && length(`description`) == 1)) {
          stop(paste("Error! Invalid data for `description`. Must be a string:", `description`))
        }
        self$`description` <- `description`
      }
      if (!is.null(`stores_ids`)) {
        stopifnot(is.vector(`stores_ids`), length(`stores_ids`) != 0)
        sapply(`stores_ids`, function(x) stopifnot(is.character(x)))
        self$`stores_ids` <- `stores_ids`
      }
      if (!is.null(`keywords`)) {
        if (!(is.character(`keywords`) && length(`keywords`) == 1)) {
          stop(paste("Error! Invalid data for `keywords`. Must be a string:", `keywords`))
        }
        self$`keywords` <- `keywords`
      }
      if (!is.null(`meta_description`)) {
        if (!(is.character(`meta_description`) && length(`meta_description`) == 1)) {
          stop(paste("Error! Invalid data for `meta_description`. Must be a string:", `meta_description`))
        }
        self$`meta_description` <- `meta_description`
      }
      if (!is.null(`meta_title`)) {
        if (!(is.character(`meta_title`) && length(`meta_title`) == 1)) {
          stop(paste("Error! Invalid data for `meta_title`. Must be a string:", `meta_title`))
        }
        self$`meta_title` <- `meta_title`
      }
      if (!is.null(`avail`)) {
        if (!(is.logical(`avail`) && length(`avail`) == 1)) {
          stop(paste("Error! Invalid data for `avail`. Must be a boolean:", `avail`))
        }
        self$`avail` <- `avail`
      }
      if (!is.null(`path`)) {
        if (!(is.character(`path`) && length(`path`) == 1)) {
          stop(paste("Error! Invalid data for `path`. Must be a string:", `path`))
        }
        self$`path` <- `path`
      }
      if (!is.null(`seo_url`)) {
        if (!(is.character(`seo_url`) && length(`seo_url`) == 1)) {
          stop(paste("Error! Invalid data for `seo_url`. Must be a string:", `seo_url`))
        }
        self$`seo_url` <- `seo_url`
      }
      if (!is.null(`sort_order`)) {
        if (!(is.numeric(`sort_order`) && length(`sort_order`) == 1)) {
          stop(paste("Error! Invalid data for `sort_order`. Must be an integer:", `sort_order`))
        }
        self$`sort_order` <- `sort_order`
      }
      if (!is.null(`images`)) {
        stopifnot(is.vector(`images`), length(`images`) != 0)
        sapply(`images`, function(x) stopifnot(R6::is.R6(x)))
        self$`images` <- `images`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return Category as a base R list.
    #' @examples
    #' # convert array of Category (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert Category to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      CategoryObject <- list()
      if (!is.null(self$`id`)) {
        CategoryObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`parent_id`)) {
        CategoryObject[["parent_id"]] <-
          self$`parent_id`
      }
      if (!is.null(self$`created_at`)) {
        CategoryObject[["created_at"]] <-
          self$`created_at`$toSimpleType()
      }
      if (!is.null(self$`modified_at`)) {
        CategoryObject[["modified_at"]] <-
          self$`modified_at`$toSimpleType()
      }
      if (!is.null(self$`name`)) {
        CategoryObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`short_description`)) {
        CategoryObject[["short_description"]] <-
          self$`short_description`
      }
      if (!is.null(self$`description`)) {
        CategoryObject[["description"]] <-
          self$`description`
      }
      if (!is.null(self$`stores_ids`)) {
        CategoryObject[["stores_ids"]] <-
          self$`stores_ids`
      }
      if (!is.null(self$`keywords`)) {
        CategoryObject[["keywords"]] <-
          self$`keywords`
      }
      if (!is.null(self$`meta_description`)) {
        CategoryObject[["meta_description"]] <-
          self$`meta_description`
      }
      if (!is.null(self$`meta_title`)) {
        CategoryObject[["meta_title"]] <-
          self$`meta_title`
      }
      if (!is.null(self$`avail`)) {
        CategoryObject[["avail"]] <-
          self$`avail`
      }
      if (!is.null(self$`path`)) {
        CategoryObject[["path"]] <-
          self$`path`
      }
      if (!is.null(self$`seo_url`)) {
        CategoryObject[["seo_url"]] <-
          self$`seo_url`
      }
      if (!is.null(self$`sort_order`)) {
        CategoryObject[["sort_order"]] <-
          self$`sort_order`
      }
      if (!is.null(self$`images`)) {
        CategoryObject[["images"]] <-
          lapply(self$`images`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`additional_fields`)) {
        CategoryObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        CategoryObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(CategoryObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of Category
    #'
    #' @param input_json the JSON input
    #' @return the instance of Category
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`parent_id`)) {
        self$`parent_id` <- this_object$`parent_id`
      }
      if (!is.null(this_object$`created_at`)) {
        `created_at_object` <- A2CDateTime$new()
        `created_at_object`$fromJSON(jsonlite::toJSON(this_object$`created_at`, auto_unbox = TRUE, digits = NA))
        self$`created_at` <- `created_at_object`
      }
      if (!is.null(this_object$`modified_at`)) {
        `modified_at_object` <- A2CDateTime$new()
        `modified_at_object`$fromJSON(jsonlite::toJSON(this_object$`modified_at`, auto_unbox = TRUE, digits = NA))
        self$`modified_at` <- `modified_at_object`
      }
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`short_description`)) {
        self$`short_description` <- this_object$`short_description`
      }
      if (!is.null(this_object$`description`)) {
        self$`description` <- this_object$`description`
      }
      if (!is.null(this_object$`stores_ids`)) {
        self$`stores_ids` <- ApiClient$new()$deserializeObj(this_object$`stores_ids`, "array[character]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`keywords`)) {
        self$`keywords` <- this_object$`keywords`
      }
      if (!is.null(this_object$`meta_description`)) {
        self$`meta_description` <- this_object$`meta_description`
      }
      if (!is.null(this_object$`meta_title`)) {
        self$`meta_title` <- this_object$`meta_title`
      }
      if (!is.null(this_object$`avail`)) {
        self$`avail` <- this_object$`avail`
      }
      if (!is.null(this_object$`path`)) {
        self$`path` <- this_object$`path`
      }
      if (!is.null(this_object$`seo_url`)) {
        self$`seo_url` <- this_object$`seo_url`
      }
      if (!is.null(this_object$`sort_order`)) {
        self$`sort_order` <- this_object$`sort_order`
      }
      if (!is.null(this_object$`images`)) {
        self$`images` <- ApiClient$new()$deserializeObj(this_object$`images`, "array[Image]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return Category in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of Category
    #'
    #' @param input_json the JSON input
    #' @return the instance of Category
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`parent_id` <- this_object$`parent_id`
      self$`created_at` <- A2CDateTime$new()$fromJSON(jsonlite::toJSON(this_object$`created_at`, auto_unbox = TRUE, digits = NA))
      self$`modified_at` <- A2CDateTime$new()$fromJSON(jsonlite::toJSON(this_object$`modified_at`, auto_unbox = TRUE, digits = NA))
      self$`name` <- this_object$`name`
      self$`short_description` <- this_object$`short_description`
      self$`description` <- this_object$`description`
      self$`stores_ids` <- ApiClient$new()$deserializeObj(this_object$`stores_ids`, "array[character]", loadNamespace("openapi"))
      self$`keywords` <- this_object$`keywords`
      self$`meta_description` <- this_object$`meta_description`
      self$`meta_title` <- this_object$`meta_title`
      self$`avail` <- this_object$`avail`
      self$`path` <- this_object$`path`
      self$`seo_url` <- this_object$`seo_url`
      self$`sort_order` <- this_object$`sort_order`
      self$`images` <- ApiClient$new()$deserializeObj(this_object$`images`, "array[Image]", loadNamespace("openapi"))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to Category and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of Category
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# Category$unlock()
#
## Below is an example to define the print function
# Category$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# Category$lock()

