#' Create a new Script
#'
#' @description
#' Script Class
#'
#' @docType class
#' @title Script
#' @description Script Class
#' @format An \code{R6Class} generator object
#' @field id  character [optional]
#' @field name  character [optional]
#' @field description  character [optional]
#' @field src  character [optional]
#' @field scope  character [optional]
#' @field event  character [optional]
#' @field load_method  character [optional]
#' @field html  character [optional]
#' @field created_time  \link{A2CDateTime} [optional]
#' @field modified_time  \link{A2CDateTime} [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
Script <- R6::R6Class(
  "Script",
  public = list(
    `id` = NULL,
    `name` = NULL,
    `description` = NULL,
    `src` = NULL,
    `scope` = NULL,
    `event` = NULL,
    `load_method` = NULL,
    `html` = NULL,
    `created_time` = NULL,
    `modified_time` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new Script class.
    #'
    #' @param id id
    #' @param name name
    #' @param description description
    #' @param src src
    #' @param scope scope
    #' @param event event
    #' @param load_method load_method
    #' @param html html
    #' @param created_time created_time
    #' @param modified_time modified_time
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `name` = NULL, `description` = NULL, `src` = NULL, `scope` = NULL, `event` = NULL, `load_method` = NULL, `html` = NULL, `created_time` = NULL, `modified_time` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`description`)) {
        if (!(is.character(`description`) && length(`description`) == 1)) {
          stop(paste("Error! Invalid data for `description`. Must be a string:", `description`))
        }
        self$`description` <- `description`
      }
      if (!is.null(`src`)) {
        if (!(is.character(`src`) && length(`src`) == 1)) {
          stop(paste("Error! Invalid data for `src`. Must be a string:", `src`))
        }
        self$`src` <- `src`
      }
      if (!is.null(`scope`)) {
        if (!(is.character(`scope`) && length(`scope`) == 1)) {
          stop(paste("Error! Invalid data for `scope`. Must be a string:", `scope`))
        }
        self$`scope` <- `scope`
      }
      if (!is.null(`event`)) {
        if (!(is.character(`event`) && length(`event`) == 1)) {
          stop(paste("Error! Invalid data for `event`. Must be a string:", `event`))
        }
        self$`event` <- `event`
      }
      if (!is.null(`load_method`)) {
        if (!(is.character(`load_method`) && length(`load_method`) == 1)) {
          stop(paste("Error! Invalid data for `load_method`. Must be a string:", `load_method`))
        }
        self$`load_method` <- `load_method`
      }
      if (!is.null(`html`)) {
        if (!(is.character(`html`) && length(`html`) == 1)) {
          stop(paste("Error! Invalid data for `html`. Must be a string:", `html`))
        }
        self$`html` <- `html`
      }
      if (!is.null(`created_time`)) {
        stopifnot(R6::is.R6(`created_time`))
        self$`created_time` <- `created_time`
      }
      if (!is.null(`modified_time`)) {
        stopifnot(R6::is.R6(`modified_time`))
        self$`modified_time` <- `modified_time`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return Script as a base R list.
    #' @examples
    #' # convert array of Script (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert Script to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ScriptObject <- list()
      if (!is.null(self$`id`)) {
        ScriptObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`name`)) {
        ScriptObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`description`)) {
        ScriptObject[["description"]] <-
          self$`description`
      }
      if (!is.null(self$`src`)) {
        ScriptObject[["src"]] <-
          self$`src`
      }
      if (!is.null(self$`scope`)) {
        ScriptObject[["scope"]] <-
          self$`scope`
      }
      if (!is.null(self$`event`)) {
        ScriptObject[["event"]] <-
          self$`event`
      }
      if (!is.null(self$`load_method`)) {
        ScriptObject[["load_method"]] <-
          self$`load_method`
      }
      if (!is.null(self$`html`)) {
        ScriptObject[["html"]] <-
          self$`html`
      }
      if (!is.null(self$`created_time`)) {
        ScriptObject[["created_time"]] <-
          self$`created_time`$toSimpleType()
      }
      if (!is.null(self$`modified_time`)) {
        ScriptObject[["modified_time"]] <-
          self$`modified_time`$toSimpleType()
      }
      if (!is.null(self$`additional_fields`)) {
        ScriptObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        ScriptObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(ScriptObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of Script
    #'
    #' @param input_json the JSON input
    #' @return the instance of Script
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`description`)) {
        self$`description` <- this_object$`description`
      }
      if (!is.null(this_object$`src`)) {
        self$`src` <- this_object$`src`
      }
      if (!is.null(this_object$`scope`)) {
        self$`scope` <- this_object$`scope`
      }
      if (!is.null(this_object$`event`)) {
        self$`event` <- this_object$`event`
      }
      if (!is.null(this_object$`load_method`)) {
        self$`load_method` <- this_object$`load_method`
      }
      if (!is.null(this_object$`html`)) {
        self$`html` <- this_object$`html`
      }
      if (!is.null(this_object$`created_time`)) {
        `created_time_object` <- A2CDateTime$new()
        `created_time_object`$fromJSON(jsonlite::toJSON(this_object$`created_time`, auto_unbox = TRUE, digits = NA))
        self$`created_time` <- `created_time_object`
      }
      if (!is.null(this_object$`modified_time`)) {
        `modified_time_object` <- A2CDateTime$new()
        `modified_time_object`$fromJSON(jsonlite::toJSON(this_object$`modified_time`, auto_unbox = TRUE, digits = NA))
        self$`modified_time` <- `modified_time_object`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return Script in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of Script
    #'
    #' @param input_json the JSON input
    #' @return the instance of Script
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`name` <- this_object$`name`
      self$`description` <- this_object$`description`
      self$`src` <- this_object$`src`
      self$`scope` <- this_object$`scope`
      self$`event` <- this_object$`event`
      self$`load_method` <- this_object$`load_method`
      self$`html` <- this_object$`html`
      self$`created_time` <- A2CDateTime$new()$fromJSON(jsonlite::toJSON(this_object$`created_time`, auto_unbox = TRUE, digits = NA))
      self$`modified_time` <- A2CDateTime$new()$fromJSON(jsonlite::toJSON(this_object$`modified_time`, auto_unbox = TRUE, digits = NA))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to Script and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of Script
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# Script$unlock()
#
## Below is an example to define the print function
# Script$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# Script$lock()

