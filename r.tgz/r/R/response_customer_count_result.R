#' Create a new ResponseCustomerCountResult
#'
#' @description
#' ResponseCustomerCountResult Class
#'
#' @docType class
#' @title ResponseCustomerCountResult
#' @description ResponseCustomerCountResult Class
#' @format An \code{R6Class} generator object
#' @field customers_count  integer [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ResponseCustomerCountResult <- R6::R6Class(
  "ResponseCustomerCountResult",
  public = list(
    `customers_count` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new ResponseCustomerCountResult class.
    #'
    #' @param customers_count customers_count
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`customers_count` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`customers_count`)) {
        if (!(is.numeric(`customers_count`) && length(`customers_count`) == 1)) {
          stop(paste("Error! Invalid data for `customers_count`. Must be an integer:", `customers_count`))
        }
        self$`customers_count` <- `customers_count`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ResponseCustomerCountResult as a base R list.
    #' @examples
    #' # convert array of ResponseCustomerCountResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ResponseCustomerCountResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ResponseCustomerCountResultObject <- list()
      if (!is.null(self$`customers_count`)) {
        ResponseCustomerCountResultObject[["customers_count"]] <-
          self$`customers_count`
      }
      if (!is.null(self$`additional_fields`)) {
        ResponseCustomerCountResultObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        ResponseCustomerCountResultObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(ResponseCustomerCountResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ResponseCustomerCountResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ResponseCustomerCountResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`customers_count`)) {
        self$`customers_count` <- this_object$`customers_count`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ResponseCustomerCountResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ResponseCustomerCountResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ResponseCustomerCountResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`customers_count` <- this_object$`customers_count`
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to ResponseCustomerCountResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ResponseCustomerCountResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ResponseCustomerCountResult$unlock()
#
## Below is an example to define the print function
# ResponseCustomerCountResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ResponseCustomerCountResult$lock()

