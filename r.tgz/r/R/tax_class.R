#' Create a new TaxClass
#'
#' @description
#' TaxClass Class
#'
#' @docType class
#' @title TaxClass
#' @description TaxClass Class
#' @format An \code{R6Class} generator object
#' @field id  character [optional]
#' @field name  character [optional]
#' @field avail  character [optional]
#' @field tax  numeric [optional]
#' @field tax_type  integer [optional]
#' @field created_at  \link{A2CDateTime} [optional]
#' @field modified_at  \link{A2CDateTime} [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
TaxClass <- R6::R6Class(
  "TaxClass",
  public = list(
    `id` = NULL,
    `name` = NULL,
    `avail` = NULL,
    `tax` = NULL,
    `tax_type` = NULL,
    `created_at` = NULL,
    `modified_at` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new TaxClass class.
    #'
    #' @param id id
    #' @param name name
    #' @param avail avail
    #' @param tax tax
    #' @param tax_type tax_type
    #' @param created_at created_at
    #' @param modified_at modified_at
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `name` = NULL, `avail` = NULL, `tax` = NULL, `tax_type` = NULL, `created_at` = NULL, `modified_at` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`avail`)) {
        if (!(is.logical(`avail`) && length(`avail`) == 1)) {
          stop(paste("Error! Invalid data for `avail`. Must be a boolean:", `avail`))
        }
        self$`avail` <- `avail`
      }
      if (!is.null(`tax`)) {
        self$`tax` <- `tax`
      }
      if (!is.null(`tax_type`)) {
        if (!(is.numeric(`tax_type`) && length(`tax_type`) == 1)) {
          stop(paste("Error! Invalid data for `tax_type`. Must be an integer:", `tax_type`))
        }
        self$`tax_type` <- `tax_type`
      }
      if (!is.null(`created_at`)) {
        stopifnot(R6::is.R6(`created_at`))
        self$`created_at` <- `created_at`
      }
      if (!is.null(`modified_at`)) {
        stopifnot(R6::is.R6(`modified_at`))
        self$`modified_at` <- `modified_at`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return TaxClass as a base R list.
    #' @examples
    #' # convert array of TaxClass (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert TaxClass to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      TaxClassObject <- list()
      if (!is.null(self$`id`)) {
        TaxClassObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`name`)) {
        TaxClassObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`avail`)) {
        TaxClassObject[["avail"]] <-
          self$`avail`
      }
      if (!is.null(self$`tax`)) {
        TaxClassObject[["tax"]] <-
          self$`tax`
      }
      if (!is.null(self$`tax_type`)) {
        TaxClassObject[["tax_type"]] <-
          self$`tax_type`
      }
      if (!is.null(self$`created_at`)) {
        TaxClassObject[["created_at"]] <-
          self$`created_at`$toSimpleType()
      }
      if (!is.null(self$`modified_at`)) {
        TaxClassObject[["modified_at"]] <-
          self$`modified_at`$toSimpleType()
      }
      if (!is.null(self$`additional_fields`)) {
        TaxClassObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        TaxClassObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(TaxClassObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of TaxClass
    #'
    #' @param input_json the JSON input
    #' @return the instance of TaxClass
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`avail`)) {
        self$`avail` <- this_object$`avail`
      }
      if (!is.null(this_object$`tax`)) {
        self$`tax` <- this_object$`tax`
      }
      if (!is.null(this_object$`tax_type`)) {
        self$`tax_type` <- this_object$`tax_type`
      }
      if (!is.null(this_object$`created_at`)) {
        `created_at_object` <- A2CDateTime$new()
        `created_at_object`$fromJSON(jsonlite::toJSON(this_object$`created_at`, auto_unbox = TRUE, digits = NA))
        self$`created_at` <- `created_at_object`
      }
      if (!is.null(this_object$`modified_at`)) {
        `modified_at_object` <- A2CDateTime$new()
        `modified_at_object`$fromJSON(jsonlite::toJSON(this_object$`modified_at`, auto_unbox = TRUE, digits = NA))
        self$`modified_at` <- `modified_at_object`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return TaxClass in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of TaxClass
    #'
    #' @param input_json the JSON input
    #' @return the instance of TaxClass
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`name` <- this_object$`name`
      self$`avail` <- this_object$`avail`
      self$`tax` <- this_object$`tax`
      self$`tax_type` <- this_object$`tax_type`
      self$`created_at` <- A2CDateTime$new()$fromJSON(jsonlite::toJSON(this_object$`created_at`, auto_unbox = TRUE, digits = NA))
      self$`modified_at` <- A2CDateTime$new()$fromJSON(jsonlite::toJSON(this_object$`modified_at`, auto_unbox = TRUE, digits = NA))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to TaxClass and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of TaxClass
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# TaxClass$unlock()
#
## Below is an example to define the print function
# TaxClass$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# TaxClass$lock()

