#' Create a new Basket
#'
#' @description
#' Basket Class
#'
#' @docType class
#' @title Basket
#' @description Basket Class
#' @format An \code{R6Class} generator object
#' @field id  character [optional]
#' @field customer  \link{BaseCustomer} [optional]
#' @field basket_url  character [optional]
#' @field created_at  \link{A2CDateTime} [optional]
#' @field modified_at  \link{A2CDateTime} [optional]
#' @field currency  \link{Currency} [optional]
#' @field basket_products  list(\link{BasketItem}) [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
Basket <- R6::R6Class(
  "Basket",
  public = list(
    `id` = NULL,
    `customer` = NULL,
    `basket_url` = NULL,
    `created_at` = NULL,
    `modified_at` = NULL,
    `currency` = NULL,
    `basket_products` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new Basket class.
    #'
    #' @param id id
    #' @param customer customer
    #' @param basket_url basket_url
    #' @param created_at created_at
    #' @param modified_at modified_at
    #' @param currency currency
    #' @param basket_products basket_products
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `customer` = NULL, `basket_url` = NULL, `created_at` = NULL, `modified_at` = NULL, `currency` = NULL, `basket_products` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`customer`)) {
        stopifnot(R6::is.R6(`customer`))
        self$`customer` <- `customer`
      }
      if (!is.null(`basket_url`)) {
        if (!(is.character(`basket_url`) && length(`basket_url`) == 1)) {
          stop(paste("Error! Invalid data for `basket_url`. Must be a string:", `basket_url`))
        }
        self$`basket_url` <- `basket_url`
      }
      if (!is.null(`created_at`)) {
        stopifnot(R6::is.R6(`created_at`))
        self$`created_at` <- `created_at`
      }
      if (!is.null(`modified_at`)) {
        stopifnot(R6::is.R6(`modified_at`))
        self$`modified_at` <- `modified_at`
      }
      if (!is.null(`currency`)) {
        stopifnot(R6::is.R6(`currency`))
        self$`currency` <- `currency`
      }
      if (!is.null(`basket_products`)) {
        stopifnot(is.vector(`basket_products`), length(`basket_products`) != 0)
        sapply(`basket_products`, function(x) stopifnot(R6::is.R6(x)))
        self$`basket_products` <- `basket_products`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return Basket as a base R list.
    #' @examples
    #' # convert array of Basket (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert Basket to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      BasketObject <- list()
      if (!is.null(self$`id`)) {
        BasketObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`customer`)) {
        BasketObject[["customer"]] <-
          self$`customer`$toSimpleType()
      }
      if (!is.null(self$`basket_url`)) {
        BasketObject[["basket_url"]] <-
          self$`basket_url`
      }
      if (!is.null(self$`created_at`)) {
        BasketObject[["created_at"]] <-
          self$`created_at`$toSimpleType()
      }
      if (!is.null(self$`modified_at`)) {
        BasketObject[["modified_at"]] <-
          self$`modified_at`$toSimpleType()
      }
      if (!is.null(self$`currency`)) {
        BasketObject[["currency"]] <-
          self$`currency`$toSimpleType()
      }
      if (!is.null(self$`basket_products`)) {
        BasketObject[["basket_products"]] <-
          lapply(self$`basket_products`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`additional_fields`)) {
        BasketObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        BasketObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(BasketObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of Basket
    #'
    #' @param input_json the JSON input
    #' @return the instance of Basket
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`customer`)) {
        `customer_object` <- BaseCustomer$new()
        `customer_object`$fromJSON(jsonlite::toJSON(this_object$`customer`, auto_unbox = TRUE, digits = NA))
        self$`customer` <- `customer_object`
      }
      if (!is.null(this_object$`basket_url`)) {
        self$`basket_url` <- this_object$`basket_url`
      }
      if (!is.null(this_object$`created_at`)) {
        `created_at_object` <- A2CDateTime$new()
        `created_at_object`$fromJSON(jsonlite::toJSON(this_object$`created_at`, auto_unbox = TRUE, digits = NA))
        self$`created_at` <- `created_at_object`
      }
      if (!is.null(this_object$`modified_at`)) {
        `modified_at_object` <- A2CDateTime$new()
        `modified_at_object`$fromJSON(jsonlite::toJSON(this_object$`modified_at`, auto_unbox = TRUE, digits = NA))
        self$`modified_at` <- `modified_at_object`
      }
      if (!is.null(this_object$`currency`)) {
        `currency_object` <- Currency$new()
        `currency_object`$fromJSON(jsonlite::toJSON(this_object$`currency`, auto_unbox = TRUE, digits = NA))
        self$`currency` <- `currency_object`
      }
      if (!is.null(this_object$`basket_products`)) {
        self$`basket_products` <- ApiClient$new()$deserializeObj(this_object$`basket_products`, "array[BasketItem]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return Basket in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of Basket
    #'
    #' @param input_json the JSON input
    #' @return the instance of Basket
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`customer` <- BaseCustomer$new()$fromJSON(jsonlite::toJSON(this_object$`customer`, auto_unbox = TRUE, digits = NA))
      self$`basket_url` <- this_object$`basket_url`
      self$`created_at` <- A2CDateTime$new()$fromJSON(jsonlite::toJSON(this_object$`created_at`, auto_unbox = TRUE, digits = NA))
      self$`modified_at` <- A2CDateTime$new()$fromJSON(jsonlite::toJSON(this_object$`modified_at`, auto_unbox = TRUE, digits = NA))
      self$`currency` <- Currency$new()$fromJSON(jsonlite::toJSON(this_object$`currency`, auto_unbox = TRUE, digits = NA))
      self$`basket_products` <- ApiClient$new()$deserializeObj(this_object$`basket_products`, "array[BasketItem]", loadNamespace("openapi"))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to Basket and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of Basket
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# Basket$unlock()
#
## Below is an example to define the print function
# Basket$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# Basket$lock()

