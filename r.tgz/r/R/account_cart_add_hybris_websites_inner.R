#' Create a new AccountCartAddHybrisWebsitesInner
#'
#' @description
#' AccountCartAddHybrisWebsitesInner Class
#'
#' @docType class
#' @title AccountCartAddHybrisWebsitesInner
#' @description AccountCartAddHybrisWebsitesInner Class
#' @format An \code{R6Class} generator object
#' @field uid  character
#' @field url  character
#' @field storeIds  list(character)
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
AccountCartAddHybrisWebsitesInner <- R6::R6Class(
  "AccountCartAddHybrisWebsitesInner",
  public = list(
    `uid` = NULL,
    `url` = NULL,
    `storeIds` = NULL,

    #' @description
    #' Initialize a new AccountCartAddHybrisWebsitesInner class.
    #'
    #' @param uid uid
    #' @param url url
    #' @param storeIds storeIds
    #' @param ... Other optional arguments.
    initialize = function(`uid`, `url`, `storeIds`, ...) {
      if (!missing(`uid`)) {
        if (!(is.character(`uid`) && length(`uid`) == 1)) {
          stop(paste("Error! Invalid data for `uid`. Must be a string:", `uid`))
        }
        self$`uid` <- `uid`
      }
      if (!missing(`url`)) {
        if (!(is.character(`url`) && length(`url`) == 1)) {
          stop(paste("Error! Invalid data for `url`. Must be a string:", `url`))
        }
        self$`url` <- `url`
      }
      if (!missing(`storeIds`)) {
        stopifnot(is.vector(`storeIds`), length(`storeIds`) != 0)
        sapply(`storeIds`, function(x) stopifnot(is.character(x)))
        self$`storeIds` <- `storeIds`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return AccountCartAddHybrisWebsitesInner as a base R list.
    #' @examples
    #' # convert array of AccountCartAddHybrisWebsitesInner (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert AccountCartAddHybrisWebsitesInner to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      AccountCartAddHybrisWebsitesInnerObject <- list()
      if (!is.null(self$`uid`)) {
        AccountCartAddHybrisWebsitesInnerObject[["uid"]] <-
          self$`uid`
      }
      if (!is.null(self$`url`)) {
        AccountCartAddHybrisWebsitesInnerObject[["url"]] <-
          self$`url`
      }
      if (!is.null(self$`storeIds`)) {
        AccountCartAddHybrisWebsitesInnerObject[["storeIds"]] <-
          self$`storeIds`
      }
      return(AccountCartAddHybrisWebsitesInnerObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of AccountCartAddHybrisWebsitesInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of AccountCartAddHybrisWebsitesInner
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`uid`)) {
        self$`uid` <- this_object$`uid`
      }
      if (!is.null(this_object$`url`)) {
        self$`url` <- this_object$`url`
      }
      if (!is.null(this_object$`storeIds`)) {
        self$`storeIds` <- ApiClient$new()$deserializeObj(this_object$`storeIds`, "array[character]", loadNamespace("openapi"))
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return AccountCartAddHybrisWebsitesInner in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of AccountCartAddHybrisWebsitesInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of AccountCartAddHybrisWebsitesInner
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`uid` <- this_object$`uid`
      self$`url` <- this_object$`url`
      self$`storeIds` <- ApiClient$new()$deserializeObj(this_object$`storeIds`, "array[character]", loadNamespace("openapi"))
      self
    },

    #' @description
    #' Validate JSON input with respect to AccountCartAddHybrisWebsitesInner and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
      # check the required field `uid`
      if (!is.null(input_json$`uid`)) {
        if (!(is.character(input_json$`uid`) && length(input_json$`uid`) == 1)) {
          stop(paste("Error! Invalid data for `uid`. Must be a string:", input_json$`uid`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for AccountCartAddHybrisWebsitesInner: the required field `uid` is missing."))
      }
      # check the required field `url`
      if (!is.null(input_json$`url`)) {
        if (!(is.character(input_json$`url`) && length(input_json$`url`) == 1)) {
          stop(paste("Error! Invalid data for `url`. Must be a string:", input_json$`url`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for AccountCartAddHybrisWebsitesInner: the required field `url` is missing."))
      }
      # check the required field `storeIds`
      if (!is.null(input_json$`storeIds`)) {
        stopifnot(is.vector(input_json$`storeIds`), length(input_json$`storeIds`) != 0)
        tmp <- sapply(input_json$`storeIds`, function(x) stopifnot(is.character(x)))
      } else {
        stop(paste("The JSON input `", input, "` is invalid for AccountCartAddHybrisWebsitesInner: the required field `storeIds` is missing."))
      }
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of AccountCartAddHybrisWebsitesInner
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      # check if the required `uid` is null
      if (is.null(self$`uid`)) {
        return(FALSE)
      }

      # check if the required `url` is null
      if (is.null(self$`url`)) {
        return(FALSE)
      }

      # check if the required `storeIds` is null
      if (is.null(self$`storeIds`)) {
        return(FALSE)
      }

      if (length(self$`storeIds`) < 1) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      # check if the required `uid` is null
      if (is.null(self$`uid`)) {
        invalid_fields["uid"] <- "Non-nullable required field `uid` cannot be null."
      }

      # check if the required `url` is null
      if (is.null(self$`url`)) {
        invalid_fields["url"] <- "Non-nullable required field `url` cannot be null."
      }

      # check if the required `storeIds` is null
      if (is.null(self$`storeIds`)) {
        invalid_fields["storeIds"] <- "Non-nullable required field `storeIds` cannot be null."
      }

      if (length(self$`storeIds`) < 1) {
        invalid_fields["storeIds"] <- "Invalid length for ``, number of items must be greater than or equal to 1."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# AccountCartAddHybrisWebsitesInner$unlock()
#
## Below is an example to define the print function
# AccountCartAddHybrisWebsitesInner$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# AccountCartAddHybrisWebsitesInner$lock()

