#' Create a new ResponseProductOptionListResult
#'
#' @description
#' ResponseProductOptionListResult Class
#'
#' @docType class
#' @title ResponseProductOptionListResult
#' @description ResponseProductOptionListResult Class
#' @format An \code{R6Class} generator object
#' @field option  list(\link{ProductOption}) [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ResponseProductOptionListResult <- R6::R6Class(
  "ResponseProductOptionListResult",
  public = list(
    `option` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new ResponseProductOptionListResult class.
    #'
    #' @param option option
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`option` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`option`)) {
        stopifnot(is.vector(`option`), length(`option`) != 0)
        sapply(`option`, function(x) stopifnot(R6::is.R6(x)))
        self$`option` <- `option`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ResponseProductOptionListResult as a base R list.
    #' @examples
    #' # convert array of ResponseProductOptionListResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ResponseProductOptionListResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ResponseProductOptionListResultObject <- list()
      if (!is.null(self$`option`)) {
        ResponseProductOptionListResultObject[["option"]] <-
          lapply(self$`option`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`additional_fields`)) {
        ResponseProductOptionListResultObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        ResponseProductOptionListResultObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(ResponseProductOptionListResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ResponseProductOptionListResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ResponseProductOptionListResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`option`)) {
        self$`option` <- ApiClient$new()$deserializeObj(this_object$`option`, "array[ProductOption]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ResponseProductOptionListResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ResponseProductOptionListResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ResponseProductOptionListResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`option` <- ApiClient$new()$deserializeObj(this_object$`option`, "array[ProductOption]", loadNamespace("openapi"))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to ResponseProductOptionListResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ResponseProductOptionListResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ResponseProductOptionListResult$unlock()
#
## Below is an example to define the print function
# ResponseProductOptionListResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ResponseProductOptionListResult$lock()

