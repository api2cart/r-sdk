#' Create a new OrderInvoiceTotals
#'
#' @description
#' OrderInvoiceTotals Class
#'
#' @docType class
#' @title OrderInvoiceTotals
#' @description OrderInvoiceTotals Class
#' @format An \code{R6Class} generator object
#' @field subtotal  numeric [optional]
#' @field discount  numeric [optional]
#' @field shipping  numeric [optional]
#' @field tax  numeric [optional]
#' @field total  numeric [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
OrderInvoiceTotals <- R6::R6Class(
  "OrderInvoiceTotals",
  public = list(
    `subtotal` = NULL,
    `discount` = NULL,
    `shipping` = NULL,
    `tax` = NULL,
    `total` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new OrderInvoiceTotals class.
    #'
    #' @param subtotal subtotal
    #' @param discount discount
    #' @param shipping shipping
    #' @param tax tax
    #' @param total total
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`subtotal` = NULL, `discount` = NULL, `shipping` = NULL, `tax` = NULL, `total` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`subtotal`)) {
        self$`subtotal` <- `subtotal`
      }
      if (!is.null(`discount`)) {
        self$`discount` <- `discount`
      }
      if (!is.null(`shipping`)) {
        self$`shipping` <- `shipping`
      }
      if (!is.null(`tax`)) {
        self$`tax` <- `tax`
      }
      if (!is.null(`total`)) {
        self$`total` <- `total`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return OrderInvoiceTotals as a base R list.
    #' @examples
    #' # convert array of OrderInvoiceTotals (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert OrderInvoiceTotals to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      OrderInvoiceTotalsObject <- list()
      if (!is.null(self$`subtotal`)) {
        OrderInvoiceTotalsObject[["subtotal"]] <-
          self$`subtotal`
      }
      if (!is.null(self$`discount`)) {
        OrderInvoiceTotalsObject[["discount"]] <-
          self$`discount`
      }
      if (!is.null(self$`shipping`)) {
        OrderInvoiceTotalsObject[["shipping"]] <-
          self$`shipping`
      }
      if (!is.null(self$`tax`)) {
        OrderInvoiceTotalsObject[["tax"]] <-
          self$`tax`
      }
      if (!is.null(self$`total`)) {
        OrderInvoiceTotalsObject[["total"]] <-
          self$`total`
      }
      if (!is.null(self$`additional_fields`)) {
        OrderInvoiceTotalsObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        OrderInvoiceTotalsObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(OrderInvoiceTotalsObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderInvoiceTotals
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderInvoiceTotals
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`subtotal`)) {
        self$`subtotal` <- this_object$`subtotal`
      }
      if (!is.null(this_object$`discount`)) {
        self$`discount` <- this_object$`discount`
      }
      if (!is.null(this_object$`shipping`)) {
        self$`shipping` <- this_object$`shipping`
      }
      if (!is.null(this_object$`tax`)) {
        self$`tax` <- this_object$`tax`
      }
      if (!is.null(this_object$`total`)) {
        self$`total` <- this_object$`total`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return OrderInvoiceTotals in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderInvoiceTotals
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderInvoiceTotals
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`subtotal` <- this_object$`subtotal`
      self$`discount` <- this_object$`discount`
      self$`shipping` <- this_object$`shipping`
      self$`tax` <- this_object$`tax`
      self$`total` <- this_object$`total`
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to OrderInvoiceTotals and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of OrderInvoiceTotals
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# OrderInvoiceTotals$unlock()
#
## Below is an example to define the print function
# OrderInvoiceTotals$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# OrderInvoiceTotals$lock()

