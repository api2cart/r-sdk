#' Create a new Cart
#'
#' @description
#' Cart Class
#'
#' @docType class
#' @title Cart
#' @description Cart Class
#' @format An \code{R6Class} generator object
#' @field name  character [optional]
#' @field url  character [optional]
#' @field version  character [optional]
#' @field bridge_version  character [optional]
#' @field default_rounding_precision  integer [optional]
#' @field db_prefix  character [optional]
#' @field stores_info  list(\link{CartStoreInfo}) [optional]
#' @field warehouses  list(\link{CartWarehouse}) [optional]
#' @field shipping_zones  list(\link{CartShippingZone}) [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
Cart <- R6::R6Class(
  "Cart",
  public = list(
    `name` = NULL,
    `url` = NULL,
    `version` = NULL,
    `bridge_version` = NULL,
    `default_rounding_precision` = NULL,
    `db_prefix` = NULL,
    `stores_info` = NULL,
    `warehouses` = NULL,
    `shipping_zones` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new Cart class.
    #'
    #' @param name name
    #' @param url url
    #' @param version version
    #' @param bridge_version bridge_version
    #' @param default_rounding_precision default_rounding_precision
    #' @param db_prefix db_prefix
    #' @param stores_info stores_info
    #' @param warehouses warehouses
    #' @param shipping_zones shipping_zones
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`name` = NULL, `url` = NULL, `version` = NULL, `bridge_version` = NULL, `default_rounding_precision` = NULL, `db_prefix` = NULL, `stores_info` = NULL, `warehouses` = NULL, `shipping_zones` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`url`)) {
        if (!(is.character(`url`) && length(`url`) == 1)) {
          stop(paste("Error! Invalid data for `url`. Must be a string:", `url`))
        }
        self$`url` <- `url`
      }
      if (!is.null(`version`)) {
        if (!(is.character(`version`) && length(`version`) == 1)) {
          stop(paste("Error! Invalid data for `version`. Must be a string:", `version`))
        }
        self$`version` <- `version`
      }
      if (!is.null(`bridge_version`)) {
        if (!(is.character(`bridge_version`) && length(`bridge_version`) == 1)) {
          stop(paste("Error! Invalid data for `bridge_version`. Must be a string:", `bridge_version`))
        }
        self$`bridge_version` <- `bridge_version`
      }
      if (!is.null(`default_rounding_precision`)) {
        if (!(is.numeric(`default_rounding_precision`) && length(`default_rounding_precision`) == 1)) {
          stop(paste("Error! Invalid data for `default_rounding_precision`. Must be an integer:", `default_rounding_precision`))
        }
        self$`default_rounding_precision` <- `default_rounding_precision`
      }
      if (!is.null(`db_prefix`)) {
        if (!(is.character(`db_prefix`) && length(`db_prefix`) == 1)) {
          stop(paste("Error! Invalid data for `db_prefix`. Must be a string:", `db_prefix`))
        }
        self$`db_prefix` <- `db_prefix`
      }
      if (!is.null(`stores_info`)) {
        stopifnot(is.vector(`stores_info`), length(`stores_info`) != 0)
        sapply(`stores_info`, function(x) stopifnot(R6::is.R6(x)))
        self$`stores_info` <- `stores_info`
      }
      if (!is.null(`warehouses`)) {
        stopifnot(is.vector(`warehouses`), length(`warehouses`) != 0)
        sapply(`warehouses`, function(x) stopifnot(R6::is.R6(x)))
        self$`warehouses` <- `warehouses`
      }
      if (!is.null(`shipping_zones`)) {
        stopifnot(is.vector(`shipping_zones`), length(`shipping_zones`) != 0)
        sapply(`shipping_zones`, function(x) stopifnot(R6::is.R6(x)))
        self$`shipping_zones` <- `shipping_zones`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return Cart as a base R list.
    #' @examples
    #' # convert array of Cart (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert Cart to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      CartObject <- list()
      if (!is.null(self$`name`)) {
        CartObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`url`)) {
        CartObject[["url"]] <-
          self$`url`
      }
      if (!is.null(self$`version`)) {
        CartObject[["version"]] <-
          self$`version`
      }
      if (!is.null(self$`bridge_version`)) {
        CartObject[["bridge_version"]] <-
          self$`bridge_version`
      }
      if (!is.null(self$`default_rounding_precision`)) {
        CartObject[["default_rounding_precision"]] <-
          self$`default_rounding_precision`
      }
      if (!is.null(self$`db_prefix`)) {
        CartObject[["db_prefix"]] <-
          self$`db_prefix`
      }
      if (!is.null(self$`stores_info`)) {
        CartObject[["stores_info"]] <-
          lapply(self$`stores_info`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`warehouses`)) {
        CartObject[["warehouses"]] <-
          lapply(self$`warehouses`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`shipping_zones`)) {
        CartObject[["shipping_zones"]] <-
          lapply(self$`shipping_zones`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`additional_fields`)) {
        CartObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        CartObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(CartObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of Cart
    #'
    #' @param input_json the JSON input
    #' @return the instance of Cart
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`url`)) {
        self$`url` <- this_object$`url`
      }
      if (!is.null(this_object$`version`)) {
        self$`version` <- this_object$`version`
      }
      if (!is.null(this_object$`bridge_version`)) {
        self$`bridge_version` <- this_object$`bridge_version`
      }
      if (!is.null(this_object$`default_rounding_precision`)) {
        self$`default_rounding_precision` <- this_object$`default_rounding_precision`
      }
      if (!is.null(this_object$`db_prefix`)) {
        self$`db_prefix` <- this_object$`db_prefix`
      }
      if (!is.null(this_object$`stores_info`)) {
        self$`stores_info` <- ApiClient$new()$deserializeObj(this_object$`stores_info`, "array[CartStoreInfo]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`warehouses`)) {
        self$`warehouses` <- ApiClient$new()$deserializeObj(this_object$`warehouses`, "array[CartWarehouse]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`shipping_zones`)) {
        self$`shipping_zones` <- ApiClient$new()$deserializeObj(this_object$`shipping_zones`, "array[CartShippingZone]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return Cart in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of Cart
    #'
    #' @param input_json the JSON input
    #' @return the instance of Cart
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`name` <- this_object$`name`
      self$`url` <- this_object$`url`
      self$`version` <- this_object$`version`
      self$`bridge_version` <- this_object$`bridge_version`
      self$`default_rounding_precision` <- this_object$`default_rounding_precision`
      self$`db_prefix` <- this_object$`db_prefix`
      self$`stores_info` <- ApiClient$new()$deserializeObj(this_object$`stores_info`, "array[CartStoreInfo]", loadNamespace("openapi"))
      self$`warehouses` <- ApiClient$new()$deserializeObj(this_object$`warehouses`, "array[CartWarehouse]", loadNamespace("openapi"))
      self$`shipping_zones` <- ApiClient$new()$deserializeObj(this_object$`shipping_zones`, "array[CartShippingZone]", loadNamespace("openapi"))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to Cart and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of Cart
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# Cart$unlock()
#
## Below is an example to define the print function
# Cart$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# Cart$lock()

