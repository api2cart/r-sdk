#' Create a new OrderInvoiceItem
#'
#' @description
#' OrderInvoiceItem Class
#'
#' @docType class
#' @title OrderInvoiceItem
#' @description OrderInvoiceItem Class
#' @format An \code{R6Class} generator object
#' @field order_product_id  character [optional]
#' @field product_id  character [optional]
#' @field variant_id  character [optional]
#' @field sku  character [optional]
#' @field name  character [optional]
#' @field quantity  numeric [optional]
#' @field price  numeric [optional]
#' @field tax  numeric [optional]
#' @field total  numeric [optional]
#' @field options  list(\link{OrderItemOption}) [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
OrderInvoiceItem <- R6::R6Class(
  "OrderInvoiceItem",
  public = list(
    `order_product_id` = NULL,
    `product_id` = NULL,
    `variant_id` = NULL,
    `sku` = NULL,
    `name` = NULL,
    `quantity` = NULL,
    `price` = NULL,
    `tax` = NULL,
    `total` = NULL,
    `options` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new OrderInvoiceItem class.
    #'
    #' @param order_product_id order_product_id
    #' @param product_id product_id
    #' @param variant_id variant_id
    #' @param sku sku
    #' @param name name
    #' @param quantity quantity
    #' @param price price
    #' @param tax tax
    #' @param total total
    #' @param options options
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`order_product_id` = NULL, `product_id` = NULL, `variant_id` = NULL, `sku` = NULL, `name` = NULL, `quantity` = NULL, `price` = NULL, `tax` = NULL, `total` = NULL, `options` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`order_product_id`)) {
        if (!(is.character(`order_product_id`) && length(`order_product_id`) == 1)) {
          stop(paste("Error! Invalid data for `order_product_id`. Must be a string:", `order_product_id`))
        }
        self$`order_product_id` <- `order_product_id`
      }
      if (!is.null(`product_id`)) {
        if (!(is.character(`product_id`) && length(`product_id`) == 1)) {
          stop(paste("Error! Invalid data for `product_id`. Must be a string:", `product_id`))
        }
        self$`product_id` <- `product_id`
      }
      if (!is.null(`variant_id`)) {
        if (!(is.character(`variant_id`) && length(`variant_id`) == 1)) {
          stop(paste("Error! Invalid data for `variant_id`. Must be a string:", `variant_id`))
        }
        self$`variant_id` <- `variant_id`
      }
      if (!is.null(`sku`)) {
        if (!(is.character(`sku`) && length(`sku`) == 1)) {
          stop(paste("Error! Invalid data for `sku`. Must be a string:", `sku`))
        }
        self$`sku` <- `sku`
      }
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`quantity`)) {
        self$`quantity` <- `quantity`
      }
      if (!is.null(`price`)) {
        self$`price` <- `price`
      }
      if (!is.null(`tax`)) {
        self$`tax` <- `tax`
      }
      if (!is.null(`total`)) {
        self$`total` <- `total`
      }
      if (!is.null(`options`)) {
        stopifnot(is.vector(`options`), length(`options`) != 0)
        sapply(`options`, function(x) stopifnot(R6::is.R6(x)))
        self$`options` <- `options`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return OrderInvoiceItem as a base R list.
    #' @examples
    #' # convert array of OrderInvoiceItem (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert OrderInvoiceItem to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      OrderInvoiceItemObject <- list()
      if (!is.null(self$`order_product_id`)) {
        OrderInvoiceItemObject[["order_product_id"]] <-
          self$`order_product_id`
      }
      if (!is.null(self$`product_id`)) {
        OrderInvoiceItemObject[["product_id"]] <-
          self$`product_id`
      }
      if (!is.null(self$`variant_id`)) {
        OrderInvoiceItemObject[["variant_id"]] <-
          self$`variant_id`
      }
      if (!is.null(self$`sku`)) {
        OrderInvoiceItemObject[["sku"]] <-
          self$`sku`
      }
      if (!is.null(self$`name`)) {
        OrderInvoiceItemObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`quantity`)) {
        OrderInvoiceItemObject[["quantity"]] <-
          self$`quantity`
      }
      if (!is.null(self$`price`)) {
        OrderInvoiceItemObject[["price"]] <-
          self$`price`
      }
      if (!is.null(self$`tax`)) {
        OrderInvoiceItemObject[["tax"]] <-
          self$`tax`
      }
      if (!is.null(self$`total`)) {
        OrderInvoiceItemObject[["total"]] <-
          self$`total`
      }
      if (!is.null(self$`options`)) {
        OrderInvoiceItemObject[["options"]] <-
          lapply(self$`options`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`additional_fields`)) {
        OrderInvoiceItemObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        OrderInvoiceItemObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(OrderInvoiceItemObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderInvoiceItem
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderInvoiceItem
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`order_product_id`)) {
        self$`order_product_id` <- this_object$`order_product_id`
      }
      if (!is.null(this_object$`product_id`)) {
        self$`product_id` <- this_object$`product_id`
      }
      if (!is.null(this_object$`variant_id`)) {
        self$`variant_id` <- this_object$`variant_id`
      }
      if (!is.null(this_object$`sku`)) {
        self$`sku` <- this_object$`sku`
      }
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`quantity`)) {
        self$`quantity` <- this_object$`quantity`
      }
      if (!is.null(this_object$`price`)) {
        self$`price` <- this_object$`price`
      }
      if (!is.null(this_object$`tax`)) {
        self$`tax` <- this_object$`tax`
      }
      if (!is.null(this_object$`total`)) {
        self$`total` <- this_object$`total`
      }
      if (!is.null(this_object$`options`)) {
        self$`options` <- ApiClient$new()$deserializeObj(this_object$`options`, "array[OrderItemOption]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return OrderInvoiceItem in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderInvoiceItem
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderInvoiceItem
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`order_product_id` <- this_object$`order_product_id`
      self$`product_id` <- this_object$`product_id`
      self$`variant_id` <- this_object$`variant_id`
      self$`sku` <- this_object$`sku`
      self$`name` <- this_object$`name`
      self$`quantity` <- this_object$`quantity`
      self$`price` <- this_object$`price`
      self$`tax` <- this_object$`tax`
      self$`total` <- this_object$`total`
      self$`options` <- ApiClient$new()$deserializeObj(this_object$`options`, "array[OrderItemOption]", loadNamespace("openapi"))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to OrderInvoiceItem and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of OrderInvoiceItem
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# OrderInvoiceItem$unlock()
#
## Below is an example to define the print function
# OrderInvoiceItem$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# OrderInvoiceItem$lock()

