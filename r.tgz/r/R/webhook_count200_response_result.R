#' Create a new WebhookCount200ResponseResult
#'
#' @description
#' WebhookCount200ResponseResult Class
#'
#' @docType class
#' @title WebhookCount200ResponseResult
#' @description WebhookCount200ResponseResult Class
#' @format An \code{R6Class} generator object
#' @field webhook_count  integer [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
WebhookCount200ResponseResult <- R6::R6Class(
  "WebhookCount200ResponseResult",
  public = list(
    `webhook_count` = NULL,

    #' @description
    #' Initialize a new WebhookCount200ResponseResult class.
    #'
    #' @param webhook_count webhook_count
    #' @param ... Other optional arguments.
    initialize = function(`webhook_count` = NULL, ...) {
      if (!is.null(`webhook_count`)) {
        if (!(is.numeric(`webhook_count`) && length(`webhook_count`) == 1)) {
          stop(paste("Error! Invalid data for `webhook_count`. Must be an integer:", `webhook_count`))
        }
        self$`webhook_count` <- `webhook_count`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return WebhookCount200ResponseResult as a base R list.
    #' @examples
    #' # convert array of WebhookCount200ResponseResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert WebhookCount200ResponseResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      WebhookCount200ResponseResultObject <- list()
      if (!is.null(self$`webhook_count`)) {
        WebhookCount200ResponseResultObject[["webhook_count"]] <-
          self$`webhook_count`
      }
      return(WebhookCount200ResponseResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of WebhookCount200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of WebhookCount200ResponseResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`webhook_count`)) {
        self$`webhook_count` <- this_object$`webhook_count`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return WebhookCount200ResponseResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of WebhookCount200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of WebhookCount200ResponseResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`webhook_count` <- this_object$`webhook_count`
      self
    },

    #' @description
    #' Validate JSON input with respect to WebhookCount200ResponseResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of WebhookCount200ResponseResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# WebhookCount200ResponseResult$unlock()
#
## Below is an example to define the print function
# WebhookCount200ResponseResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# WebhookCount200ResponseResult$lock()

