#' Create a new ResponseCartCatalogPriceRulesListResult
#'
#' @description
#' ResponseCartCatalogPriceRulesListResult Class
#'
#' @docType class
#' @title ResponseCartCatalogPriceRulesListResult
#' @description ResponseCartCatalogPriceRulesListResult Class
#' @format An \code{R6Class} generator object
#' @field catalog_price_rules_count  integer [optional]
#' @field catalog_price_rules  list(\link{CatalogPriceRule}) [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ResponseCartCatalogPriceRulesListResult <- R6::R6Class(
  "ResponseCartCatalogPriceRulesListResult",
  public = list(
    `catalog_price_rules_count` = NULL,
    `catalog_price_rules` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new ResponseCartCatalogPriceRulesListResult class.
    #'
    #' @param catalog_price_rules_count catalog_price_rules_count
    #' @param catalog_price_rules catalog_price_rules
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`catalog_price_rules_count` = NULL, `catalog_price_rules` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`catalog_price_rules_count`)) {
        if (!(is.numeric(`catalog_price_rules_count`) && length(`catalog_price_rules_count`) == 1)) {
          stop(paste("Error! Invalid data for `catalog_price_rules_count`. Must be an integer:", `catalog_price_rules_count`))
        }
        self$`catalog_price_rules_count` <- `catalog_price_rules_count`
      }
      if (!is.null(`catalog_price_rules`)) {
        stopifnot(is.vector(`catalog_price_rules`), length(`catalog_price_rules`) != 0)
        sapply(`catalog_price_rules`, function(x) stopifnot(R6::is.R6(x)))
        self$`catalog_price_rules` <- `catalog_price_rules`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ResponseCartCatalogPriceRulesListResult as a base R list.
    #' @examples
    #' # convert array of ResponseCartCatalogPriceRulesListResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ResponseCartCatalogPriceRulesListResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ResponseCartCatalogPriceRulesListResultObject <- list()
      if (!is.null(self$`catalog_price_rules_count`)) {
        ResponseCartCatalogPriceRulesListResultObject[["catalog_price_rules_count"]] <-
          self$`catalog_price_rules_count`
      }
      if (!is.null(self$`catalog_price_rules`)) {
        ResponseCartCatalogPriceRulesListResultObject[["catalog_price_rules"]] <-
          lapply(self$`catalog_price_rules`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`additional_fields`)) {
        ResponseCartCatalogPriceRulesListResultObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        ResponseCartCatalogPriceRulesListResultObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(ResponseCartCatalogPriceRulesListResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ResponseCartCatalogPriceRulesListResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ResponseCartCatalogPriceRulesListResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`catalog_price_rules_count`)) {
        self$`catalog_price_rules_count` <- this_object$`catalog_price_rules_count`
      }
      if (!is.null(this_object$`catalog_price_rules`)) {
        self$`catalog_price_rules` <- ApiClient$new()$deserializeObj(this_object$`catalog_price_rules`, "array[CatalogPriceRule]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ResponseCartCatalogPriceRulesListResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ResponseCartCatalogPriceRulesListResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ResponseCartCatalogPriceRulesListResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`catalog_price_rules_count` <- this_object$`catalog_price_rules_count`
      self$`catalog_price_rules` <- ApiClient$new()$deserializeObj(this_object$`catalog_price_rules`, "array[CatalogPriceRule]", loadNamespace("openapi"))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to ResponseCartCatalogPriceRulesListResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ResponseCartCatalogPriceRulesListResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ResponseCartCatalogPriceRulesListResult$unlock()
#
## Below is an example to define the print function
# ResponseCartCatalogPriceRulesListResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ResponseCartCatalogPriceRulesListResult$lock()

