#' Create a new ProductAddPersonalizationQuestionsInner
#'
#' @description
#' ProductAddPersonalizationQuestionsInner Class
#'
#' @docType class
#' @title ProductAddPersonalizationQuestionsInner
#' @description ProductAddPersonalizationQuestionsInner Class
#' @format An \code{R6Class} generator object
#' @field question_text  character
#' @field instructions  character [optional]
#' @field question_type  character
#' @field required  character
#' @field max_allowed_characters  integer [optional]
#' @field max_allowed_files  integer [optional]
#' @field options  list(character) [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductAddPersonalizationQuestionsInner <- R6::R6Class(
  "ProductAddPersonalizationQuestionsInner",
  public = list(
    `question_text` = NULL,
    `instructions` = NULL,
    `question_type` = NULL,
    `required` = NULL,
    `max_allowed_characters` = NULL,
    `max_allowed_files` = NULL,
    `options` = NULL,

    #' @description
    #' Initialize a new ProductAddPersonalizationQuestionsInner class.
    #'
    #' @param question_text question_text
    #' @param question_type question_type
    #' @param required required
    #' @param instructions instructions
    #' @param max_allowed_characters max_allowed_characters
    #' @param max_allowed_files max_allowed_files
    #' @param options options
    #' @param ... Other optional arguments.
    initialize = function(`question_text`, `question_type`, `required`, `instructions` = NULL, `max_allowed_characters` = NULL, `max_allowed_files` = NULL, `options` = NULL, ...) {
      if (!missing(`question_text`)) {
        if (!(is.character(`question_text`) && length(`question_text`) == 1)) {
          stop(paste("Error! Invalid data for `question_text`. Must be a string:", `question_text`))
        }
        self$`question_text` <- `question_text`
      }
      if (!missing(`question_type`)) {
        if (!(`question_type` %in% c("text_input", "dropdown", "unlabeled_upload", "labeled_upload"))) {
          stop(paste("Error! \"", `question_type`, "\" cannot be assigned to `question_type`. Must be \"text_input\", \"dropdown\", \"unlabeled_upload\", \"labeled_upload\".", sep = ""))
        }
        if (!(is.character(`question_type`) && length(`question_type`) == 1)) {
          stop(paste("Error! Invalid data for `question_type`. Must be a string:", `question_type`))
        }
        self$`question_type` <- `question_type`
      }
      if (!missing(`required`)) {
        if (!(is.logical(`required`) && length(`required`) == 1)) {
          stop(paste("Error! Invalid data for `required`. Must be a boolean:", `required`))
        }
        self$`required` <- `required`
      }
      if (!is.null(`instructions`)) {
        if (!(is.character(`instructions`) && length(`instructions`) == 1)) {
          stop(paste("Error! Invalid data for `instructions`. Must be a string:", `instructions`))
        }
        self$`instructions` <- `instructions`
      }
      if (!is.null(`max_allowed_characters`)) {
        if (!(is.numeric(`max_allowed_characters`) && length(`max_allowed_characters`) == 1)) {
          stop(paste("Error! Invalid data for `max_allowed_characters`. Must be an integer:", `max_allowed_characters`))
        }
        self$`max_allowed_characters` <- `max_allowed_characters`
      }
      if (!is.null(`max_allowed_files`)) {
        if (!(is.numeric(`max_allowed_files`) && length(`max_allowed_files`) == 1)) {
          stop(paste("Error! Invalid data for `max_allowed_files`. Must be an integer:", `max_allowed_files`))
        }
        self$`max_allowed_files` <- `max_allowed_files`
      }
      if (!is.null(`options`)) {
        stopifnot(is.vector(`options`), length(`options`) != 0)
        sapply(`options`, function(x) stopifnot(is.character(x)))
        self$`options` <- `options`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductAddPersonalizationQuestionsInner as a base R list.
    #' @examples
    #' # convert array of ProductAddPersonalizationQuestionsInner (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductAddPersonalizationQuestionsInner to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductAddPersonalizationQuestionsInnerObject <- list()
      if (!is.null(self$`question_text`)) {
        ProductAddPersonalizationQuestionsInnerObject[["question_text"]] <-
          self$`question_text`
      }
      if (!is.null(self$`instructions`)) {
        ProductAddPersonalizationQuestionsInnerObject[["instructions"]] <-
          self$`instructions`
      }
      if (!is.null(self$`question_type`)) {
        ProductAddPersonalizationQuestionsInnerObject[["question_type"]] <-
          self$`question_type`
      }
      if (!is.null(self$`required`)) {
        ProductAddPersonalizationQuestionsInnerObject[["required"]] <-
          self$`required`
      }
      if (!is.null(self$`max_allowed_characters`)) {
        ProductAddPersonalizationQuestionsInnerObject[["max_allowed_characters"]] <-
          self$`max_allowed_characters`
      }
      if (!is.null(self$`max_allowed_files`)) {
        ProductAddPersonalizationQuestionsInnerObject[["max_allowed_files"]] <-
          self$`max_allowed_files`
      }
      if (!is.null(self$`options`)) {
        ProductAddPersonalizationQuestionsInnerObject[["options"]] <-
          self$`options`
      }
      return(ProductAddPersonalizationQuestionsInnerObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductAddPersonalizationQuestionsInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductAddPersonalizationQuestionsInner
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`question_text`)) {
        self$`question_text` <- this_object$`question_text`
      }
      if (!is.null(this_object$`instructions`)) {
        self$`instructions` <- this_object$`instructions`
      }
      if (!is.null(this_object$`question_type`)) {
        if (!is.null(this_object$`question_type`) && !(this_object$`question_type` %in% c("text_input", "dropdown", "unlabeled_upload", "labeled_upload"))) {
          stop(paste("Error! \"", this_object$`question_type`, "\" cannot be assigned to `question_type`. Must be \"text_input\", \"dropdown\", \"unlabeled_upload\", \"labeled_upload\".", sep = ""))
        }
        self$`question_type` <- this_object$`question_type`
      }
      if (!is.null(this_object$`required`)) {
        self$`required` <- this_object$`required`
      }
      if (!is.null(this_object$`max_allowed_characters`)) {
        self$`max_allowed_characters` <- this_object$`max_allowed_characters`
      }
      if (!is.null(this_object$`max_allowed_files`)) {
        self$`max_allowed_files` <- this_object$`max_allowed_files`
      }
      if (!is.null(this_object$`options`)) {
        self$`options` <- ApiClient$new()$deserializeObj(this_object$`options`, "array[character]", loadNamespace("openapi"))
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductAddPersonalizationQuestionsInner in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductAddPersonalizationQuestionsInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductAddPersonalizationQuestionsInner
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`question_text` <- this_object$`question_text`
      self$`instructions` <- this_object$`instructions`
      if (!is.null(this_object$`question_type`) && !(this_object$`question_type` %in% c("text_input", "dropdown", "unlabeled_upload", "labeled_upload"))) {
        stop(paste("Error! \"", this_object$`question_type`, "\" cannot be assigned to `question_type`. Must be \"text_input\", \"dropdown\", \"unlabeled_upload\", \"labeled_upload\".", sep = ""))
      }
      self$`question_type` <- this_object$`question_type`
      self$`required` <- this_object$`required`
      self$`max_allowed_characters` <- this_object$`max_allowed_characters`
      self$`max_allowed_files` <- this_object$`max_allowed_files`
      self$`options` <- ApiClient$new()$deserializeObj(this_object$`options`, "array[character]", loadNamespace("openapi"))
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductAddPersonalizationQuestionsInner and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
      # check the required field `question_text`
      if (!is.null(input_json$`question_text`)) {
        if (!(is.character(input_json$`question_text`) && length(input_json$`question_text`) == 1)) {
          stop(paste("Error! Invalid data for `question_text`. Must be a string:", input_json$`question_text`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for ProductAddPersonalizationQuestionsInner: the required field `question_text` is missing."))
      }
      # check the required field `question_type`
      if (!is.null(input_json$`question_type`)) {
        if (!(is.character(input_json$`question_type`) && length(input_json$`question_type`) == 1)) {
          stop(paste("Error! Invalid data for `question_type`. Must be a string:", input_json$`question_type`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for ProductAddPersonalizationQuestionsInner: the required field `question_type` is missing."))
      }
      # check the required field `required`
      if (!is.null(input_json$`required`)) {
        if (!(is.logical(input_json$`required`) && length(input_json$`required`) == 1)) {
          stop(paste("Error! Invalid data for `required`. Must be a boolean:", input_json$`required`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for ProductAddPersonalizationQuestionsInner: the required field `required` is missing."))
      }
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductAddPersonalizationQuestionsInner
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      # check if the required `question_text` is null
      if (is.null(self$`question_text`)) {
        return(FALSE)
      }

      if (nchar(self$`question_text`) > 45) {
        return(FALSE)
      }
      if (nchar(self$`question_text`) < 1) {
        return(FALSE)
      }

      if (nchar(self$`instructions`) > 120) {
        return(FALSE)
      }
      if (nchar(self$`instructions`) < 1) {
        return(FALSE)
      }

      # check if the required `question_type` is null
      if (is.null(self$`question_type`)) {
        return(FALSE)
      }

      # check if the required `required` is null
      if (is.null(self$`required`)) {
        return(FALSE)
      }

      if (self$`max_allowed_characters` > 1024) {
        return(FALSE)
      }
      if (self$`max_allowed_characters` < 1) {
        return(FALSE)
      }

      if (self$`max_allowed_files` > 10) {
        return(FALSE)
      }
      if (self$`max_allowed_files` < 1) {
        return(FALSE)
      }

      if (length(self$`options`) > 30) {
        return(FALSE)
      }
      if (length(self$`options`) < 1) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      # check if the required `question_text` is null
      if (is.null(self$`question_text`)) {
        invalid_fields["question_text"] <- "Non-nullable required field `question_text` cannot be null."
      }

      if (nchar(self$`question_text`) > 45) {
        invalid_fields["question_text"] <- "Invalid length for `question_text`, must be smaller than or equal to 45."
      }
      if (nchar(self$`question_text`) < 1) {
        invalid_fields["question_text"] <- "Invalid length for `question_text`, must be bigger than or equal to 1."
      }

      if (nchar(self$`instructions`) > 120) {
        invalid_fields["instructions"] <- "Invalid length for `instructions`, must be smaller than or equal to 120."
      }
      if (nchar(self$`instructions`) < 1) {
        invalid_fields["instructions"] <- "Invalid length for `instructions`, must be bigger than or equal to 1."
      }

      # check if the required `question_type` is null
      if (is.null(self$`question_type`)) {
        invalid_fields["question_type"] <- "Non-nullable required field `question_type` cannot be null."
      }

      # check if the required `required` is null
      if (is.null(self$`required`)) {
        invalid_fields["required"] <- "Non-nullable required field `required` cannot be null."
      }

      if (self$`max_allowed_characters` > 1024) {
        invalid_fields["max_allowed_characters"] <- "Invalid value for `max_allowed_characters`, must be smaller than or equal to 1024."
      }
      if (self$`max_allowed_characters` < 1) {
        invalid_fields["max_allowed_characters"] <- "Invalid value for `max_allowed_characters`, must be bigger than or equal to 1."
      }

      if (self$`max_allowed_files` > 10) {
        invalid_fields["max_allowed_files"] <- "Invalid value for `max_allowed_files`, must be smaller than or equal to 10."
      }
      if (self$`max_allowed_files` < 1) {
        invalid_fields["max_allowed_files"] <- "Invalid value for `max_allowed_files`, must be bigger than or equal to 1."
      }

      if (length(self$`options`) > 30) {
        invalid_fields["options"] <- "Invalid length for `options`, number of items must be less than or equal to 30."
      }
      if (length(self$`options`) < 1) {
        invalid_fields["options"] <- "Invalid length for ``, number of items must be greater than or equal to 1."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductAddPersonalizationQuestionsInner$unlock()
#
## Below is an example to define the print function
# ProductAddPersonalizationQuestionsInner$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductAddPersonalizationQuestionsInner$lock()

