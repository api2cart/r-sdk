#' Create a new TaxClassCountries
#'
#' @description
#' TaxClassCountries Class
#'
#' @docType class
#' @title TaxClassCountries
#' @description TaxClassCountries Class
#' @format An \code{R6Class} generator object
#' @field id  character [optional]
#' @field name  character [optional]
#' @field code  character [optional]
#' @field tax  numeric [optional]
#' @field tax_type  integer [optional]
#' @field states  list(\link{TaxClassStates}) [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
TaxClassCountries <- R6::R6Class(
  "TaxClassCountries",
  public = list(
    `id` = NULL,
    `name` = NULL,
    `code` = NULL,
    `tax` = NULL,
    `tax_type` = NULL,
    `states` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new TaxClassCountries class.
    #'
    #' @param id id
    #' @param name name
    #' @param code code
    #' @param tax tax
    #' @param tax_type tax_type
    #' @param states states
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `name` = NULL, `code` = NULL, `tax` = NULL, `tax_type` = NULL, `states` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`code`)) {
        if (!(is.character(`code`) && length(`code`) == 1)) {
          stop(paste("Error! Invalid data for `code`. Must be a string:", `code`))
        }
        self$`code` <- `code`
      }
      if (!is.null(`tax`)) {
        self$`tax` <- `tax`
      }
      if (!is.null(`tax_type`)) {
        if (!(is.numeric(`tax_type`) && length(`tax_type`) == 1)) {
          stop(paste("Error! Invalid data for `tax_type`. Must be an integer:", `tax_type`))
        }
        self$`tax_type` <- `tax_type`
      }
      if (!is.null(`states`)) {
        stopifnot(is.vector(`states`), length(`states`) != 0)
        sapply(`states`, function(x) stopifnot(R6::is.R6(x)))
        self$`states` <- `states`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return TaxClassCountries as a base R list.
    #' @examples
    #' # convert array of TaxClassCountries (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert TaxClassCountries to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      TaxClassCountriesObject <- list()
      if (!is.null(self$`id`)) {
        TaxClassCountriesObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`name`)) {
        TaxClassCountriesObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`code`)) {
        TaxClassCountriesObject[["code"]] <-
          self$`code`
      }
      if (!is.null(self$`tax`)) {
        TaxClassCountriesObject[["tax"]] <-
          self$`tax`
      }
      if (!is.null(self$`tax_type`)) {
        TaxClassCountriesObject[["tax_type"]] <-
          self$`tax_type`
      }
      if (!is.null(self$`states`)) {
        TaxClassCountriesObject[["states"]] <-
          lapply(self$`states`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`additional_fields`)) {
        TaxClassCountriesObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        TaxClassCountriesObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(TaxClassCountriesObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of TaxClassCountries
    #'
    #' @param input_json the JSON input
    #' @return the instance of TaxClassCountries
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`code`)) {
        self$`code` <- this_object$`code`
      }
      if (!is.null(this_object$`tax`)) {
        self$`tax` <- this_object$`tax`
      }
      if (!is.null(this_object$`tax_type`)) {
        self$`tax_type` <- this_object$`tax_type`
      }
      if (!is.null(this_object$`states`)) {
        self$`states` <- ApiClient$new()$deserializeObj(this_object$`states`, "array[TaxClassStates]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return TaxClassCountries in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of TaxClassCountries
    #'
    #' @param input_json the JSON input
    #' @return the instance of TaxClassCountries
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`name` <- this_object$`name`
      self$`code` <- this_object$`code`
      self$`tax` <- this_object$`tax`
      self$`tax_type` <- this_object$`tax_type`
      self$`states` <- ApiClient$new()$deserializeObj(this_object$`states`, "array[TaxClassStates]", loadNamespace("openapi"))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to TaxClassCountries and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of TaxClassCountries
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# TaxClassCountries$unlock()
#
## Below is an example to define the print function
# TaxClassCountries$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# TaxClassCountries$lock()

