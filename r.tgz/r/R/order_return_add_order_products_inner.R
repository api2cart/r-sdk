#' Create a new OrderReturnAddOrderProductsInner
#'
#' @description
#' OrderReturnAddOrderProductsInner Class
#'
#' @docType class
#' @title OrderReturnAddOrderProductsInner
#' @description OrderReturnAddOrderProductsInner Class
#' @format An \code{R6Class} generator object
#' @field order_product_id Defines which products from the order should be returned character
#' @field order_product_quantity Defines how many product units from the order should be returned integer
#' @field order_product_reason_id Defines the ID of the return reason character
#' @field order_product_action_id Defines the ID of the return action character
#' @field order_product_customer_comment Defines the customer's comment for return character [optional]
#' @field order_product_handling_status Defines handling status character [optional]
#' @field order_product_condition Defines the product condition character [optional]
#' @field order_product_reason Defines return reason character [optional]
#' @field order_product_status Defines product return status character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
OrderReturnAddOrderProductsInner <- R6::R6Class(
  "OrderReturnAddOrderProductsInner",
  public = list(
    `order_product_id` = NULL,
    `order_product_quantity` = NULL,
    `order_product_reason_id` = NULL,
    `order_product_action_id` = NULL,
    `order_product_customer_comment` = NULL,
    `order_product_handling_status` = NULL,
    `order_product_condition` = NULL,
    `order_product_reason` = NULL,
    `order_product_status` = NULL,

    #' @description
    #' Initialize a new OrderReturnAddOrderProductsInner class.
    #'
    #' @param order_product_id Defines which products from the order should be returned
    #' @param order_product_quantity Defines how many product units from the order should be returned
    #' @param order_product_reason_id Defines the ID of the return reason
    #' @param order_product_action_id Defines the ID of the return action
    #' @param order_product_customer_comment Defines the customer's comment for return
    #' @param order_product_handling_status Defines handling status
    #' @param order_product_condition Defines the product condition
    #' @param order_product_reason Defines return reason
    #' @param order_product_status Defines product return status
    #' @param ... Other optional arguments.
    initialize = function(`order_product_id`, `order_product_quantity`, `order_product_reason_id`, `order_product_action_id`, `order_product_customer_comment` = NULL, `order_product_handling_status` = NULL, `order_product_condition` = NULL, `order_product_reason` = NULL, `order_product_status` = NULL, ...) {
      if (!missing(`order_product_id`)) {
        if (!(is.character(`order_product_id`) && length(`order_product_id`) == 1)) {
          stop(paste("Error! Invalid data for `order_product_id`. Must be a string:", `order_product_id`))
        }
        self$`order_product_id` <- `order_product_id`
      }
      if (!missing(`order_product_quantity`)) {
        if (!(is.numeric(`order_product_quantity`) && length(`order_product_quantity`) == 1)) {
          stop(paste("Error! Invalid data for `order_product_quantity`. Must be an integer:", `order_product_quantity`))
        }
        self$`order_product_quantity` <- `order_product_quantity`
      }
      if (!missing(`order_product_reason_id`)) {
        if (!(is.character(`order_product_reason_id`) && length(`order_product_reason_id`) == 1)) {
          stop(paste("Error! Invalid data for `order_product_reason_id`. Must be a string:", `order_product_reason_id`))
        }
        self$`order_product_reason_id` <- `order_product_reason_id`
      }
      if (!missing(`order_product_action_id`)) {
        if (!(is.character(`order_product_action_id`) && length(`order_product_action_id`) == 1)) {
          stop(paste("Error! Invalid data for `order_product_action_id`. Must be a string:", `order_product_action_id`))
        }
        self$`order_product_action_id` <- `order_product_action_id`
      }
      if (!is.null(`order_product_customer_comment`)) {
        if (!(is.character(`order_product_customer_comment`) && length(`order_product_customer_comment`) == 1)) {
          stop(paste("Error! Invalid data for `order_product_customer_comment`. Must be a string:", `order_product_customer_comment`))
        }
        self$`order_product_customer_comment` <- `order_product_customer_comment`
      }
      if (!is.null(`order_product_handling_status`)) {
        if (!(is.character(`order_product_handling_status`) && length(`order_product_handling_status`) == 1)) {
          stop(paste("Error! Invalid data for `order_product_handling_status`. Must be a string:", `order_product_handling_status`))
        }
        self$`order_product_handling_status` <- `order_product_handling_status`
      }
      if (!is.null(`order_product_condition`)) {
        if (!(is.character(`order_product_condition`) && length(`order_product_condition`) == 1)) {
          stop(paste("Error! Invalid data for `order_product_condition`. Must be a string:", `order_product_condition`))
        }
        self$`order_product_condition` <- `order_product_condition`
      }
      if (!is.null(`order_product_reason`)) {
        if (!(is.character(`order_product_reason`) && length(`order_product_reason`) == 1)) {
          stop(paste("Error! Invalid data for `order_product_reason`. Must be a string:", `order_product_reason`))
        }
        self$`order_product_reason` <- `order_product_reason`
      }
      if (!is.null(`order_product_status`)) {
        if (!(is.character(`order_product_status`) && length(`order_product_status`) == 1)) {
          stop(paste("Error! Invalid data for `order_product_status`. Must be a string:", `order_product_status`))
        }
        self$`order_product_status` <- `order_product_status`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return OrderReturnAddOrderProductsInner as a base R list.
    #' @examples
    #' # convert array of OrderReturnAddOrderProductsInner (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert OrderReturnAddOrderProductsInner to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      OrderReturnAddOrderProductsInnerObject <- list()
      if (!is.null(self$`order_product_id`)) {
        OrderReturnAddOrderProductsInnerObject[["order_product_id"]] <-
          self$`order_product_id`
      }
      if (!is.null(self$`order_product_quantity`)) {
        OrderReturnAddOrderProductsInnerObject[["order_product_quantity"]] <-
          self$`order_product_quantity`
      }
      if (!is.null(self$`order_product_reason_id`)) {
        OrderReturnAddOrderProductsInnerObject[["order_product_reason_id"]] <-
          self$`order_product_reason_id`
      }
      if (!is.null(self$`order_product_action_id`)) {
        OrderReturnAddOrderProductsInnerObject[["order_product_action_id"]] <-
          self$`order_product_action_id`
      }
      if (!is.null(self$`order_product_customer_comment`)) {
        OrderReturnAddOrderProductsInnerObject[["order_product_customer_comment"]] <-
          self$`order_product_customer_comment`
      }
      if (!is.null(self$`order_product_handling_status`)) {
        OrderReturnAddOrderProductsInnerObject[["order_product_handling_status"]] <-
          self$`order_product_handling_status`
      }
      if (!is.null(self$`order_product_condition`)) {
        OrderReturnAddOrderProductsInnerObject[["order_product_condition"]] <-
          self$`order_product_condition`
      }
      if (!is.null(self$`order_product_reason`)) {
        OrderReturnAddOrderProductsInnerObject[["order_product_reason"]] <-
          self$`order_product_reason`
      }
      if (!is.null(self$`order_product_status`)) {
        OrderReturnAddOrderProductsInnerObject[["order_product_status"]] <-
          self$`order_product_status`
      }
      return(OrderReturnAddOrderProductsInnerObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderReturnAddOrderProductsInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderReturnAddOrderProductsInner
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`order_product_id`)) {
        self$`order_product_id` <- this_object$`order_product_id`
      }
      if (!is.null(this_object$`order_product_quantity`)) {
        self$`order_product_quantity` <- this_object$`order_product_quantity`
      }
      if (!is.null(this_object$`order_product_reason_id`)) {
        self$`order_product_reason_id` <- this_object$`order_product_reason_id`
      }
      if (!is.null(this_object$`order_product_action_id`)) {
        self$`order_product_action_id` <- this_object$`order_product_action_id`
      }
      if (!is.null(this_object$`order_product_customer_comment`)) {
        self$`order_product_customer_comment` <- this_object$`order_product_customer_comment`
      }
      if (!is.null(this_object$`order_product_handling_status`)) {
        self$`order_product_handling_status` <- this_object$`order_product_handling_status`
      }
      if (!is.null(this_object$`order_product_condition`)) {
        self$`order_product_condition` <- this_object$`order_product_condition`
      }
      if (!is.null(this_object$`order_product_reason`)) {
        self$`order_product_reason` <- this_object$`order_product_reason`
      }
      if (!is.null(this_object$`order_product_status`)) {
        self$`order_product_status` <- this_object$`order_product_status`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return OrderReturnAddOrderProductsInner in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderReturnAddOrderProductsInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderReturnAddOrderProductsInner
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`order_product_id` <- this_object$`order_product_id`
      self$`order_product_quantity` <- this_object$`order_product_quantity`
      self$`order_product_reason_id` <- this_object$`order_product_reason_id`
      self$`order_product_action_id` <- this_object$`order_product_action_id`
      self$`order_product_customer_comment` <- this_object$`order_product_customer_comment`
      self$`order_product_handling_status` <- this_object$`order_product_handling_status`
      self$`order_product_condition` <- this_object$`order_product_condition`
      self$`order_product_reason` <- this_object$`order_product_reason`
      self$`order_product_status` <- this_object$`order_product_status`
      self
    },

    #' @description
    #' Validate JSON input with respect to OrderReturnAddOrderProductsInner and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
      # check the required field `order_product_id`
      if (!is.null(input_json$`order_product_id`)) {
        if (!(is.character(input_json$`order_product_id`) && length(input_json$`order_product_id`) == 1)) {
          stop(paste("Error! Invalid data for `order_product_id`. Must be a string:", input_json$`order_product_id`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for OrderReturnAddOrderProductsInner: the required field `order_product_id` is missing."))
      }
      # check the required field `order_product_quantity`
      if (!is.null(input_json$`order_product_quantity`)) {
        if (!(is.numeric(input_json$`order_product_quantity`) && length(input_json$`order_product_quantity`) == 1)) {
          stop(paste("Error! Invalid data for `order_product_quantity`. Must be an integer:", input_json$`order_product_quantity`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for OrderReturnAddOrderProductsInner: the required field `order_product_quantity` is missing."))
      }
      # check the required field `order_product_reason_id`
      if (!is.null(input_json$`order_product_reason_id`)) {
        if (!(is.character(input_json$`order_product_reason_id`) && length(input_json$`order_product_reason_id`) == 1)) {
          stop(paste("Error! Invalid data for `order_product_reason_id`. Must be a string:", input_json$`order_product_reason_id`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for OrderReturnAddOrderProductsInner: the required field `order_product_reason_id` is missing."))
      }
      # check the required field `order_product_action_id`
      if (!is.null(input_json$`order_product_action_id`)) {
        if (!(is.character(input_json$`order_product_action_id`) && length(input_json$`order_product_action_id`) == 1)) {
          stop(paste("Error! Invalid data for `order_product_action_id`. Must be a string:", input_json$`order_product_action_id`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for OrderReturnAddOrderProductsInner: the required field `order_product_action_id` is missing."))
      }
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of OrderReturnAddOrderProductsInner
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      # check if the required `order_product_id` is null
      if (is.null(self$`order_product_id`)) {
        return(FALSE)
      }

      # check if the required `order_product_quantity` is null
      if (is.null(self$`order_product_quantity`)) {
        return(FALSE)
      }

      # check if the required `order_product_reason_id` is null
      if (is.null(self$`order_product_reason_id`)) {
        return(FALSE)
      }

      # check if the required `order_product_action_id` is null
      if (is.null(self$`order_product_action_id`)) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      # check if the required `order_product_id` is null
      if (is.null(self$`order_product_id`)) {
        invalid_fields["order_product_id"] <- "Non-nullable required field `order_product_id` cannot be null."
      }

      # check if the required `order_product_quantity` is null
      if (is.null(self$`order_product_quantity`)) {
        invalid_fields["order_product_quantity"] <- "Non-nullable required field `order_product_quantity` cannot be null."
      }

      # check if the required `order_product_reason_id` is null
      if (is.null(self$`order_product_reason_id`)) {
        invalid_fields["order_product_reason_id"] <- "Non-nullable required field `order_product_reason_id` cannot be null."
      }

      # check if the required `order_product_action_id` is null
      if (is.null(self$`order_product_action_id`)) {
        invalid_fields["order_product_action_id"] <- "Non-nullable required field `order_product_action_id` cannot be null."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# OrderReturnAddOrderProductsInner$unlock()
#
## Below is an example to define the print function
# OrderReturnAddOrderProductsInner$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# OrderReturnAddOrderProductsInner$lock()

