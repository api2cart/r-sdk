#' Create a new OrderCalculateTax
#'
#' @description
#' OrderCalculateTax Class
#'
#' @docType class
#' @title OrderCalculateTax
#' @description OrderCalculateTax Class
#' @format An \code{R6Class} generator object
#' @field code  character [optional]
#' @field rate  numeric [optional]
#' @field value  numeric [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
OrderCalculateTax <- R6::R6Class(
  "OrderCalculateTax",
  public = list(
    `code` = NULL,
    `rate` = NULL,
    `value` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new OrderCalculateTax class.
    #'
    #' @param code code
    #' @param rate rate
    #' @param value value
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`code` = NULL, `rate` = NULL, `value` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`code`)) {
        if (!(is.character(`code`) && length(`code`) == 1)) {
          stop(paste("Error! Invalid data for `code`. Must be a string:", `code`))
        }
        self$`code` <- `code`
      }
      if (!is.null(`rate`)) {
        self$`rate` <- `rate`
      }
      if (!is.null(`value`)) {
        self$`value` <- `value`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return OrderCalculateTax as a base R list.
    #' @examples
    #' # convert array of OrderCalculateTax (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert OrderCalculateTax to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      OrderCalculateTaxObject <- list()
      if (!is.null(self$`code`)) {
        OrderCalculateTaxObject[["code"]] <-
          self$`code`
      }
      if (!is.null(self$`rate`)) {
        OrderCalculateTaxObject[["rate"]] <-
          self$`rate`
      }
      if (!is.null(self$`value`)) {
        OrderCalculateTaxObject[["value"]] <-
          self$`value`
      }
      if (!is.null(self$`additional_fields`)) {
        OrderCalculateTaxObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        OrderCalculateTaxObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(OrderCalculateTaxObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderCalculateTax
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderCalculateTax
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`code`)) {
        self$`code` <- this_object$`code`
      }
      if (!is.null(this_object$`rate`)) {
        self$`rate` <- this_object$`rate`
      }
      if (!is.null(this_object$`value`)) {
        self$`value` <- this_object$`value`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return OrderCalculateTax in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderCalculateTax
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderCalculateTax
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`code` <- this_object$`code`
      self$`rate` <- this_object$`rate`
      self$`value` <- this_object$`value`
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to OrderCalculateTax and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of OrderCalculateTax
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# OrderCalculateTax$unlock()
#
## Below is an example to define the print function
# OrderCalculateTax$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# OrderCalculateTax$lock()

