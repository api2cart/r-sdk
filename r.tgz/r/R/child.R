#' Create a new Child
#'
#' @description
#' Child Class
#'
#' @docType class
#' @title Child
#' @description Child Class
#' @format An \code{R6Class} generator object
#' @field id  character [optional]
#' @field parent_id  character [optional]
#' @field sku  character [optional]
#' @field upc  character [optional]
#' @field ean  character [optional]
#' @field mpn  character [optional]
#' @field gtin  character [optional]
#' @field isbn  character [optional]
#' @field url  character [optional]
#' @field seo_url  character [optional]
#' @field sort_order  integer [optional]
#' @field created_time  \link{A2CDateTime} [optional]
#' @field modified_time  \link{A2CDateTime} [optional]
#' @field name  character [optional]
#' @field short_description  character [optional]
#' @field full_description  character [optional]
#' @field images  list(\link{Image}) [optional]
#' @field combination  list(\link{ProductChildItemCombination}) [optional]
#' @field default_price  numeric [optional]
#' @field cost_price  numeric [optional]
#' @field unit_price  numeric [optional]
#' @field measure_unit  character [optional]
#' @field list_price  numeric [optional]
#' @field wholesale_price  numeric [optional]
#' @field advanced_price  list(\link{ProductAdvancedPrice}) [optional]
#' @field tax_class_id  character [optional]
#' @field avail_for_sale  character [optional]
#' @field allow_backorders  character [optional]
#' @field in_stock  character [optional]
#' @field on_sale  character [optional]
#' @field manage_stock  character [optional]
#' @field inventory_level  numeric [optional]
#' @field inventory  list(\link{ProductInventory}) [optional]
#' @field min_quantity  numeric [optional]
#' @field low_stock_threshold  numeric [optional]
#' @field default_qty_in_pack  numeric [optional]
#' @field is_qty_in_pack_fixed  character [optional]
#' @field weight_unit  character [optional]
#' @field weight  numeric [optional]
#' @field dimensions_unit  character [optional]
#' @field width  numeric [optional]
#' @field height  numeric [optional]
#' @field length  numeric [optional]
#' @field meta_title  character [optional]
#' @field meta_description  character [optional]
#' @field meta_keywords  character [optional]
#' @field discounts  list(\link{Discount}) [optional]
#' @field is_virtual  character [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
Child <- R6::R6Class(
  "Child",
  public = list(
    `id` = NULL,
    `parent_id` = NULL,
    `sku` = NULL,
    `upc` = NULL,
    `ean` = NULL,
    `mpn` = NULL,
    `gtin` = NULL,
    `isbn` = NULL,
    `url` = NULL,
    `seo_url` = NULL,
    `sort_order` = NULL,
    `created_time` = NULL,
    `modified_time` = NULL,
    `name` = NULL,
    `short_description` = NULL,
    `full_description` = NULL,
    `images` = NULL,
    `combination` = NULL,
    `default_price` = NULL,
    `cost_price` = NULL,
    `unit_price` = NULL,
    `measure_unit` = NULL,
    `list_price` = NULL,
    `wholesale_price` = NULL,
    `advanced_price` = NULL,
    `tax_class_id` = NULL,
    `avail_for_sale` = NULL,
    `allow_backorders` = NULL,
    `in_stock` = NULL,
    `on_sale` = NULL,
    `manage_stock` = NULL,
    `inventory_level` = NULL,
    `inventory` = NULL,
    `min_quantity` = NULL,
    `low_stock_threshold` = NULL,
    `default_qty_in_pack` = NULL,
    `is_qty_in_pack_fixed` = NULL,
    `weight_unit` = NULL,
    `weight` = NULL,
    `dimensions_unit` = NULL,
    `width` = NULL,
    `height` = NULL,
    `length` = NULL,
    `meta_title` = NULL,
    `meta_description` = NULL,
    `meta_keywords` = NULL,
    `discounts` = NULL,
    `is_virtual` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new Child class.
    #'
    #' @param id id
    #' @param parent_id parent_id
    #' @param sku sku
    #' @param upc upc
    #' @param ean ean
    #' @param mpn mpn
    #' @param gtin gtin
    #' @param isbn isbn
    #' @param url url
    #' @param seo_url seo_url
    #' @param sort_order sort_order
    #' @param created_time created_time
    #' @param modified_time modified_time
    #' @param name name
    #' @param short_description short_description
    #' @param full_description full_description
    #' @param images images
    #' @param combination combination
    #' @param default_price default_price
    #' @param cost_price cost_price
    #' @param unit_price unit_price
    #' @param measure_unit measure_unit
    #' @param list_price list_price
    #' @param wholesale_price wholesale_price
    #' @param advanced_price advanced_price
    #' @param tax_class_id tax_class_id
    #' @param avail_for_sale avail_for_sale
    #' @param allow_backorders allow_backorders
    #' @param in_stock in_stock
    #' @param on_sale on_sale
    #' @param manage_stock manage_stock
    #' @param inventory_level inventory_level
    #' @param inventory inventory
    #' @param min_quantity min_quantity
    #' @param low_stock_threshold low_stock_threshold
    #' @param default_qty_in_pack default_qty_in_pack
    #' @param is_qty_in_pack_fixed is_qty_in_pack_fixed
    #' @param weight_unit weight_unit
    #' @param weight weight
    #' @param dimensions_unit dimensions_unit
    #' @param width width
    #' @param height height
    #' @param length length
    #' @param meta_title meta_title
    #' @param meta_description meta_description
    #' @param meta_keywords meta_keywords
    #' @param discounts discounts
    #' @param is_virtual is_virtual
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `parent_id` = NULL, `sku` = NULL, `upc` = NULL, `ean` = NULL, `mpn` = NULL, `gtin` = NULL, `isbn` = NULL, `url` = NULL, `seo_url` = NULL, `sort_order` = NULL, `created_time` = NULL, `modified_time` = NULL, `name` = NULL, `short_description` = NULL, `full_description` = NULL, `images` = NULL, `combination` = NULL, `default_price` = NULL, `cost_price` = NULL, `unit_price` = NULL, `measure_unit` = NULL, `list_price` = NULL, `wholesale_price` = NULL, `advanced_price` = NULL, `tax_class_id` = NULL, `avail_for_sale` = NULL, `allow_backorders` = NULL, `in_stock` = NULL, `on_sale` = NULL, `manage_stock` = NULL, `inventory_level` = NULL, `inventory` = NULL, `min_quantity` = NULL, `low_stock_threshold` = NULL, `default_qty_in_pack` = NULL, `is_qty_in_pack_fixed` = NULL, `weight_unit` = NULL, `weight` = NULL, `dimensions_unit` = NULL, `width` = NULL, `height` = NULL, `length` = NULL, `meta_title` = NULL, `meta_description` = NULL, `meta_keywords` = NULL, `discounts` = NULL, `is_virtual` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`parent_id`)) {
        if (!(is.character(`parent_id`) && length(`parent_id`) == 1)) {
          stop(paste("Error! Invalid data for `parent_id`. Must be a string:", `parent_id`))
        }
        self$`parent_id` <- `parent_id`
      }
      if (!is.null(`sku`)) {
        if (!(is.character(`sku`) && length(`sku`) == 1)) {
          stop(paste("Error! Invalid data for `sku`. Must be a string:", `sku`))
        }
        self$`sku` <- `sku`
      }
      if (!is.null(`upc`)) {
        if (!(is.character(`upc`) && length(`upc`) == 1)) {
          stop(paste("Error! Invalid data for `upc`. Must be a string:", `upc`))
        }
        self$`upc` <- `upc`
      }
      if (!is.null(`ean`)) {
        if (!(is.character(`ean`) && length(`ean`) == 1)) {
          stop(paste("Error! Invalid data for `ean`. Must be a string:", `ean`))
        }
        self$`ean` <- `ean`
      }
      if (!is.null(`mpn`)) {
        if (!(is.character(`mpn`) && length(`mpn`) == 1)) {
          stop(paste("Error! Invalid data for `mpn`. Must be a string:", `mpn`))
        }
        self$`mpn` <- `mpn`
      }
      if (!is.null(`gtin`)) {
        if (!(is.character(`gtin`) && length(`gtin`) == 1)) {
          stop(paste("Error! Invalid data for `gtin`. Must be a string:", `gtin`))
        }
        self$`gtin` <- `gtin`
      }
      if (!is.null(`isbn`)) {
        if (!(is.character(`isbn`) && length(`isbn`) == 1)) {
          stop(paste("Error! Invalid data for `isbn`. Must be a string:", `isbn`))
        }
        self$`isbn` <- `isbn`
      }
      if (!is.null(`url`)) {
        if (!(is.character(`url`) && length(`url`) == 1)) {
          stop(paste("Error! Invalid data for `url`. Must be a string:", `url`))
        }
        self$`url` <- `url`
      }
      if (!is.null(`seo_url`)) {
        if (!(is.character(`seo_url`) && length(`seo_url`) == 1)) {
          stop(paste("Error! Invalid data for `seo_url`. Must be a string:", `seo_url`))
        }
        self$`seo_url` <- `seo_url`
      }
      if (!is.null(`sort_order`)) {
        if (!(is.numeric(`sort_order`) && length(`sort_order`) == 1)) {
          stop(paste("Error! Invalid data for `sort_order`. Must be an integer:", `sort_order`))
        }
        self$`sort_order` <- `sort_order`
      }
      if (!is.null(`created_time`)) {
        stopifnot(R6::is.R6(`created_time`))
        self$`created_time` <- `created_time`
      }
      if (!is.null(`modified_time`)) {
        stopifnot(R6::is.R6(`modified_time`))
        self$`modified_time` <- `modified_time`
      }
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`short_description`)) {
        if (!(is.character(`short_description`) && length(`short_description`) == 1)) {
          stop(paste("Error! Invalid data for `short_description`. Must be a string:", `short_description`))
        }
        self$`short_description` <- `short_description`
      }
      if (!is.null(`full_description`)) {
        if (!(is.character(`full_description`) && length(`full_description`) == 1)) {
          stop(paste("Error! Invalid data for `full_description`. Must be a string:", `full_description`))
        }
        self$`full_description` <- `full_description`
      }
      if (!is.null(`images`)) {
        stopifnot(is.vector(`images`), length(`images`) != 0)
        sapply(`images`, function(x) stopifnot(R6::is.R6(x)))
        self$`images` <- `images`
      }
      if (!is.null(`combination`)) {
        stopifnot(is.vector(`combination`), length(`combination`) != 0)
        sapply(`combination`, function(x) stopifnot(R6::is.R6(x)))
        self$`combination` <- `combination`
      }
      if (!is.null(`default_price`)) {
        self$`default_price` <- `default_price`
      }
      if (!is.null(`cost_price`)) {
        self$`cost_price` <- `cost_price`
      }
      if (!is.null(`unit_price`)) {
        self$`unit_price` <- `unit_price`
      }
      if (!is.null(`measure_unit`)) {
        if (!(is.character(`measure_unit`) && length(`measure_unit`) == 1)) {
          stop(paste("Error! Invalid data for `measure_unit`. Must be a string:", `measure_unit`))
        }
        self$`measure_unit` <- `measure_unit`
      }
      if (!is.null(`list_price`)) {
        self$`list_price` <- `list_price`
      }
      if (!is.null(`wholesale_price`)) {
        self$`wholesale_price` <- `wholesale_price`
      }
      if (!is.null(`advanced_price`)) {
        stopifnot(is.vector(`advanced_price`), length(`advanced_price`) != 0)
        sapply(`advanced_price`, function(x) stopifnot(R6::is.R6(x)))
        self$`advanced_price` <- `advanced_price`
      }
      if (!is.null(`tax_class_id`)) {
        if (!(is.character(`tax_class_id`) && length(`tax_class_id`) == 1)) {
          stop(paste("Error! Invalid data for `tax_class_id`. Must be a string:", `tax_class_id`))
        }
        self$`tax_class_id` <- `tax_class_id`
      }
      if (!is.null(`avail_for_sale`)) {
        if (!(is.logical(`avail_for_sale`) && length(`avail_for_sale`) == 1)) {
          stop(paste("Error! Invalid data for `avail_for_sale`. Must be a boolean:", `avail_for_sale`))
        }
        self$`avail_for_sale` <- `avail_for_sale`
      }
      if (!is.null(`allow_backorders`)) {
        if (!(is.logical(`allow_backorders`) && length(`allow_backorders`) == 1)) {
          stop(paste("Error! Invalid data for `allow_backorders`. Must be a boolean:", `allow_backorders`))
        }
        self$`allow_backorders` <- `allow_backorders`
      }
      if (!is.null(`in_stock`)) {
        if (!(is.logical(`in_stock`) && length(`in_stock`) == 1)) {
          stop(paste("Error! Invalid data for `in_stock`. Must be a boolean:", `in_stock`))
        }
        self$`in_stock` <- `in_stock`
      }
      if (!is.null(`on_sale`)) {
        if (!(is.logical(`on_sale`) && length(`on_sale`) == 1)) {
          stop(paste("Error! Invalid data for `on_sale`. Must be a boolean:", `on_sale`))
        }
        self$`on_sale` <- `on_sale`
      }
      if (!is.null(`manage_stock`)) {
        if (!(is.logical(`manage_stock`) && length(`manage_stock`) == 1)) {
          stop(paste("Error! Invalid data for `manage_stock`. Must be a boolean:", `manage_stock`))
        }
        self$`manage_stock` <- `manage_stock`
      }
      if (!is.null(`inventory_level`)) {
        self$`inventory_level` <- `inventory_level`
      }
      if (!is.null(`inventory`)) {
        stopifnot(is.vector(`inventory`), length(`inventory`) != 0)
        sapply(`inventory`, function(x) stopifnot(R6::is.R6(x)))
        self$`inventory` <- `inventory`
      }
      if (!is.null(`min_quantity`)) {
        self$`min_quantity` <- `min_quantity`
      }
      if (!is.null(`low_stock_threshold`)) {
        self$`low_stock_threshold` <- `low_stock_threshold`
      }
      if (!is.null(`default_qty_in_pack`)) {
        self$`default_qty_in_pack` <- `default_qty_in_pack`
      }
      if (!is.null(`is_qty_in_pack_fixed`)) {
        if (!(is.logical(`is_qty_in_pack_fixed`) && length(`is_qty_in_pack_fixed`) == 1)) {
          stop(paste("Error! Invalid data for `is_qty_in_pack_fixed`. Must be a boolean:", `is_qty_in_pack_fixed`))
        }
        self$`is_qty_in_pack_fixed` <- `is_qty_in_pack_fixed`
      }
      if (!is.null(`weight_unit`)) {
        if (!(is.character(`weight_unit`) && length(`weight_unit`) == 1)) {
          stop(paste("Error! Invalid data for `weight_unit`. Must be a string:", `weight_unit`))
        }
        self$`weight_unit` <- `weight_unit`
      }
      if (!is.null(`weight`)) {
        self$`weight` <- `weight`
      }
      if (!is.null(`dimensions_unit`)) {
        if (!(is.character(`dimensions_unit`) && length(`dimensions_unit`) == 1)) {
          stop(paste("Error! Invalid data for `dimensions_unit`. Must be a string:", `dimensions_unit`))
        }
        self$`dimensions_unit` <- `dimensions_unit`
      }
      if (!is.null(`width`)) {
        self$`width` <- `width`
      }
      if (!is.null(`height`)) {
        self$`height` <- `height`
      }
      if (!is.null(`length`)) {
        self$`length` <- `length`
      }
      if (!is.null(`meta_title`)) {
        if (!(is.character(`meta_title`) && length(`meta_title`) == 1)) {
          stop(paste("Error! Invalid data for `meta_title`. Must be a string:", `meta_title`))
        }
        self$`meta_title` <- `meta_title`
      }
      if (!is.null(`meta_description`)) {
        if (!(is.character(`meta_description`) && length(`meta_description`) == 1)) {
          stop(paste("Error! Invalid data for `meta_description`. Must be a string:", `meta_description`))
        }
        self$`meta_description` <- `meta_description`
      }
      if (!is.null(`meta_keywords`)) {
        if (!(is.character(`meta_keywords`) && length(`meta_keywords`) == 1)) {
          stop(paste("Error! Invalid data for `meta_keywords`. Must be a string:", `meta_keywords`))
        }
        self$`meta_keywords` <- `meta_keywords`
      }
      if (!is.null(`discounts`)) {
        stopifnot(is.vector(`discounts`), length(`discounts`) != 0)
        sapply(`discounts`, function(x) stopifnot(R6::is.R6(x)))
        self$`discounts` <- `discounts`
      }
      if (!is.null(`is_virtual`)) {
        if (!(is.logical(`is_virtual`) && length(`is_virtual`) == 1)) {
          stop(paste("Error! Invalid data for `is_virtual`. Must be a boolean:", `is_virtual`))
        }
        self$`is_virtual` <- `is_virtual`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return Child as a base R list.
    #' @examples
    #' # convert array of Child (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert Child to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ChildObject <- list()
      if (!is.null(self$`id`)) {
        ChildObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`parent_id`)) {
        ChildObject[["parent_id"]] <-
          self$`parent_id`
      }
      if (!is.null(self$`sku`)) {
        ChildObject[["sku"]] <-
          self$`sku`
      }
      if (!is.null(self$`upc`)) {
        ChildObject[["upc"]] <-
          self$`upc`
      }
      if (!is.null(self$`ean`)) {
        ChildObject[["ean"]] <-
          self$`ean`
      }
      if (!is.null(self$`mpn`)) {
        ChildObject[["mpn"]] <-
          self$`mpn`
      }
      if (!is.null(self$`gtin`)) {
        ChildObject[["gtin"]] <-
          self$`gtin`
      }
      if (!is.null(self$`isbn`)) {
        ChildObject[["isbn"]] <-
          self$`isbn`
      }
      if (!is.null(self$`url`)) {
        ChildObject[["url"]] <-
          self$`url`
      }
      if (!is.null(self$`seo_url`)) {
        ChildObject[["seo_url"]] <-
          self$`seo_url`
      }
      if (!is.null(self$`sort_order`)) {
        ChildObject[["sort_order"]] <-
          self$`sort_order`
      }
      if (!is.null(self$`created_time`)) {
        ChildObject[["created_time"]] <-
          self$`created_time`$toSimpleType()
      }
      if (!is.null(self$`modified_time`)) {
        ChildObject[["modified_time"]] <-
          self$`modified_time`$toSimpleType()
      }
      if (!is.null(self$`name`)) {
        ChildObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`short_description`)) {
        ChildObject[["short_description"]] <-
          self$`short_description`
      }
      if (!is.null(self$`full_description`)) {
        ChildObject[["full_description"]] <-
          self$`full_description`
      }
      if (!is.null(self$`images`)) {
        ChildObject[["images"]] <-
          lapply(self$`images`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`combination`)) {
        ChildObject[["combination"]] <-
          lapply(self$`combination`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`default_price`)) {
        ChildObject[["default_price"]] <-
          self$`default_price`
      }
      if (!is.null(self$`cost_price`)) {
        ChildObject[["cost_price"]] <-
          self$`cost_price`
      }
      if (!is.null(self$`unit_price`)) {
        ChildObject[["unit_price"]] <-
          self$`unit_price`
      }
      if (!is.null(self$`measure_unit`)) {
        ChildObject[["measure_unit"]] <-
          self$`measure_unit`
      }
      if (!is.null(self$`list_price`)) {
        ChildObject[["list_price"]] <-
          self$`list_price`
      }
      if (!is.null(self$`wholesale_price`)) {
        ChildObject[["wholesale_price"]] <-
          self$`wholesale_price`
      }
      if (!is.null(self$`advanced_price`)) {
        ChildObject[["advanced_price"]] <-
          lapply(self$`advanced_price`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`tax_class_id`)) {
        ChildObject[["tax_class_id"]] <-
          self$`tax_class_id`
      }
      if (!is.null(self$`avail_for_sale`)) {
        ChildObject[["avail_for_sale"]] <-
          self$`avail_for_sale`
      }
      if (!is.null(self$`allow_backorders`)) {
        ChildObject[["allow_backorders"]] <-
          self$`allow_backorders`
      }
      if (!is.null(self$`in_stock`)) {
        ChildObject[["in_stock"]] <-
          self$`in_stock`
      }
      if (!is.null(self$`on_sale`)) {
        ChildObject[["on_sale"]] <-
          self$`on_sale`
      }
      if (!is.null(self$`manage_stock`)) {
        ChildObject[["manage_stock"]] <-
          self$`manage_stock`
      }
      if (!is.null(self$`inventory_level`)) {
        ChildObject[["inventory_level"]] <-
          self$`inventory_level`
      }
      if (!is.null(self$`inventory`)) {
        ChildObject[["inventory"]] <-
          lapply(self$`inventory`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`min_quantity`)) {
        ChildObject[["min_quantity"]] <-
          self$`min_quantity`
      }
      if (!is.null(self$`low_stock_threshold`)) {
        ChildObject[["low_stock_threshold"]] <-
          self$`low_stock_threshold`
      }
      if (!is.null(self$`default_qty_in_pack`)) {
        ChildObject[["default_qty_in_pack"]] <-
          self$`default_qty_in_pack`
      }
      if (!is.null(self$`is_qty_in_pack_fixed`)) {
        ChildObject[["is_qty_in_pack_fixed"]] <-
          self$`is_qty_in_pack_fixed`
      }
      if (!is.null(self$`weight_unit`)) {
        ChildObject[["weight_unit"]] <-
          self$`weight_unit`
      }
      if (!is.null(self$`weight`)) {
        ChildObject[["weight"]] <-
          self$`weight`
      }
      if (!is.null(self$`dimensions_unit`)) {
        ChildObject[["dimensions_unit"]] <-
          self$`dimensions_unit`
      }
      if (!is.null(self$`width`)) {
        ChildObject[["width"]] <-
          self$`width`
      }
      if (!is.null(self$`height`)) {
        ChildObject[["height"]] <-
          self$`height`
      }
      if (!is.null(self$`length`)) {
        ChildObject[["length"]] <-
          self$`length`
      }
      if (!is.null(self$`meta_title`)) {
        ChildObject[["meta_title"]] <-
          self$`meta_title`
      }
      if (!is.null(self$`meta_description`)) {
        ChildObject[["meta_description"]] <-
          self$`meta_description`
      }
      if (!is.null(self$`meta_keywords`)) {
        ChildObject[["meta_keywords"]] <-
          self$`meta_keywords`
      }
      if (!is.null(self$`discounts`)) {
        ChildObject[["discounts"]] <-
          lapply(self$`discounts`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`is_virtual`)) {
        ChildObject[["is_virtual"]] <-
          self$`is_virtual`
      }
      if (!is.null(self$`additional_fields`)) {
        ChildObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        ChildObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(ChildObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of Child
    #'
    #' @param input_json the JSON input
    #' @return the instance of Child
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`parent_id`)) {
        self$`parent_id` <- this_object$`parent_id`
      }
      if (!is.null(this_object$`sku`)) {
        self$`sku` <- this_object$`sku`
      }
      if (!is.null(this_object$`upc`)) {
        self$`upc` <- this_object$`upc`
      }
      if (!is.null(this_object$`ean`)) {
        self$`ean` <- this_object$`ean`
      }
      if (!is.null(this_object$`mpn`)) {
        self$`mpn` <- this_object$`mpn`
      }
      if (!is.null(this_object$`gtin`)) {
        self$`gtin` <- this_object$`gtin`
      }
      if (!is.null(this_object$`isbn`)) {
        self$`isbn` <- this_object$`isbn`
      }
      if (!is.null(this_object$`url`)) {
        self$`url` <- this_object$`url`
      }
      if (!is.null(this_object$`seo_url`)) {
        self$`seo_url` <- this_object$`seo_url`
      }
      if (!is.null(this_object$`sort_order`)) {
        self$`sort_order` <- this_object$`sort_order`
      }
      if (!is.null(this_object$`created_time`)) {
        `created_time_object` <- A2CDateTime$new()
        `created_time_object`$fromJSON(jsonlite::toJSON(this_object$`created_time`, auto_unbox = TRUE, digits = NA))
        self$`created_time` <- `created_time_object`
      }
      if (!is.null(this_object$`modified_time`)) {
        `modified_time_object` <- A2CDateTime$new()
        `modified_time_object`$fromJSON(jsonlite::toJSON(this_object$`modified_time`, auto_unbox = TRUE, digits = NA))
        self$`modified_time` <- `modified_time_object`
      }
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`short_description`)) {
        self$`short_description` <- this_object$`short_description`
      }
      if (!is.null(this_object$`full_description`)) {
        self$`full_description` <- this_object$`full_description`
      }
      if (!is.null(this_object$`images`)) {
        self$`images` <- ApiClient$new()$deserializeObj(this_object$`images`, "array[Image]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`combination`)) {
        self$`combination` <- ApiClient$new()$deserializeObj(this_object$`combination`, "array[ProductChildItemCombination]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`default_price`)) {
        self$`default_price` <- this_object$`default_price`
      }
      if (!is.null(this_object$`cost_price`)) {
        self$`cost_price` <- this_object$`cost_price`
      }
      if (!is.null(this_object$`unit_price`)) {
        self$`unit_price` <- this_object$`unit_price`
      }
      if (!is.null(this_object$`measure_unit`)) {
        self$`measure_unit` <- this_object$`measure_unit`
      }
      if (!is.null(this_object$`list_price`)) {
        self$`list_price` <- this_object$`list_price`
      }
      if (!is.null(this_object$`wholesale_price`)) {
        self$`wholesale_price` <- this_object$`wholesale_price`
      }
      if (!is.null(this_object$`advanced_price`)) {
        self$`advanced_price` <- ApiClient$new()$deserializeObj(this_object$`advanced_price`, "array[ProductAdvancedPrice]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`tax_class_id`)) {
        self$`tax_class_id` <- this_object$`tax_class_id`
      }
      if (!is.null(this_object$`avail_for_sale`)) {
        self$`avail_for_sale` <- this_object$`avail_for_sale`
      }
      if (!is.null(this_object$`allow_backorders`)) {
        self$`allow_backorders` <- this_object$`allow_backorders`
      }
      if (!is.null(this_object$`in_stock`)) {
        self$`in_stock` <- this_object$`in_stock`
      }
      if (!is.null(this_object$`on_sale`)) {
        self$`on_sale` <- this_object$`on_sale`
      }
      if (!is.null(this_object$`manage_stock`)) {
        self$`manage_stock` <- this_object$`manage_stock`
      }
      if (!is.null(this_object$`inventory_level`)) {
        self$`inventory_level` <- this_object$`inventory_level`
      }
      if (!is.null(this_object$`inventory`)) {
        self$`inventory` <- ApiClient$new()$deserializeObj(this_object$`inventory`, "array[ProductInventory]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`min_quantity`)) {
        self$`min_quantity` <- this_object$`min_quantity`
      }
      if (!is.null(this_object$`low_stock_threshold`)) {
        self$`low_stock_threshold` <- this_object$`low_stock_threshold`
      }
      if (!is.null(this_object$`default_qty_in_pack`)) {
        self$`default_qty_in_pack` <- this_object$`default_qty_in_pack`
      }
      if (!is.null(this_object$`is_qty_in_pack_fixed`)) {
        self$`is_qty_in_pack_fixed` <- this_object$`is_qty_in_pack_fixed`
      }
      if (!is.null(this_object$`weight_unit`)) {
        self$`weight_unit` <- this_object$`weight_unit`
      }
      if (!is.null(this_object$`weight`)) {
        self$`weight` <- this_object$`weight`
      }
      if (!is.null(this_object$`dimensions_unit`)) {
        self$`dimensions_unit` <- this_object$`dimensions_unit`
      }
      if (!is.null(this_object$`width`)) {
        self$`width` <- this_object$`width`
      }
      if (!is.null(this_object$`height`)) {
        self$`height` <- this_object$`height`
      }
      if (!is.null(this_object$`length`)) {
        self$`length` <- this_object$`length`
      }
      if (!is.null(this_object$`meta_title`)) {
        self$`meta_title` <- this_object$`meta_title`
      }
      if (!is.null(this_object$`meta_description`)) {
        self$`meta_description` <- this_object$`meta_description`
      }
      if (!is.null(this_object$`meta_keywords`)) {
        self$`meta_keywords` <- this_object$`meta_keywords`
      }
      if (!is.null(this_object$`discounts`)) {
        self$`discounts` <- ApiClient$new()$deserializeObj(this_object$`discounts`, "array[Discount]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`is_virtual`)) {
        self$`is_virtual` <- this_object$`is_virtual`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return Child in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of Child
    #'
    #' @param input_json the JSON input
    #' @return the instance of Child
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`parent_id` <- this_object$`parent_id`
      self$`sku` <- this_object$`sku`
      self$`upc` <- this_object$`upc`
      self$`ean` <- this_object$`ean`
      self$`mpn` <- this_object$`mpn`
      self$`gtin` <- this_object$`gtin`
      self$`isbn` <- this_object$`isbn`
      self$`url` <- this_object$`url`
      self$`seo_url` <- this_object$`seo_url`
      self$`sort_order` <- this_object$`sort_order`
      self$`created_time` <- A2CDateTime$new()$fromJSON(jsonlite::toJSON(this_object$`created_time`, auto_unbox = TRUE, digits = NA))
      self$`modified_time` <- A2CDateTime$new()$fromJSON(jsonlite::toJSON(this_object$`modified_time`, auto_unbox = TRUE, digits = NA))
      self$`name` <- this_object$`name`
      self$`short_description` <- this_object$`short_description`
      self$`full_description` <- this_object$`full_description`
      self$`images` <- ApiClient$new()$deserializeObj(this_object$`images`, "array[Image]", loadNamespace("openapi"))
      self$`combination` <- ApiClient$new()$deserializeObj(this_object$`combination`, "array[ProductChildItemCombination]", loadNamespace("openapi"))
      self$`default_price` <- this_object$`default_price`
      self$`cost_price` <- this_object$`cost_price`
      self$`unit_price` <- this_object$`unit_price`
      self$`measure_unit` <- this_object$`measure_unit`
      self$`list_price` <- this_object$`list_price`
      self$`wholesale_price` <- this_object$`wholesale_price`
      self$`advanced_price` <- ApiClient$new()$deserializeObj(this_object$`advanced_price`, "array[ProductAdvancedPrice]", loadNamespace("openapi"))
      self$`tax_class_id` <- this_object$`tax_class_id`
      self$`avail_for_sale` <- this_object$`avail_for_sale`
      self$`allow_backorders` <- this_object$`allow_backorders`
      self$`in_stock` <- this_object$`in_stock`
      self$`on_sale` <- this_object$`on_sale`
      self$`manage_stock` <- this_object$`manage_stock`
      self$`inventory_level` <- this_object$`inventory_level`
      self$`inventory` <- ApiClient$new()$deserializeObj(this_object$`inventory`, "array[ProductInventory]", loadNamespace("openapi"))
      self$`min_quantity` <- this_object$`min_quantity`
      self$`low_stock_threshold` <- this_object$`low_stock_threshold`
      self$`default_qty_in_pack` <- this_object$`default_qty_in_pack`
      self$`is_qty_in_pack_fixed` <- this_object$`is_qty_in_pack_fixed`
      self$`weight_unit` <- this_object$`weight_unit`
      self$`weight` <- this_object$`weight`
      self$`dimensions_unit` <- this_object$`dimensions_unit`
      self$`width` <- this_object$`width`
      self$`height` <- this_object$`height`
      self$`length` <- this_object$`length`
      self$`meta_title` <- this_object$`meta_title`
      self$`meta_description` <- this_object$`meta_description`
      self$`meta_keywords` <- this_object$`meta_keywords`
      self$`discounts` <- ApiClient$new()$deserializeObj(this_object$`discounts`, "array[Discount]", loadNamespace("openapi"))
      self$`is_virtual` <- this_object$`is_virtual`
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to Child and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of Child
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# Child$unlock()
#
## Below is an example to define the print function
# Child$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# Child$lock()

