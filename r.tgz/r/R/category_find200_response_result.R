#' Create a new CategoryFind200ResponseResult
#'
#' @description
#' CategoryFind200ResponseResult Class
#'
#' @docType class
#' @title CategoryFind200ResponseResult
#' @description CategoryFind200ResponseResult Class
#' @format An \code{R6Class} generator object
#' @field category  list(\link{CategoryFind200ResponseResultCategoryInner}) [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
CategoryFind200ResponseResult <- R6::R6Class(
  "CategoryFind200ResponseResult",
  public = list(
    `category` = NULL,

    #' @description
    #' Initialize a new CategoryFind200ResponseResult class.
    #'
    #' @param category category
    #' @param ... Other optional arguments.
    initialize = function(`category` = NULL, ...) {
      if (!is.null(`category`)) {
        stopifnot(is.vector(`category`), length(`category`) != 0)
        sapply(`category`, function(x) stopifnot(R6::is.R6(x)))
        self$`category` <- `category`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return CategoryFind200ResponseResult as a base R list.
    #' @examples
    #' # convert array of CategoryFind200ResponseResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert CategoryFind200ResponseResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      CategoryFind200ResponseResultObject <- list()
      if (!is.null(self$`category`)) {
        CategoryFind200ResponseResultObject[["category"]] <-
          lapply(self$`category`, function(x) x$toSimpleType())
      }
      return(CategoryFind200ResponseResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of CategoryFind200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of CategoryFind200ResponseResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`category`)) {
        self$`category` <- ApiClient$new()$deserializeObj(this_object$`category`, "array[CategoryFind200ResponseResultCategoryInner]", loadNamespace("openapi"))
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return CategoryFind200ResponseResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of CategoryFind200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of CategoryFind200ResponseResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`category` <- ApiClient$new()$deserializeObj(this_object$`category`, "array[CategoryFind200ResponseResultCategoryInner]", loadNamespace("openapi"))
      self
    },

    #' @description
    #' Validate JSON input with respect to CategoryFind200ResponseResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of CategoryFind200ResponseResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# CategoryFind200ResponseResult$unlock()
#
## Below is an example to define the print function
# CategoryFind200ResponseResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# CategoryFind200ResponseResult$lock()

