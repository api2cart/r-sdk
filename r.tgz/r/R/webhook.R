#' Create a new Webhook
#'
#' @description
#' Webhook Class
#'
#' @docType class
#' @title Webhook
#' @description Webhook Class
#' @format An \code{R6Class} generator object
#' @field id  integer [optional]
#' @field label  character [optional]
#' @field store_id  character [optional]
#' @field lang_id  character [optional]
#' @field active  character [optional]
#' @field callback  character [optional]
#' @field fields  character [optional]
#' @field response_fields  character [optional]
#' @field created_at  character [optional]
#' @field updated_at  character [optional]
#' @field entity  character [optional]
#' @field action  character [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
Webhook <- R6::R6Class(
  "Webhook",
  public = list(
    `id` = NULL,
    `label` = NULL,
    `store_id` = NULL,
    `lang_id` = NULL,
    `active` = NULL,
    `callback` = NULL,
    `fields` = NULL,
    `response_fields` = NULL,
    `created_at` = NULL,
    `updated_at` = NULL,
    `entity` = NULL,
    `action` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new Webhook class.
    #'
    #' @param id id
    #' @param label label
    #' @param store_id store_id
    #' @param lang_id lang_id
    #' @param active active
    #' @param callback callback
    #' @param fields fields
    #' @param response_fields response_fields
    #' @param created_at created_at
    #' @param updated_at updated_at
    #' @param entity entity
    #' @param action action
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `label` = NULL, `store_id` = NULL, `lang_id` = NULL, `active` = NULL, `callback` = NULL, `fields` = NULL, `response_fields` = NULL, `created_at` = NULL, `updated_at` = NULL, `entity` = NULL, `action` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.numeric(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be an integer:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`label`)) {
        if (!(is.character(`label`) && length(`label`) == 1)) {
          stop(paste("Error! Invalid data for `label`. Must be a string:", `label`))
        }
        self$`label` <- `label`
      }
      if (!is.null(`store_id`)) {
        if (!(is.character(`store_id`) && length(`store_id`) == 1)) {
          stop(paste("Error! Invalid data for `store_id`. Must be a string:", `store_id`))
        }
        self$`store_id` <- `store_id`
      }
      if (!is.null(`lang_id`)) {
        if (!(is.character(`lang_id`) && length(`lang_id`) == 1)) {
          stop(paste("Error! Invalid data for `lang_id`. Must be a string:", `lang_id`))
        }
        self$`lang_id` <- `lang_id`
      }
      if (!is.null(`active`)) {
        if (!(is.logical(`active`) && length(`active`) == 1)) {
          stop(paste("Error! Invalid data for `active`. Must be a boolean:", `active`))
        }
        self$`active` <- `active`
      }
      if (!is.null(`callback`)) {
        if (!(is.character(`callback`) && length(`callback`) == 1)) {
          stop(paste("Error! Invalid data for `callback`. Must be a string:", `callback`))
        }
        self$`callback` <- `callback`
      }
      if (!is.null(`fields`)) {
        if (!(is.character(`fields`) && length(`fields`) == 1)) {
          stop(paste("Error! Invalid data for `fields`. Must be a string:", `fields`))
        }
        self$`fields` <- `fields`
      }
      if (!is.null(`response_fields`)) {
        if (!(is.character(`response_fields`) && length(`response_fields`) == 1)) {
          stop(paste("Error! Invalid data for `response_fields`. Must be a string:", `response_fields`))
        }
        self$`response_fields` <- `response_fields`
      }
      if (!is.null(`created_at`)) {
        if (!(is.character(`created_at`) && length(`created_at`) == 1)) {
          stop(paste("Error! Invalid data for `created_at`. Must be a string:", `created_at`))
        }
        self$`created_at` <- `created_at`
      }
      if (!is.null(`updated_at`)) {
        if (!(is.character(`updated_at`) && length(`updated_at`) == 1)) {
          stop(paste("Error! Invalid data for `updated_at`. Must be a string:", `updated_at`))
        }
        self$`updated_at` <- `updated_at`
      }
      if (!is.null(`entity`)) {
        if (!(is.character(`entity`) && length(`entity`) == 1)) {
          stop(paste("Error! Invalid data for `entity`. Must be a string:", `entity`))
        }
        self$`entity` <- `entity`
      }
      if (!is.null(`action`)) {
        if (!(is.character(`action`) && length(`action`) == 1)) {
          stop(paste("Error! Invalid data for `action`. Must be a string:", `action`))
        }
        self$`action` <- `action`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return Webhook as a base R list.
    #' @examples
    #' # convert array of Webhook (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert Webhook to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      WebhookObject <- list()
      if (!is.null(self$`id`)) {
        WebhookObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`label`)) {
        WebhookObject[["label"]] <-
          self$`label`
      }
      if (!is.null(self$`store_id`)) {
        WebhookObject[["store_id"]] <-
          self$`store_id`
      }
      if (!is.null(self$`lang_id`)) {
        WebhookObject[["lang_id"]] <-
          self$`lang_id`
      }
      if (!is.null(self$`active`)) {
        WebhookObject[["active"]] <-
          self$`active`
      }
      if (!is.null(self$`callback`)) {
        WebhookObject[["callback"]] <-
          self$`callback`
      }
      if (!is.null(self$`fields`)) {
        WebhookObject[["fields"]] <-
          self$`fields`
      }
      if (!is.null(self$`response_fields`)) {
        WebhookObject[["response_fields"]] <-
          self$`response_fields`
      }
      if (!is.null(self$`created_at`)) {
        WebhookObject[["created_at"]] <-
          self$`created_at`
      }
      if (!is.null(self$`updated_at`)) {
        WebhookObject[["updated_at"]] <-
          self$`updated_at`
      }
      if (!is.null(self$`entity`)) {
        WebhookObject[["entity"]] <-
          self$`entity`
      }
      if (!is.null(self$`action`)) {
        WebhookObject[["action"]] <-
          self$`action`
      }
      if (!is.null(self$`additional_fields`)) {
        WebhookObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        WebhookObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(WebhookObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of Webhook
    #'
    #' @param input_json the JSON input
    #' @return the instance of Webhook
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`label`)) {
        self$`label` <- this_object$`label`
      }
      if (!is.null(this_object$`store_id`)) {
        self$`store_id` <- this_object$`store_id`
      }
      if (!is.null(this_object$`lang_id`)) {
        self$`lang_id` <- this_object$`lang_id`
      }
      if (!is.null(this_object$`active`)) {
        self$`active` <- this_object$`active`
      }
      if (!is.null(this_object$`callback`)) {
        self$`callback` <- this_object$`callback`
      }
      if (!is.null(this_object$`fields`)) {
        self$`fields` <- this_object$`fields`
      }
      if (!is.null(this_object$`response_fields`)) {
        self$`response_fields` <- this_object$`response_fields`
      }
      if (!is.null(this_object$`created_at`)) {
        self$`created_at` <- this_object$`created_at`
      }
      if (!is.null(this_object$`updated_at`)) {
        self$`updated_at` <- this_object$`updated_at`
      }
      if (!is.null(this_object$`entity`)) {
        self$`entity` <- this_object$`entity`
      }
      if (!is.null(this_object$`action`)) {
        self$`action` <- this_object$`action`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return Webhook in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of Webhook
    #'
    #' @param input_json the JSON input
    #' @return the instance of Webhook
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`label` <- this_object$`label`
      self$`store_id` <- this_object$`store_id`
      self$`lang_id` <- this_object$`lang_id`
      self$`active` <- this_object$`active`
      self$`callback` <- this_object$`callback`
      self$`fields` <- this_object$`fields`
      self$`response_fields` <- this_object$`response_fields`
      self$`created_at` <- this_object$`created_at`
      self$`updated_at` <- this_object$`updated_at`
      self$`entity` <- this_object$`entity`
      self$`action` <- this_object$`action`
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to Webhook and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of Webhook
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# Webhook$unlock()
#
## Below is an example to define the print function
# Webhook$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# Webhook$lock()

