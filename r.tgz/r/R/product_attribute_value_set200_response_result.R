#' Create a new ProductAttributeValueSet200ResponseResult
#'
#' @description
#' ProductAttributeValueSet200ResponseResult Class
#'
#' @docType class
#' @title ProductAttributeValueSet200ResponseResult
#' @description ProductAttributeValueSet200ResponseResult Class
#' @format An \code{R6Class} generator object
#' @field product_id  character [optional]
#' @field attribute_id  character [optional]
#' @field value_id  character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductAttributeValueSet200ResponseResult <- R6::R6Class(
  "ProductAttributeValueSet200ResponseResult",
  public = list(
    `product_id` = NULL,
    `attribute_id` = NULL,
    `value_id` = NULL,

    #' @description
    #' Initialize a new ProductAttributeValueSet200ResponseResult class.
    #'
    #' @param product_id product_id
    #' @param attribute_id attribute_id
    #' @param value_id value_id
    #' @param ... Other optional arguments.
    initialize = function(`product_id` = NULL, `attribute_id` = NULL, `value_id` = NULL, ...) {
      if (!is.null(`product_id`)) {
        if (!(is.character(`product_id`) && length(`product_id`) == 1)) {
          stop(paste("Error! Invalid data for `product_id`. Must be a string:", `product_id`))
        }
        self$`product_id` <- `product_id`
      }
      if (!is.null(`attribute_id`)) {
        if (!(is.character(`attribute_id`) && length(`attribute_id`) == 1)) {
          stop(paste("Error! Invalid data for `attribute_id`. Must be a string:", `attribute_id`))
        }
        self$`attribute_id` <- `attribute_id`
      }
      if (!is.null(`value_id`)) {
        if (!(is.character(`value_id`) && length(`value_id`) == 1)) {
          stop(paste("Error! Invalid data for `value_id`. Must be a string:", `value_id`))
        }
        self$`value_id` <- `value_id`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductAttributeValueSet200ResponseResult as a base R list.
    #' @examples
    #' # convert array of ProductAttributeValueSet200ResponseResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductAttributeValueSet200ResponseResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductAttributeValueSet200ResponseResultObject <- list()
      if (!is.null(self$`product_id`)) {
        ProductAttributeValueSet200ResponseResultObject[["product_id"]] <-
          self$`product_id`
      }
      if (!is.null(self$`attribute_id`)) {
        ProductAttributeValueSet200ResponseResultObject[["attribute_id"]] <-
          self$`attribute_id`
      }
      if (!is.null(self$`value_id`)) {
        ProductAttributeValueSet200ResponseResultObject[["value_id"]] <-
          self$`value_id`
      }
      return(ProductAttributeValueSet200ResponseResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductAttributeValueSet200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductAttributeValueSet200ResponseResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`product_id`)) {
        self$`product_id` <- this_object$`product_id`
      }
      if (!is.null(this_object$`attribute_id`)) {
        self$`attribute_id` <- this_object$`attribute_id`
      }
      if (!is.null(this_object$`value_id`)) {
        self$`value_id` <- this_object$`value_id`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductAttributeValueSet200ResponseResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductAttributeValueSet200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductAttributeValueSet200ResponseResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`product_id` <- this_object$`product_id`
      self$`attribute_id` <- this_object$`attribute_id`
      self$`value_id` <- this_object$`value_id`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductAttributeValueSet200ResponseResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductAttributeValueSet200ResponseResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductAttributeValueSet200ResponseResult$unlock()
#
## Below is an example to define the print function
# ProductAttributeValueSet200ResponseResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductAttributeValueSet200ResponseResult$lock()

