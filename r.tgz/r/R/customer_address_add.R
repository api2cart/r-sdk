#' Create a new CustomerAddressAdd
#'
#' @description
#' CustomerAddressAdd Class
#'
#' @docType class
#' @title CustomerAddressAdd
#' @description CustomerAddressAdd Class
#' @format An \code{R6Class} generator object
#' @field customer_id Defines customer id character
#' @field store_id Store Id character [optional]
#' @field first_name Defines customer's address first name character [optional]
#' @field last_name Defines customer's address last name character [optional]
#' @field company Defines customer's address company character [optional]
#' @field address1 Specifies customer's address address1 character
#' @field address2 Specifies customer's address address2 character [optional]
#' @field city Specifies customer's address city character
#' @field country Specifies customer's address ISO code or name of country character
#' @field state Specifies customer's address ISO code or name of state character [optional]
#' @field postcode Specifies customer's address postcode character
#' @field identification_number Specifies the national ID card number of this person, or a unique tax identification number for customer's address character [optional]
#' @field types Specifies customer's address types list(character) [optional]
#' @field default Specifies whether the customer's address is used by default character [optional]
#' @field phone Defines customer's address phone number character [optional]
#' @field phone_mobile Defines customer's address mobile phone number character [optional]
#' @field fax Defines customer's address fax character [optional]
#' @field website Defines Link to customer's address website character [optional]
#' @field gender Defines customer's address gender character [optional]
#' @field tax_id Add Tax Id character [optional]
#' @field alias Specifies customer's alias in the address book character [optional]
#' @field idempotency_key A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong> character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
CustomerAddressAdd <- R6::R6Class(
  "CustomerAddressAdd",
  public = list(
    `customer_id` = NULL,
    `store_id` = NULL,
    `first_name` = NULL,
    `last_name` = NULL,
    `company` = NULL,
    `address1` = NULL,
    `address2` = NULL,
    `city` = NULL,
    `country` = NULL,
    `state` = NULL,
    `postcode` = NULL,
    `identification_number` = NULL,
    `types` = NULL,
    `default` = NULL,
    `phone` = NULL,
    `phone_mobile` = NULL,
    `fax` = NULL,
    `website` = NULL,
    `gender` = NULL,
    `tax_id` = NULL,
    `alias` = NULL,
    `idempotency_key` = NULL,

    #' @description
    #' Initialize a new CustomerAddressAdd class.
    #'
    #' @param customer_id Defines customer id
    #' @param address1 Specifies customer's address address1
    #' @param city Specifies customer's address city
    #' @param country Specifies customer's address ISO code or name of country
    #' @param postcode Specifies customer's address postcode
    #' @param store_id Store Id
    #' @param first_name Defines customer's address first name
    #' @param last_name Defines customer's address last name
    #' @param company Defines customer's address company
    #' @param address2 Specifies customer's address address2
    #' @param state Specifies customer's address ISO code or name of state
    #' @param identification_number Specifies the national ID card number of this person, or a unique tax identification number for customer's address
    #' @param types Specifies customer's address types
    #' @param default Specifies whether the customer's address is used by default
    #' @param phone Defines customer's address phone number
    #' @param phone_mobile Defines customer's address mobile phone number
    #' @param fax Defines customer's address fax
    #' @param website Defines Link to customer's address website
    #' @param gender Defines customer's address gender
    #' @param tax_id Add Tax Id
    #' @param alias Specifies customer's alias in the address book
    #' @param idempotency_key A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong>
    #' @param ... Other optional arguments.
    initialize = function(`customer_id`, `address1`, `city`, `country`, `postcode`, `store_id` = NULL, `first_name` = NULL, `last_name` = NULL, `company` = NULL, `address2` = NULL, `state` = NULL, `identification_number` = NULL, `types` = NULL, `default` = NULL, `phone` = NULL, `phone_mobile` = NULL, `fax` = NULL, `website` = NULL, `gender` = NULL, `tax_id` = NULL, `alias` = NULL, `idempotency_key` = NULL, ...) {
      if (!missing(`customer_id`)) {
        if (!(is.character(`customer_id`) && length(`customer_id`) == 1)) {
          stop(paste("Error! Invalid data for `customer_id`. Must be a string:", `customer_id`))
        }
        self$`customer_id` <- `customer_id`
      }
      if (!missing(`address1`)) {
        if (!(is.character(`address1`) && length(`address1`) == 1)) {
          stop(paste("Error! Invalid data for `address1`. Must be a string:", `address1`))
        }
        self$`address1` <- `address1`
      }
      if (!missing(`city`)) {
        if (!(is.character(`city`) && length(`city`) == 1)) {
          stop(paste("Error! Invalid data for `city`. Must be a string:", `city`))
        }
        self$`city` <- `city`
      }
      if (!missing(`country`)) {
        if (!(is.character(`country`) && length(`country`) == 1)) {
          stop(paste("Error! Invalid data for `country`. Must be a string:", `country`))
        }
        self$`country` <- `country`
      }
      if (!missing(`postcode`)) {
        if (!(is.character(`postcode`) && length(`postcode`) == 1)) {
          stop(paste("Error! Invalid data for `postcode`. Must be a string:", `postcode`))
        }
        self$`postcode` <- `postcode`
      }
      if (!is.null(`store_id`)) {
        if (!(is.character(`store_id`) && length(`store_id`) == 1)) {
          stop(paste("Error! Invalid data for `store_id`. Must be a string:", `store_id`))
        }
        self$`store_id` <- `store_id`
      }
      if (!is.null(`first_name`)) {
        if (!(is.character(`first_name`) && length(`first_name`) == 1)) {
          stop(paste("Error! Invalid data for `first_name`. Must be a string:", `first_name`))
        }
        self$`first_name` <- `first_name`
      }
      if (!is.null(`last_name`)) {
        if (!(is.character(`last_name`) && length(`last_name`) == 1)) {
          stop(paste("Error! Invalid data for `last_name`. Must be a string:", `last_name`))
        }
        self$`last_name` <- `last_name`
      }
      if (!is.null(`company`)) {
        if (!(is.character(`company`) && length(`company`) == 1)) {
          stop(paste("Error! Invalid data for `company`. Must be a string:", `company`))
        }
        self$`company` <- `company`
      }
      if (!is.null(`address2`)) {
        if (!(is.character(`address2`) && length(`address2`) == 1)) {
          stop(paste("Error! Invalid data for `address2`. Must be a string:", `address2`))
        }
        self$`address2` <- `address2`
      }
      if (!is.null(`state`)) {
        if (!(is.character(`state`) && length(`state`) == 1)) {
          stop(paste("Error! Invalid data for `state`. Must be a string:", `state`))
        }
        self$`state` <- `state`
      }
      if (!is.null(`identification_number`)) {
        if (!(is.character(`identification_number`) && length(`identification_number`) == 1)) {
          stop(paste("Error! Invalid data for `identification_number`. Must be a string:", `identification_number`))
        }
        self$`identification_number` <- `identification_number`
      }
      if (!is.null(`types`)) {
        stopifnot(is.vector(`types`), length(`types`) != 0)
        sapply(`types`, function(x) stopifnot(is.character(x)))
        self$`types` <- `types`
      }
      if (!is.null(`default`)) {
        if (!(is.logical(`default`) && length(`default`) == 1)) {
          stop(paste("Error! Invalid data for `default`. Must be a boolean:", `default`))
        }
        self$`default` <- `default`
      }
      if (!is.null(`phone`)) {
        if (!(is.character(`phone`) && length(`phone`) == 1)) {
          stop(paste("Error! Invalid data for `phone`. Must be a string:", `phone`))
        }
        self$`phone` <- `phone`
      }
      if (!is.null(`phone_mobile`)) {
        if (!(is.character(`phone_mobile`) && length(`phone_mobile`) == 1)) {
          stop(paste("Error! Invalid data for `phone_mobile`. Must be a string:", `phone_mobile`))
        }
        self$`phone_mobile` <- `phone_mobile`
      }
      if (!is.null(`fax`)) {
        if (!(is.character(`fax`) && length(`fax`) == 1)) {
          stop(paste("Error! Invalid data for `fax`. Must be a string:", `fax`))
        }
        self$`fax` <- `fax`
      }
      if (!is.null(`website`)) {
        if (!(is.character(`website`) && length(`website`) == 1)) {
          stop(paste("Error! Invalid data for `website`. Must be a string:", `website`))
        }
        self$`website` <- `website`
      }
      if (!is.null(`gender`)) {
        if (!(is.character(`gender`) && length(`gender`) == 1)) {
          stop(paste("Error! Invalid data for `gender`. Must be a string:", `gender`))
        }
        self$`gender` <- `gender`
      }
      if (!is.null(`tax_id`)) {
        if (!(is.character(`tax_id`) && length(`tax_id`) == 1)) {
          stop(paste("Error! Invalid data for `tax_id`. Must be a string:", `tax_id`))
        }
        self$`tax_id` <- `tax_id`
      }
      if (!is.null(`alias`)) {
        if (!(is.character(`alias`) && length(`alias`) == 1)) {
          stop(paste("Error! Invalid data for `alias`. Must be a string:", `alias`))
        }
        self$`alias` <- `alias`
      }
      if (!is.null(`idempotency_key`)) {
        if (!(is.character(`idempotency_key`) && length(`idempotency_key`) == 1)) {
          stop(paste("Error! Invalid data for `idempotency_key`. Must be a string:", `idempotency_key`))
        }
        self$`idempotency_key` <- `idempotency_key`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return CustomerAddressAdd as a base R list.
    #' @examples
    #' # convert array of CustomerAddressAdd (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert CustomerAddressAdd to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      CustomerAddressAddObject <- list()
      if (!is.null(self$`customer_id`)) {
        CustomerAddressAddObject[["customer_id"]] <-
          self$`customer_id`
      }
      if (!is.null(self$`store_id`)) {
        CustomerAddressAddObject[["store_id"]] <-
          self$`store_id`
      }
      if (!is.null(self$`first_name`)) {
        CustomerAddressAddObject[["first_name"]] <-
          self$`first_name`
      }
      if (!is.null(self$`last_name`)) {
        CustomerAddressAddObject[["last_name"]] <-
          self$`last_name`
      }
      if (!is.null(self$`company`)) {
        CustomerAddressAddObject[["company"]] <-
          self$`company`
      }
      if (!is.null(self$`address1`)) {
        CustomerAddressAddObject[["address1"]] <-
          self$`address1`
      }
      if (!is.null(self$`address2`)) {
        CustomerAddressAddObject[["address2"]] <-
          self$`address2`
      }
      if (!is.null(self$`city`)) {
        CustomerAddressAddObject[["city"]] <-
          self$`city`
      }
      if (!is.null(self$`country`)) {
        CustomerAddressAddObject[["country"]] <-
          self$`country`
      }
      if (!is.null(self$`state`)) {
        CustomerAddressAddObject[["state"]] <-
          self$`state`
      }
      if (!is.null(self$`postcode`)) {
        CustomerAddressAddObject[["postcode"]] <-
          self$`postcode`
      }
      if (!is.null(self$`identification_number`)) {
        CustomerAddressAddObject[["identification_number"]] <-
          self$`identification_number`
      }
      if (!is.null(self$`types`)) {
        CustomerAddressAddObject[["types"]] <-
          self$`types`
      }
      if (!is.null(self$`default`)) {
        CustomerAddressAddObject[["default"]] <-
          self$`default`
      }
      if (!is.null(self$`phone`)) {
        CustomerAddressAddObject[["phone"]] <-
          self$`phone`
      }
      if (!is.null(self$`phone_mobile`)) {
        CustomerAddressAddObject[["phone_mobile"]] <-
          self$`phone_mobile`
      }
      if (!is.null(self$`fax`)) {
        CustomerAddressAddObject[["fax"]] <-
          self$`fax`
      }
      if (!is.null(self$`website`)) {
        CustomerAddressAddObject[["website"]] <-
          self$`website`
      }
      if (!is.null(self$`gender`)) {
        CustomerAddressAddObject[["gender"]] <-
          self$`gender`
      }
      if (!is.null(self$`tax_id`)) {
        CustomerAddressAddObject[["tax_id"]] <-
          self$`tax_id`
      }
      if (!is.null(self$`alias`)) {
        CustomerAddressAddObject[["alias"]] <-
          self$`alias`
      }
      if (!is.null(self$`idempotency_key`)) {
        CustomerAddressAddObject[["idempotency_key"]] <-
          self$`idempotency_key`
      }
      return(CustomerAddressAddObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of CustomerAddressAdd
    #'
    #' @param input_json the JSON input
    #' @return the instance of CustomerAddressAdd
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`customer_id`)) {
        self$`customer_id` <- this_object$`customer_id`
      }
      if (!is.null(this_object$`store_id`)) {
        self$`store_id` <- this_object$`store_id`
      }
      if (!is.null(this_object$`first_name`)) {
        self$`first_name` <- this_object$`first_name`
      }
      if (!is.null(this_object$`last_name`)) {
        self$`last_name` <- this_object$`last_name`
      }
      if (!is.null(this_object$`company`)) {
        self$`company` <- this_object$`company`
      }
      if (!is.null(this_object$`address1`)) {
        self$`address1` <- this_object$`address1`
      }
      if (!is.null(this_object$`address2`)) {
        self$`address2` <- this_object$`address2`
      }
      if (!is.null(this_object$`city`)) {
        self$`city` <- this_object$`city`
      }
      if (!is.null(this_object$`country`)) {
        self$`country` <- this_object$`country`
      }
      if (!is.null(this_object$`state`)) {
        self$`state` <- this_object$`state`
      }
      if (!is.null(this_object$`postcode`)) {
        self$`postcode` <- this_object$`postcode`
      }
      if (!is.null(this_object$`identification_number`)) {
        self$`identification_number` <- this_object$`identification_number`
      }
      if (!is.null(this_object$`types`)) {
        self$`types` <- ApiClient$new()$deserializeObj(this_object$`types`, "array[character]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`default`)) {
        self$`default` <- this_object$`default`
      }
      if (!is.null(this_object$`phone`)) {
        self$`phone` <- this_object$`phone`
      }
      if (!is.null(this_object$`phone_mobile`)) {
        self$`phone_mobile` <- this_object$`phone_mobile`
      }
      if (!is.null(this_object$`fax`)) {
        self$`fax` <- this_object$`fax`
      }
      if (!is.null(this_object$`website`)) {
        self$`website` <- this_object$`website`
      }
      if (!is.null(this_object$`gender`)) {
        self$`gender` <- this_object$`gender`
      }
      if (!is.null(this_object$`tax_id`)) {
        self$`tax_id` <- this_object$`tax_id`
      }
      if (!is.null(this_object$`alias`)) {
        self$`alias` <- this_object$`alias`
      }
      if (!is.null(this_object$`idempotency_key`)) {
        self$`idempotency_key` <- this_object$`idempotency_key`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return CustomerAddressAdd in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of CustomerAddressAdd
    #'
    #' @param input_json the JSON input
    #' @return the instance of CustomerAddressAdd
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`customer_id` <- this_object$`customer_id`
      self$`store_id` <- this_object$`store_id`
      self$`first_name` <- this_object$`first_name`
      self$`last_name` <- this_object$`last_name`
      self$`company` <- this_object$`company`
      self$`address1` <- this_object$`address1`
      self$`address2` <- this_object$`address2`
      self$`city` <- this_object$`city`
      self$`country` <- this_object$`country`
      self$`state` <- this_object$`state`
      self$`postcode` <- this_object$`postcode`
      self$`identification_number` <- this_object$`identification_number`
      self$`types` <- ApiClient$new()$deserializeObj(this_object$`types`, "array[character]", loadNamespace("openapi"))
      self$`default` <- this_object$`default`
      self$`phone` <- this_object$`phone`
      self$`phone_mobile` <- this_object$`phone_mobile`
      self$`fax` <- this_object$`fax`
      self$`website` <- this_object$`website`
      self$`gender` <- this_object$`gender`
      self$`tax_id` <- this_object$`tax_id`
      self$`alias` <- this_object$`alias`
      self$`idempotency_key` <- this_object$`idempotency_key`
      self
    },

    #' @description
    #' Validate JSON input with respect to CustomerAddressAdd and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
      # check the required field `customer_id`
      if (!is.null(input_json$`customer_id`)) {
        if (!(is.character(input_json$`customer_id`) && length(input_json$`customer_id`) == 1)) {
          stop(paste("Error! Invalid data for `customer_id`. Must be a string:", input_json$`customer_id`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for CustomerAddressAdd: the required field `customer_id` is missing."))
      }
      # check the required field `address1`
      if (!is.null(input_json$`address1`)) {
        if (!(is.character(input_json$`address1`) && length(input_json$`address1`) == 1)) {
          stop(paste("Error! Invalid data for `address1`. Must be a string:", input_json$`address1`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for CustomerAddressAdd: the required field `address1` is missing."))
      }
      # check the required field `city`
      if (!is.null(input_json$`city`)) {
        if (!(is.character(input_json$`city`) && length(input_json$`city`) == 1)) {
          stop(paste("Error! Invalid data for `city`. Must be a string:", input_json$`city`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for CustomerAddressAdd: the required field `city` is missing."))
      }
      # check the required field `country`
      if (!is.null(input_json$`country`)) {
        if (!(is.character(input_json$`country`) && length(input_json$`country`) == 1)) {
          stop(paste("Error! Invalid data for `country`. Must be a string:", input_json$`country`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for CustomerAddressAdd: the required field `country` is missing."))
      }
      # check the required field `postcode`
      if (!is.null(input_json$`postcode`)) {
        if (!(is.character(input_json$`postcode`) && length(input_json$`postcode`) == 1)) {
          stop(paste("Error! Invalid data for `postcode`. Must be a string:", input_json$`postcode`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for CustomerAddressAdd: the required field `postcode` is missing."))
      }
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of CustomerAddressAdd
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      # check if the required `customer_id` is null
      if (is.null(self$`customer_id`)) {
        return(FALSE)
      }

      # check if the required `address1` is null
      if (is.null(self$`address1`)) {
        return(FALSE)
      }

      # check if the required `city` is null
      if (is.null(self$`city`)) {
        return(FALSE)
      }

      # check if the required `country` is null
      if (is.null(self$`country`)) {
        return(FALSE)
      }

      # check if the required `postcode` is null
      if (is.null(self$`postcode`)) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      # check if the required `customer_id` is null
      if (is.null(self$`customer_id`)) {
        invalid_fields["customer_id"] <- "Non-nullable required field `customer_id` cannot be null."
      }

      # check if the required `address1` is null
      if (is.null(self$`address1`)) {
        invalid_fields["address1"] <- "Non-nullable required field `address1` cannot be null."
      }

      # check if the required `city` is null
      if (is.null(self$`city`)) {
        invalid_fields["city"] <- "Non-nullable required field `city` cannot be null."
      }

      # check if the required `country` is null
      if (is.null(self$`country`)) {
        invalid_fields["country"] <- "Non-nullable required field `country` cannot be null."
      }

      # check if the required `postcode` is null
      if (is.null(self$`postcode`)) {
        invalid_fields["postcode"] <- "Non-nullable required field `postcode` cannot be null."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# CustomerAddressAdd$unlock()
#
## Below is an example to define the print function
# CustomerAddressAdd$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# CustomerAddressAdd$lock()

