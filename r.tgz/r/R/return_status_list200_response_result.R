#' Create a new ReturnStatusList200ResponseResult
#'
#' @description
#' ReturnStatusList200ResponseResult Class
#'
#' @docType class
#' @title ReturnStatusList200ResponseResult
#' @description ReturnStatusList200ResponseResult Class
#' @format An \code{R6Class} generator object
#' @field return_statuses  list(\link{OrderFinancialStatusList200ResponseResultOrderFinancialStatusesInner}) [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ReturnStatusList200ResponseResult <- R6::R6Class(
  "ReturnStatusList200ResponseResult",
  public = list(
    `return_statuses` = NULL,

    #' @description
    #' Initialize a new ReturnStatusList200ResponseResult class.
    #'
    #' @param return_statuses return_statuses
    #' @param ... Other optional arguments.
    initialize = function(`return_statuses` = NULL, ...) {
      if (!is.null(`return_statuses`)) {
        stopifnot(is.vector(`return_statuses`), length(`return_statuses`) != 0)
        sapply(`return_statuses`, function(x) stopifnot(R6::is.R6(x)))
        self$`return_statuses` <- `return_statuses`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ReturnStatusList200ResponseResult as a base R list.
    #' @examples
    #' # convert array of ReturnStatusList200ResponseResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ReturnStatusList200ResponseResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ReturnStatusList200ResponseResultObject <- list()
      if (!is.null(self$`return_statuses`)) {
        ReturnStatusList200ResponseResultObject[["return_statuses"]] <-
          lapply(self$`return_statuses`, function(x) x$toSimpleType())
      }
      return(ReturnStatusList200ResponseResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ReturnStatusList200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ReturnStatusList200ResponseResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`return_statuses`)) {
        self$`return_statuses` <- ApiClient$new()$deserializeObj(this_object$`return_statuses`, "array[OrderFinancialStatusList200ResponseResultOrderFinancialStatusesInner]", loadNamespace("openapi"))
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ReturnStatusList200ResponseResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ReturnStatusList200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ReturnStatusList200ResponseResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`return_statuses` <- ApiClient$new()$deserializeObj(this_object$`return_statuses`, "array[OrderFinancialStatusList200ResponseResultOrderFinancialStatusesInner]", loadNamespace("openapi"))
      self
    },

    #' @description
    #' Validate JSON input with respect to ReturnStatusList200ResponseResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ReturnStatusList200ResponseResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ReturnStatusList200ResponseResult$unlock()
#
## Below is an example to define the print function
# ReturnStatusList200ResponseResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ReturnStatusList200ResponseResult$lock()

