#' Create a new ProductUpdateBatchPayloadInner
#'
#' @description
#' ProductUpdateBatchPayloadInner Class
#'
#' @docType class
#' @title ProductUpdateBatchPayloadInner
#' @description ProductUpdateBatchPayloadInner Class
#' @format An \code{R6Class} generator object
#' @field id  character
#' @field name  character [optional]
#' @field description  character [optional]
#' @field short_description  character [optional]
#' @field sku  character [optional]
#' @field model  character [optional]
#' @field price  numeric [optional]
#' @field special_price  numeric [optional]
#' @field sprice_create  character [optional]
#' @field sprice_expire  character [optional]
#' @field cost_price  numeric [optional]
#' @field old_price  numeric [optional]
#' @field fixed_cost_shipping_price  numeric [optional]
#' @field advanced_prices If an empty array is passed, all entries will be deleted when the 'nested_items_update_behaviour' parameter is set to 'replace'. list(\link{ProductUpdateBatchPayloadInnerAdvancedPricesInner}) [optional]
#' @field quantity  numeric [optional]
#' @field increase_quantity  numeric [optional]
#' @field reduce_quantity  numeric [optional]
#' @field reserve_quantity  numeric [optional]
#' @field store_id  character [optional]
#' @field lang_id  character [optional]
#' @field status  character [optional]
#' @field type  character [optional]
#' @field condition  character [optional]
#' @field condition_description  character [optional]
#' @field visible  character [optional]
#' @field available_for_view  character [optional]
#' @field available_for_sale  character [optional]
#' @field avail_from  character [optional]
#' @field weight  numeric [optional]
#' @field length  numeric [optional]
#' @field width  numeric [optional]
#' @field height  numeric [optional]
#' @field dimensions_unit  character [optional]
#' @field weight_unit  character [optional]
#' @field manage_stock  character [optional]
#' @field in_stock  character [optional]
#' @field backorder_status  character [optional]
#' @field is_free_shipping  character [optional]
#' @field is_virtual  character [optional]
#' @field taxable  character [optional]
#' @field downloadable  character [optional]
#' @field warehouse_id  character [optional]
#' @field tax_class_id  character [optional]
#' @field categories_ids  list(character) [optional]
#' @field meta_title  character [optional]
#' @field meta_description  character [optional]
#' @field meta_keywords  list(character) [optional]
#' @field url  character [optional]
#' @field seo_url  character [optional]
#' @field manufacturer  character [optional]
#' @field manufacturer_id  character [optional]
#' @field mpn  character [optional]
#' @field gtin  character [optional]
#' @field upc  character [optional]
#' @field isbn  character [optional]
#' @field ean  character [optional]
#' @field barcode  character [optional]
#' @field images Property 'nested_items_update_behaviour' does not apply. Specified items will be added to existing product images list(\link{ProductUpdateBatchPayloadInnerImagesInner}) [optional]
#' @field related_products_ids If an empty array is passed, all entries will be deleted when the 'nested_items_update_behaviour' parameter is set to 'replace'. list(character) [optional]
#' @field up_sell_products_ids If an empty array is passed, all entries will be deleted when the 'nested_items_update_behaviour' parameter is set to 'replace'. list(character) [optional]
#' @field cross_sell_products_ids If an empty array is passed, all entries will be deleted when the 'nested_items_update_behaviour' parameter is set to 'replace'. list(character) [optional]
#' @field tags  list(character) [optional]
#' @field search_keywords  list(character) [optional]
#' @field harmonized_system_code  character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductUpdateBatchPayloadInner <- R6::R6Class(
  "ProductUpdateBatchPayloadInner",
  public = list(
    `id` = NULL,
    `name` = NULL,
    `description` = NULL,
    `short_description` = NULL,
    `sku` = NULL,
    `model` = NULL,
    `price` = NULL,
    `special_price` = NULL,
    `sprice_create` = NULL,
    `sprice_expire` = NULL,
    `cost_price` = NULL,
    `old_price` = NULL,
    `fixed_cost_shipping_price` = NULL,
    `advanced_prices` = NULL,
    `quantity` = NULL,
    `increase_quantity` = NULL,
    `reduce_quantity` = NULL,
    `reserve_quantity` = NULL,
    `store_id` = NULL,
    `lang_id` = NULL,
    `status` = NULL,
    `type` = NULL,
    `condition` = NULL,
    `condition_description` = NULL,
    `visible` = NULL,
    `available_for_view` = NULL,
    `available_for_sale` = NULL,
    `avail_from` = NULL,
    `weight` = NULL,
    `length` = NULL,
    `width` = NULL,
    `height` = NULL,
    `dimensions_unit` = NULL,
    `weight_unit` = NULL,
    `manage_stock` = NULL,
    `in_stock` = NULL,
    `backorder_status` = NULL,
    `is_free_shipping` = NULL,
    `is_virtual` = NULL,
    `taxable` = NULL,
    `downloadable` = NULL,
    `warehouse_id` = NULL,
    `tax_class_id` = NULL,
    `categories_ids` = NULL,
    `meta_title` = NULL,
    `meta_description` = NULL,
    `meta_keywords` = NULL,
    `url` = NULL,
    `seo_url` = NULL,
    `manufacturer` = NULL,
    `manufacturer_id` = NULL,
    `mpn` = NULL,
    `gtin` = NULL,
    `upc` = NULL,
    `isbn` = NULL,
    `ean` = NULL,
    `barcode` = NULL,
    `images` = NULL,
    `related_products_ids` = NULL,
    `up_sell_products_ids` = NULL,
    `cross_sell_products_ids` = NULL,
    `tags` = NULL,
    `search_keywords` = NULL,
    `harmonized_system_code` = NULL,

    #' @description
    #' Initialize a new ProductUpdateBatchPayloadInner class.
    #'
    #' @param id id
    #' @param name name
    #' @param description description
    #' @param short_description short_description
    #' @param sku sku
    #' @param model model
    #' @param price price
    #' @param special_price special_price
    #' @param sprice_create sprice_create
    #' @param sprice_expire sprice_expire
    #' @param cost_price cost_price
    #' @param old_price old_price
    #' @param fixed_cost_shipping_price fixed_cost_shipping_price
    #' @param advanced_prices If an empty array is passed, all entries will be deleted when the 'nested_items_update_behaviour' parameter is set to 'replace'.
    #' @param quantity quantity
    #' @param increase_quantity increase_quantity
    #' @param reduce_quantity reduce_quantity
    #' @param reserve_quantity reserve_quantity
    #' @param store_id store_id
    #' @param lang_id lang_id
    #' @param status status
    #' @param type type
    #' @param condition condition
    #' @param condition_description condition_description
    #' @param visible visible
    #' @param available_for_view available_for_view
    #' @param available_for_sale available_for_sale
    #' @param avail_from avail_from
    #' @param weight weight
    #' @param length length
    #' @param width width
    #' @param height height
    #' @param dimensions_unit dimensions_unit
    #' @param weight_unit weight_unit
    #' @param manage_stock manage_stock
    #' @param in_stock in_stock
    #' @param backorder_status backorder_status
    #' @param is_free_shipping is_free_shipping
    #' @param is_virtual is_virtual
    #' @param taxable taxable
    #' @param downloadable downloadable
    #' @param warehouse_id warehouse_id
    #' @param tax_class_id tax_class_id
    #' @param categories_ids categories_ids
    #' @param meta_title meta_title
    #' @param meta_description meta_description
    #' @param meta_keywords meta_keywords
    #' @param url url
    #' @param seo_url seo_url
    #' @param manufacturer manufacturer
    #' @param manufacturer_id manufacturer_id
    #' @param mpn mpn
    #' @param gtin gtin
    #' @param upc upc
    #' @param isbn isbn
    #' @param ean ean
    #' @param barcode barcode
    #' @param images Property 'nested_items_update_behaviour' does not apply. Specified items will be added to existing product images
    #' @param related_products_ids If an empty array is passed, all entries will be deleted when the 'nested_items_update_behaviour' parameter is set to 'replace'.
    #' @param up_sell_products_ids If an empty array is passed, all entries will be deleted when the 'nested_items_update_behaviour' parameter is set to 'replace'.
    #' @param cross_sell_products_ids If an empty array is passed, all entries will be deleted when the 'nested_items_update_behaviour' parameter is set to 'replace'.
    #' @param tags tags
    #' @param search_keywords search_keywords
    #' @param harmonized_system_code harmonized_system_code
    #' @param ... Other optional arguments.
    initialize = function(`id`, `name` = NULL, `description` = NULL, `short_description` = NULL, `sku` = NULL, `model` = NULL, `price` = NULL, `special_price` = NULL, `sprice_create` = NULL, `sprice_expire` = NULL, `cost_price` = NULL, `old_price` = NULL, `fixed_cost_shipping_price` = NULL, `advanced_prices` = NULL, `quantity` = NULL, `increase_quantity` = NULL, `reduce_quantity` = NULL, `reserve_quantity` = NULL, `store_id` = NULL, `lang_id` = NULL, `status` = NULL, `type` = NULL, `condition` = NULL, `condition_description` = NULL, `visible` = NULL, `available_for_view` = NULL, `available_for_sale` = NULL, `avail_from` = NULL, `weight` = NULL, `length` = NULL, `width` = NULL, `height` = NULL, `dimensions_unit` = NULL, `weight_unit` = NULL, `manage_stock` = NULL, `in_stock` = NULL, `backorder_status` = NULL, `is_free_shipping` = NULL, `is_virtual` = NULL, `taxable` = NULL, `downloadable` = NULL, `warehouse_id` = NULL, `tax_class_id` = NULL, `categories_ids` = NULL, `meta_title` = NULL, `meta_description` = NULL, `meta_keywords` = NULL, `url` = NULL, `seo_url` = NULL, `manufacturer` = NULL, `manufacturer_id` = NULL, `mpn` = NULL, `gtin` = NULL, `upc` = NULL, `isbn` = NULL, `ean` = NULL, `barcode` = NULL, `images` = NULL, `related_products_ids` = NULL, `up_sell_products_ids` = NULL, `cross_sell_products_ids` = NULL, `tags` = NULL, `search_keywords` = NULL, `harmonized_system_code` = NULL, ...) {
      if (!missing(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`description`)) {
        if (!(is.character(`description`) && length(`description`) == 1)) {
          stop(paste("Error! Invalid data for `description`. Must be a string:", `description`))
        }
        self$`description` <- `description`
      }
      if (!is.null(`short_description`)) {
        if (!(is.character(`short_description`) && length(`short_description`) == 1)) {
          stop(paste("Error! Invalid data for `short_description`. Must be a string:", `short_description`))
        }
        self$`short_description` <- `short_description`
      }
      if (!is.null(`sku`)) {
        if (!(is.character(`sku`) && length(`sku`) == 1)) {
          stop(paste("Error! Invalid data for `sku`. Must be a string:", `sku`))
        }
        self$`sku` <- `sku`
      }
      if (!is.null(`model`)) {
        if (!(is.character(`model`) && length(`model`) == 1)) {
          stop(paste("Error! Invalid data for `model`. Must be a string:", `model`))
        }
        self$`model` <- `model`
      }
      if (!is.null(`price`)) {
        self$`price` <- `price`
      }
      if (!is.null(`special_price`)) {
        self$`special_price` <- `special_price`
      }
      if (!is.null(`sprice_create`)) {
        if (!(is.character(`sprice_create`) && length(`sprice_create`) == 1)) {
          stop(paste("Error! Invalid data for `sprice_create`. Must be a string:", `sprice_create`))
        }
        self$`sprice_create` <- `sprice_create`
      }
      if (!is.null(`sprice_expire`)) {
        if (!(is.character(`sprice_expire`) && length(`sprice_expire`) == 1)) {
          stop(paste("Error! Invalid data for `sprice_expire`. Must be a string:", `sprice_expire`))
        }
        self$`sprice_expire` <- `sprice_expire`
      }
      if (!is.null(`cost_price`)) {
        self$`cost_price` <- `cost_price`
      }
      if (!is.null(`old_price`)) {
        self$`old_price` <- `old_price`
      }
      if (!is.null(`fixed_cost_shipping_price`)) {
        self$`fixed_cost_shipping_price` <- `fixed_cost_shipping_price`
      }
      if (!is.null(`advanced_prices`)) {
        stopifnot(is.vector(`advanced_prices`), length(`advanced_prices`) != 0)
        sapply(`advanced_prices`, function(x) stopifnot(R6::is.R6(x)))
        self$`advanced_prices` <- `advanced_prices`
      }
      if (!is.null(`quantity`)) {
        self$`quantity` <- `quantity`
      }
      if (!is.null(`increase_quantity`)) {
        self$`increase_quantity` <- `increase_quantity`
      }
      if (!is.null(`reduce_quantity`)) {
        self$`reduce_quantity` <- `reduce_quantity`
      }
      if (!is.null(`reserve_quantity`)) {
        self$`reserve_quantity` <- `reserve_quantity`
      }
      if (!is.null(`store_id`)) {
        if (!(is.character(`store_id`) && length(`store_id`) == 1)) {
          stop(paste("Error! Invalid data for `store_id`. Must be a string:", `store_id`))
        }
        self$`store_id` <- `store_id`
      }
      if (!is.null(`lang_id`)) {
        if (!(is.character(`lang_id`) && length(`lang_id`) == 1)) {
          stop(paste("Error! Invalid data for `lang_id`. Must be a string:", `lang_id`))
        }
        self$`lang_id` <- `lang_id`
      }
      if (!is.null(`status`)) {
        if (!(is.character(`status`) && length(`status`) == 1)) {
          stop(paste("Error! Invalid data for `status`. Must be a string:", `status`))
        }
        self$`status` <- `status`
      }
      if (!is.null(`type`)) {
        if (!(is.character(`type`) && length(`type`) == 1)) {
          stop(paste("Error! Invalid data for `type`. Must be a string:", `type`))
        }
        self$`type` <- `type`
      }
      if (!is.null(`condition`)) {
        if (!(is.character(`condition`) && length(`condition`) == 1)) {
          stop(paste("Error! Invalid data for `condition`. Must be a string:", `condition`))
        }
        self$`condition` <- `condition`
      }
      if (!is.null(`condition_description`)) {
        if (!(is.character(`condition_description`) && length(`condition_description`) == 1)) {
          stop(paste("Error! Invalid data for `condition_description`. Must be a string:", `condition_description`))
        }
        self$`condition_description` <- `condition_description`
      }
      if (!is.null(`visible`)) {
        if (!(is.character(`visible`) && length(`visible`) == 1)) {
          stop(paste("Error! Invalid data for `visible`. Must be a string:", `visible`))
        }
        self$`visible` <- `visible`
      }
      if (!is.null(`available_for_view`)) {
        if (!(is.logical(`available_for_view`) && length(`available_for_view`) == 1)) {
          stop(paste("Error! Invalid data for `available_for_view`. Must be a boolean:", `available_for_view`))
        }
        self$`available_for_view` <- `available_for_view`
      }
      if (!is.null(`available_for_sale`)) {
        if (!(is.logical(`available_for_sale`) && length(`available_for_sale`) == 1)) {
          stop(paste("Error! Invalid data for `available_for_sale`. Must be a boolean:", `available_for_sale`))
        }
        self$`available_for_sale` <- `available_for_sale`
      }
      if (!is.null(`avail_from`)) {
        if (!(is.character(`avail_from`) && length(`avail_from`) == 1)) {
          stop(paste("Error! Invalid data for `avail_from`. Must be a string:", `avail_from`))
        }
        self$`avail_from` <- `avail_from`
      }
      if (!is.null(`weight`)) {
        self$`weight` <- `weight`
      }
      if (!is.null(`length`)) {
        self$`length` <- `length`
      }
      if (!is.null(`width`)) {
        self$`width` <- `width`
      }
      if (!is.null(`height`)) {
        self$`height` <- `height`
      }
      if (!is.null(`dimensions_unit`)) {
        if (!(is.character(`dimensions_unit`) && length(`dimensions_unit`) == 1)) {
          stop(paste("Error! Invalid data for `dimensions_unit`. Must be a string:", `dimensions_unit`))
        }
        self$`dimensions_unit` <- `dimensions_unit`
      }
      if (!is.null(`weight_unit`)) {
        if (!(is.character(`weight_unit`) && length(`weight_unit`) == 1)) {
          stop(paste("Error! Invalid data for `weight_unit`. Must be a string:", `weight_unit`))
        }
        self$`weight_unit` <- `weight_unit`
      }
      if (!is.null(`manage_stock`)) {
        if (!(is.logical(`manage_stock`) && length(`manage_stock`) == 1)) {
          stop(paste("Error! Invalid data for `manage_stock`. Must be a boolean:", `manage_stock`))
        }
        self$`manage_stock` <- `manage_stock`
      }
      if (!is.null(`in_stock`)) {
        if (!(is.logical(`in_stock`) && length(`in_stock`) == 1)) {
          stop(paste("Error! Invalid data for `in_stock`. Must be a boolean:", `in_stock`))
        }
        self$`in_stock` <- `in_stock`
      }
      if (!is.null(`backorder_status`)) {
        if (!(is.character(`backorder_status`) && length(`backorder_status`) == 1)) {
          stop(paste("Error! Invalid data for `backorder_status`. Must be a string:", `backorder_status`))
        }
        self$`backorder_status` <- `backorder_status`
      }
      if (!is.null(`is_free_shipping`)) {
        if (!(is.logical(`is_free_shipping`) && length(`is_free_shipping`) == 1)) {
          stop(paste("Error! Invalid data for `is_free_shipping`. Must be a boolean:", `is_free_shipping`))
        }
        self$`is_free_shipping` <- `is_free_shipping`
      }
      if (!is.null(`is_virtual`)) {
        if (!(is.logical(`is_virtual`) && length(`is_virtual`) == 1)) {
          stop(paste("Error! Invalid data for `is_virtual`. Must be a boolean:", `is_virtual`))
        }
        self$`is_virtual` <- `is_virtual`
      }
      if (!is.null(`taxable`)) {
        if (!(is.logical(`taxable`) && length(`taxable`) == 1)) {
          stop(paste("Error! Invalid data for `taxable`. Must be a boolean:", `taxable`))
        }
        self$`taxable` <- `taxable`
      }
      if (!is.null(`downloadable`)) {
        if (!(is.logical(`downloadable`) && length(`downloadable`) == 1)) {
          stop(paste("Error! Invalid data for `downloadable`. Must be a boolean:", `downloadable`))
        }
        self$`downloadable` <- `downloadable`
      }
      if (!is.null(`warehouse_id`)) {
        if (!(is.character(`warehouse_id`) && length(`warehouse_id`) == 1)) {
          stop(paste("Error! Invalid data for `warehouse_id`. Must be a string:", `warehouse_id`))
        }
        self$`warehouse_id` <- `warehouse_id`
      }
      if (!is.null(`tax_class_id`)) {
        if (!(is.character(`tax_class_id`) && length(`tax_class_id`) == 1)) {
          stop(paste("Error! Invalid data for `tax_class_id`. Must be a string:", `tax_class_id`))
        }
        self$`tax_class_id` <- `tax_class_id`
      }
      if (!is.null(`categories_ids`)) {
        stopifnot(is.vector(`categories_ids`), length(`categories_ids`) != 0)
        sapply(`categories_ids`, function(x) stopifnot(is.character(x)))
        self$`categories_ids` <- `categories_ids`
      }
      if (!is.null(`meta_title`)) {
        if (!(is.character(`meta_title`) && length(`meta_title`) == 1)) {
          stop(paste("Error! Invalid data for `meta_title`. Must be a string:", `meta_title`))
        }
        self$`meta_title` <- `meta_title`
      }
      if (!is.null(`meta_description`)) {
        if (!(is.character(`meta_description`) && length(`meta_description`) == 1)) {
          stop(paste("Error! Invalid data for `meta_description`. Must be a string:", `meta_description`))
        }
        self$`meta_description` <- `meta_description`
      }
      if (!is.null(`meta_keywords`)) {
        stopifnot(is.vector(`meta_keywords`), length(`meta_keywords`) != 0)
        sapply(`meta_keywords`, function(x) stopifnot(is.character(x)))
        self$`meta_keywords` <- `meta_keywords`
      }
      if (!is.null(`url`)) {
        if (!(is.character(`url`) && length(`url`) == 1)) {
          stop(paste("Error! Invalid data for `url`. Must be a string:", `url`))
        }
        self$`url` <- `url`
      }
      if (!is.null(`seo_url`)) {
        if (!(is.character(`seo_url`) && length(`seo_url`) == 1)) {
          stop(paste("Error! Invalid data for `seo_url`. Must be a string:", `seo_url`))
        }
        self$`seo_url` <- `seo_url`
      }
      if (!is.null(`manufacturer`)) {
        if (!(is.character(`manufacturer`) && length(`manufacturer`) == 1)) {
          stop(paste("Error! Invalid data for `manufacturer`. Must be a string:", `manufacturer`))
        }
        self$`manufacturer` <- `manufacturer`
      }
      if (!is.null(`manufacturer_id`)) {
        if (!(is.character(`manufacturer_id`) && length(`manufacturer_id`) == 1)) {
          stop(paste("Error! Invalid data for `manufacturer_id`. Must be a string:", `manufacturer_id`))
        }
        self$`manufacturer_id` <- `manufacturer_id`
      }
      if (!is.null(`mpn`)) {
        if (!(is.character(`mpn`) && length(`mpn`) == 1)) {
          stop(paste("Error! Invalid data for `mpn`. Must be a string:", `mpn`))
        }
        self$`mpn` <- `mpn`
      }
      if (!is.null(`gtin`)) {
        if (!(is.character(`gtin`) && length(`gtin`) == 1)) {
          stop(paste("Error! Invalid data for `gtin`. Must be a string:", `gtin`))
        }
        self$`gtin` <- `gtin`
      }
      if (!is.null(`upc`)) {
        if (!(is.character(`upc`) && length(`upc`) == 1)) {
          stop(paste("Error! Invalid data for `upc`. Must be a string:", `upc`))
        }
        self$`upc` <- `upc`
      }
      if (!is.null(`isbn`)) {
        if (!(is.character(`isbn`) && length(`isbn`) == 1)) {
          stop(paste("Error! Invalid data for `isbn`. Must be a string:", `isbn`))
        }
        self$`isbn` <- `isbn`
      }
      if (!is.null(`ean`)) {
        if (!(is.character(`ean`) && length(`ean`) == 1)) {
          stop(paste("Error! Invalid data for `ean`. Must be a string:", `ean`))
        }
        self$`ean` <- `ean`
      }
      if (!is.null(`barcode`)) {
        if (!(is.character(`barcode`) && length(`barcode`) == 1)) {
          stop(paste("Error! Invalid data for `barcode`. Must be a string:", `barcode`))
        }
        self$`barcode` <- `barcode`
      }
      if (!is.null(`images`)) {
        stopifnot(is.vector(`images`), length(`images`) != 0)
        sapply(`images`, function(x) stopifnot(R6::is.R6(x)))
        self$`images` <- `images`
      }
      if (!is.null(`related_products_ids`)) {
        stopifnot(is.vector(`related_products_ids`), length(`related_products_ids`) != 0)
        sapply(`related_products_ids`, function(x) stopifnot(is.character(x)))
        self$`related_products_ids` <- `related_products_ids`
      }
      if (!is.null(`up_sell_products_ids`)) {
        stopifnot(is.vector(`up_sell_products_ids`), length(`up_sell_products_ids`) != 0)
        sapply(`up_sell_products_ids`, function(x) stopifnot(is.character(x)))
        self$`up_sell_products_ids` <- `up_sell_products_ids`
      }
      if (!is.null(`cross_sell_products_ids`)) {
        stopifnot(is.vector(`cross_sell_products_ids`), length(`cross_sell_products_ids`) != 0)
        sapply(`cross_sell_products_ids`, function(x) stopifnot(is.character(x)))
        self$`cross_sell_products_ids` <- `cross_sell_products_ids`
      }
      if (!is.null(`tags`)) {
        stopifnot(is.vector(`tags`), length(`tags`) != 0)
        sapply(`tags`, function(x) stopifnot(is.character(x)))
        self$`tags` <- `tags`
      }
      if (!is.null(`search_keywords`)) {
        stopifnot(is.vector(`search_keywords`), length(`search_keywords`) != 0)
        sapply(`search_keywords`, function(x) stopifnot(is.character(x)))
        self$`search_keywords` <- `search_keywords`
      }
      if (!is.null(`harmonized_system_code`)) {
        if (!(is.character(`harmonized_system_code`) && length(`harmonized_system_code`) == 1)) {
          stop(paste("Error! Invalid data for `harmonized_system_code`. Must be a string:", `harmonized_system_code`))
        }
        self$`harmonized_system_code` <- `harmonized_system_code`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductUpdateBatchPayloadInner as a base R list.
    #' @examples
    #' # convert array of ProductUpdateBatchPayloadInner (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductUpdateBatchPayloadInner to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductUpdateBatchPayloadInnerObject <- list()
      if (!is.null(self$`id`)) {
        ProductUpdateBatchPayloadInnerObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`name`)) {
        ProductUpdateBatchPayloadInnerObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`description`)) {
        ProductUpdateBatchPayloadInnerObject[["description"]] <-
          self$`description`
      }
      if (!is.null(self$`short_description`)) {
        ProductUpdateBatchPayloadInnerObject[["short_description"]] <-
          self$`short_description`
      }
      if (!is.null(self$`sku`)) {
        ProductUpdateBatchPayloadInnerObject[["sku"]] <-
          self$`sku`
      }
      if (!is.null(self$`model`)) {
        ProductUpdateBatchPayloadInnerObject[["model"]] <-
          self$`model`
      }
      if (!is.null(self$`price`)) {
        ProductUpdateBatchPayloadInnerObject[["price"]] <-
          self$`price`
      }
      if (!is.null(self$`special_price`)) {
        ProductUpdateBatchPayloadInnerObject[["special_price"]] <-
          self$`special_price`
      }
      if (!is.null(self$`sprice_create`)) {
        ProductUpdateBatchPayloadInnerObject[["sprice_create"]] <-
          self$`sprice_create`
      }
      if (!is.null(self$`sprice_expire`)) {
        ProductUpdateBatchPayloadInnerObject[["sprice_expire"]] <-
          self$`sprice_expire`
      }
      if (!is.null(self$`cost_price`)) {
        ProductUpdateBatchPayloadInnerObject[["cost_price"]] <-
          self$`cost_price`
      }
      if (!is.null(self$`old_price`)) {
        ProductUpdateBatchPayloadInnerObject[["old_price"]] <-
          self$`old_price`
      }
      if (!is.null(self$`fixed_cost_shipping_price`)) {
        ProductUpdateBatchPayloadInnerObject[["fixed_cost_shipping_price"]] <-
          self$`fixed_cost_shipping_price`
      }
      if (!is.null(self$`advanced_prices`)) {
        ProductUpdateBatchPayloadInnerObject[["advanced_prices"]] <-
          lapply(self$`advanced_prices`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`quantity`)) {
        ProductUpdateBatchPayloadInnerObject[["quantity"]] <-
          self$`quantity`
      }
      if (!is.null(self$`increase_quantity`)) {
        ProductUpdateBatchPayloadInnerObject[["increase_quantity"]] <-
          self$`increase_quantity`
      }
      if (!is.null(self$`reduce_quantity`)) {
        ProductUpdateBatchPayloadInnerObject[["reduce_quantity"]] <-
          self$`reduce_quantity`
      }
      if (!is.null(self$`reserve_quantity`)) {
        ProductUpdateBatchPayloadInnerObject[["reserve_quantity"]] <-
          self$`reserve_quantity`
      }
      if (!is.null(self$`store_id`)) {
        ProductUpdateBatchPayloadInnerObject[["store_id"]] <-
          self$`store_id`
      }
      if (!is.null(self$`lang_id`)) {
        ProductUpdateBatchPayloadInnerObject[["lang_id"]] <-
          self$`lang_id`
      }
      if (!is.null(self$`status`)) {
        ProductUpdateBatchPayloadInnerObject[["status"]] <-
          self$`status`
      }
      if (!is.null(self$`type`)) {
        ProductUpdateBatchPayloadInnerObject[["type"]] <-
          self$`type`
      }
      if (!is.null(self$`condition`)) {
        ProductUpdateBatchPayloadInnerObject[["condition"]] <-
          self$`condition`
      }
      if (!is.null(self$`condition_description`)) {
        ProductUpdateBatchPayloadInnerObject[["condition_description"]] <-
          self$`condition_description`
      }
      if (!is.null(self$`visible`)) {
        ProductUpdateBatchPayloadInnerObject[["visible"]] <-
          self$`visible`
      }
      if (!is.null(self$`available_for_view`)) {
        ProductUpdateBatchPayloadInnerObject[["available_for_view"]] <-
          self$`available_for_view`
      }
      if (!is.null(self$`available_for_sale`)) {
        ProductUpdateBatchPayloadInnerObject[["available_for_sale"]] <-
          self$`available_for_sale`
      }
      if (!is.null(self$`avail_from`)) {
        ProductUpdateBatchPayloadInnerObject[["avail_from"]] <-
          self$`avail_from`
      }
      if (!is.null(self$`weight`)) {
        ProductUpdateBatchPayloadInnerObject[["weight"]] <-
          self$`weight`
      }
      if (!is.null(self$`length`)) {
        ProductUpdateBatchPayloadInnerObject[["length"]] <-
          self$`length`
      }
      if (!is.null(self$`width`)) {
        ProductUpdateBatchPayloadInnerObject[["width"]] <-
          self$`width`
      }
      if (!is.null(self$`height`)) {
        ProductUpdateBatchPayloadInnerObject[["height"]] <-
          self$`height`
      }
      if (!is.null(self$`dimensions_unit`)) {
        ProductUpdateBatchPayloadInnerObject[["dimensions_unit"]] <-
          self$`dimensions_unit`
      }
      if (!is.null(self$`weight_unit`)) {
        ProductUpdateBatchPayloadInnerObject[["weight_unit"]] <-
          self$`weight_unit`
      }
      if (!is.null(self$`manage_stock`)) {
        ProductUpdateBatchPayloadInnerObject[["manage_stock"]] <-
          self$`manage_stock`
      }
      if (!is.null(self$`in_stock`)) {
        ProductUpdateBatchPayloadInnerObject[["in_stock"]] <-
          self$`in_stock`
      }
      if (!is.null(self$`backorder_status`)) {
        ProductUpdateBatchPayloadInnerObject[["backorder_status"]] <-
          self$`backorder_status`
      }
      if (!is.null(self$`is_free_shipping`)) {
        ProductUpdateBatchPayloadInnerObject[["is_free_shipping"]] <-
          self$`is_free_shipping`
      }
      if (!is.null(self$`is_virtual`)) {
        ProductUpdateBatchPayloadInnerObject[["is_virtual"]] <-
          self$`is_virtual`
      }
      if (!is.null(self$`taxable`)) {
        ProductUpdateBatchPayloadInnerObject[["taxable"]] <-
          self$`taxable`
      }
      if (!is.null(self$`downloadable`)) {
        ProductUpdateBatchPayloadInnerObject[["downloadable"]] <-
          self$`downloadable`
      }
      if (!is.null(self$`warehouse_id`)) {
        ProductUpdateBatchPayloadInnerObject[["warehouse_id"]] <-
          self$`warehouse_id`
      }
      if (!is.null(self$`tax_class_id`)) {
        ProductUpdateBatchPayloadInnerObject[["tax_class_id"]] <-
          self$`tax_class_id`
      }
      if (!is.null(self$`categories_ids`)) {
        ProductUpdateBatchPayloadInnerObject[["categories_ids"]] <-
          self$`categories_ids`
      }
      if (!is.null(self$`meta_title`)) {
        ProductUpdateBatchPayloadInnerObject[["meta_title"]] <-
          self$`meta_title`
      }
      if (!is.null(self$`meta_description`)) {
        ProductUpdateBatchPayloadInnerObject[["meta_description"]] <-
          self$`meta_description`
      }
      if (!is.null(self$`meta_keywords`)) {
        ProductUpdateBatchPayloadInnerObject[["meta_keywords"]] <-
          self$`meta_keywords`
      }
      if (!is.null(self$`url`)) {
        ProductUpdateBatchPayloadInnerObject[["url"]] <-
          self$`url`
      }
      if (!is.null(self$`seo_url`)) {
        ProductUpdateBatchPayloadInnerObject[["seo_url"]] <-
          self$`seo_url`
      }
      if (!is.null(self$`manufacturer`)) {
        ProductUpdateBatchPayloadInnerObject[["manufacturer"]] <-
          self$`manufacturer`
      }
      if (!is.null(self$`manufacturer_id`)) {
        ProductUpdateBatchPayloadInnerObject[["manufacturer_id"]] <-
          self$`manufacturer_id`
      }
      if (!is.null(self$`mpn`)) {
        ProductUpdateBatchPayloadInnerObject[["mpn"]] <-
          self$`mpn`
      }
      if (!is.null(self$`gtin`)) {
        ProductUpdateBatchPayloadInnerObject[["gtin"]] <-
          self$`gtin`
      }
      if (!is.null(self$`upc`)) {
        ProductUpdateBatchPayloadInnerObject[["upc"]] <-
          self$`upc`
      }
      if (!is.null(self$`isbn`)) {
        ProductUpdateBatchPayloadInnerObject[["isbn"]] <-
          self$`isbn`
      }
      if (!is.null(self$`ean`)) {
        ProductUpdateBatchPayloadInnerObject[["ean"]] <-
          self$`ean`
      }
      if (!is.null(self$`barcode`)) {
        ProductUpdateBatchPayloadInnerObject[["barcode"]] <-
          self$`barcode`
      }
      if (!is.null(self$`images`)) {
        ProductUpdateBatchPayloadInnerObject[["images"]] <-
          lapply(self$`images`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`related_products_ids`)) {
        ProductUpdateBatchPayloadInnerObject[["related_products_ids"]] <-
          self$`related_products_ids`
      }
      if (!is.null(self$`up_sell_products_ids`)) {
        ProductUpdateBatchPayloadInnerObject[["up_sell_products_ids"]] <-
          self$`up_sell_products_ids`
      }
      if (!is.null(self$`cross_sell_products_ids`)) {
        ProductUpdateBatchPayloadInnerObject[["cross_sell_products_ids"]] <-
          self$`cross_sell_products_ids`
      }
      if (!is.null(self$`tags`)) {
        ProductUpdateBatchPayloadInnerObject[["tags"]] <-
          self$`tags`
      }
      if (!is.null(self$`search_keywords`)) {
        ProductUpdateBatchPayloadInnerObject[["search_keywords"]] <-
          self$`search_keywords`
      }
      if (!is.null(self$`harmonized_system_code`)) {
        ProductUpdateBatchPayloadInnerObject[["harmonized_system_code"]] <-
          self$`harmonized_system_code`
      }
      return(ProductUpdateBatchPayloadInnerObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductUpdateBatchPayloadInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductUpdateBatchPayloadInner
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`description`)) {
        self$`description` <- this_object$`description`
      }
      if (!is.null(this_object$`short_description`)) {
        self$`short_description` <- this_object$`short_description`
      }
      if (!is.null(this_object$`sku`)) {
        self$`sku` <- this_object$`sku`
      }
      if (!is.null(this_object$`model`)) {
        self$`model` <- this_object$`model`
      }
      if (!is.null(this_object$`price`)) {
        self$`price` <- this_object$`price`
      }
      if (!is.null(this_object$`special_price`)) {
        self$`special_price` <- this_object$`special_price`
      }
      if (!is.null(this_object$`sprice_create`)) {
        self$`sprice_create` <- this_object$`sprice_create`
      }
      if (!is.null(this_object$`sprice_expire`)) {
        self$`sprice_expire` <- this_object$`sprice_expire`
      }
      if (!is.null(this_object$`cost_price`)) {
        self$`cost_price` <- this_object$`cost_price`
      }
      if (!is.null(this_object$`old_price`)) {
        self$`old_price` <- this_object$`old_price`
      }
      if (!is.null(this_object$`fixed_cost_shipping_price`)) {
        self$`fixed_cost_shipping_price` <- this_object$`fixed_cost_shipping_price`
      }
      if (!is.null(this_object$`advanced_prices`)) {
        self$`advanced_prices` <- ApiClient$new()$deserializeObj(this_object$`advanced_prices`, "array[ProductUpdateBatchPayloadInnerAdvancedPricesInner]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`quantity`)) {
        self$`quantity` <- this_object$`quantity`
      }
      if (!is.null(this_object$`increase_quantity`)) {
        self$`increase_quantity` <- this_object$`increase_quantity`
      }
      if (!is.null(this_object$`reduce_quantity`)) {
        self$`reduce_quantity` <- this_object$`reduce_quantity`
      }
      if (!is.null(this_object$`reserve_quantity`)) {
        self$`reserve_quantity` <- this_object$`reserve_quantity`
      }
      if (!is.null(this_object$`store_id`)) {
        self$`store_id` <- this_object$`store_id`
      }
      if (!is.null(this_object$`lang_id`)) {
        self$`lang_id` <- this_object$`lang_id`
      }
      if (!is.null(this_object$`status`)) {
        self$`status` <- this_object$`status`
      }
      if (!is.null(this_object$`type`)) {
        self$`type` <- this_object$`type`
      }
      if (!is.null(this_object$`condition`)) {
        self$`condition` <- this_object$`condition`
      }
      if (!is.null(this_object$`condition_description`)) {
        self$`condition_description` <- this_object$`condition_description`
      }
      if (!is.null(this_object$`visible`)) {
        self$`visible` <- this_object$`visible`
      }
      if (!is.null(this_object$`available_for_view`)) {
        self$`available_for_view` <- this_object$`available_for_view`
      }
      if (!is.null(this_object$`available_for_sale`)) {
        self$`available_for_sale` <- this_object$`available_for_sale`
      }
      if (!is.null(this_object$`avail_from`)) {
        self$`avail_from` <- this_object$`avail_from`
      }
      if (!is.null(this_object$`weight`)) {
        self$`weight` <- this_object$`weight`
      }
      if (!is.null(this_object$`length`)) {
        self$`length` <- this_object$`length`
      }
      if (!is.null(this_object$`width`)) {
        self$`width` <- this_object$`width`
      }
      if (!is.null(this_object$`height`)) {
        self$`height` <- this_object$`height`
      }
      if (!is.null(this_object$`dimensions_unit`)) {
        self$`dimensions_unit` <- this_object$`dimensions_unit`
      }
      if (!is.null(this_object$`weight_unit`)) {
        self$`weight_unit` <- this_object$`weight_unit`
      }
      if (!is.null(this_object$`manage_stock`)) {
        self$`manage_stock` <- this_object$`manage_stock`
      }
      if (!is.null(this_object$`in_stock`)) {
        self$`in_stock` <- this_object$`in_stock`
      }
      if (!is.null(this_object$`backorder_status`)) {
        self$`backorder_status` <- this_object$`backorder_status`
      }
      if (!is.null(this_object$`is_free_shipping`)) {
        self$`is_free_shipping` <- this_object$`is_free_shipping`
      }
      if (!is.null(this_object$`is_virtual`)) {
        self$`is_virtual` <- this_object$`is_virtual`
      }
      if (!is.null(this_object$`taxable`)) {
        self$`taxable` <- this_object$`taxable`
      }
      if (!is.null(this_object$`downloadable`)) {
        self$`downloadable` <- this_object$`downloadable`
      }
      if (!is.null(this_object$`warehouse_id`)) {
        self$`warehouse_id` <- this_object$`warehouse_id`
      }
      if (!is.null(this_object$`tax_class_id`)) {
        self$`tax_class_id` <- this_object$`tax_class_id`
      }
      if (!is.null(this_object$`categories_ids`)) {
        self$`categories_ids` <- ApiClient$new()$deserializeObj(this_object$`categories_ids`, "array[character]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`meta_title`)) {
        self$`meta_title` <- this_object$`meta_title`
      }
      if (!is.null(this_object$`meta_description`)) {
        self$`meta_description` <- this_object$`meta_description`
      }
      if (!is.null(this_object$`meta_keywords`)) {
        self$`meta_keywords` <- ApiClient$new()$deserializeObj(this_object$`meta_keywords`, "array[character]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`url`)) {
        self$`url` <- this_object$`url`
      }
      if (!is.null(this_object$`seo_url`)) {
        self$`seo_url` <- this_object$`seo_url`
      }
      if (!is.null(this_object$`manufacturer`)) {
        self$`manufacturer` <- this_object$`manufacturer`
      }
      if (!is.null(this_object$`manufacturer_id`)) {
        self$`manufacturer_id` <- this_object$`manufacturer_id`
      }
      if (!is.null(this_object$`mpn`)) {
        self$`mpn` <- this_object$`mpn`
      }
      if (!is.null(this_object$`gtin`)) {
        self$`gtin` <- this_object$`gtin`
      }
      if (!is.null(this_object$`upc`)) {
        self$`upc` <- this_object$`upc`
      }
      if (!is.null(this_object$`isbn`)) {
        self$`isbn` <- this_object$`isbn`
      }
      if (!is.null(this_object$`ean`)) {
        self$`ean` <- this_object$`ean`
      }
      if (!is.null(this_object$`barcode`)) {
        self$`barcode` <- this_object$`barcode`
      }
      if (!is.null(this_object$`images`)) {
        self$`images` <- ApiClient$new()$deserializeObj(this_object$`images`, "array[ProductUpdateBatchPayloadInnerImagesInner]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`related_products_ids`)) {
        self$`related_products_ids` <- ApiClient$new()$deserializeObj(this_object$`related_products_ids`, "array[character]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`up_sell_products_ids`)) {
        self$`up_sell_products_ids` <- ApiClient$new()$deserializeObj(this_object$`up_sell_products_ids`, "array[character]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`cross_sell_products_ids`)) {
        self$`cross_sell_products_ids` <- ApiClient$new()$deserializeObj(this_object$`cross_sell_products_ids`, "array[character]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`tags`)) {
        self$`tags` <- ApiClient$new()$deserializeObj(this_object$`tags`, "array[character]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`search_keywords`)) {
        self$`search_keywords` <- ApiClient$new()$deserializeObj(this_object$`search_keywords`, "array[character]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`harmonized_system_code`)) {
        self$`harmonized_system_code` <- this_object$`harmonized_system_code`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductUpdateBatchPayloadInner in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductUpdateBatchPayloadInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductUpdateBatchPayloadInner
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`name` <- this_object$`name`
      self$`description` <- this_object$`description`
      self$`short_description` <- this_object$`short_description`
      self$`sku` <- this_object$`sku`
      self$`model` <- this_object$`model`
      self$`price` <- this_object$`price`
      self$`special_price` <- this_object$`special_price`
      self$`sprice_create` <- this_object$`sprice_create`
      self$`sprice_expire` <- this_object$`sprice_expire`
      self$`cost_price` <- this_object$`cost_price`
      self$`old_price` <- this_object$`old_price`
      self$`fixed_cost_shipping_price` <- this_object$`fixed_cost_shipping_price`
      self$`advanced_prices` <- ApiClient$new()$deserializeObj(this_object$`advanced_prices`, "array[ProductUpdateBatchPayloadInnerAdvancedPricesInner]", loadNamespace("openapi"))
      self$`quantity` <- this_object$`quantity`
      self$`increase_quantity` <- this_object$`increase_quantity`
      self$`reduce_quantity` <- this_object$`reduce_quantity`
      self$`reserve_quantity` <- this_object$`reserve_quantity`
      self$`store_id` <- this_object$`store_id`
      self$`lang_id` <- this_object$`lang_id`
      self$`status` <- this_object$`status`
      self$`type` <- this_object$`type`
      self$`condition` <- this_object$`condition`
      self$`condition_description` <- this_object$`condition_description`
      self$`visible` <- this_object$`visible`
      self$`available_for_view` <- this_object$`available_for_view`
      self$`available_for_sale` <- this_object$`available_for_sale`
      self$`avail_from` <- this_object$`avail_from`
      self$`weight` <- this_object$`weight`
      self$`length` <- this_object$`length`
      self$`width` <- this_object$`width`
      self$`height` <- this_object$`height`
      self$`dimensions_unit` <- this_object$`dimensions_unit`
      self$`weight_unit` <- this_object$`weight_unit`
      self$`manage_stock` <- this_object$`manage_stock`
      self$`in_stock` <- this_object$`in_stock`
      self$`backorder_status` <- this_object$`backorder_status`
      self$`is_free_shipping` <- this_object$`is_free_shipping`
      self$`is_virtual` <- this_object$`is_virtual`
      self$`taxable` <- this_object$`taxable`
      self$`downloadable` <- this_object$`downloadable`
      self$`warehouse_id` <- this_object$`warehouse_id`
      self$`tax_class_id` <- this_object$`tax_class_id`
      self$`categories_ids` <- ApiClient$new()$deserializeObj(this_object$`categories_ids`, "array[character]", loadNamespace("openapi"))
      self$`meta_title` <- this_object$`meta_title`
      self$`meta_description` <- this_object$`meta_description`
      self$`meta_keywords` <- ApiClient$new()$deserializeObj(this_object$`meta_keywords`, "array[character]", loadNamespace("openapi"))
      self$`url` <- this_object$`url`
      self$`seo_url` <- this_object$`seo_url`
      self$`manufacturer` <- this_object$`manufacturer`
      self$`manufacturer_id` <- this_object$`manufacturer_id`
      self$`mpn` <- this_object$`mpn`
      self$`gtin` <- this_object$`gtin`
      self$`upc` <- this_object$`upc`
      self$`isbn` <- this_object$`isbn`
      self$`ean` <- this_object$`ean`
      self$`barcode` <- this_object$`barcode`
      self$`images` <- ApiClient$new()$deserializeObj(this_object$`images`, "array[ProductUpdateBatchPayloadInnerImagesInner]", loadNamespace("openapi"))
      self$`related_products_ids` <- ApiClient$new()$deserializeObj(this_object$`related_products_ids`, "array[character]", loadNamespace("openapi"))
      self$`up_sell_products_ids` <- ApiClient$new()$deserializeObj(this_object$`up_sell_products_ids`, "array[character]", loadNamespace("openapi"))
      self$`cross_sell_products_ids` <- ApiClient$new()$deserializeObj(this_object$`cross_sell_products_ids`, "array[character]", loadNamespace("openapi"))
      self$`tags` <- ApiClient$new()$deserializeObj(this_object$`tags`, "array[character]", loadNamespace("openapi"))
      self$`search_keywords` <- ApiClient$new()$deserializeObj(this_object$`search_keywords`, "array[character]", loadNamespace("openapi"))
      self$`harmonized_system_code` <- this_object$`harmonized_system_code`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductUpdateBatchPayloadInner and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
      # check the required field `id`
      if (!is.null(input_json$`id`)) {
        if (!(is.character(input_json$`id`) && length(input_json$`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", input_json$`id`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for ProductUpdateBatchPayloadInner: the required field `id` is missing."))
      }
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductUpdateBatchPayloadInner
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      # check if the required `id` is null
      if (is.null(self$`id`)) {
        return(FALSE)
      }

      if (length(self$`categories_ids`) < 1) {
        return(FALSE)
      }

      if (length(self$`meta_keywords`) < 1) {
        return(FALSE)
      }

      if (length(self$`images`) < 1) {
        return(FALSE)
      }

      if (length(self$`tags`) < 1) {
        return(FALSE)
      }

      if (length(self$`search_keywords`) < 1) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      # check if the required `id` is null
      if (is.null(self$`id`)) {
        invalid_fields["id"] <- "Non-nullable required field `id` cannot be null."
      }

      if (length(self$`categories_ids`) < 1) {
        invalid_fields["categories_ids"] <- "Invalid length for ``, number of items must be greater than or equal to 1."
      }

      if (length(self$`meta_keywords`) < 1) {
        invalid_fields["meta_keywords"] <- "Invalid length for ``, number of items must be greater than or equal to 1."
      }

      if (length(self$`images`) < 1) {
        invalid_fields["images"] <- "Invalid length for ``, number of items must be greater than or equal to 1."
      }

      if (length(self$`tags`) < 1) {
        invalid_fields["tags"] <- "Invalid length for ``, number of items must be greater than or equal to 1."
      }

      if (length(self$`search_keywords`) < 1) {
        invalid_fields["search_keywords"] <- "Invalid length for ``, number of items must be greater than or equal to 1."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductUpdateBatchPayloadInner$unlock()
#
## Below is an example to define the print function
# ProductUpdateBatchPayloadInner$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductUpdateBatchPayloadInner$lock()

