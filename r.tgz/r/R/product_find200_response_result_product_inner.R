#' Create a new ProductFind200ResponseResultProductInner
#'
#' @description
#' ProductFind200ResponseResultProductInner Class
#'
#' @docType class
#' @title ProductFind200ResponseResultProductInner
#' @description ProductFind200ResponseResultProductInner Class
#' @format An \code{R6Class} generator object
#' @field id  character [optional]
#' @field name  character [optional]
#' @field description  character [optional]
#' @field price  numeric [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductFind200ResponseResultProductInner <- R6::R6Class(
  "ProductFind200ResponseResultProductInner",
  public = list(
    `id` = NULL,
    `name` = NULL,
    `description` = NULL,
    `price` = NULL,

    #' @description
    #' Initialize a new ProductFind200ResponseResultProductInner class.
    #'
    #' @param id id
    #' @param name name
    #' @param description description
    #' @param price price
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `name` = NULL, `description` = NULL, `price` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`description`)) {
        if (!(is.character(`description`) && length(`description`) == 1)) {
          stop(paste("Error! Invalid data for `description`. Must be a string:", `description`))
        }
        self$`description` <- `description`
      }
      if (!is.null(`price`)) {
        self$`price` <- `price`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductFind200ResponseResultProductInner as a base R list.
    #' @examples
    #' # convert array of ProductFind200ResponseResultProductInner (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductFind200ResponseResultProductInner to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductFind200ResponseResultProductInnerObject <- list()
      if (!is.null(self$`id`)) {
        ProductFind200ResponseResultProductInnerObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`name`)) {
        ProductFind200ResponseResultProductInnerObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`description`)) {
        ProductFind200ResponseResultProductInnerObject[["description"]] <-
          self$`description`
      }
      if (!is.null(self$`price`)) {
        ProductFind200ResponseResultProductInnerObject[["price"]] <-
          self$`price`
      }
      return(ProductFind200ResponseResultProductInnerObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductFind200ResponseResultProductInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductFind200ResponseResultProductInner
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`description`)) {
        self$`description` <- this_object$`description`
      }
      if (!is.null(this_object$`price`)) {
        self$`price` <- this_object$`price`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductFind200ResponseResultProductInner in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductFind200ResponseResultProductInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductFind200ResponseResultProductInner
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`name` <- this_object$`name`
      self$`description` <- this_object$`description`
      self$`price` <- this_object$`price`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductFind200ResponseResultProductInner and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductFind200ResponseResultProductInner
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductFind200ResponseResultProductInner$unlock()
#
## Below is an example to define the print function
# ProductFind200ResponseResultProductInner$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductFind200ResponseResultProductInner$lock()

