#' Create a new ProductAddSpecificsInnerBookingDetailsOverridesInner
#'
#' @description
#' ProductAddSpecificsInnerBookingDetailsOverridesInner Class
#'
#' @docType class
#' @title ProductAddSpecificsInnerBookingDetailsOverridesInner
#' @description ProductAddSpecificsInnerBookingDetailsOverridesInner Class
#' @format An \code{R6Class} generator object
#' @field day  character
#' @field date  character
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductAddSpecificsInnerBookingDetailsOverridesInner <- R6::R6Class(
  "ProductAddSpecificsInnerBookingDetailsOverridesInner",
  public = list(
    `day` = NULL,
    `date` = NULL,

    #' @description
    #' Initialize a new ProductAddSpecificsInnerBookingDetailsOverridesInner class.
    #'
    #' @param day day
    #' @param date date
    #' @param ... Other optional arguments.
    initialize = function(`day`, `date`, ...) {
      if (!missing(`day`)) {
        if (!(`day` %in% c("sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"))) {
          stop(paste("Error! \"", `day`, "\" cannot be assigned to `day`. Must be \"sunday\", \"monday\", \"tuesday\", \"wednesday\", \"thursday\", \"friday\", \"saturday\".", sep = ""))
        }
        if (!(is.character(`day`) && length(`day`) == 1)) {
          stop(paste("Error! Invalid data for `day`. Must be a string:", `day`))
        }
        self$`day` <- `day`
      }
      if (!missing(`date`)) {
        if (!(is.character(`date`) && length(`date`) == 1)) {
          stop(paste("Error! Invalid data for `date`. Must be a string:", `date`))
        }
        self$`date` <- `date`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductAddSpecificsInnerBookingDetailsOverridesInner as a base R list.
    #' @examples
    #' # convert array of ProductAddSpecificsInnerBookingDetailsOverridesInner (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductAddSpecificsInnerBookingDetailsOverridesInner to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductAddSpecificsInnerBookingDetailsOverridesInnerObject <- list()
      if (!is.null(self$`day`)) {
        ProductAddSpecificsInnerBookingDetailsOverridesInnerObject[["day"]] <-
          self$`day`
      }
      if (!is.null(self$`date`)) {
        ProductAddSpecificsInnerBookingDetailsOverridesInnerObject[["date"]] <-
          self$`date`
      }
      return(ProductAddSpecificsInnerBookingDetailsOverridesInnerObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductAddSpecificsInnerBookingDetailsOverridesInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductAddSpecificsInnerBookingDetailsOverridesInner
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`day`)) {
        if (!is.null(this_object$`day`) && !(this_object$`day` %in% c("sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"))) {
          stop(paste("Error! \"", this_object$`day`, "\" cannot be assigned to `day`. Must be \"sunday\", \"monday\", \"tuesday\", \"wednesday\", \"thursday\", \"friday\", \"saturday\".", sep = ""))
        }
        self$`day` <- this_object$`day`
      }
      if (!is.null(this_object$`date`)) {
        self$`date` <- this_object$`date`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductAddSpecificsInnerBookingDetailsOverridesInner in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductAddSpecificsInnerBookingDetailsOverridesInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductAddSpecificsInnerBookingDetailsOverridesInner
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`day`) && !(this_object$`day` %in% c("sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"))) {
        stop(paste("Error! \"", this_object$`day`, "\" cannot be assigned to `day`. Must be \"sunday\", \"monday\", \"tuesday\", \"wednesday\", \"thursday\", \"friday\", \"saturday\".", sep = ""))
      }
      self$`day` <- this_object$`day`
      self$`date` <- this_object$`date`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductAddSpecificsInnerBookingDetailsOverridesInner and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
      # check the required field `day`
      if (!is.null(input_json$`day`)) {
        if (!(is.character(input_json$`day`) && length(input_json$`day`) == 1)) {
          stop(paste("Error! Invalid data for `day`. Must be a string:", input_json$`day`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for ProductAddSpecificsInnerBookingDetailsOverridesInner: the required field `day` is missing."))
      }
      # check the required field `date`
      if (!is.null(input_json$`date`)) {
        if (!(is.character(input_json$`date`) && length(input_json$`date`) == 1)) {
          stop(paste("Error! Invalid data for `date`. Must be a string:", input_json$`date`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for ProductAddSpecificsInnerBookingDetailsOverridesInner: the required field `date` is missing."))
      }
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductAddSpecificsInnerBookingDetailsOverridesInner
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      # check if the required `day` is null
      if (is.null(self$`day`)) {
        return(FALSE)
      }

      # check if the required `date` is null
      if (is.null(self$`date`)) {
        return(FALSE)
      }

      if (!str_detect(self$`date`, "^(19|20)\\d\\d-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01])$")) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      # check if the required `day` is null
      if (is.null(self$`day`)) {
        invalid_fields["day"] <- "Non-nullable required field `day` cannot be null."
      }

      # check if the required `date` is null
      if (is.null(self$`date`)) {
        invalid_fields["date"] <- "Non-nullable required field `date` cannot be null."
      }

      if (!str_detect(self$`date`, "^(19|20)\\d\\d-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01])$")) {
        invalid_fields["date"] <- "Invalid value for `date`, must conform to the pattern ^(19|20)\\d\\d-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01])$."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductAddSpecificsInnerBookingDetailsOverridesInner$unlock()
#
## Below is an example to define the print function
# ProductAddSpecificsInnerBookingDetailsOverridesInner$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductAddSpecificsInnerBookingDetailsOverridesInner$lock()

