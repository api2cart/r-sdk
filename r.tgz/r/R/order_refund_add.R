#' Create a new OrderRefundAdd
#'
#' @description
#' OrderRefundAdd Class
#'
#' @docType class
#' @title OrderRefundAdd
#' @description OrderRefundAdd Class
#' @format An \code{R6Class} generator object
#' @field order_id Defines the order for which the refund will be created. character [optional]
#' @field items Defines items in the order that will be refunded list(\link{OrderRefundAddItemsInner}) [optional]
#' @field total_price Defines order refund amount. numeric [optional]
#' @field shipping_price Defines refund shipping amount. numeric [optional]
#' @field fee_price Specifies refund's fee price numeric [optional]
#' @field message Refund reason, or some else message which assigned to refund. character [optional]
#' @field item_restock Boolean, whether or not to add the line items back to the store inventory. character [optional]
#' @field send_notifications Send notifications to customer after refund was created character [optional]
#' @field date Specifies an order creation date in format Y-m-d H:i:s character [optional]
#' @field store_id Store Id character [optional]
#' @field is_online Indicates whether refund type is online character [optional]
#' @field idempotency_key A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong> character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
OrderRefundAdd <- R6::R6Class(
  "OrderRefundAdd",
  public = list(
    `order_id` = NULL,
    `items` = NULL,
    `total_price` = NULL,
    `shipping_price` = NULL,
    `fee_price` = NULL,
    `message` = NULL,
    `item_restock` = NULL,
    `send_notifications` = NULL,
    `date` = NULL,
    `store_id` = NULL,
    `is_online` = NULL,
    `idempotency_key` = NULL,

    #' @description
    #' Initialize a new OrderRefundAdd class.
    #'
    #' @param order_id Defines the order for which the refund will be created.
    #' @param items Defines items in the order that will be refunded
    #' @param total_price Defines order refund amount.
    #' @param shipping_price Defines refund shipping amount.
    #' @param fee_price Specifies refund's fee price
    #' @param message Refund reason, or some else message which assigned to refund.
    #' @param item_restock Boolean, whether or not to add the line items back to the store inventory.. Default to FALSE.
    #' @param send_notifications Send notifications to customer after refund was created. Default to FALSE.
    #' @param date Specifies an order creation date in format Y-m-d H:i:s
    #' @param store_id Store Id
    #' @param is_online Indicates whether refund type is online. Default to FALSE.
    #' @param idempotency_key A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong>
    #' @param ... Other optional arguments.
    initialize = function(`order_id` = NULL, `items` = NULL, `total_price` = NULL, `shipping_price` = NULL, `fee_price` = NULL, `message` = NULL, `item_restock` = FALSE, `send_notifications` = FALSE, `date` = NULL, `store_id` = NULL, `is_online` = FALSE, `idempotency_key` = NULL, ...) {
      if (!is.null(`order_id`)) {
        if (!(is.character(`order_id`) && length(`order_id`) == 1)) {
          stop(paste("Error! Invalid data for `order_id`. Must be a string:", `order_id`))
        }
        self$`order_id` <- `order_id`
      }
      if (!is.null(`items`)) {
        stopifnot(is.vector(`items`), length(`items`) != 0)
        sapply(`items`, function(x) stopifnot(R6::is.R6(x)))
        self$`items` <- `items`
      }
      if (!is.null(`total_price`)) {
        self$`total_price` <- `total_price`
      }
      if (!is.null(`shipping_price`)) {
        self$`shipping_price` <- `shipping_price`
      }
      if (!is.null(`fee_price`)) {
        self$`fee_price` <- `fee_price`
      }
      if (!is.null(`message`)) {
        if (!(is.character(`message`) && length(`message`) == 1)) {
          stop(paste("Error! Invalid data for `message`. Must be a string:", `message`))
        }
        self$`message` <- `message`
      }
      if (!is.null(`item_restock`)) {
        if (!(is.logical(`item_restock`) && length(`item_restock`) == 1)) {
          stop(paste("Error! Invalid data for `item_restock`. Must be a boolean:", `item_restock`))
        }
        self$`item_restock` <- `item_restock`
      }
      if (!is.null(`send_notifications`)) {
        if (!(is.logical(`send_notifications`) && length(`send_notifications`) == 1)) {
          stop(paste("Error! Invalid data for `send_notifications`. Must be a boolean:", `send_notifications`))
        }
        self$`send_notifications` <- `send_notifications`
      }
      if (!is.null(`date`)) {
        if (!(is.character(`date`) && length(`date`) == 1)) {
          stop(paste("Error! Invalid data for `date`. Must be a string:", `date`))
        }
        self$`date` <- `date`
      }
      if (!is.null(`store_id`)) {
        if (!(is.character(`store_id`) && length(`store_id`) == 1)) {
          stop(paste("Error! Invalid data for `store_id`. Must be a string:", `store_id`))
        }
        self$`store_id` <- `store_id`
      }
      if (!is.null(`is_online`)) {
        if (!(is.logical(`is_online`) && length(`is_online`) == 1)) {
          stop(paste("Error! Invalid data for `is_online`. Must be a boolean:", `is_online`))
        }
        self$`is_online` <- `is_online`
      }
      if (!is.null(`idempotency_key`)) {
        if (!(is.character(`idempotency_key`) && length(`idempotency_key`) == 1)) {
          stop(paste("Error! Invalid data for `idempotency_key`. Must be a string:", `idempotency_key`))
        }
        self$`idempotency_key` <- `idempotency_key`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return OrderRefundAdd as a base R list.
    #' @examples
    #' # convert array of OrderRefundAdd (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert OrderRefundAdd to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      OrderRefundAddObject <- list()
      if (!is.null(self$`order_id`)) {
        OrderRefundAddObject[["order_id"]] <-
          self$`order_id`
      }
      if (!is.null(self$`items`)) {
        OrderRefundAddObject[["items"]] <-
          lapply(self$`items`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`total_price`)) {
        OrderRefundAddObject[["total_price"]] <-
          self$`total_price`
      }
      if (!is.null(self$`shipping_price`)) {
        OrderRefundAddObject[["shipping_price"]] <-
          self$`shipping_price`
      }
      if (!is.null(self$`fee_price`)) {
        OrderRefundAddObject[["fee_price"]] <-
          self$`fee_price`
      }
      if (!is.null(self$`message`)) {
        OrderRefundAddObject[["message"]] <-
          self$`message`
      }
      if (!is.null(self$`item_restock`)) {
        OrderRefundAddObject[["item_restock"]] <-
          self$`item_restock`
      }
      if (!is.null(self$`send_notifications`)) {
        OrderRefundAddObject[["send_notifications"]] <-
          self$`send_notifications`
      }
      if (!is.null(self$`date`)) {
        OrderRefundAddObject[["date"]] <-
          self$`date`
      }
      if (!is.null(self$`store_id`)) {
        OrderRefundAddObject[["store_id"]] <-
          self$`store_id`
      }
      if (!is.null(self$`is_online`)) {
        OrderRefundAddObject[["is_online"]] <-
          self$`is_online`
      }
      if (!is.null(self$`idempotency_key`)) {
        OrderRefundAddObject[["idempotency_key"]] <-
          self$`idempotency_key`
      }
      return(OrderRefundAddObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderRefundAdd
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderRefundAdd
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`order_id`)) {
        self$`order_id` <- this_object$`order_id`
      }
      if (!is.null(this_object$`items`)) {
        self$`items` <- ApiClient$new()$deserializeObj(this_object$`items`, "array[OrderRefundAddItemsInner]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`total_price`)) {
        self$`total_price` <- this_object$`total_price`
      }
      if (!is.null(this_object$`shipping_price`)) {
        self$`shipping_price` <- this_object$`shipping_price`
      }
      if (!is.null(this_object$`fee_price`)) {
        self$`fee_price` <- this_object$`fee_price`
      }
      if (!is.null(this_object$`message`)) {
        self$`message` <- this_object$`message`
      }
      if (!is.null(this_object$`item_restock`)) {
        self$`item_restock` <- this_object$`item_restock`
      }
      if (!is.null(this_object$`send_notifications`)) {
        self$`send_notifications` <- this_object$`send_notifications`
      }
      if (!is.null(this_object$`date`)) {
        self$`date` <- this_object$`date`
      }
      if (!is.null(this_object$`store_id`)) {
        self$`store_id` <- this_object$`store_id`
      }
      if (!is.null(this_object$`is_online`)) {
        self$`is_online` <- this_object$`is_online`
      }
      if (!is.null(this_object$`idempotency_key`)) {
        self$`idempotency_key` <- this_object$`idempotency_key`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return OrderRefundAdd in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderRefundAdd
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderRefundAdd
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`order_id` <- this_object$`order_id`
      self$`items` <- ApiClient$new()$deserializeObj(this_object$`items`, "array[OrderRefundAddItemsInner]", loadNamespace("openapi"))
      self$`total_price` <- this_object$`total_price`
      self$`shipping_price` <- this_object$`shipping_price`
      self$`fee_price` <- this_object$`fee_price`
      self$`message` <- this_object$`message`
      self$`item_restock` <- this_object$`item_restock`
      self$`send_notifications` <- this_object$`send_notifications`
      self$`date` <- this_object$`date`
      self$`store_id` <- this_object$`store_id`
      self$`is_online` <- this_object$`is_online`
      self$`idempotency_key` <- this_object$`idempotency_key`
      self
    },

    #' @description
    #' Validate JSON input with respect to OrderRefundAdd and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of OrderRefundAdd
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# OrderRefundAdd$unlock()
#
## Below is an example to define the print function
# OrderRefundAdd$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# OrderRefundAdd$lock()

