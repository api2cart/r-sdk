#' Create a new ProductVariantAddBatchPayloadInner
#'
#' @description
#' ProductVariantAddBatchPayloadInner Class
#'
#' @docType class
#' @title ProductVariantAddBatchPayloadInner
#' @description ProductVariantAddBatchPayloadInner Class
#' @format An \code{R6Class} generator object
#' @field product_id  character
#' @field combination A unique combination that contains an array of options and their values, which form a variation. list(\link{ProductVariantAddBatchPayloadInnerCombinationInner})
#' @field name  character [optional]
#' @field description  character [optional]
#' @field short_description  character [optional]
#' @field sku  character
#' @field model  character [optional]
#' @field price  numeric [optional]
#' @field old_price  numeric [optional]
#' @field cost_price  numeric [optional]
#' @field special_price  numeric [optional]
#' @field sprice_create  character [optional]
#' @field sprice_expire  character [optional]
#' @field advanced_prices  list(\link{ProductUpdateBatchPayloadInnerAdvancedPricesInner}) [optional]
#' @field meta_title  numeric [optional]
#' @field meta_description  numeric [optional]
#' @field meta_keywords  list(character) [optional]
#' @field categories_ids  list(character) [optional]
#' @field stores_ids  list(character) [optional]
#' @field weight  numeric [optional]
#' @field width  numeric [optional]
#' @field height  numeric [optional]
#' @field length  numeric [optional]
#' @field weight_unit  character [optional]
#' @field warehouse_id  character [optional]
#' @field quantity  numeric [optional]
#' @field manage_stock  character [optional]
#' @field in_stock  character [optional]
#' @field store_id  character [optional]
#' @field lang_id  character [optional]
#' @field tax_class_id  character [optional]
#' @field backorder_status  character [optional]
#' @field status  character [optional]
#' @field visible  character [optional]
#' @field is_virtual  character [optional]
#' @field downloadable  character [optional]
#' @field is_default  character [optional]
#' @field upc  character [optional]
#' @field isbn  character [optional]
#' @field mpn  character [optional]
#' @field ean  character [optional]
#' @field barcode  character [optional]
#' @field available_for_sale  character [optional]
#' @field is_free_shipping  character [optional]
#' @field taxable  character [optional]
#' @field seo_url  character [optional]
#' @field manufacturer_id  character [optional]
#' @field harmonized_system_code  character [optional]
#' @field marketplace_item_properties  object [optional]
#' @field images  list(\link{ProductAddBatchPayloadInnerImagesInner}) [optional]
#' @field product_images_ids  list(character) [optional]
#' @field related_products_ids  list(character) [optional]
#' @field up_sell_products_ids  list(character) [optional]
#' @field cross_sell_products_ids  list(character) [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductVariantAddBatchPayloadInner <- R6::R6Class(
  "ProductVariantAddBatchPayloadInner",
  public = list(
    `product_id` = NULL,
    `combination` = NULL,
    `name` = NULL,
    `description` = NULL,
    `short_description` = NULL,
    `sku` = NULL,
    `model` = NULL,
    `price` = NULL,
    `old_price` = NULL,
    `cost_price` = NULL,
    `special_price` = NULL,
    `sprice_create` = NULL,
    `sprice_expire` = NULL,
    `advanced_prices` = NULL,
    `meta_title` = NULL,
    `meta_description` = NULL,
    `meta_keywords` = NULL,
    `categories_ids` = NULL,
    `stores_ids` = NULL,
    `weight` = NULL,
    `width` = NULL,
    `height` = NULL,
    `length` = NULL,
    `weight_unit` = NULL,
    `warehouse_id` = NULL,
    `quantity` = NULL,
    `manage_stock` = NULL,
    `in_stock` = NULL,
    `store_id` = NULL,
    `lang_id` = NULL,
    `tax_class_id` = NULL,
    `backorder_status` = NULL,
    `status` = NULL,
    `visible` = NULL,
    `is_virtual` = NULL,
    `downloadable` = NULL,
    `is_default` = NULL,
    `upc` = NULL,
    `isbn` = NULL,
    `mpn` = NULL,
    `ean` = NULL,
    `barcode` = NULL,
    `available_for_sale` = NULL,
    `is_free_shipping` = NULL,
    `taxable` = NULL,
    `seo_url` = NULL,
    `manufacturer_id` = NULL,
    `harmonized_system_code` = NULL,
    `marketplace_item_properties` = NULL,
    `images` = NULL,
    `product_images_ids` = NULL,
    `related_products_ids` = NULL,
    `up_sell_products_ids` = NULL,
    `cross_sell_products_ids` = NULL,

    #' @description
    #' Initialize a new ProductVariantAddBatchPayloadInner class.
    #'
    #' @param product_id product_id
    #' @param combination A unique combination that contains an array of options and their values, which form a variation.
    #' @param sku sku
    #' @param name name
    #' @param description description
    #' @param short_description short_description
    #' @param model model
    #' @param price price
    #' @param old_price old_price
    #' @param cost_price cost_price
    #' @param special_price special_price
    #' @param sprice_create sprice_create
    #' @param sprice_expire sprice_expire
    #' @param advanced_prices advanced_prices
    #' @param meta_title meta_title
    #' @param meta_description meta_description
    #' @param meta_keywords meta_keywords
    #' @param categories_ids categories_ids
    #' @param stores_ids stores_ids
    #' @param weight weight
    #' @param width width
    #' @param height height
    #' @param length length
    #' @param weight_unit weight_unit
    #' @param warehouse_id warehouse_id
    #' @param quantity quantity
    #' @param manage_stock manage_stock
    #' @param in_stock in_stock
    #' @param store_id store_id
    #' @param lang_id lang_id
    #' @param tax_class_id tax_class_id
    #' @param backorder_status backorder_status
    #' @param status status
    #' @param visible visible
    #' @param is_virtual is_virtual
    #' @param downloadable downloadable
    #' @param is_default is_default
    #' @param upc upc
    #' @param isbn isbn
    #' @param mpn mpn
    #' @param ean ean
    #' @param barcode barcode
    #' @param available_for_sale available_for_sale
    #' @param is_free_shipping is_free_shipping
    #' @param taxable taxable
    #' @param seo_url seo_url
    #' @param manufacturer_id manufacturer_id
    #' @param harmonized_system_code harmonized_system_code
    #' @param marketplace_item_properties marketplace_item_properties
    #' @param images images
    #' @param product_images_ids product_images_ids
    #' @param related_products_ids related_products_ids
    #' @param up_sell_products_ids up_sell_products_ids
    #' @param cross_sell_products_ids cross_sell_products_ids
    #' @param ... Other optional arguments.
    initialize = function(`product_id`, `combination`, `sku`, `name` = NULL, `description` = NULL, `short_description` = NULL, `model` = NULL, `price` = NULL, `old_price` = NULL, `cost_price` = NULL, `special_price` = NULL, `sprice_create` = NULL, `sprice_expire` = NULL, `advanced_prices` = NULL, `meta_title` = NULL, `meta_description` = NULL, `meta_keywords` = NULL, `categories_ids` = NULL, `stores_ids` = NULL, `weight` = NULL, `width` = NULL, `height` = NULL, `length` = NULL, `weight_unit` = NULL, `warehouse_id` = NULL, `quantity` = NULL, `manage_stock` = NULL, `in_stock` = NULL, `store_id` = NULL, `lang_id` = NULL, `tax_class_id` = NULL, `backorder_status` = NULL, `status` = NULL, `visible` = NULL, `is_virtual` = NULL, `downloadable` = NULL, `is_default` = NULL, `upc` = NULL, `isbn` = NULL, `mpn` = NULL, `ean` = NULL, `barcode` = NULL, `available_for_sale` = NULL, `is_free_shipping` = NULL, `taxable` = NULL, `seo_url` = NULL, `manufacturer_id` = NULL, `harmonized_system_code` = NULL, `marketplace_item_properties` = NULL, `images` = NULL, `product_images_ids` = NULL, `related_products_ids` = NULL, `up_sell_products_ids` = NULL, `cross_sell_products_ids` = NULL, ...) {
      if (!missing(`product_id`)) {
        if (!(is.character(`product_id`) && length(`product_id`) == 1)) {
          stop(paste("Error! Invalid data for `product_id`. Must be a string:", `product_id`))
        }
        self$`product_id` <- `product_id`
      }
      if (!missing(`combination`)) {
        stopifnot(is.vector(`combination`), length(`combination`) != 0)
        sapply(`combination`, function(x) stopifnot(R6::is.R6(x)))
        self$`combination` <- `combination`
      }
      if (!missing(`sku`)) {
        if (!(is.character(`sku`) && length(`sku`) == 1)) {
          stop(paste("Error! Invalid data for `sku`. Must be a string:", `sku`))
        }
        self$`sku` <- `sku`
      }
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`description`)) {
        if (!(is.character(`description`) && length(`description`) == 1)) {
          stop(paste("Error! Invalid data for `description`. Must be a string:", `description`))
        }
        self$`description` <- `description`
      }
      if (!is.null(`short_description`)) {
        if (!(is.character(`short_description`) && length(`short_description`) == 1)) {
          stop(paste("Error! Invalid data for `short_description`. Must be a string:", `short_description`))
        }
        self$`short_description` <- `short_description`
      }
      if (!is.null(`model`)) {
        if (!(is.character(`model`) && length(`model`) == 1)) {
          stop(paste("Error! Invalid data for `model`. Must be a string:", `model`))
        }
        self$`model` <- `model`
      }
      if (!is.null(`price`)) {
        self$`price` <- `price`
      }
      if (!is.null(`old_price`)) {
        self$`old_price` <- `old_price`
      }
      if (!is.null(`cost_price`)) {
        self$`cost_price` <- `cost_price`
      }
      if (!is.null(`special_price`)) {
        self$`special_price` <- `special_price`
      }
      if (!is.null(`sprice_create`)) {
        if (!(is.character(`sprice_create`) && length(`sprice_create`) == 1)) {
          stop(paste("Error! Invalid data for `sprice_create`. Must be a string:", `sprice_create`))
        }
        self$`sprice_create` <- `sprice_create`
      }
      if (!is.null(`sprice_expire`)) {
        if (!(is.character(`sprice_expire`) && length(`sprice_expire`) == 1)) {
          stop(paste("Error! Invalid data for `sprice_expire`. Must be a string:", `sprice_expire`))
        }
        self$`sprice_expire` <- `sprice_expire`
      }
      if (!is.null(`advanced_prices`)) {
        stopifnot(is.vector(`advanced_prices`), length(`advanced_prices`) != 0)
        sapply(`advanced_prices`, function(x) stopifnot(R6::is.R6(x)))
        self$`advanced_prices` <- `advanced_prices`
      }
      if (!is.null(`meta_title`)) {
        self$`meta_title` <- `meta_title`
      }
      if (!is.null(`meta_description`)) {
        self$`meta_description` <- `meta_description`
      }
      if (!is.null(`meta_keywords`)) {
        stopifnot(is.vector(`meta_keywords`), length(`meta_keywords`) != 0)
        sapply(`meta_keywords`, function(x) stopifnot(is.character(x)))
        self$`meta_keywords` <- `meta_keywords`
      }
      if (!is.null(`categories_ids`)) {
        stopifnot(is.vector(`categories_ids`), length(`categories_ids`) != 0)
        sapply(`categories_ids`, function(x) stopifnot(is.character(x)))
        self$`categories_ids` <- `categories_ids`
      }
      if (!is.null(`stores_ids`)) {
        stopifnot(is.vector(`stores_ids`), length(`stores_ids`) != 0)
        sapply(`stores_ids`, function(x) stopifnot(is.character(x)))
        self$`stores_ids` <- `stores_ids`
      }
      if (!is.null(`weight`)) {
        self$`weight` <- `weight`
      }
      if (!is.null(`width`)) {
        self$`width` <- `width`
      }
      if (!is.null(`height`)) {
        self$`height` <- `height`
      }
      if (!is.null(`length`)) {
        self$`length` <- `length`
      }
      if (!is.null(`weight_unit`)) {
        if (!(is.character(`weight_unit`) && length(`weight_unit`) == 1)) {
          stop(paste("Error! Invalid data for `weight_unit`. Must be a string:", `weight_unit`))
        }
        self$`weight_unit` <- `weight_unit`
      }
      if (!is.null(`warehouse_id`)) {
        if (!(is.character(`warehouse_id`) && length(`warehouse_id`) == 1)) {
          stop(paste("Error! Invalid data for `warehouse_id`. Must be a string:", `warehouse_id`))
        }
        self$`warehouse_id` <- `warehouse_id`
      }
      if (!is.null(`quantity`)) {
        self$`quantity` <- `quantity`
      }
      if (!is.null(`manage_stock`)) {
        if (!(is.logical(`manage_stock`) && length(`manage_stock`) == 1)) {
          stop(paste("Error! Invalid data for `manage_stock`. Must be a boolean:", `manage_stock`))
        }
        self$`manage_stock` <- `manage_stock`
      }
      if (!is.null(`in_stock`)) {
        if (!(is.logical(`in_stock`) && length(`in_stock`) == 1)) {
          stop(paste("Error! Invalid data for `in_stock`. Must be a boolean:", `in_stock`))
        }
        self$`in_stock` <- `in_stock`
      }
      if (!is.null(`store_id`)) {
        if (!(is.character(`store_id`) && length(`store_id`) == 1)) {
          stop(paste("Error! Invalid data for `store_id`. Must be a string:", `store_id`))
        }
        self$`store_id` <- `store_id`
      }
      if (!is.null(`lang_id`)) {
        if (!(is.character(`lang_id`) && length(`lang_id`) == 1)) {
          stop(paste("Error! Invalid data for `lang_id`. Must be a string:", `lang_id`))
        }
        self$`lang_id` <- `lang_id`
      }
      if (!is.null(`tax_class_id`)) {
        if (!(is.character(`tax_class_id`) && length(`tax_class_id`) == 1)) {
          stop(paste("Error! Invalid data for `tax_class_id`. Must be a string:", `tax_class_id`))
        }
        self$`tax_class_id` <- `tax_class_id`
      }
      if (!is.null(`backorder_status`)) {
        if (!(is.character(`backorder_status`) && length(`backorder_status`) == 1)) {
          stop(paste("Error! Invalid data for `backorder_status`. Must be a string:", `backorder_status`))
        }
        self$`backorder_status` <- `backorder_status`
      }
      if (!is.null(`status`)) {
        if (!(is.character(`status`) && length(`status`) == 1)) {
          stop(paste("Error! Invalid data for `status`. Must be a string:", `status`))
        }
        self$`status` <- `status`
      }
      if (!is.null(`visible`)) {
        if (!(is.character(`visible`) && length(`visible`) == 1)) {
          stop(paste("Error! Invalid data for `visible`. Must be a string:", `visible`))
        }
        self$`visible` <- `visible`
      }
      if (!is.null(`is_virtual`)) {
        if (!(is.logical(`is_virtual`) && length(`is_virtual`) == 1)) {
          stop(paste("Error! Invalid data for `is_virtual`. Must be a boolean:", `is_virtual`))
        }
        self$`is_virtual` <- `is_virtual`
      }
      if (!is.null(`downloadable`)) {
        if (!(is.logical(`downloadable`) && length(`downloadable`) == 1)) {
          stop(paste("Error! Invalid data for `downloadable`. Must be a boolean:", `downloadable`))
        }
        self$`downloadable` <- `downloadable`
      }
      if (!is.null(`is_default`)) {
        if (!(is.logical(`is_default`) && length(`is_default`) == 1)) {
          stop(paste("Error! Invalid data for `is_default`. Must be a boolean:", `is_default`))
        }
        self$`is_default` <- `is_default`
      }
      if (!is.null(`upc`)) {
        if (!(is.character(`upc`) && length(`upc`) == 1)) {
          stop(paste("Error! Invalid data for `upc`. Must be a string:", `upc`))
        }
        self$`upc` <- `upc`
      }
      if (!is.null(`isbn`)) {
        if (!(is.character(`isbn`) && length(`isbn`) == 1)) {
          stop(paste("Error! Invalid data for `isbn`. Must be a string:", `isbn`))
        }
        self$`isbn` <- `isbn`
      }
      if (!is.null(`mpn`)) {
        if (!(is.character(`mpn`) && length(`mpn`) == 1)) {
          stop(paste("Error! Invalid data for `mpn`. Must be a string:", `mpn`))
        }
        self$`mpn` <- `mpn`
      }
      if (!is.null(`ean`)) {
        if (!(is.character(`ean`) && length(`ean`) == 1)) {
          stop(paste("Error! Invalid data for `ean`. Must be a string:", `ean`))
        }
        self$`ean` <- `ean`
      }
      if (!is.null(`barcode`)) {
        if (!(is.character(`barcode`) && length(`barcode`) == 1)) {
          stop(paste("Error! Invalid data for `barcode`. Must be a string:", `barcode`))
        }
        self$`barcode` <- `barcode`
      }
      if (!is.null(`available_for_sale`)) {
        if (!(is.logical(`available_for_sale`) && length(`available_for_sale`) == 1)) {
          stop(paste("Error! Invalid data for `available_for_sale`. Must be a boolean:", `available_for_sale`))
        }
        self$`available_for_sale` <- `available_for_sale`
      }
      if (!is.null(`is_free_shipping`)) {
        if (!(is.logical(`is_free_shipping`) && length(`is_free_shipping`) == 1)) {
          stop(paste("Error! Invalid data for `is_free_shipping`. Must be a boolean:", `is_free_shipping`))
        }
        self$`is_free_shipping` <- `is_free_shipping`
      }
      if (!is.null(`taxable`)) {
        if (!(is.logical(`taxable`) && length(`taxable`) == 1)) {
          stop(paste("Error! Invalid data for `taxable`. Must be a boolean:", `taxable`))
        }
        self$`taxable` <- `taxable`
      }
      if (!is.null(`seo_url`)) {
        if (!(is.character(`seo_url`) && length(`seo_url`) == 1)) {
          stop(paste("Error! Invalid data for `seo_url`. Must be a string:", `seo_url`))
        }
        self$`seo_url` <- `seo_url`
      }
      if (!is.null(`manufacturer_id`)) {
        if (!(is.character(`manufacturer_id`) && length(`manufacturer_id`) == 1)) {
          stop(paste("Error! Invalid data for `manufacturer_id`. Must be a string:", `manufacturer_id`))
        }
        self$`manufacturer_id` <- `manufacturer_id`
      }
      if (!is.null(`harmonized_system_code`)) {
        if (!(is.character(`harmonized_system_code`) && length(`harmonized_system_code`) == 1)) {
          stop(paste("Error! Invalid data for `harmonized_system_code`. Must be a string:", `harmonized_system_code`))
        }
        self$`harmonized_system_code` <- `harmonized_system_code`
      }
      if (!is.null(`marketplace_item_properties`)) {
        self$`marketplace_item_properties` <- `marketplace_item_properties`
      }
      if (!is.null(`images`)) {
        stopifnot(is.vector(`images`), length(`images`) != 0)
        sapply(`images`, function(x) stopifnot(R6::is.R6(x)))
        self$`images` <- `images`
      }
      if (!is.null(`product_images_ids`)) {
        stopifnot(is.vector(`product_images_ids`), length(`product_images_ids`) != 0)
        sapply(`product_images_ids`, function(x) stopifnot(is.character(x)))
        self$`product_images_ids` <- `product_images_ids`
      }
      if (!is.null(`related_products_ids`)) {
        stopifnot(is.vector(`related_products_ids`), length(`related_products_ids`) != 0)
        sapply(`related_products_ids`, function(x) stopifnot(is.character(x)))
        self$`related_products_ids` <- `related_products_ids`
      }
      if (!is.null(`up_sell_products_ids`)) {
        stopifnot(is.vector(`up_sell_products_ids`), length(`up_sell_products_ids`) != 0)
        sapply(`up_sell_products_ids`, function(x) stopifnot(is.character(x)))
        self$`up_sell_products_ids` <- `up_sell_products_ids`
      }
      if (!is.null(`cross_sell_products_ids`)) {
        stopifnot(is.vector(`cross_sell_products_ids`), length(`cross_sell_products_ids`) != 0)
        sapply(`cross_sell_products_ids`, function(x) stopifnot(is.character(x)))
        self$`cross_sell_products_ids` <- `cross_sell_products_ids`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductVariantAddBatchPayloadInner as a base R list.
    #' @examples
    #' # convert array of ProductVariantAddBatchPayloadInner (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductVariantAddBatchPayloadInner to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductVariantAddBatchPayloadInnerObject <- list()
      if (!is.null(self$`product_id`)) {
        ProductVariantAddBatchPayloadInnerObject[["product_id"]] <-
          self$`product_id`
      }
      if (!is.null(self$`combination`)) {
        ProductVariantAddBatchPayloadInnerObject[["combination"]] <-
          lapply(self$`combination`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`name`)) {
        ProductVariantAddBatchPayloadInnerObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`description`)) {
        ProductVariantAddBatchPayloadInnerObject[["description"]] <-
          self$`description`
      }
      if (!is.null(self$`short_description`)) {
        ProductVariantAddBatchPayloadInnerObject[["short_description"]] <-
          self$`short_description`
      }
      if (!is.null(self$`sku`)) {
        ProductVariantAddBatchPayloadInnerObject[["sku"]] <-
          self$`sku`
      }
      if (!is.null(self$`model`)) {
        ProductVariantAddBatchPayloadInnerObject[["model"]] <-
          self$`model`
      }
      if (!is.null(self$`price`)) {
        ProductVariantAddBatchPayloadInnerObject[["price"]] <-
          self$`price`
      }
      if (!is.null(self$`old_price`)) {
        ProductVariantAddBatchPayloadInnerObject[["old_price"]] <-
          self$`old_price`
      }
      if (!is.null(self$`cost_price`)) {
        ProductVariantAddBatchPayloadInnerObject[["cost_price"]] <-
          self$`cost_price`
      }
      if (!is.null(self$`special_price`)) {
        ProductVariantAddBatchPayloadInnerObject[["special_price"]] <-
          self$`special_price`
      }
      if (!is.null(self$`sprice_create`)) {
        ProductVariantAddBatchPayloadInnerObject[["sprice_create"]] <-
          self$`sprice_create`
      }
      if (!is.null(self$`sprice_expire`)) {
        ProductVariantAddBatchPayloadInnerObject[["sprice_expire"]] <-
          self$`sprice_expire`
      }
      if (!is.null(self$`advanced_prices`)) {
        ProductVariantAddBatchPayloadInnerObject[["advanced_prices"]] <-
          lapply(self$`advanced_prices`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`meta_title`)) {
        ProductVariantAddBatchPayloadInnerObject[["meta_title"]] <-
          self$`meta_title`
      }
      if (!is.null(self$`meta_description`)) {
        ProductVariantAddBatchPayloadInnerObject[["meta_description"]] <-
          self$`meta_description`
      }
      if (!is.null(self$`meta_keywords`)) {
        ProductVariantAddBatchPayloadInnerObject[["meta_keywords"]] <-
          self$`meta_keywords`
      }
      if (!is.null(self$`categories_ids`)) {
        ProductVariantAddBatchPayloadInnerObject[["categories_ids"]] <-
          self$`categories_ids`
      }
      if (!is.null(self$`stores_ids`)) {
        ProductVariantAddBatchPayloadInnerObject[["stores_ids"]] <-
          self$`stores_ids`
      }
      if (!is.null(self$`weight`)) {
        ProductVariantAddBatchPayloadInnerObject[["weight"]] <-
          self$`weight`
      }
      if (!is.null(self$`width`)) {
        ProductVariantAddBatchPayloadInnerObject[["width"]] <-
          self$`width`
      }
      if (!is.null(self$`height`)) {
        ProductVariantAddBatchPayloadInnerObject[["height"]] <-
          self$`height`
      }
      if (!is.null(self$`length`)) {
        ProductVariantAddBatchPayloadInnerObject[["length"]] <-
          self$`length`
      }
      if (!is.null(self$`weight_unit`)) {
        ProductVariantAddBatchPayloadInnerObject[["weight_unit"]] <-
          self$`weight_unit`
      }
      if (!is.null(self$`warehouse_id`)) {
        ProductVariantAddBatchPayloadInnerObject[["warehouse_id"]] <-
          self$`warehouse_id`
      }
      if (!is.null(self$`quantity`)) {
        ProductVariantAddBatchPayloadInnerObject[["quantity"]] <-
          self$`quantity`
      }
      if (!is.null(self$`manage_stock`)) {
        ProductVariantAddBatchPayloadInnerObject[["manage_stock"]] <-
          self$`manage_stock`
      }
      if (!is.null(self$`in_stock`)) {
        ProductVariantAddBatchPayloadInnerObject[["in_stock"]] <-
          self$`in_stock`
      }
      if (!is.null(self$`store_id`)) {
        ProductVariantAddBatchPayloadInnerObject[["store_id"]] <-
          self$`store_id`
      }
      if (!is.null(self$`lang_id`)) {
        ProductVariantAddBatchPayloadInnerObject[["lang_id"]] <-
          self$`lang_id`
      }
      if (!is.null(self$`tax_class_id`)) {
        ProductVariantAddBatchPayloadInnerObject[["tax_class_id"]] <-
          self$`tax_class_id`
      }
      if (!is.null(self$`backorder_status`)) {
        ProductVariantAddBatchPayloadInnerObject[["backorder_status"]] <-
          self$`backorder_status`
      }
      if (!is.null(self$`status`)) {
        ProductVariantAddBatchPayloadInnerObject[["status"]] <-
          self$`status`
      }
      if (!is.null(self$`visible`)) {
        ProductVariantAddBatchPayloadInnerObject[["visible"]] <-
          self$`visible`
      }
      if (!is.null(self$`is_virtual`)) {
        ProductVariantAddBatchPayloadInnerObject[["is_virtual"]] <-
          self$`is_virtual`
      }
      if (!is.null(self$`downloadable`)) {
        ProductVariantAddBatchPayloadInnerObject[["downloadable"]] <-
          self$`downloadable`
      }
      if (!is.null(self$`is_default`)) {
        ProductVariantAddBatchPayloadInnerObject[["is_default"]] <-
          self$`is_default`
      }
      if (!is.null(self$`upc`)) {
        ProductVariantAddBatchPayloadInnerObject[["upc"]] <-
          self$`upc`
      }
      if (!is.null(self$`isbn`)) {
        ProductVariantAddBatchPayloadInnerObject[["isbn"]] <-
          self$`isbn`
      }
      if (!is.null(self$`mpn`)) {
        ProductVariantAddBatchPayloadInnerObject[["mpn"]] <-
          self$`mpn`
      }
      if (!is.null(self$`ean`)) {
        ProductVariantAddBatchPayloadInnerObject[["ean"]] <-
          self$`ean`
      }
      if (!is.null(self$`barcode`)) {
        ProductVariantAddBatchPayloadInnerObject[["barcode"]] <-
          self$`barcode`
      }
      if (!is.null(self$`available_for_sale`)) {
        ProductVariantAddBatchPayloadInnerObject[["available_for_sale"]] <-
          self$`available_for_sale`
      }
      if (!is.null(self$`is_free_shipping`)) {
        ProductVariantAddBatchPayloadInnerObject[["is_free_shipping"]] <-
          self$`is_free_shipping`
      }
      if (!is.null(self$`taxable`)) {
        ProductVariantAddBatchPayloadInnerObject[["taxable"]] <-
          self$`taxable`
      }
      if (!is.null(self$`seo_url`)) {
        ProductVariantAddBatchPayloadInnerObject[["seo_url"]] <-
          self$`seo_url`
      }
      if (!is.null(self$`manufacturer_id`)) {
        ProductVariantAddBatchPayloadInnerObject[["manufacturer_id"]] <-
          self$`manufacturer_id`
      }
      if (!is.null(self$`harmonized_system_code`)) {
        ProductVariantAddBatchPayloadInnerObject[["harmonized_system_code"]] <-
          self$`harmonized_system_code`
      }
      if (!is.null(self$`marketplace_item_properties`)) {
        ProductVariantAddBatchPayloadInnerObject[["marketplace_item_properties"]] <-
          self$`marketplace_item_properties`
      }
      if (!is.null(self$`images`)) {
        ProductVariantAddBatchPayloadInnerObject[["images"]] <-
          lapply(self$`images`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`product_images_ids`)) {
        ProductVariantAddBatchPayloadInnerObject[["product_images_ids"]] <-
          self$`product_images_ids`
      }
      if (!is.null(self$`related_products_ids`)) {
        ProductVariantAddBatchPayloadInnerObject[["related_products_ids"]] <-
          self$`related_products_ids`
      }
      if (!is.null(self$`up_sell_products_ids`)) {
        ProductVariantAddBatchPayloadInnerObject[["up_sell_products_ids"]] <-
          self$`up_sell_products_ids`
      }
      if (!is.null(self$`cross_sell_products_ids`)) {
        ProductVariantAddBatchPayloadInnerObject[["cross_sell_products_ids"]] <-
          self$`cross_sell_products_ids`
      }
      return(ProductVariantAddBatchPayloadInnerObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductVariantAddBatchPayloadInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductVariantAddBatchPayloadInner
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`product_id`)) {
        self$`product_id` <- this_object$`product_id`
      }
      if (!is.null(this_object$`combination`)) {
        self$`combination` <- ApiClient$new()$deserializeObj(this_object$`combination`, "array[ProductVariantAddBatchPayloadInnerCombinationInner]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`description`)) {
        self$`description` <- this_object$`description`
      }
      if (!is.null(this_object$`short_description`)) {
        self$`short_description` <- this_object$`short_description`
      }
      if (!is.null(this_object$`sku`)) {
        self$`sku` <- this_object$`sku`
      }
      if (!is.null(this_object$`model`)) {
        self$`model` <- this_object$`model`
      }
      if (!is.null(this_object$`price`)) {
        self$`price` <- this_object$`price`
      }
      if (!is.null(this_object$`old_price`)) {
        self$`old_price` <- this_object$`old_price`
      }
      if (!is.null(this_object$`cost_price`)) {
        self$`cost_price` <- this_object$`cost_price`
      }
      if (!is.null(this_object$`special_price`)) {
        self$`special_price` <- this_object$`special_price`
      }
      if (!is.null(this_object$`sprice_create`)) {
        self$`sprice_create` <- this_object$`sprice_create`
      }
      if (!is.null(this_object$`sprice_expire`)) {
        self$`sprice_expire` <- this_object$`sprice_expire`
      }
      if (!is.null(this_object$`advanced_prices`)) {
        self$`advanced_prices` <- ApiClient$new()$deserializeObj(this_object$`advanced_prices`, "array[ProductUpdateBatchPayloadInnerAdvancedPricesInner]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`meta_title`)) {
        self$`meta_title` <- this_object$`meta_title`
      }
      if (!is.null(this_object$`meta_description`)) {
        self$`meta_description` <- this_object$`meta_description`
      }
      if (!is.null(this_object$`meta_keywords`)) {
        self$`meta_keywords` <- ApiClient$new()$deserializeObj(this_object$`meta_keywords`, "array[character]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`categories_ids`)) {
        self$`categories_ids` <- ApiClient$new()$deserializeObj(this_object$`categories_ids`, "array[character]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`stores_ids`)) {
        self$`stores_ids` <- ApiClient$new()$deserializeObj(this_object$`stores_ids`, "array[character]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`weight`)) {
        self$`weight` <- this_object$`weight`
      }
      if (!is.null(this_object$`width`)) {
        self$`width` <- this_object$`width`
      }
      if (!is.null(this_object$`height`)) {
        self$`height` <- this_object$`height`
      }
      if (!is.null(this_object$`length`)) {
        self$`length` <- this_object$`length`
      }
      if (!is.null(this_object$`weight_unit`)) {
        self$`weight_unit` <- this_object$`weight_unit`
      }
      if (!is.null(this_object$`warehouse_id`)) {
        self$`warehouse_id` <- this_object$`warehouse_id`
      }
      if (!is.null(this_object$`quantity`)) {
        self$`quantity` <- this_object$`quantity`
      }
      if (!is.null(this_object$`manage_stock`)) {
        self$`manage_stock` <- this_object$`manage_stock`
      }
      if (!is.null(this_object$`in_stock`)) {
        self$`in_stock` <- this_object$`in_stock`
      }
      if (!is.null(this_object$`store_id`)) {
        self$`store_id` <- this_object$`store_id`
      }
      if (!is.null(this_object$`lang_id`)) {
        self$`lang_id` <- this_object$`lang_id`
      }
      if (!is.null(this_object$`tax_class_id`)) {
        self$`tax_class_id` <- this_object$`tax_class_id`
      }
      if (!is.null(this_object$`backorder_status`)) {
        self$`backorder_status` <- this_object$`backorder_status`
      }
      if (!is.null(this_object$`status`)) {
        self$`status` <- this_object$`status`
      }
      if (!is.null(this_object$`visible`)) {
        self$`visible` <- this_object$`visible`
      }
      if (!is.null(this_object$`is_virtual`)) {
        self$`is_virtual` <- this_object$`is_virtual`
      }
      if (!is.null(this_object$`downloadable`)) {
        self$`downloadable` <- this_object$`downloadable`
      }
      if (!is.null(this_object$`is_default`)) {
        self$`is_default` <- this_object$`is_default`
      }
      if (!is.null(this_object$`upc`)) {
        self$`upc` <- this_object$`upc`
      }
      if (!is.null(this_object$`isbn`)) {
        self$`isbn` <- this_object$`isbn`
      }
      if (!is.null(this_object$`mpn`)) {
        self$`mpn` <- this_object$`mpn`
      }
      if (!is.null(this_object$`ean`)) {
        self$`ean` <- this_object$`ean`
      }
      if (!is.null(this_object$`barcode`)) {
        self$`barcode` <- this_object$`barcode`
      }
      if (!is.null(this_object$`available_for_sale`)) {
        self$`available_for_sale` <- this_object$`available_for_sale`
      }
      if (!is.null(this_object$`is_free_shipping`)) {
        self$`is_free_shipping` <- this_object$`is_free_shipping`
      }
      if (!is.null(this_object$`taxable`)) {
        self$`taxable` <- this_object$`taxable`
      }
      if (!is.null(this_object$`seo_url`)) {
        self$`seo_url` <- this_object$`seo_url`
      }
      if (!is.null(this_object$`manufacturer_id`)) {
        self$`manufacturer_id` <- this_object$`manufacturer_id`
      }
      if (!is.null(this_object$`harmonized_system_code`)) {
        self$`harmonized_system_code` <- this_object$`harmonized_system_code`
      }
      if (!is.null(this_object$`marketplace_item_properties`)) {
        self$`marketplace_item_properties` <- this_object$`marketplace_item_properties`
      }
      if (!is.null(this_object$`images`)) {
        self$`images` <- ApiClient$new()$deserializeObj(this_object$`images`, "array[ProductAddBatchPayloadInnerImagesInner]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`product_images_ids`)) {
        self$`product_images_ids` <- ApiClient$new()$deserializeObj(this_object$`product_images_ids`, "array[character]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`related_products_ids`)) {
        self$`related_products_ids` <- ApiClient$new()$deserializeObj(this_object$`related_products_ids`, "array[character]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`up_sell_products_ids`)) {
        self$`up_sell_products_ids` <- ApiClient$new()$deserializeObj(this_object$`up_sell_products_ids`, "array[character]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`cross_sell_products_ids`)) {
        self$`cross_sell_products_ids` <- ApiClient$new()$deserializeObj(this_object$`cross_sell_products_ids`, "array[character]", loadNamespace("openapi"))
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductVariantAddBatchPayloadInner in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductVariantAddBatchPayloadInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductVariantAddBatchPayloadInner
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`product_id` <- this_object$`product_id`
      self$`combination` <- ApiClient$new()$deserializeObj(this_object$`combination`, "array[ProductVariantAddBatchPayloadInnerCombinationInner]", loadNamespace("openapi"))
      self$`name` <- this_object$`name`
      self$`description` <- this_object$`description`
      self$`short_description` <- this_object$`short_description`
      self$`sku` <- this_object$`sku`
      self$`model` <- this_object$`model`
      self$`price` <- this_object$`price`
      self$`old_price` <- this_object$`old_price`
      self$`cost_price` <- this_object$`cost_price`
      self$`special_price` <- this_object$`special_price`
      self$`sprice_create` <- this_object$`sprice_create`
      self$`sprice_expire` <- this_object$`sprice_expire`
      self$`advanced_prices` <- ApiClient$new()$deserializeObj(this_object$`advanced_prices`, "array[ProductUpdateBatchPayloadInnerAdvancedPricesInner]", loadNamespace("openapi"))
      self$`meta_title` <- this_object$`meta_title`
      self$`meta_description` <- this_object$`meta_description`
      self$`meta_keywords` <- ApiClient$new()$deserializeObj(this_object$`meta_keywords`, "array[character]", loadNamespace("openapi"))
      self$`categories_ids` <- ApiClient$new()$deserializeObj(this_object$`categories_ids`, "array[character]", loadNamespace("openapi"))
      self$`stores_ids` <- ApiClient$new()$deserializeObj(this_object$`stores_ids`, "array[character]", loadNamespace("openapi"))
      self$`weight` <- this_object$`weight`
      self$`width` <- this_object$`width`
      self$`height` <- this_object$`height`
      self$`length` <- this_object$`length`
      self$`weight_unit` <- this_object$`weight_unit`
      self$`warehouse_id` <- this_object$`warehouse_id`
      self$`quantity` <- this_object$`quantity`
      self$`manage_stock` <- this_object$`manage_stock`
      self$`in_stock` <- this_object$`in_stock`
      self$`store_id` <- this_object$`store_id`
      self$`lang_id` <- this_object$`lang_id`
      self$`tax_class_id` <- this_object$`tax_class_id`
      self$`backorder_status` <- this_object$`backorder_status`
      self$`status` <- this_object$`status`
      self$`visible` <- this_object$`visible`
      self$`is_virtual` <- this_object$`is_virtual`
      self$`downloadable` <- this_object$`downloadable`
      self$`is_default` <- this_object$`is_default`
      self$`upc` <- this_object$`upc`
      self$`isbn` <- this_object$`isbn`
      self$`mpn` <- this_object$`mpn`
      self$`ean` <- this_object$`ean`
      self$`barcode` <- this_object$`barcode`
      self$`available_for_sale` <- this_object$`available_for_sale`
      self$`is_free_shipping` <- this_object$`is_free_shipping`
      self$`taxable` <- this_object$`taxable`
      self$`seo_url` <- this_object$`seo_url`
      self$`manufacturer_id` <- this_object$`manufacturer_id`
      self$`harmonized_system_code` <- this_object$`harmonized_system_code`
      self$`marketplace_item_properties` <- this_object$`marketplace_item_properties`
      self$`images` <- ApiClient$new()$deserializeObj(this_object$`images`, "array[ProductAddBatchPayloadInnerImagesInner]", loadNamespace("openapi"))
      self$`product_images_ids` <- ApiClient$new()$deserializeObj(this_object$`product_images_ids`, "array[character]", loadNamespace("openapi"))
      self$`related_products_ids` <- ApiClient$new()$deserializeObj(this_object$`related_products_ids`, "array[character]", loadNamespace("openapi"))
      self$`up_sell_products_ids` <- ApiClient$new()$deserializeObj(this_object$`up_sell_products_ids`, "array[character]", loadNamespace("openapi"))
      self$`cross_sell_products_ids` <- ApiClient$new()$deserializeObj(this_object$`cross_sell_products_ids`, "array[character]", loadNamespace("openapi"))
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductVariantAddBatchPayloadInner and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
      # check the required field `product_id`
      if (!is.null(input_json$`product_id`)) {
        if (!(is.character(input_json$`product_id`) && length(input_json$`product_id`) == 1)) {
          stop(paste("Error! Invalid data for `product_id`. Must be a string:", input_json$`product_id`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for ProductVariantAddBatchPayloadInner: the required field `product_id` is missing."))
      }
      # check the required field `combination`
      if (!is.null(input_json$`combination`)) {
        stopifnot(is.vector(input_json$`combination`), length(input_json$`combination`) != 0)
        tmp <- sapply(input_json$`combination`, function(x) stopifnot(R6::is.R6(x)))
      } else {
        stop(paste("The JSON input `", input, "` is invalid for ProductVariantAddBatchPayloadInner: the required field `combination` is missing."))
      }
      # check the required field `sku`
      if (!is.null(input_json$`sku`)) {
        if (!(is.character(input_json$`sku`) && length(input_json$`sku`) == 1)) {
          stop(paste("Error! Invalid data for `sku`. Must be a string:", input_json$`sku`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for ProductVariantAddBatchPayloadInner: the required field `sku` is missing."))
      }
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductVariantAddBatchPayloadInner
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      # check if the required `product_id` is null
      if (is.null(self$`product_id`)) {
        return(FALSE)
      }

      # check if the required `combination` is null
      if (is.null(self$`combination`)) {
        return(FALSE)
      }

      if (length(self$`combination`) < 1) {
        return(FALSE)
      }

      # check if the required `sku` is null
      if (is.null(self$`sku`)) {
        return(FALSE)
      }

      if (length(self$`advanced_prices`) < 1) {
        return(FALSE)
      }

      if (length(self$`meta_keywords`) < 1) {
        return(FALSE)
      }

      if (length(self$`categories_ids`) < 1) {
        return(FALSE)
      }

      if (length(self$`stores_ids`) < 1) {
        return(FALSE)
      }

      if (length(self$`images`) > 1) {
        return(FALSE)
      }

      if (length(self$`product_images_ids`) < 1) {
        return(FALSE)
      }

      if (length(self$`related_products_ids`) < 1) {
        return(FALSE)
      }

      if (length(self$`up_sell_products_ids`) < 1) {
        return(FALSE)
      }

      if (length(self$`cross_sell_products_ids`) < 1) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      # check if the required `product_id` is null
      if (is.null(self$`product_id`)) {
        invalid_fields["product_id"] <- "Non-nullable required field `product_id` cannot be null."
      }

      # check if the required `combination` is null
      if (is.null(self$`combination`)) {
        invalid_fields["combination"] <- "Non-nullable required field `combination` cannot be null."
      }

      if (length(self$`combination`) < 1) {
        invalid_fields["combination"] <- "Invalid length for ``, number of items must be greater than or equal to 1."
      }

      # check if the required `sku` is null
      if (is.null(self$`sku`)) {
        invalid_fields["sku"] <- "Non-nullable required field `sku` cannot be null."
      }

      if (length(self$`advanced_prices`) < 1) {
        invalid_fields["advanced_prices"] <- "Invalid length for ``, number of items must be greater than or equal to 1."
      }

      if (length(self$`meta_keywords`) < 1) {
        invalid_fields["meta_keywords"] <- "Invalid length for ``, number of items must be greater than or equal to 1."
      }

      if (length(self$`categories_ids`) < 1) {
        invalid_fields["categories_ids"] <- "Invalid length for ``, number of items must be greater than or equal to 1."
      }

      if (length(self$`stores_ids`) < 1) {
        invalid_fields["stores_ids"] <- "Invalid length for ``, number of items must be greater than or equal to 1."
      }

      if (length(self$`images`) > 1) {
        invalid_fields["images"] <- "Invalid length for `images`, number of items must be less than or equal to 1."
      }

      if (length(self$`product_images_ids`) < 1) {
        invalid_fields["product_images_ids"] <- "Invalid length for ``, number of items must be greater than or equal to 1."
      }

      if (length(self$`related_products_ids`) < 1) {
        invalid_fields["related_products_ids"] <- "Invalid length for ``, number of items must be greater than or equal to 1."
      }

      if (length(self$`up_sell_products_ids`) < 1) {
        invalid_fields["up_sell_products_ids"] <- "Invalid length for ``, number of items must be greater than or equal to 1."
      }

      if (length(self$`cross_sell_products_ids`) < 1) {
        invalid_fields["cross_sell_products_ids"] <- "Invalid length for ``, number of items must be greater than or equal to 1."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductVariantAddBatchPayloadInner$unlock()
#
## Below is an example to define the print function
# ProductVariantAddBatchPayloadInner$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductVariantAddBatchPayloadInner$lock()

