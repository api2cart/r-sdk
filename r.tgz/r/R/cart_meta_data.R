#' Create a new CartMetaData
#'
#' @description
#' CartMetaData Class
#'
#' @docType class
#' @title CartMetaData
#' @description CartMetaData Class
#' @format An \code{R6Class} generator object
#' @field id  character [optional]
#' @field key  character [optional]
#' @field value  character [optional]
#' @field namespace  character [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
CartMetaData <- R6::R6Class(
  "CartMetaData",
  public = list(
    `id` = NULL,
    `key` = NULL,
    `value` = NULL,
    `namespace` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new CartMetaData class.
    #'
    #' @param id id
    #' @param key key
    #' @param value value
    #' @param namespace namespace
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `key` = NULL, `value` = NULL, `namespace` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`key`)) {
        if (!(is.character(`key`) && length(`key`) == 1)) {
          stop(paste("Error! Invalid data for `key`. Must be a string:", `key`))
        }
        self$`key` <- `key`
      }
      if (!is.null(`value`)) {
        if (!(is.character(`value`) && length(`value`) == 1)) {
          stop(paste("Error! Invalid data for `value`. Must be a string:", `value`))
        }
        self$`value` <- `value`
      }
      if (!is.null(`namespace`)) {
        if (!(is.character(`namespace`) && length(`namespace`) == 1)) {
          stop(paste("Error! Invalid data for `namespace`. Must be a string:", `namespace`))
        }
        self$`namespace` <- `namespace`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return CartMetaData as a base R list.
    #' @examples
    #' # convert array of CartMetaData (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert CartMetaData to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      CartMetaDataObject <- list()
      if (!is.null(self$`id`)) {
        CartMetaDataObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`key`)) {
        CartMetaDataObject[["key"]] <-
          self$`key`
      }
      if (!is.null(self$`value`)) {
        CartMetaDataObject[["value"]] <-
          self$`value`
      }
      if (!is.null(self$`namespace`)) {
        CartMetaDataObject[["namespace"]] <-
          self$`namespace`
      }
      if (!is.null(self$`additional_fields`)) {
        CartMetaDataObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        CartMetaDataObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(CartMetaDataObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of CartMetaData
    #'
    #' @param input_json the JSON input
    #' @return the instance of CartMetaData
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`key`)) {
        self$`key` <- this_object$`key`
      }
      if (!is.null(this_object$`value`)) {
        self$`value` <- this_object$`value`
      }
      if (!is.null(this_object$`namespace`)) {
        self$`namespace` <- this_object$`namespace`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return CartMetaData in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of CartMetaData
    #'
    #' @param input_json the JSON input
    #' @return the instance of CartMetaData
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`key` <- this_object$`key`
      self$`value` <- this_object$`value`
      self$`namespace` <- this_object$`namespace`
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to CartMetaData and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of CartMetaData
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# CartMetaData$unlock()
#
## Below is an example to define the print function
# CartMetaData$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# CartMetaData$lock()

