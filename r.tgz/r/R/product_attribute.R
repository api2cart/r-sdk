#' Create a new ProductAttribute
#'
#' @description
#' ProductAttribute Class
#'
#' @docType class
#' @title ProductAttribute
#' @description ProductAttribute Class
#' @format An \code{R6Class} generator object
#' @field attribute_id  character [optional]
#' @field code  character [optional]
#' @field name  character [optional]
#' @field lang_id  character [optional]
#' @field store_id  character [optional]
#' @field value  character [optional]
#' @field required  character [optional]
#' @field visible  character [optional]
#' @field type  character [optional]
#' @field position  integer [optional]
#' @field attribute_group_id  character [optional]
#' @field product_id  character [optional]
#' @field variant_id  character [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductAttribute <- R6::R6Class(
  "ProductAttribute",
  public = list(
    `attribute_id` = NULL,
    `code` = NULL,
    `name` = NULL,
    `lang_id` = NULL,
    `store_id` = NULL,
    `value` = NULL,
    `required` = NULL,
    `visible` = NULL,
    `type` = NULL,
    `position` = NULL,
    `attribute_group_id` = NULL,
    `product_id` = NULL,
    `variant_id` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new ProductAttribute class.
    #'
    #' @param attribute_id attribute_id
    #' @param code code
    #' @param name name
    #' @param lang_id lang_id
    #' @param store_id store_id
    #' @param value value
    #' @param required required
    #' @param visible visible
    #' @param type type
    #' @param position position
    #' @param attribute_group_id attribute_group_id
    #' @param product_id product_id
    #' @param variant_id variant_id
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`attribute_id` = NULL, `code` = NULL, `name` = NULL, `lang_id` = NULL, `store_id` = NULL, `value` = NULL, `required` = NULL, `visible` = NULL, `type` = NULL, `position` = NULL, `attribute_group_id` = NULL, `product_id` = NULL, `variant_id` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`attribute_id`)) {
        if (!(is.character(`attribute_id`) && length(`attribute_id`) == 1)) {
          stop(paste("Error! Invalid data for `attribute_id`. Must be a string:", `attribute_id`))
        }
        self$`attribute_id` <- `attribute_id`
      }
      if (!is.null(`code`)) {
        if (!(is.character(`code`) && length(`code`) == 1)) {
          stop(paste("Error! Invalid data for `code`. Must be a string:", `code`))
        }
        self$`code` <- `code`
      }
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`lang_id`)) {
        if (!(is.character(`lang_id`) && length(`lang_id`) == 1)) {
          stop(paste("Error! Invalid data for `lang_id`. Must be a string:", `lang_id`))
        }
        self$`lang_id` <- `lang_id`
      }
      if (!is.null(`store_id`)) {
        if (!(is.character(`store_id`) && length(`store_id`) == 1)) {
          stop(paste("Error! Invalid data for `store_id`. Must be a string:", `store_id`))
        }
        self$`store_id` <- `store_id`
      }
      if (!is.null(`value`)) {
        if (!(is.character(`value`) && length(`value`) == 1)) {
          stop(paste("Error! Invalid data for `value`. Must be a string:", `value`))
        }
        self$`value` <- `value`
      }
      if (!is.null(`required`)) {
        if (!(is.logical(`required`) && length(`required`) == 1)) {
          stop(paste("Error! Invalid data for `required`. Must be a boolean:", `required`))
        }
        self$`required` <- `required`
      }
      if (!is.null(`visible`)) {
        if (!(is.logical(`visible`) && length(`visible`) == 1)) {
          stop(paste("Error! Invalid data for `visible`. Must be a boolean:", `visible`))
        }
        self$`visible` <- `visible`
      }
      if (!is.null(`type`)) {
        if (!(is.character(`type`) && length(`type`) == 1)) {
          stop(paste("Error! Invalid data for `type`. Must be a string:", `type`))
        }
        self$`type` <- `type`
      }
      if (!is.null(`position`)) {
        if (!(is.numeric(`position`) && length(`position`) == 1)) {
          stop(paste("Error! Invalid data for `position`. Must be an integer:", `position`))
        }
        self$`position` <- `position`
      }
      if (!is.null(`attribute_group_id`)) {
        if (!(is.character(`attribute_group_id`) && length(`attribute_group_id`) == 1)) {
          stop(paste("Error! Invalid data for `attribute_group_id`. Must be a string:", `attribute_group_id`))
        }
        self$`attribute_group_id` <- `attribute_group_id`
      }
      if (!is.null(`product_id`)) {
        if (!(is.character(`product_id`) && length(`product_id`) == 1)) {
          stop(paste("Error! Invalid data for `product_id`. Must be a string:", `product_id`))
        }
        self$`product_id` <- `product_id`
      }
      if (!is.null(`variant_id`)) {
        if (!(is.character(`variant_id`) && length(`variant_id`) == 1)) {
          stop(paste("Error! Invalid data for `variant_id`. Must be a string:", `variant_id`))
        }
        self$`variant_id` <- `variant_id`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductAttribute as a base R list.
    #' @examples
    #' # convert array of ProductAttribute (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductAttribute to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductAttributeObject <- list()
      if (!is.null(self$`attribute_id`)) {
        ProductAttributeObject[["attribute_id"]] <-
          self$`attribute_id`
      }
      if (!is.null(self$`code`)) {
        ProductAttributeObject[["code"]] <-
          self$`code`
      }
      if (!is.null(self$`name`)) {
        ProductAttributeObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`lang_id`)) {
        ProductAttributeObject[["lang_id"]] <-
          self$`lang_id`
      }
      if (!is.null(self$`store_id`)) {
        ProductAttributeObject[["store_id"]] <-
          self$`store_id`
      }
      if (!is.null(self$`value`)) {
        ProductAttributeObject[["value"]] <-
          self$`value`
      }
      if (!is.null(self$`required`)) {
        ProductAttributeObject[["required"]] <-
          self$`required`
      }
      if (!is.null(self$`visible`)) {
        ProductAttributeObject[["visible"]] <-
          self$`visible`
      }
      if (!is.null(self$`type`)) {
        ProductAttributeObject[["type"]] <-
          self$`type`
      }
      if (!is.null(self$`position`)) {
        ProductAttributeObject[["position"]] <-
          self$`position`
      }
      if (!is.null(self$`attribute_group_id`)) {
        ProductAttributeObject[["attribute_group_id"]] <-
          self$`attribute_group_id`
      }
      if (!is.null(self$`product_id`)) {
        ProductAttributeObject[["product_id"]] <-
          self$`product_id`
      }
      if (!is.null(self$`variant_id`)) {
        ProductAttributeObject[["variant_id"]] <-
          self$`variant_id`
      }
      if (!is.null(self$`additional_fields`)) {
        ProductAttributeObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        ProductAttributeObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(ProductAttributeObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductAttribute
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductAttribute
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`attribute_id`)) {
        self$`attribute_id` <- this_object$`attribute_id`
      }
      if (!is.null(this_object$`code`)) {
        self$`code` <- this_object$`code`
      }
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`lang_id`)) {
        self$`lang_id` <- this_object$`lang_id`
      }
      if (!is.null(this_object$`store_id`)) {
        self$`store_id` <- this_object$`store_id`
      }
      if (!is.null(this_object$`value`)) {
        self$`value` <- this_object$`value`
      }
      if (!is.null(this_object$`required`)) {
        self$`required` <- this_object$`required`
      }
      if (!is.null(this_object$`visible`)) {
        self$`visible` <- this_object$`visible`
      }
      if (!is.null(this_object$`type`)) {
        self$`type` <- this_object$`type`
      }
      if (!is.null(this_object$`position`)) {
        self$`position` <- this_object$`position`
      }
      if (!is.null(this_object$`attribute_group_id`)) {
        self$`attribute_group_id` <- this_object$`attribute_group_id`
      }
      if (!is.null(this_object$`product_id`)) {
        self$`product_id` <- this_object$`product_id`
      }
      if (!is.null(this_object$`variant_id`)) {
        self$`variant_id` <- this_object$`variant_id`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductAttribute in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductAttribute
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductAttribute
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`attribute_id` <- this_object$`attribute_id`
      self$`code` <- this_object$`code`
      self$`name` <- this_object$`name`
      self$`lang_id` <- this_object$`lang_id`
      self$`store_id` <- this_object$`store_id`
      self$`value` <- this_object$`value`
      self$`required` <- this_object$`required`
      self$`visible` <- this_object$`visible`
      self$`type` <- this_object$`type`
      self$`position` <- this_object$`position`
      self$`attribute_group_id` <- this_object$`attribute_group_id`
      self$`product_id` <- this_object$`product_id`
      self$`variant_id` <- this_object$`variant_id`
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductAttribute and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductAttribute
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductAttribute$unlock()
#
## Below is an example to define the print function
# ProductAttribute$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductAttribute$lock()

