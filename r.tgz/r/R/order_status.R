#' Create a new OrderStatus
#'
#' @description
#' OrderStatus Class
#'
#' @docType class
#' @title OrderStatus
#' @description OrderStatus Class
#' @format An \code{R6Class} generator object
#' @field id  character [optional]
#' @field name  character [optional]
#' @field history  list(\link{OrderStatusHistoryItem}) [optional]
#' @field refund_info  \link{OrderStatusRefund} [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
OrderStatus <- R6::R6Class(
  "OrderStatus",
  public = list(
    `id` = NULL,
    `name` = NULL,
    `history` = NULL,
    `refund_info` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new OrderStatus class.
    #'
    #' @param id id
    #' @param name name
    #' @param history history
    #' @param refund_info refund_info
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `name` = NULL, `history` = NULL, `refund_info` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`history`)) {
        stopifnot(is.vector(`history`), length(`history`) != 0)
        sapply(`history`, function(x) stopifnot(R6::is.R6(x)))
        self$`history` <- `history`
      }
      if (!is.null(`refund_info`)) {
        stopifnot(R6::is.R6(`refund_info`))
        self$`refund_info` <- `refund_info`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return OrderStatus as a base R list.
    #' @examples
    #' # convert array of OrderStatus (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert OrderStatus to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      OrderStatusObject <- list()
      if (!is.null(self$`id`)) {
        OrderStatusObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`name`)) {
        OrderStatusObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`history`)) {
        OrderStatusObject[["history"]] <-
          lapply(self$`history`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`refund_info`)) {
        OrderStatusObject[["refund_info"]] <-
          self$`refund_info`$toSimpleType()
      }
      if (!is.null(self$`additional_fields`)) {
        OrderStatusObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        OrderStatusObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(OrderStatusObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderStatus
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderStatus
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`history`)) {
        self$`history` <- ApiClient$new()$deserializeObj(this_object$`history`, "array[OrderStatusHistoryItem]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`refund_info`)) {
        `refund_info_object` <- OrderStatusRefund$new()
        `refund_info_object`$fromJSON(jsonlite::toJSON(this_object$`refund_info`, auto_unbox = TRUE, digits = NA))
        self$`refund_info` <- `refund_info_object`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return OrderStatus in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderStatus
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderStatus
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`name` <- this_object$`name`
      self$`history` <- ApiClient$new()$deserializeObj(this_object$`history`, "array[OrderStatusHistoryItem]", loadNamespace("openapi"))
      self$`refund_info` <- OrderStatusRefund$new()$fromJSON(jsonlite::toJSON(this_object$`refund_info`, auto_unbox = TRUE, digits = NA))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to OrderStatus and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of OrderStatus
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# OrderStatus$unlock()
#
## Below is an example to define the print function
# OrderStatus$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# OrderStatus$lock()

