#' Create a new BatchJob
#'
#' @description
#' BatchJob Class
#'
#' @docType class
#' @title BatchJob
#' @description BatchJob Class
#' @format An \code{R6Class} generator object
#' @field id  character [optional]
#' @field method  character [optional]
#' @field status  character [optional]
#' @field created_time  \link{A2CDateTime} [optional]
#' @field processed_time  \link{A2CDateTime} [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
BatchJob <- R6::R6Class(
  "BatchJob",
  public = list(
    `id` = NULL,
    `method` = NULL,
    `status` = NULL,
    `created_time` = NULL,
    `processed_time` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new BatchJob class.
    #'
    #' @param id id
    #' @param method method
    #' @param status status
    #' @param created_time created_time
    #' @param processed_time processed_time
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `method` = NULL, `status` = NULL, `created_time` = NULL, `processed_time` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`method`)) {
        if (!(is.character(`method`) && length(`method`) == 1)) {
          stop(paste("Error! Invalid data for `method`. Must be a string:", `method`))
        }
        self$`method` <- `method`
      }
      if (!is.null(`status`)) {
        if (!(is.character(`status`) && length(`status`) == 1)) {
          stop(paste("Error! Invalid data for `status`. Must be a string:", `status`))
        }
        self$`status` <- `status`
      }
      if (!is.null(`created_time`)) {
        stopifnot(R6::is.R6(`created_time`))
        self$`created_time` <- `created_time`
      }
      if (!is.null(`processed_time`)) {
        stopifnot(R6::is.R6(`processed_time`))
        self$`processed_time` <- `processed_time`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return BatchJob as a base R list.
    #' @examples
    #' # convert array of BatchJob (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert BatchJob to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      BatchJobObject <- list()
      if (!is.null(self$`id`)) {
        BatchJobObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`method`)) {
        BatchJobObject[["method"]] <-
          self$`method`
      }
      if (!is.null(self$`status`)) {
        BatchJobObject[["status"]] <-
          self$`status`
      }
      if (!is.null(self$`created_time`)) {
        BatchJobObject[["created_time"]] <-
          self$`created_time`$toSimpleType()
      }
      if (!is.null(self$`processed_time`)) {
        BatchJobObject[["processed_time"]] <-
          self$`processed_time`$toSimpleType()
      }
      if (!is.null(self$`additional_fields`)) {
        BatchJobObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        BatchJobObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(BatchJobObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of BatchJob
    #'
    #' @param input_json the JSON input
    #' @return the instance of BatchJob
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`method`)) {
        self$`method` <- this_object$`method`
      }
      if (!is.null(this_object$`status`)) {
        self$`status` <- this_object$`status`
      }
      if (!is.null(this_object$`created_time`)) {
        `created_time_object` <- A2CDateTime$new()
        `created_time_object`$fromJSON(jsonlite::toJSON(this_object$`created_time`, auto_unbox = TRUE, digits = NA))
        self$`created_time` <- `created_time_object`
      }
      if (!is.null(this_object$`processed_time`)) {
        `processed_time_object` <- A2CDateTime$new()
        `processed_time_object`$fromJSON(jsonlite::toJSON(this_object$`processed_time`, auto_unbox = TRUE, digits = NA))
        self$`processed_time` <- `processed_time_object`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return BatchJob in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of BatchJob
    #'
    #' @param input_json the JSON input
    #' @return the instance of BatchJob
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`method` <- this_object$`method`
      self$`status` <- this_object$`status`
      self$`created_time` <- A2CDateTime$new()$fromJSON(jsonlite::toJSON(this_object$`created_time`, auto_unbox = TRUE, digits = NA))
      self$`processed_time` <- A2CDateTime$new()$fromJSON(jsonlite::toJSON(this_object$`processed_time`, auto_unbox = TRUE, digits = NA))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to BatchJob and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of BatchJob
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# BatchJob$unlock()
#
## Below is an example to define the print function
# BatchJob$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# BatchJob$lock()

