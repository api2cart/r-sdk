#' Create a new CartGiftcardCount200ResponseResult
#'
#' @description
#' CartGiftcardCount200ResponseResult Class
#'
#' @docType class
#' @title CartGiftcardCount200ResponseResult
#' @description CartGiftcardCount200ResponseResult Class
#' @format An \code{R6Class} generator object
#' @field gift_cards_count  integer [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
CartGiftcardCount200ResponseResult <- R6::R6Class(
  "CartGiftcardCount200ResponseResult",
  public = list(
    `gift_cards_count` = NULL,

    #' @description
    #' Initialize a new CartGiftcardCount200ResponseResult class.
    #'
    #' @param gift_cards_count gift_cards_count
    #' @param ... Other optional arguments.
    initialize = function(`gift_cards_count` = NULL, ...) {
      if (!is.null(`gift_cards_count`)) {
        if (!(is.numeric(`gift_cards_count`) && length(`gift_cards_count`) == 1)) {
          stop(paste("Error! Invalid data for `gift_cards_count`. Must be an integer:", `gift_cards_count`))
        }
        self$`gift_cards_count` <- `gift_cards_count`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return CartGiftcardCount200ResponseResult as a base R list.
    #' @examples
    #' # convert array of CartGiftcardCount200ResponseResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert CartGiftcardCount200ResponseResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      CartGiftcardCount200ResponseResultObject <- list()
      if (!is.null(self$`gift_cards_count`)) {
        CartGiftcardCount200ResponseResultObject[["gift_cards_count"]] <-
          self$`gift_cards_count`
      }
      return(CartGiftcardCount200ResponseResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of CartGiftcardCount200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of CartGiftcardCount200ResponseResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`gift_cards_count`)) {
        self$`gift_cards_count` <- this_object$`gift_cards_count`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return CartGiftcardCount200ResponseResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of CartGiftcardCount200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of CartGiftcardCount200ResponseResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`gift_cards_count` <- this_object$`gift_cards_count`
      self
    },

    #' @description
    #' Validate JSON input with respect to CartGiftcardCount200ResponseResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of CartGiftcardCount200ResponseResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# CartGiftcardCount200ResponseResult$unlock()
#
## Below is an example to define the print function
# CartGiftcardCount200ResponseResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# CartGiftcardCount200ResponseResult$lock()

