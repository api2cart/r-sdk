#' Create a new MarketplaceProduct
#'
#' @description
#' MarketplaceProduct Class
#'
#' @docType class
#' @title MarketplaceProduct
#' @description MarketplaceProduct Class
#' @format An \code{R6Class} generator object
#' @field id  character [optional]
#' @field type  character [optional]
#' @field u_asin  character [optional]
#' @field u_ean  character [optional]
#' @field u_gtin  character [optional]
#' @field u_isbn  character [optional]
#' @field u_mpn  character [optional]
#' @field u_upc  character [optional]
#' @field name  character [optional]
#' @field description  character [optional]
#' @field url  character [optional]
#' @field price  numeric [optional]
#' @field images  list(\link{Image}) [optional]
#' @field product_options  list(\link{ProductOption}) [optional]
#' @field manufacturer  character [optional]
#' @field brand  character [optional]
#' @field weight  numeric [optional]
#' @field weight_unit  character [optional]
#' @field dimensions_unit  character [optional]
#' @field width  numeric [optional]
#' @field height  numeric [optional]
#' @field length  numeric [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
MarketplaceProduct <- R6::R6Class(
  "MarketplaceProduct",
  public = list(
    `id` = NULL,
    `type` = NULL,
    `u_asin` = NULL,
    `u_ean` = NULL,
    `u_gtin` = NULL,
    `u_isbn` = NULL,
    `u_mpn` = NULL,
    `u_upc` = NULL,
    `name` = NULL,
    `description` = NULL,
    `url` = NULL,
    `price` = NULL,
    `images` = NULL,
    `product_options` = NULL,
    `manufacturer` = NULL,
    `brand` = NULL,
    `weight` = NULL,
    `weight_unit` = NULL,
    `dimensions_unit` = NULL,
    `width` = NULL,
    `height` = NULL,
    `length` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new MarketplaceProduct class.
    #'
    #' @param id id
    #' @param type type
    #' @param u_asin u_asin
    #' @param u_ean u_ean
    #' @param u_gtin u_gtin
    #' @param u_isbn u_isbn
    #' @param u_mpn u_mpn
    #' @param u_upc u_upc
    #' @param name name
    #' @param description description
    #' @param url url
    #' @param price price
    #' @param images images
    #' @param product_options product_options
    #' @param manufacturer manufacturer
    #' @param brand brand
    #' @param weight weight
    #' @param weight_unit weight_unit
    #' @param dimensions_unit dimensions_unit
    #' @param width width
    #' @param height height
    #' @param length length
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `type` = NULL, `u_asin` = NULL, `u_ean` = NULL, `u_gtin` = NULL, `u_isbn` = NULL, `u_mpn` = NULL, `u_upc` = NULL, `name` = NULL, `description` = NULL, `url` = NULL, `price` = NULL, `images` = NULL, `product_options` = NULL, `manufacturer` = NULL, `brand` = NULL, `weight` = NULL, `weight_unit` = NULL, `dimensions_unit` = NULL, `width` = NULL, `height` = NULL, `length` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`type`)) {
        if (!(is.character(`type`) && length(`type`) == 1)) {
          stop(paste("Error! Invalid data for `type`. Must be a string:", `type`))
        }
        self$`type` <- `type`
      }
      if (!is.null(`u_asin`)) {
        if (!(is.character(`u_asin`) && length(`u_asin`) == 1)) {
          stop(paste("Error! Invalid data for `u_asin`. Must be a string:", `u_asin`))
        }
        self$`u_asin` <- `u_asin`
      }
      if (!is.null(`u_ean`)) {
        if (!(is.character(`u_ean`) && length(`u_ean`) == 1)) {
          stop(paste("Error! Invalid data for `u_ean`. Must be a string:", `u_ean`))
        }
        self$`u_ean` <- `u_ean`
      }
      if (!is.null(`u_gtin`)) {
        if (!(is.character(`u_gtin`) && length(`u_gtin`) == 1)) {
          stop(paste("Error! Invalid data for `u_gtin`. Must be a string:", `u_gtin`))
        }
        self$`u_gtin` <- `u_gtin`
      }
      if (!is.null(`u_isbn`)) {
        if (!(is.character(`u_isbn`) && length(`u_isbn`) == 1)) {
          stop(paste("Error! Invalid data for `u_isbn`. Must be a string:", `u_isbn`))
        }
        self$`u_isbn` <- `u_isbn`
      }
      if (!is.null(`u_mpn`)) {
        if (!(is.character(`u_mpn`) && length(`u_mpn`) == 1)) {
          stop(paste("Error! Invalid data for `u_mpn`. Must be a string:", `u_mpn`))
        }
        self$`u_mpn` <- `u_mpn`
      }
      if (!is.null(`u_upc`)) {
        if (!(is.character(`u_upc`) && length(`u_upc`) == 1)) {
          stop(paste("Error! Invalid data for `u_upc`. Must be a string:", `u_upc`))
        }
        self$`u_upc` <- `u_upc`
      }
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`description`)) {
        if (!(is.character(`description`) && length(`description`) == 1)) {
          stop(paste("Error! Invalid data for `description`. Must be a string:", `description`))
        }
        self$`description` <- `description`
      }
      if (!is.null(`url`)) {
        if (!(is.character(`url`) && length(`url`) == 1)) {
          stop(paste("Error! Invalid data for `url`. Must be a string:", `url`))
        }
        self$`url` <- `url`
      }
      if (!is.null(`price`)) {
        self$`price` <- `price`
      }
      if (!is.null(`images`)) {
        stopifnot(is.vector(`images`), length(`images`) != 0)
        sapply(`images`, function(x) stopifnot(R6::is.R6(x)))
        self$`images` <- `images`
      }
      if (!is.null(`product_options`)) {
        stopifnot(is.vector(`product_options`), length(`product_options`) != 0)
        sapply(`product_options`, function(x) stopifnot(R6::is.R6(x)))
        self$`product_options` <- `product_options`
      }
      if (!is.null(`manufacturer`)) {
        if (!(is.character(`manufacturer`) && length(`manufacturer`) == 1)) {
          stop(paste("Error! Invalid data for `manufacturer`. Must be a string:", `manufacturer`))
        }
        self$`manufacturer` <- `manufacturer`
      }
      if (!is.null(`brand`)) {
        if (!(is.character(`brand`) && length(`brand`) == 1)) {
          stop(paste("Error! Invalid data for `brand`. Must be a string:", `brand`))
        }
        self$`brand` <- `brand`
      }
      if (!is.null(`weight`)) {
        self$`weight` <- `weight`
      }
      if (!is.null(`weight_unit`)) {
        if (!(is.character(`weight_unit`) && length(`weight_unit`) == 1)) {
          stop(paste("Error! Invalid data for `weight_unit`. Must be a string:", `weight_unit`))
        }
        self$`weight_unit` <- `weight_unit`
      }
      if (!is.null(`dimensions_unit`)) {
        if (!(is.character(`dimensions_unit`) && length(`dimensions_unit`) == 1)) {
          stop(paste("Error! Invalid data for `dimensions_unit`. Must be a string:", `dimensions_unit`))
        }
        self$`dimensions_unit` <- `dimensions_unit`
      }
      if (!is.null(`width`)) {
        self$`width` <- `width`
      }
      if (!is.null(`height`)) {
        self$`height` <- `height`
      }
      if (!is.null(`length`)) {
        self$`length` <- `length`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return MarketplaceProduct as a base R list.
    #' @examples
    #' # convert array of MarketplaceProduct (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert MarketplaceProduct to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      MarketplaceProductObject <- list()
      if (!is.null(self$`id`)) {
        MarketplaceProductObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`type`)) {
        MarketplaceProductObject[["type"]] <-
          self$`type`
      }
      if (!is.null(self$`u_asin`)) {
        MarketplaceProductObject[["u_asin"]] <-
          self$`u_asin`
      }
      if (!is.null(self$`u_ean`)) {
        MarketplaceProductObject[["u_ean"]] <-
          self$`u_ean`
      }
      if (!is.null(self$`u_gtin`)) {
        MarketplaceProductObject[["u_gtin"]] <-
          self$`u_gtin`
      }
      if (!is.null(self$`u_isbn`)) {
        MarketplaceProductObject[["u_isbn"]] <-
          self$`u_isbn`
      }
      if (!is.null(self$`u_mpn`)) {
        MarketplaceProductObject[["u_mpn"]] <-
          self$`u_mpn`
      }
      if (!is.null(self$`u_upc`)) {
        MarketplaceProductObject[["u_upc"]] <-
          self$`u_upc`
      }
      if (!is.null(self$`name`)) {
        MarketplaceProductObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`description`)) {
        MarketplaceProductObject[["description"]] <-
          self$`description`
      }
      if (!is.null(self$`url`)) {
        MarketplaceProductObject[["url"]] <-
          self$`url`
      }
      if (!is.null(self$`price`)) {
        MarketplaceProductObject[["price"]] <-
          self$`price`
      }
      if (!is.null(self$`images`)) {
        MarketplaceProductObject[["images"]] <-
          lapply(self$`images`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`product_options`)) {
        MarketplaceProductObject[["product_options"]] <-
          lapply(self$`product_options`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`manufacturer`)) {
        MarketplaceProductObject[["manufacturer"]] <-
          self$`manufacturer`
      }
      if (!is.null(self$`brand`)) {
        MarketplaceProductObject[["brand"]] <-
          self$`brand`
      }
      if (!is.null(self$`weight`)) {
        MarketplaceProductObject[["weight"]] <-
          self$`weight`
      }
      if (!is.null(self$`weight_unit`)) {
        MarketplaceProductObject[["weight_unit"]] <-
          self$`weight_unit`
      }
      if (!is.null(self$`dimensions_unit`)) {
        MarketplaceProductObject[["dimensions_unit"]] <-
          self$`dimensions_unit`
      }
      if (!is.null(self$`width`)) {
        MarketplaceProductObject[["width"]] <-
          self$`width`
      }
      if (!is.null(self$`height`)) {
        MarketplaceProductObject[["height"]] <-
          self$`height`
      }
      if (!is.null(self$`length`)) {
        MarketplaceProductObject[["length"]] <-
          self$`length`
      }
      if (!is.null(self$`additional_fields`)) {
        MarketplaceProductObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        MarketplaceProductObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(MarketplaceProductObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of MarketplaceProduct
    #'
    #' @param input_json the JSON input
    #' @return the instance of MarketplaceProduct
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`type`)) {
        self$`type` <- this_object$`type`
      }
      if (!is.null(this_object$`u_asin`)) {
        self$`u_asin` <- this_object$`u_asin`
      }
      if (!is.null(this_object$`u_ean`)) {
        self$`u_ean` <- this_object$`u_ean`
      }
      if (!is.null(this_object$`u_gtin`)) {
        self$`u_gtin` <- this_object$`u_gtin`
      }
      if (!is.null(this_object$`u_isbn`)) {
        self$`u_isbn` <- this_object$`u_isbn`
      }
      if (!is.null(this_object$`u_mpn`)) {
        self$`u_mpn` <- this_object$`u_mpn`
      }
      if (!is.null(this_object$`u_upc`)) {
        self$`u_upc` <- this_object$`u_upc`
      }
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`description`)) {
        self$`description` <- this_object$`description`
      }
      if (!is.null(this_object$`url`)) {
        self$`url` <- this_object$`url`
      }
      if (!is.null(this_object$`price`)) {
        self$`price` <- this_object$`price`
      }
      if (!is.null(this_object$`images`)) {
        self$`images` <- ApiClient$new()$deserializeObj(this_object$`images`, "array[Image]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`product_options`)) {
        self$`product_options` <- ApiClient$new()$deserializeObj(this_object$`product_options`, "array[ProductOption]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`manufacturer`)) {
        self$`manufacturer` <- this_object$`manufacturer`
      }
      if (!is.null(this_object$`brand`)) {
        self$`brand` <- this_object$`brand`
      }
      if (!is.null(this_object$`weight`)) {
        self$`weight` <- this_object$`weight`
      }
      if (!is.null(this_object$`weight_unit`)) {
        self$`weight_unit` <- this_object$`weight_unit`
      }
      if (!is.null(this_object$`dimensions_unit`)) {
        self$`dimensions_unit` <- this_object$`dimensions_unit`
      }
      if (!is.null(this_object$`width`)) {
        self$`width` <- this_object$`width`
      }
      if (!is.null(this_object$`height`)) {
        self$`height` <- this_object$`height`
      }
      if (!is.null(this_object$`length`)) {
        self$`length` <- this_object$`length`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return MarketplaceProduct in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of MarketplaceProduct
    #'
    #' @param input_json the JSON input
    #' @return the instance of MarketplaceProduct
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`type` <- this_object$`type`
      self$`u_asin` <- this_object$`u_asin`
      self$`u_ean` <- this_object$`u_ean`
      self$`u_gtin` <- this_object$`u_gtin`
      self$`u_isbn` <- this_object$`u_isbn`
      self$`u_mpn` <- this_object$`u_mpn`
      self$`u_upc` <- this_object$`u_upc`
      self$`name` <- this_object$`name`
      self$`description` <- this_object$`description`
      self$`url` <- this_object$`url`
      self$`price` <- this_object$`price`
      self$`images` <- ApiClient$new()$deserializeObj(this_object$`images`, "array[Image]", loadNamespace("openapi"))
      self$`product_options` <- ApiClient$new()$deserializeObj(this_object$`product_options`, "array[ProductOption]", loadNamespace("openapi"))
      self$`manufacturer` <- this_object$`manufacturer`
      self$`brand` <- this_object$`brand`
      self$`weight` <- this_object$`weight`
      self$`weight_unit` <- this_object$`weight_unit`
      self$`dimensions_unit` <- this_object$`dimensions_unit`
      self$`width` <- this_object$`width`
      self$`height` <- this_object$`height`
      self$`length` <- this_object$`length`
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to MarketplaceProduct and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of MarketplaceProduct
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# MarketplaceProduct$unlock()
#
## Below is an example to define the print function
# MarketplaceProduct$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# MarketplaceProduct$lock()

