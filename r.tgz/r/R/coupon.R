#' Create a new Coupon
#'
#' @description
#' Coupon Class
#'
#' @docType class
#' @title Coupon
#' @description Coupon Class
#' @format An \code{R6Class} generator object
#' @field id  character [optional]
#' @field code  character [optional]
#' @field codes  list(\link{CouponCode}) [optional]
#' @field name  character [optional]
#' @field description  character [optional]
#' @field actions  list(\link{CouponAction}) [optional]
#' @field date_start  \link{A2CDateTime} [optional]
#' @field date_end  \link{A2CDateTime} [optional]
#' @field avail  character [optional]
#' @field priority  integer [optional]
#' @field used_times  integer [optional]
#' @field usage_limit  integer [optional]
#' @field usage_limit_per_customer  integer [optional]
#' @field logic_operator  character [optional]
#' @field conditions  list(\link{CouponCondition}) [optional]
#' @field usage_history  list(\link{CouponHistory}) [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
Coupon <- R6::R6Class(
  "Coupon",
  public = list(
    `id` = NULL,
    `code` = NULL,
    `codes` = NULL,
    `name` = NULL,
    `description` = NULL,
    `actions` = NULL,
    `date_start` = NULL,
    `date_end` = NULL,
    `avail` = NULL,
    `priority` = NULL,
    `used_times` = NULL,
    `usage_limit` = NULL,
    `usage_limit_per_customer` = NULL,
    `logic_operator` = NULL,
    `conditions` = NULL,
    `usage_history` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new Coupon class.
    #'
    #' @param id id
    #' @param code code
    #' @param codes codes
    #' @param name name
    #' @param description description
    #' @param actions actions
    #' @param date_start date_start
    #' @param date_end date_end
    #' @param avail avail
    #' @param priority priority
    #' @param used_times used_times
    #' @param usage_limit usage_limit
    #' @param usage_limit_per_customer usage_limit_per_customer
    #' @param logic_operator logic_operator
    #' @param conditions conditions
    #' @param usage_history usage_history
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `code` = NULL, `codes` = NULL, `name` = NULL, `description` = NULL, `actions` = NULL, `date_start` = NULL, `date_end` = NULL, `avail` = NULL, `priority` = NULL, `used_times` = NULL, `usage_limit` = NULL, `usage_limit_per_customer` = NULL, `logic_operator` = NULL, `conditions` = NULL, `usage_history` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`code`)) {
        if (!(is.character(`code`) && length(`code`) == 1)) {
          stop(paste("Error! Invalid data for `code`. Must be a string:", `code`))
        }
        self$`code` <- `code`
      }
      if (!is.null(`codes`)) {
        stopifnot(is.vector(`codes`), length(`codes`) != 0)
        sapply(`codes`, function(x) stopifnot(R6::is.R6(x)))
        self$`codes` <- `codes`
      }
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`description`)) {
        if (!(is.character(`description`) && length(`description`) == 1)) {
          stop(paste("Error! Invalid data for `description`. Must be a string:", `description`))
        }
        self$`description` <- `description`
      }
      if (!is.null(`actions`)) {
        stopifnot(is.vector(`actions`), length(`actions`) != 0)
        sapply(`actions`, function(x) stopifnot(R6::is.R6(x)))
        self$`actions` <- `actions`
      }
      if (!is.null(`date_start`)) {
        stopifnot(R6::is.R6(`date_start`))
        self$`date_start` <- `date_start`
      }
      if (!is.null(`date_end`)) {
        stopifnot(R6::is.R6(`date_end`))
        self$`date_end` <- `date_end`
      }
      if (!is.null(`avail`)) {
        if (!(is.logical(`avail`) && length(`avail`) == 1)) {
          stop(paste("Error! Invalid data for `avail`. Must be a boolean:", `avail`))
        }
        self$`avail` <- `avail`
      }
      if (!is.null(`priority`)) {
        if (!(is.numeric(`priority`) && length(`priority`) == 1)) {
          stop(paste("Error! Invalid data for `priority`. Must be an integer:", `priority`))
        }
        self$`priority` <- `priority`
      }
      if (!is.null(`used_times`)) {
        if (!(is.numeric(`used_times`) && length(`used_times`) == 1)) {
          stop(paste("Error! Invalid data for `used_times`. Must be an integer:", `used_times`))
        }
        self$`used_times` <- `used_times`
      }
      if (!is.null(`usage_limit`)) {
        if (!(is.numeric(`usage_limit`) && length(`usage_limit`) == 1)) {
          stop(paste("Error! Invalid data for `usage_limit`. Must be an integer:", `usage_limit`))
        }
        self$`usage_limit` <- `usage_limit`
      }
      if (!is.null(`usage_limit_per_customer`)) {
        if (!(is.numeric(`usage_limit_per_customer`) && length(`usage_limit_per_customer`) == 1)) {
          stop(paste("Error! Invalid data for `usage_limit_per_customer`. Must be an integer:", `usage_limit_per_customer`))
        }
        self$`usage_limit_per_customer` <- `usage_limit_per_customer`
      }
      if (!is.null(`logic_operator`)) {
        if (!(is.character(`logic_operator`) && length(`logic_operator`) == 1)) {
          stop(paste("Error! Invalid data for `logic_operator`. Must be a string:", `logic_operator`))
        }
        self$`logic_operator` <- `logic_operator`
      }
      if (!is.null(`conditions`)) {
        stopifnot(is.vector(`conditions`), length(`conditions`) != 0)
        sapply(`conditions`, function(x) stopifnot(R6::is.R6(x)))
        self$`conditions` <- `conditions`
      }
      if (!is.null(`usage_history`)) {
        stopifnot(is.vector(`usage_history`), length(`usage_history`) != 0)
        sapply(`usage_history`, function(x) stopifnot(R6::is.R6(x)))
        self$`usage_history` <- `usage_history`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return Coupon as a base R list.
    #' @examples
    #' # convert array of Coupon (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert Coupon to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      CouponObject <- list()
      if (!is.null(self$`id`)) {
        CouponObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`code`)) {
        CouponObject[["code"]] <-
          self$`code`
      }
      if (!is.null(self$`codes`)) {
        CouponObject[["codes"]] <-
          lapply(self$`codes`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`name`)) {
        CouponObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`description`)) {
        CouponObject[["description"]] <-
          self$`description`
      }
      if (!is.null(self$`actions`)) {
        CouponObject[["actions"]] <-
          lapply(self$`actions`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`date_start`)) {
        CouponObject[["date_start"]] <-
          self$`date_start`$toSimpleType()
      }
      if (!is.null(self$`date_end`)) {
        CouponObject[["date_end"]] <-
          self$`date_end`$toSimpleType()
      }
      if (!is.null(self$`avail`)) {
        CouponObject[["avail"]] <-
          self$`avail`
      }
      if (!is.null(self$`priority`)) {
        CouponObject[["priority"]] <-
          self$`priority`
      }
      if (!is.null(self$`used_times`)) {
        CouponObject[["used_times"]] <-
          self$`used_times`
      }
      if (!is.null(self$`usage_limit`)) {
        CouponObject[["usage_limit"]] <-
          self$`usage_limit`
      }
      if (!is.null(self$`usage_limit_per_customer`)) {
        CouponObject[["usage_limit_per_customer"]] <-
          self$`usage_limit_per_customer`
      }
      if (!is.null(self$`logic_operator`)) {
        CouponObject[["logic_operator"]] <-
          self$`logic_operator`
      }
      if (!is.null(self$`conditions`)) {
        CouponObject[["conditions"]] <-
          lapply(self$`conditions`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`usage_history`)) {
        CouponObject[["usage_history"]] <-
          lapply(self$`usage_history`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`additional_fields`)) {
        CouponObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        CouponObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(CouponObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of Coupon
    #'
    #' @param input_json the JSON input
    #' @return the instance of Coupon
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`code`)) {
        self$`code` <- this_object$`code`
      }
      if (!is.null(this_object$`codes`)) {
        self$`codes` <- ApiClient$new()$deserializeObj(this_object$`codes`, "array[CouponCode]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`description`)) {
        self$`description` <- this_object$`description`
      }
      if (!is.null(this_object$`actions`)) {
        self$`actions` <- ApiClient$new()$deserializeObj(this_object$`actions`, "array[CouponAction]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`date_start`)) {
        `date_start_object` <- A2CDateTime$new()
        `date_start_object`$fromJSON(jsonlite::toJSON(this_object$`date_start`, auto_unbox = TRUE, digits = NA))
        self$`date_start` <- `date_start_object`
      }
      if (!is.null(this_object$`date_end`)) {
        `date_end_object` <- A2CDateTime$new()
        `date_end_object`$fromJSON(jsonlite::toJSON(this_object$`date_end`, auto_unbox = TRUE, digits = NA))
        self$`date_end` <- `date_end_object`
      }
      if (!is.null(this_object$`avail`)) {
        self$`avail` <- this_object$`avail`
      }
      if (!is.null(this_object$`priority`)) {
        self$`priority` <- this_object$`priority`
      }
      if (!is.null(this_object$`used_times`)) {
        self$`used_times` <- this_object$`used_times`
      }
      if (!is.null(this_object$`usage_limit`)) {
        self$`usage_limit` <- this_object$`usage_limit`
      }
      if (!is.null(this_object$`usage_limit_per_customer`)) {
        self$`usage_limit_per_customer` <- this_object$`usage_limit_per_customer`
      }
      if (!is.null(this_object$`logic_operator`)) {
        self$`logic_operator` <- this_object$`logic_operator`
      }
      if (!is.null(this_object$`conditions`)) {
        self$`conditions` <- ApiClient$new()$deserializeObj(this_object$`conditions`, "array[CouponCondition]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`usage_history`)) {
        self$`usage_history` <- ApiClient$new()$deserializeObj(this_object$`usage_history`, "array[CouponHistory]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return Coupon in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of Coupon
    #'
    #' @param input_json the JSON input
    #' @return the instance of Coupon
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`code` <- this_object$`code`
      self$`codes` <- ApiClient$new()$deserializeObj(this_object$`codes`, "array[CouponCode]", loadNamespace("openapi"))
      self$`name` <- this_object$`name`
      self$`description` <- this_object$`description`
      self$`actions` <- ApiClient$new()$deserializeObj(this_object$`actions`, "array[CouponAction]", loadNamespace("openapi"))
      self$`date_start` <- A2CDateTime$new()$fromJSON(jsonlite::toJSON(this_object$`date_start`, auto_unbox = TRUE, digits = NA))
      self$`date_end` <- A2CDateTime$new()$fromJSON(jsonlite::toJSON(this_object$`date_end`, auto_unbox = TRUE, digits = NA))
      self$`avail` <- this_object$`avail`
      self$`priority` <- this_object$`priority`
      self$`used_times` <- this_object$`used_times`
      self$`usage_limit` <- this_object$`usage_limit`
      self$`usage_limit_per_customer` <- this_object$`usage_limit_per_customer`
      self$`logic_operator` <- this_object$`logic_operator`
      self$`conditions` <- ApiClient$new()$deserializeObj(this_object$`conditions`, "array[CouponCondition]", loadNamespace("openapi"))
      self$`usage_history` <- ApiClient$new()$deserializeObj(this_object$`usage_history`, "array[CouponHistory]", loadNamespace("openapi"))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to Coupon and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of Coupon
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# Coupon$unlock()
#
## Below is an example to define the print function
# Coupon$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# Coupon$lock()

