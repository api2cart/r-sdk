#' Create a new ProductVariantAdd
#'
#' @description
#' ProductVariantAdd Class
#'
#' @docType class
#' @title ProductVariantAdd
#' @description ProductVariantAdd Class
#' @format An \code{R6Class} generator object
#' @field product_id Defines product's id where the variant has to be added character [optional]
#' @field attributes Defines variant's attributes list list(\link{ProductVariantAddAttributesInner}) [optional]
#' @field name Defines variant's name that has to be added character [optional]
#' @field model Specifies variant's model that has to be added character
#' @field description Specifies variant's description character [optional]
#' @field short_description Defines short description character [optional]
#' @field available_for_view Specifies the set of visible/invisible product's variants for users character [optional]
#' @field available_for_sale Specifies the set of visible/invisible product's variants for sale character [optional]
#' @field status Defines status character [optional]
#' @field is_virtual Defines whether the product is virtual character [optional]
#' @field is_default Defines as a default variant character [optional]
#' @field store_id Add variants specified by store id character [optional]
#' @field stores_ids Assign variant to the stores that is specified by comma-separated stores' id character [optional]
#' @field lang_id Language id character [optional]
#' @field price Defines new product's variant price numeric [optional]
#' @field old_price Defines product's old price numeric [optional]
#' @field cost_price Defines new product's cost price numeric [optional]
#' @field special_price Specifies variant's model that has to be added numeric [optional]
#' @field sprice_create Defines the date of special price creation character [optional]
#' @field sprice_modified Defines the date of special price modification character [optional]
#' @field sprice_expire Defines the term of special price offer duration character [optional]
#' @field tier_prices Defines product's tier prices list(\link{ProductAddTierPricesInner}) [optional]
#' @field measure_unit Unit for the price per unit. Must be in allowed list character [optional]
#' @field unit_price Defines new product's unit price numeric [optional]
#' @field prices_inc_tax Indicates whether prices include tax. character [optional]
#' @field quantity Defines product variant's quantity that has to be added numeric [optional]
#' @field warehouse_id This parameter is used for selecting a warehouse where you need to set/modify a product quantity. character [optional]
#' @field in_stock Set stock status character [optional]
#' @field backorder_status Set backorder status character [optional]
#' @field manage_stock Defines inventory tracking for product variant character [optional]
#' @field low_stock_threshold Specify the quantity threshold below which the product is considered low in stock numeric [optional]
#' @field weight Weight numeric [optional]
#' @field width Defines product's width numeric [optional]
#' @field height Defines product's height numeric [optional]
#' @field length Defines product's length numeric [optional]
#' @field weight_unit Weight Unit character [optional]
#' @field sku Defines variant's sku that has to be added character [optional]
#' @field barcode A barcode is a unique code composed of numbers used as a product identifier. character [optional]
#' @field gtin Global Trade Item Number. An GTIN is an identifier for trade items. character [optional]
#' @field upc Universal Product Code. A UPC (UPC-A) is a commonly used identifer for many different products. character [optional]
#' @field ean European Article Number. An EAN is a unique 8 or 13-digit identifier that many industries (such as book publishers) use to identify products. character [optional]
#' @field mpn Manufacturer Part Number. A MPN is an identifier of a particular part design or material used. character [optional]
#' @field isbn International Standard Book Number. An ISBN is a unique identifier for books. character [optional]
#' @field seo_url Defines unique URL for SEO character [optional]
#' @field manufacturer Specifies the product variant's manufacturer character [optional]
#' @field created_at Defines the date of entity creation character [optional]
#' @field meta_title Defines unique meta title for each entity character [optional]
#' @field meta_keywords Defines unique meta keywords for each entity character [optional]
#' @field meta_description Defines unique meta description of a entity character [optional]
#' @field url Defines unique product variant's URL character [optional]
#' @field tax_class_id Defines tax classes where entity has to be added character [optional]
#' @field taxable Specifies whether a tax is charged character [optional]
#' @field fixed_cost_shipping_price Specifies fixed cost shipping price numeric [optional]
#' @field is_free_shipping Specifies variant's free shipping flag that has to be added character [optional]
#' @field country_of_origin The country where the inventory item was made character [optional]
#' @field harmonized_system_code Harmonized System Code. An HSC is a 6-digit identifier that allows participating countries to classify traded goods on a common basis for customs purposes character [optional]
#' @field processing_profile_id The numeric ID of the processing profile (readiness state) for physical products in Etsy. You can find possible values in the \"cart.info\" API method response, in the field processing_profiles[]->readiness_state_id. integer [optional]
#' @field marketplace_item_properties String containing the JSON representation of the supplied data character [optional]
#' @field clear_cache Is cache clear required character [optional]
#' @field idempotency_key A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong> character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductVariantAdd <- R6::R6Class(
  "ProductVariantAdd",
  public = list(
    `product_id` = NULL,
    `attributes` = NULL,
    `name` = NULL,
    `model` = NULL,
    `description` = NULL,
    `short_description` = NULL,
    `available_for_view` = NULL,
    `available_for_sale` = NULL,
    `status` = NULL,
    `is_virtual` = NULL,
    `is_default` = NULL,
    `store_id` = NULL,
    `stores_ids` = NULL,
    `lang_id` = NULL,
    `price` = NULL,
    `old_price` = NULL,
    `cost_price` = NULL,
    `special_price` = NULL,
    `sprice_create` = NULL,
    `sprice_modified` = NULL,
    `sprice_expire` = NULL,
    `tier_prices` = NULL,
    `measure_unit` = NULL,
    `unit_price` = NULL,
    `prices_inc_tax` = NULL,
    `quantity` = NULL,
    `warehouse_id` = NULL,
    `in_stock` = NULL,
    `backorder_status` = NULL,
    `manage_stock` = NULL,
    `low_stock_threshold` = NULL,
    `weight` = NULL,
    `width` = NULL,
    `height` = NULL,
    `length` = NULL,
    `weight_unit` = NULL,
    `sku` = NULL,
    `barcode` = NULL,
    `gtin` = NULL,
    `upc` = NULL,
    `ean` = NULL,
    `mpn` = NULL,
    `isbn` = NULL,
    `seo_url` = NULL,
    `manufacturer` = NULL,
    `created_at` = NULL,
    `meta_title` = NULL,
    `meta_keywords` = NULL,
    `meta_description` = NULL,
    `url` = NULL,
    `tax_class_id` = NULL,
    `taxable` = NULL,
    `fixed_cost_shipping_price` = NULL,
    `is_free_shipping` = NULL,
    `country_of_origin` = NULL,
    `harmonized_system_code` = NULL,
    `processing_profile_id` = NULL,
    `marketplace_item_properties` = NULL,
    `clear_cache` = NULL,
    `idempotency_key` = NULL,

    #' @description
    #' Initialize a new ProductVariantAdd class.
    #'
    #' @param model Specifies variant's model that has to be added
    #' @param product_id Defines product's id where the variant has to be added
    #' @param attributes Defines variant's attributes list
    #' @param name Defines variant's name that has to be added
    #' @param description Specifies variant's description
    #' @param short_description Defines short description
    #' @param available_for_view Specifies the set of visible/invisible product's variants for users. Default to TRUE.
    #' @param available_for_sale Specifies the set of visible/invisible product's variants for sale. Default to TRUE.
    #' @param status Defines status
    #' @param is_virtual Defines whether the product is virtual. Default to FALSE.
    #' @param is_default Defines as a default variant
    #' @param store_id Add variants specified by store id
    #' @param stores_ids Assign variant to the stores that is specified by comma-separated stores' id
    #' @param lang_id Language id
    #' @param price Defines new product's variant price
    #' @param old_price Defines product's old price
    #' @param cost_price Defines new product's cost price
    #' @param special_price Specifies variant's model that has to be added
    #' @param sprice_create Defines the date of special price creation
    #' @param sprice_modified Defines the date of special price modification
    #' @param sprice_expire Defines the term of special price offer duration
    #' @param tier_prices Defines product's tier prices
    #' @param measure_unit Unit for the price per unit. Must be in allowed list
    #' @param unit_price Defines new product's unit price
    #' @param prices_inc_tax Indicates whether prices include tax.. Default to FALSE.
    #' @param quantity Defines product variant's quantity that has to be added. Default to 0.
    #' @param warehouse_id This parameter is used for selecting a warehouse where you need to set/modify a product quantity.
    #' @param in_stock Set stock status
    #' @param backorder_status Set backorder status
    #' @param manage_stock Defines inventory tracking for product variant
    #' @param low_stock_threshold Specify the quantity threshold below which the product is considered low in stock
    #' @param weight Weight. Default to 0.
    #' @param width Defines product's width
    #' @param height Defines product's height
    #' @param length Defines product's length
    #' @param weight_unit Weight Unit
    #' @param sku Defines variant's sku that has to be added
    #' @param barcode A barcode is a unique code composed of numbers used as a product identifier.
    #' @param gtin Global Trade Item Number. An GTIN is an identifier for trade items.
    #' @param upc Universal Product Code. A UPC (UPC-A) is a commonly used identifer for many different products.
    #' @param ean European Article Number. An EAN is a unique 8 or 13-digit identifier that many industries (such as book publishers) use to identify products.
    #' @param mpn Manufacturer Part Number. A MPN is an identifier of a particular part design or material used.
    #' @param isbn International Standard Book Number. An ISBN is a unique identifier for books.
    #' @param seo_url Defines unique URL for SEO
    #' @param manufacturer Specifies the product variant's manufacturer
    #' @param created_at Defines the date of entity creation
    #' @param meta_title Defines unique meta title for each entity
    #' @param meta_keywords Defines unique meta keywords for each entity
    #' @param meta_description Defines unique meta description of a entity
    #' @param url Defines unique product variant's URL
    #' @param tax_class_id Defines tax classes where entity has to be added
    #' @param taxable Specifies whether a tax is charged. Default to TRUE.
    #' @param fixed_cost_shipping_price Specifies fixed cost shipping price
    #' @param is_free_shipping Specifies variant's free shipping flag that has to be added
    #' @param country_of_origin The country where the inventory item was made
    #' @param harmonized_system_code Harmonized System Code. An HSC is a 6-digit identifier that allows participating countries to classify traded goods on a common basis for customs purposes
    #' @param processing_profile_id The numeric ID of the processing profile (readiness state) for physical products in Etsy. You can find possible values in the \"cart.info\" API method response, in the field processing_profiles[]->readiness_state_id.
    #' @param marketplace_item_properties String containing the JSON representation of the supplied data
    #' @param clear_cache Is cache clear required. Default to TRUE.
    #' @param idempotency_key A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong>
    #' @param ... Other optional arguments.
    initialize = function(`model`, `product_id` = NULL, `attributes` = NULL, `name` = NULL, `description` = NULL, `short_description` = NULL, `available_for_view` = TRUE, `available_for_sale` = TRUE, `status` = NULL, `is_virtual` = FALSE, `is_default` = NULL, `store_id` = NULL, `stores_ids` = NULL, `lang_id` = NULL, `price` = NULL, `old_price` = NULL, `cost_price` = NULL, `special_price` = NULL, `sprice_create` = NULL, `sprice_modified` = NULL, `sprice_expire` = NULL, `tier_prices` = NULL, `measure_unit` = NULL, `unit_price` = NULL, `prices_inc_tax` = FALSE, `quantity` = 0, `warehouse_id` = NULL, `in_stock` = NULL, `backorder_status` = NULL, `manage_stock` = NULL, `low_stock_threshold` = NULL, `weight` = 0, `width` = NULL, `height` = NULL, `length` = NULL, `weight_unit` = NULL, `sku` = NULL, `barcode` = NULL, `gtin` = NULL, `upc` = NULL, `ean` = NULL, `mpn` = NULL, `isbn` = NULL, `seo_url` = NULL, `manufacturer` = NULL, `created_at` = NULL, `meta_title` = NULL, `meta_keywords` = NULL, `meta_description` = NULL, `url` = NULL, `tax_class_id` = NULL, `taxable` = TRUE, `fixed_cost_shipping_price` = NULL, `is_free_shipping` = NULL, `country_of_origin` = NULL, `harmonized_system_code` = NULL, `processing_profile_id` = NULL, `marketplace_item_properties` = NULL, `clear_cache` = TRUE, `idempotency_key` = NULL, ...) {
      if (!missing(`model`)) {
        if (!(is.character(`model`) && length(`model`) == 1)) {
          stop(paste("Error! Invalid data for `model`. Must be a string:", `model`))
        }
        self$`model` <- `model`
      }
      if (!is.null(`product_id`)) {
        if (!(is.character(`product_id`) && length(`product_id`) == 1)) {
          stop(paste("Error! Invalid data for `product_id`. Must be a string:", `product_id`))
        }
        self$`product_id` <- `product_id`
      }
      if (!is.null(`attributes`)) {
        stopifnot(is.vector(`attributes`), length(`attributes`) != 0)
        sapply(`attributes`, function(x) stopifnot(R6::is.R6(x)))
        self$`attributes` <- `attributes`
      }
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`description`)) {
        if (!(is.character(`description`) && length(`description`) == 1)) {
          stop(paste("Error! Invalid data for `description`. Must be a string:", `description`))
        }
        self$`description` <- `description`
      }
      if (!is.null(`short_description`)) {
        if (!(is.character(`short_description`) && length(`short_description`) == 1)) {
          stop(paste("Error! Invalid data for `short_description`. Must be a string:", `short_description`))
        }
        self$`short_description` <- `short_description`
      }
      if (!is.null(`available_for_view`)) {
        if (!(is.logical(`available_for_view`) && length(`available_for_view`) == 1)) {
          stop(paste("Error! Invalid data for `available_for_view`. Must be a boolean:", `available_for_view`))
        }
        self$`available_for_view` <- `available_for_view`
      }
      if (!is.null(`available_for_sale`)) {
        if (!(is.logical(`available_for_sale`) && length(`available_for_sale`) == 1)) {
          stop(paste("Error! Invalid data for `available_for_sale`. Must be a boolean:", `available_for_sale`))
        }
        self$`available_for_sale` <- `available_for_sale`
      }
      if (!is.null(`status`)) {
        if (!(is.character(`status`) && length(`status`) == 1)) {
          stop(paste("Error! Invalid data for `status`. Must be a string:", `status`))
        }
        self$`status` <- `status`
      }
      if (!is.null(`is_virtual`)) {
        if (!(is.logical(`is_virtual`) && length(`is_virtual`) == 1)) {
          stop(paste("Error! Invalid data for `is_virtual`. Must be a boolean:", `is_virtual`))
        }
        self$`is_virtual` <- `is_virtual`
      }
      if (!is.null(`is_default`)) {
        if (!(is.logical(`is_default`) && length(`is_default`) == 1)) {
          stop(paste("Error! Invalid data for `is_default`. Must be a boolean:", `is_default`))
        }
        self$`is_default` <- `is_default`
      }
      if (!is.null(`store_id`)) {
        if (!(is.character(`store_id`) && length(`store_id`) == 1)) {
          stop(paste("Error! Invalid data for `store_id`. Must be a string:", `store_id`))
        }
        self$`store_id` <- `store_id`
      }
      if (!is.null(`stores_ids`)) {
        if (!(is.character(`stores_ids`) && length(`stores_ids`) == 1)) {
          stop(paste("Error! Invalid data for `stores_ids`. Must be a string:", `stores_ids`))
        }
        self$`stores_ids` <- `stores_ids`
      }
      if (!is.null(`lang_id`)) {
        if (!(is.character(`lang_id`) && length(`lang_id`) == 1)) {
          stop(paste("Error! Invalid data for `lang_id`. Must be a string:", `lang_id`))
        }
        self$`lang_id` <- `lang_id`
      }
      if (!is.null(`price`)) {
        self$`price` <- `price`
      }
      if (!is.null(`old_price`)) {
        self$`old_price` <- `old_price`
      }
      if (!is.null(`cost_price`)) {
        self$`cost_price` <- `cost_price`
      }
      if (!is.null(`special_price`)) {
        self$`special_price` <- `special_price`
      }
      if (!is.null(`sprice_create`)) {
        if (!(is.character(`sprice_create`) && length(`sprice_create`) == 1)) {
          stop(paste("Error! Invalid data for `sprice_create`. Must be a string:", `sprice_create`))
        }
        self$`sprice_create` <- `sprice_create`
      }
      if (!is.null(`sprice_modified`)) {
        if (!(is.character(`sprice_modified`) && length(`sprice_modified`) == 1)) {
          stop(paste("Error! Invalid data for `sprice_modified`. Must be a string:", `sprice_modified`))
        }
        self$`sprice_modified` <- `sprice_modified`
      }
      if (!is.null(`sprice_expire`)) {
        if (!(is.character(`sprice_expire`) && length(`sprice_expire`) == 1)) {
          stop(paste("Error! Invalid data for `sprice_expire`. Must be a string:", `sprice_expire`))
        }
        self$`sprice_expire` <- `sprice_expire`
      }
      if (!is.null(`tier_prices`)) {
        stopifnot(is.vector(`tier_prices`), length(`tier_prices`) != 0)
        sapply(`tier_prices`, function(x) stopifnot(R6::is.R6(x)))
        self$`tier_prices` <- `tier_prices`
      }
      if (!is.null(`measure_unit`)) {
        if (!(is.character(`measure_unit`) && length(`measure_unit`) == 1)) {
          stop(paste("Error! Invalid data for `measure_unit`. Must be a string:", `measure_unit`))
        }
        self$`measure_unit` <- `measure_unit`
      }
      if (!is.null(`unit_price`)) {
        self$`unit_price` <- `unit_price`
      }
      if (!is.null(`prices_inc_tax`)) {
        if (!(is.logical(`prices_inc_tax`) && length(`prices_inc_tax`) == 1)) {
          stop(paste("Error! Invalid data for `prices_inc_tax`. Must be a boolean:", `prices_inc_tax`))
        }
        self$`prices_inc_tax` <- `prices_inc_tax`
      }
      if (!is.null(`quantity`)) {
        self$`quantity` <- `quantity`
      }
      if (!is.null(`warehouse_id`)) {
        if (!(is.character(`warehouse_id`) && length(`warehouse_id`) == 1)) {
          stop(paste("Error! Invalid data for `warehouse_id`. Must be a string:", `warehouse_id`))
        }
        self$`warehouse_id` <- `warehouse_id`
      }
      if (!is.null(`in_stock`)) {
        if (!(is.logical(`in_stock`) && length(`in_stock`) == 1)) {
          stop(paste("Error! Invalid data for `in_stock`. Must be a boolean:", `in_stock`))
        }
        self$`in_stock` <- `in_stock`
      }
      if (!is.null(`backorder_status`)) {
        if (!(is.character(`backorder_status`) && length(`backorder_status`) == 1)) {
          stop(paste("Error! Invalid data for `backorder_status`. Must be a string:", `backorder_status`))
        }
        self$`backorder_status` <- `backorder_status`
      }
      if (!is.null(`manage_stock`)) {
        if (!(is.logical(`manage_stock`) && length(`manage_stock`) == 1)) {
          stop(paste("Error! Invalid data for `manage_stock`. Must be a boolean:", `manage_stock`))
        }
        self$`manage_stock` <- `manage_stock`
      }
      if (!is.null(`low_stock_threshold`)) {
        self$`low_stock_threshold` <- `low_stock_threshold`
      }
      if (!is.null(`weight`)) {
        self$`weight` <- `weight`
      }
      if (!is.null(`width`)) {
        self$`width` <- `width`
      }
      if (!is.null(`height`)) {
        self$`height` <- `height`
      }
      if (!is.null(`length`)) {
        self$`length` <- `length`
      }
      if (!is.null(`weight_unit`)) {
        if (!(is.character(`weight_unit`) && length(`weight_unit`) == 1)) {
          stop(paste("Error! Invalid data for `weight_unit`. Must be a string:", `weight_unit`))
        }
        self$`weight_unit` <- `weight_unit`
      }
      if (!is.null(`sku`)) {
        if (!(is.character(`sku`) && length(`sku`) == 1)) {
          stop(paste("Error! Invalid data for `sku`. Must be a string:", `sku`))
        }
        self$`sku` <- `sku`
      }
      if (!is.null(`barcode`)) {
        if (!(is.character(`barcode`) && length(`barcode`) == 1)) {
          stop(paste("Error! Invalid data for `barcode`. Must be a string:", `barcode`))
        }
        self$`barcode` <- `barcode`
      }
      if (!is.null(`gtin`)) {
        if (!(is.character(`gtin`) && length(`gtin`) == 1)) {
          stop(paste("Error! Invalid data for `gtin`. Must be a string:", `gtin`))
        }
        self$`gtin` <- `gtin`
      }
      if (!is.null(`upc`)) {
        if (!(is.character(`upc`) && length(`upc`) == 1)) {
          stop(paste("Error! Invalid data for `upc`. Must be a string:", `upc`))
        }
        self$`upc` <- `upc`
      }
      if (!is.null(`ean`)) {
        if (!(is.character(`ean`) && length(`ean`) == 1)) {
          stop(paste("Error! Invalid data for `ean`. Must be a string:", `ean`))
        }
        self$`ean` <- `ean`
      }
      if (!is.null(`mpn`)) {
        if (!(is.character(`mpn`) && length(`mpn`) == 1)) {
          stop(paste("Error! Invalid data for `mpn`. Must be a string:", `mpn`))
        }
        self$`mpn` <- `mpn`
      }
      if (!is.null(`isbn`)) {
        if (!(is.character(`isbn`) && length(`isbn`) == 1)) {
          stop(paste("Error! Invalid data for `isbn`. Must be a string:", `isbn`))
        }
        self$`isbn` <- `isbn`
      }
      if (!is.null(`seo_url`)) {
        if (!(is.character(`seo_url`) && length(`seo_url`) == 1)) {
          stop(paste("Error! Invalid data for `seo_url`. Must be a string:", `seo_url`))
        }
        self$`seo_url` <- `seo_url`
      }
      if (!is.null(`manufacturer`)) {
        if (!(is.character(`manufacturer`) && length(`manufacturer`) == 1)) {
          stop(paste("Error! Invalid data for `manufacturer`. Must be a string:", `manufacturer`))
        }
        self$`manufacturer` <- `manufacturer`
      }
      if (!is.null(`created_at`)) {
        if (!(is.character(`created_at`) && length(`created_at`) == 1)) {
          stop(paste("Error! Invalid data for `created_at`. Must be a string:", `created_at`))
        }
        self$`created_at` <- `created_at`
      }
      if (!is.null(`meta_title`)) {
        if (!(is.character(`meta_title`) && length(`meta_title`) == 1)) {
          stop(paste("Error! Invalid data for `meta_title`. Must be a string:", `meta_title`))
        }
        self$`meta_title` <- `meta_title`
      }
      if (!is.null(`meta_keywords`)) {
        if (!(is.character(`meta_keywords`) && length(`meta_keywords`) == 1)) {
          stop(paste("Error! Invalid data for `meta_keywords`. Must be a string:", `meta_keywords`))
        }
        self$`meta_keywords` <- `meta_keywords`
      }
      if (!is.null(`meta_description`)) {
        if (!(is.character(`meta_description`) && length(`meta_description`) == 1)) {
          stop(paste("Error! Invalid data for `meta_description`. Must be a string:", `meta_description`))
        }
        self$`meta_description` <- `meta_description`
      }
      if (!is.null(`url`)) {
        if (!(is.character(`url`) && length(`url`) == 1)) {
          stop(paste("Error! Invalid data for `url`. Must be a string:", `url`))
        }
        self$`url` <- `url`
      }
      if (!is.null(`tax_class_id`)) {
        if (!(is.character(`tax_class_id`) && length(`tax_class_id`) == 1)) {
          stop(paste("Error! Invalid data for `tax_class_id`. Must be a string:", `tax_class_id`))
        }
        self$`tax_class_id` <- `tax_class_id`
      }
      if (!is.null(`taxable`)) {
        if (!(is.logical(`taxable`) && length(`taxable`) == 1)) {
          stop(paste("Error! Invalid data for `taxable`. Must be a boolean:", `taxable`))
        }
        self$`taxable` <- `taxable`
      }
      if (!is.null(`fixed_cost_shipping_price`)) {
        self$`fixed_cost_shipping_price` <- `fixed_cost_shipping_price`
      }
      if (!is.null(`is_free_shipping`)) {
        if (!(is.logical(`is_free_shipping`) && length(`is_free_shipping`) == 1)) {
          stop(paste("Error! Invalid data for `is_free_shipping`. Must be a boolean:", `is_free_shipping`))
        }
        self$`is_free_shipping` <- `is_free_shipping`
      }
      if (!is.null(`country_of_origin`)) {
        if (!(is.character(`country_of_origin`) && length(`country_of_origin`) == 1)) {
          stop(paste("Error! Invalid data for `country_of_origin`. Must be a string:", `country_of_origin`))
        }
        self$`country_of_origin` <- `country_of_origin`
      }
      if (!is.null(`harmonized_system_code`)) {
        if (!(is.character(`harmonized_system_code`) && length(`harmonized_system_code`) == 1)) {
          stop(paste("Error! Invalid data for `harmonized_system_code`. Must be a string:", `harmonized_system_code`))
        }
        self$`harmonized_system_code` <- `harmonized_system_code`
      }
      if (!is.null(`processing_profile_id`)) {
        if (!(is.numeric(`processing_profile_id`) && length(`processing_profile_id`) == 1)) {
          stop(paste("Error! Invalid data for `processing_profile_id`. Must be an integer:", `processing_profile_id`))
        }
        self$`processing_profile_id` <- `processing_profile_id`
      }
      if (!is.null(`marketplace_item_properties`)) {
        if (!(is.character(`marketplace_item_properties`) && length(`marketplace_item_properties`) == 1)) {
          stop(paste("Error! Invalid data for `marketplace_item_properties`. Must be a string:", `marketplace_item_properties`))
        }
        self$`marketplace_item_properties` <- `marketplace_item_properties`
      }
      if (!is.null(`clear_cache`)) {
        if (!(is.logical(`clear_cache`) && length(`clear_cache`) == 1)) {
          stop(paste("Error! Invalid data for `clear_cache`. Must be a boolean:", `clear_cache`))
        }
        self$`clear_cache` <- `clear_cache`
      }
      if (!is.null(`idempotency_key`)) {
        if (!(is.character(`idempotency_key`) && length(`idempotency_key`) == 1)) {
          stop(paste("Error! Invalid data for `idempotency_key`. Must be a string:", `idempotency_key`))
        }
        self$`idempotency_key` <- `idempotency_key`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductVariantAdd as a base R list.
    #' @examples
    #' # convert array of ProductVariantAdd (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductVariantAdd to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductVariantAddObject <- list()
      if (!is.null(self$`product_id`)) {
        ProductVariantAddObject[["product_id"]] <-
          self$`product_id`
      }
      if (!is.null(self$`attributes`)) {
        ProductVariantAddObject[["attributes"]] <-
          lapply(self$`attributes`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`name`)) {
        ProductVariantAddObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`model`)) {
        ProductVariantAddObject[["model"]] <-
          self$`model`
      }
      if (!is.null(self$`description`)) {
        ProductVariantAddObject[["description"]] <-
          self$`description`
      }
      if (!is.null(self$`short_description`)) {
        ProductVariantAddObject[["short_description"]] <-
          self$`short_description`
      }
      if (!is.null(self$`available_for_view`)) {
        ProductVariantAddObject[["available_for_view"]] <-
          self$`available_for_view`
      }
      if (!is.null(self$`available_for_sale`)) {
        ProductVariantAddObject[["available_for_sale"]] <-
          self$`available_for_sale`
      }
      if (!is.null(self$`status`)) {
        ProductVariantAddObject[["status"]] <-
          self$`status`
      }
      if (!is.null(self$`is_virtual`)) {
        ProductVariantAddObject[["is_virtual"]] <-
          self$`is_virtual`
      }
      if (!is.null(self$`is_default`)) {
        ProductVariantAddObject[["is_default"]] <-
          self$`is_default`
      }
      if (!is.null(self$`store_id`)) {
        ProductVariantAddObject[["store_id"]] <-
          self$`store_id`
      }
      if (!is.null(self$`stores_ids`)) {
        ProductVariantAddObject[["stores_ids"]] <-
          self$`stores_ids`
      }
      if (!is.null(self$`lang_id`)) {
        ProductVariantAddObject[["lang_id"]] <-
          self$`lang_id`
      }
      if (!is.null(self$`price`)) {
        ProductVariantAddObject[["price"]] <-
          self$`price`
      }
      if (!is.null(self$`old_price`)) {
        ProductVariantAddObject[["old_price"]] <-
          self$`old_price`
      }
      if (!is.null(self$`cost_price`)) {
        ProductVariantAddObject[["cost_price"]] <-
          self$`cost_price`
      }
      if (!is.null(self$`special_price`)) {
        ProductVariantAddObject[["special_price"]] <-
          self$`special_price`
      }
      if (!is.null(self$`sprice_create`)) {
        ProductVariantAddObject[["sprice_create"]] <-
          self$`sprice_create`
      }
      if (!is.null(self$`sprice_modified`)) {
        ProductVariantAddObject[["sprice_modified"]] <-
          self$`sprice_modified`
      }
      if (!is.null(self$`sprice_expire`)) {
        ProductVariantAddObject[["sprice_expire"]] <-
          self$`sprice_expire`
      }
      if (!is.null(self$`tier_prices`)) {
        ProductVariantAddObject[["tier_prices"]] <-
          lapply(self$`tier_prices`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`measure_unit`)) {
        ProductVariantAddObject[["measure_unit"]] <-
          self$`measure_unit`
      }
      if (!is.null(self$`unit_price`)) {
        ProductVariantAddObject[["unit_price"]] <-
          self$`unit_price`
      }
      if (!is.null(self$`prices_inc_tax`)) {
        ProductVariantAddObject[["prices_inc_tax"]] <-
          self$`prices_inc_tax`
      }
      if (!is.null(self$`quantity`)) {
        ProductVariantAddObject[["quantity"]] <-
          self$`quantity`
      }
      if (!is.null(self$`warehouse_id`)) {
        ProductVariantAddObject[["warehouse_id"]] <-
          self$`warehouse_id`
      }
      if (!is.null(self$`in_stock`)) {
        ProductVariantAddObject[["in_stock"]] <-
          self$`in_stock`
      }
      if (!is.null(self$`backorder_status`)) {
        ProductVariantAddObject[["backorder_status"]] <-
          self$`backorder_status`
      }
      if (!is.null(self$`manage_stock`)) {
        ProductVariantAddObject[["manage_stock"]] <-
          self$`manage_stock`
      }
      if (!is.null(self$`low_stock_threshold`)) {
        ProductVariantAddObject[["low_stock_threshold"]] <-
          self$`low_stock_threshold`
      }
      if (!is.null(self$`weight`)) {
        ProductVariantAddObject[["weight"]] <-
          self$`weight`
      }
      if (!is.null(self$`width`)) {
        ProductVariantAddObject[["width"]] <-
          self$`width`
      }
      if (!is.null(self$`height`)) {
        ProductVariantAddObject[["height"]] <-
          self$`height`
      }
      if (!is.null(self$`length`)) {
        ProductVariantAddObject[["length"]] <-
          self$`length`
      }
      if (!is.null(self$`weight_unit`)) {
        ProductVariantAddObject[["weight_unit"]] <-
          self$`weight_unit`
      }
      if (!is.null(self$`sku`)) {
        ProductVariantAddObject[["sku"]] <-
          self$`sku`
      }
      if (!is.null(self$`barcode`)) {
        ProductVariantAddObject[["barcode"]] <-
          self$`barcode`
      }
      if (!is.null(self$`gtin`)) {
        ProductVariantAddObject[["gtin"]] <-
          self$`gtin`
      }
      if (!is.null(self$`upc`)) {
        ProductVariantAddObject[["upc"]] <-
          self$`upc`
      }
      if (!is.null(self$`ean`)) {
        ProductVariantAddObject[["ean"]] <-
          self$`ean`
      }
      if (!is.null(self$`mpn`)) {
        ProductVariantAddObject[["mpn"]] <-
          self$`mpn`
      }
      if (!is.null(self$`isbn`)) {
        ProductVariantAddObject[["isbn"]] <-
          self$`isbn`
      }
      if (!is.null(self$`seo_url`)) {
        ProductVariantAddObject[["seo_url"]] <-
          self$`seo_url`
      }
      if (!is.null(self$`manufacturer`)) {
        ProductVariantAddObject[["manufacturer"]] <-
          self$`manufacturer`
      }
      if (!is.null(self$`created_at`)) {
        ProductVariantAddObject[["created_at"]] <-
          self$`created_at`
      }
      if (!is.null(self$`meta_title`)) {
        ProductVariantAddObject[["meta_title"]] <-
          self$`meta_title`
      }
      if (!is.null(self$`meta_keywords`)) {
        ProductVariantAddObject[["meta_keywords"]] <-
          self$`meta_keywords`
      }
      if (!is.null(self$`meta_description`)) {
        ProductVariantAddObject[["meta_description"]] <-
          self$`meta_description`
      }
      if (!is.null(self$`url`)) {
        ProductVariantAddObject[["url"]] <-
          self$`url`
      }
      if (!is.null(self$`tax_class_id`)) {
        ProductVariantAddObject[["tax_class_id"]] <-
          self$`tax_class_id`
      }
      if (!is.null(self$`taxable`)) {
        ProductVariantAddObject[["taxable"]] <-
          self$`taxable`
      }
      if (!is.null(self$`fixed_cost_shipping_price`)) {
        ProductVariantAddObject[["fixed_cost_shipping_price"]] <-
          self$`fixed_cost_shipping_price`
      }
      if (!is.null(self$`is_free_shipping`)) {
        ProductVariantAddObject[["is_free_shipping"]] <-
          self$`is_free_shipping`
      }
      if (!is.null(self$`country_of_origin`)) {
        ProductVariantAddObject[["country_of_origin"]] <-
          self$`country_of_origin`
      }
      if (!is.null(self$`harmonized_system_code`)) {
        ProductVariantAddObject[["harmonized_system_code"]] <-
          self$`harmonized_system_code`
      }
      if (!is.null(self$`processing_profile_id`)) {
        ProductVariantAddObject[["processing_profile_id"]] <-
          self$`processing_profile_id`
      }
      if (!is.null(self$`marketplace_item_properties`)) {
        ProductVariantAddObject[["marketplace_item_properties"]] <-
          self$`marketplace_item_properties`
      }
      if (!is.null(self$`clear_cache`)) {
        ProductVariantAddObject[["clear_cache"]] <-
          self$`clear_cache`
      }
      if (!is.null(self$`idempotency_key`)) {
        ProductVariantAddObject[["idempotency_key"]] <-
          self$`idempotency_key`
      }
      return(ProductVariantAddObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductVariantAdd
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductVariantAdd
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`product_id`)) {
        self$`product_id` <- this_object$`product_id`
      }
      if (!is.null(this_object$`attributes`)) {
        self$`attributes` <- ApiClient$new()$deserializeObj(this_object$`attributes`, "array[ProductVariantAddAttributesInner]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`model`)) {
        self$`model` <- this_object$`model`
      }
      if (!is.null(this_object$`description`)) {
        self$`description` <- this_object$`description`
      }
      if (!is.null(this_object$`short_description`)) {
        self$`short_description` <- this_object$`short_description`
      }
      if (!is.null(this_object$`available_for_view`)) {
        self$`available_for_view` <- this_object$`available_for_view`
      }
      if (!is.null(this_object$`available_for_sale`)) {
        self$`available_for_sale` <- this_object$`available_for_sale`
      }
      if (!is.null(this_object$`status`)) {
        self$`status` <- this_object$`status`
      }
      if (!is.null(this_object$`is_virtual`)) {
        self$`is_virtual` <- this_object$`is_virtual`
      }
      if (!is.null(this_object$`is_default`)) {
        self$`is_default` <- this_object$`is_default`
      }
      if (!is.null(this_object$`store_id`)) {
        self$`store_id` <- this_object$`store_id`
      }
      if (!is.null(this_object$`stores_ids`)) {
        self$`stores_ids` <- this_object$`stores_ids`
      }
      if (!is.null(this_object$`lang_id`)) {
        self$`lang_id` <- this_object$`lang_id`
      }
      if (!is.null(this_object$`price`)) {
        self$`price` <- this_object$`price`
      }
      if (!is.null(this_object$`old_price`)) {
        self$`old_price` <- this_object$`old_price`
      }
      if (!is.null(this_object$`cost_price`)) {
        self$`cost_price` <- this_object$`cost_price`
      }
      if (!is.null(this_object$`special_price`)) {
        self$`special_price` <- this_object$`special_price`
      }
      if (!is.null(this_object$`sprice_create`)) {
        self$`sprice_create` <- this_object$`sprice_create`
      }
      if (!is.null(this_object$`sprice_modified`)) {
        self$`sprice_modified` <- this_object$`sprice_modified`
      }
      if (!is.null(this_object$`sprice_expire`)) {
        self$`sprice_expire` <- this_object$`sprice_expire`
      }
      if (!is.null(this_object$`tier_prices`)) {
        self$`tier_prices` <- ApiClient$new()$deserializeObj(this_object$`tier_prices`, "array[ProductAddTierPricesInner]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`measure_unit`)) {
        self$`measure_unit` <- this_object$`measure_unit`
      }
      if (!is.null(this_object$`unit_price`)) {
        self$`unit_price` <- this_object$`unit_price`
      }
      if (!is.null(this_object$`prices_inc_tax`)) {
        self$`prices_inc_tax` <- this_object$`prices_inc_tax`
      }
      if (!is.null(this_object$`quantity`)) {
        self$`quantity` <- this_object$`quantity`
      }
      if (!is.null(this_object$`warehouse_id`)) {
        self$`warehouse_id` <- this_object$`warehouse_id`
      }
      if (!is.null(this_object$`in_stock`)) {
        self$`in_stock` <- this_object$`in_stock`
      }
      if (!is.null(this_object$`backorder_status`)) {
        self$`backorder_status` <- this_object$`backorder_status`
      }
      if (!is.null(this_object$`manage_stock`)) {
        self$`manage_stock` <- this_object$`manage_stock`
      }
      if (!is.null(this_object$`low_stock_threshold`)) {
        self$`low_stock_threshold` <- this_object$`low_stock_threshold`
      }
      if (!is.null(this_object$`weight`)) {
        self$`weight` <- this_object$`weight`
      }
      if (!is.null(this_object$`width`)) {
        self$`width` <- this_object$`width`
      }
      if (!is.null(this_object$`height`)) {
        self$`height` <- this_object$`height`
      }
      if (!is.null(this_object$`length`)) {
        self$`length` <- this_object$`length`
      }
      if (!is.null(this_object$`weight_unit`)) {
        self$`weight_unit` <- this_object$`weight_unit`
      }
      if (!is.null(this_object$`sku`)) {
        self$`sku` <- this_object$`sku`
      }
      if (!is.null(this_object$`barcode`)) {
        self$`barcode` <- this_object$`barcode`
      }
      if (!is.null(this_object$`gtin`)) {
        self$`gtin` <- this_object$`gtin`
      }
      if (!is.null(this_object$`upc`)) {
        self$`upc` <- this_object$`upc`
      }
      if (!is.null(this_object$`ean`)) {
        self$`ean` <- this_object$`ean`
      }
      if (!is.null(this_object$`mpn`)) {
        self$`mpn` <- this_object$`mpn`
      }
      if (!is.null(this_object$`isbn`)) {
        self$`isbn` <- this_object$`isbn`
      }
      if (!is.null(this_object$`seo_url`)) {
        self$`seo_url` <- this_object$`seo_url`
      }
      if (!is.null(this_object$`manufacturer`)) {
        self$`manufacturer` <- this_object$`manufacturer`
      }
      if (!is.null(this_object$`created_at`)) {
        self$`created_at` <- this_object$`created_at`
      }
      if (!is.null(this_object$`meta_title`)) {
        self$`meta_title` <- this_object$`meta_title`
      }
      if (!is.null(this_object$`meta_keywords`)) {
        self$`meta_keywords` <- this_object$`meta_keywords`
      }
      if (!is.null(this_object$`meta_description`)) {
        self$`meta_description` <- this_object$`meta_description`
      }
      if (!is.null(this_object$`url`)) {
        self$`url` <- this_object$`url`
      }
      if (!is.null(this_object$`tax_class_id`)) {
        self$`tax_class_id` <- this_object$`tax_class_id`
      }
      if (!is.null(this_object$`taxable`)) {
        self$`taxable` <- this_object$`taxable`
      }
      if (!is.null(this_object$`fixed_cost_shipping_price`)) {
        self$`fixed_cost_shipping_price` <- this_object$`fixed_cost_shipping_price`
      }
      if (!is.null(this_object$`is_free_shipping`)) {
        self$`is_free_shipping` <- this_object$`is_free_shipping`
      }
      if (!is.null(this_object$`country_of_origin`)) {
        self$`country_of_origin` <- this_object$`country_of_origin`
      }
      if (!is.null(this_object$`harmonized_system_code`)) {
        self$`harmonized_system_code` <- this_object$`harmonized_system_code`
      }
      if (!is.null(this_object$`processing_profile_id`)) {
        self$`processing_profile_id` <- this_object$`processing_profile_id`
      }
      if (!is.null(this_object$`marketplace_item_properties`)) {
        self$`marketplace_item_properties` <- this_object$`marketplace_item_properties`
      }
      if (!is.null(this_object$`clear_cache`)) {
        self$`clear_cache` <- this_object$`clear_cache`
      }
      if (!is.null(this_object$`idempotency_key`)) {
        self$`idempotency_key` <- this_object$`idempotency_key`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductVariantAdd in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductVariantAdd
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductVariantAdd
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`product_id` <- this_object$`product_id`
      self$`attributes` <- ApiClient$new()$deserializeObj(this_object$`attributes`, "array[ProductVariantAddAttributesInner]", loadNamespace("openapi"))
      self$`name` <- this_object$`name`
      self$`model` <- this_object$`model`
      self$`description` <- this_object$`description`
      self$`short_description` <- this_object$`short_description`
      self$`available_for_view` <- this_object$`available_for_view`
      self$`available_for_sale` <- this_object$`available_for_sale`
      self$`status` <- this_object$`status`
      self$`is_virtual` <- this_object$`is_virtual`
      self$`is_default` <- this_object$`is_default`
      self$`store_id` <- this_object$`store_id`
      self$`stores_ids` <- this_object$`stores_ids`
      self$`lang_id` <- this_object$`lang_id`
      self$`price` <- this_object$`price`
      self$`old_price` <- this_object$`old_price`
      self$`cost_price` <- this_object$`cost_price`
      self$`special_price` <- this_object$`special_price`
      self$`sprice_create` <- this_object$`sprice_create`
      self$`sprice_modified` <- this_object$`sprice_modified`
      self$`sprice_expire` <- this_object$`sprice_expire`
      self$`tier_prices` <- ApiClient$new()$deserializeObj(this_object$`tier_prices`, "array[ProductAddTierPricesInner]", loadNamespace("openapi"))
      self$`measure_unit` <- this_object$`measure_unit`
      self$`unit_price` <- this_object$`unit_price`
      self$`prices_inc_tax` <- this_object$`prices_inc_tax`
      self$`quantity` <- this_object$`quantity`
      self$`warehouse_id` <- this_object$`warehouse_id`
      self$`in_stock` <- this_object$`in_stock`
      self$`backorder_status` <- this_object$`backorder_status`
      self$`manage_stock` <- this_object$`manage_stock`
      self$`low_stock_threshold` <- this_object$`low_stock_threshold`
      self$`weight` <- this_object$`weight`
      self$`width` <- this_object$`width`
      self$`height` <- this_object$`height`
      self$`length` <- this_object$`length`
      self$`weight_unit` <- this_object$`weight_unit`
      self$`sku` <- this_object$`sku`
      self$`barcode` <- this_object$`barcode`
      self$`gtin` <- this_object$`gtin`
      self$`upc` <- this_object$`upc`
      self$`ean` <- this_object$`ean`
      self$`mpn` <- this_object$`mpn`
      self$`isbn` <- this_object$`isbn`
      self$`seo_url` <- this_object$`seo_url`
      self$`manufacturer` <- this_object$`manufacturer`
      self$`created_at` <- this_object$`created_at`
      self$`meta_title` <- this_object$`meta_title`
      self$`meta_keywords` <- this_object$`meta_keywords`
      self$`meta_description` <- this_object$`meta_description`
      self$`url` <- this_object$`url`
      self$`tax_class_id` <- this_object$`tax_class_id`
      self$`taxable` <- this_object$`taxable`
      self$`fixed_cost_shipping_price` <- this_object$`fixed_cost_shipping_price`
      self$`is_free_shipping` <- this_object$`is_free_shipping`
      self$`country_of_origin` <- this_object$`country_of_origin`
      self$`harmonized_system_code` <- this_object$`harmonized_system_code`
      self$`processing_profile_id` <- this_object$`processing_profile_id`
      self$`marketplace_item_properties` <- this_object$`marketplace_item_properties`
      self$`clear_cache` <- this_object$`clear_cache`
      self$`idempotency_key` <- this_object$`idempotency_key`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductVariantAdd and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
      # check the required field `model`
      if (!is.null(input_json$`model`)) {
        if (!(is.character(input_json$`model`) && length(input_json$`model`) == 1)) {
          stop(paste("Error! Invalid data for `model`. Must be a string:", input_json$`model`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for ProductVariantAdd: the required field `model` is missing."))
      }
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductVariantAdd
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      # check if the required `model` is null
      if (is.null(self$`model`)) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      # check if the required `model` is null
      if (is.null(self$`model`)) {
        invalid_fields["model"] <- "Non-nullable required field `model` cannot be null."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductVariantAdd$unlock()
#
## Below is an example to define the print function
# ProductVariantAdd$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductVariantAdd$lock()

