#' Create a new AnalyticsProductMetric
#'
#' @description
#' AnalyticsProductMetric Class
#'
#' @docType class
#' @title AnalyticsProductMetric
#' @description AnalyticsProductMetric Class
#' @format An \code{R6Class} generator object
#' @field items_sold  integer [optional]
#' @field orders_count  integer [optional]
#' @field gross_sales  numeric [optional]
#' @field net_sales  numeric [optional]
#' @field discounts  numeric [optional]
#' @field refunds  numeric [optional]
#' @field currency_id  character [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
AnalyticsProductMetric <- R6::R6Class(
  "AnalyticsProductMetric",
  public = list(
    `items_sold` = NULL,
    `orders_count` = NULL,
    `gross_sales` = NULL,
    `net_sales` = NULL,
    `discounts` = NULL,
    `refunds` = NULL,
    `currency_id` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new AnalyticsProductMetric class.
    #'
    #' @param items_sold items_sold
    #' @param orders_count orders_count
    #' @param gross_sales gross_sales
    #' @param net_sales net_sales
    #' @param discounts discounts
    #' @param refunds refunds
    #' @param currency_id currency_id
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`items_sold` = NULL, `orders_count` = NULL, `gross_sales` = NULL, `net_sales` = NULL, `discounts` = NULL, `refunds` = NULL, `currency_id` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`items_sold`)) {
        if (!(is.numeric(`items_sold`) && length(`items_sold`) == 1)) {
          stop(paste("Error! Invalid data for `items_sold`. Must be an integer:", `items_sold`))
        }
        self$`items_sold` <- `items_sold`
      }
      if (!is.null(`orders_count`)) {
        if (!(is.numeric(`orders_count`) && length(`orders_count`) == 1)) {
          stop(paste("Error! Invalid data for `orders_count`. Must be an integer:", `orders_count`))
        }
        self$`orders_count` <- `orders_count`
      }
      if (!is.null(`gross_sales`)) {
        self$`gross_sales` <- `gross_sales`
      }
      if (!is.null(`net_sales`)) {
        self$`net_sales` <- `net_sales`
      }
      if (!is.null(`discounts`)) {
        self$`discounts` <- `discounts`
      }
      if (!is.null(`refunds`)) {
        self$`refunds` <- `refunds`
      }
      if (!is.null(`currency_id`)) {
        if (!(is.character(`currency_id`) && length(`currency_id`) == 1)) {
          stop(paste("Error! Invalid data for `currency_id`. Must be a string:", `currency_id`))
        }
        self$`currency_id` <- `currency_id`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return AnalyticsProductMetric as a base R list.
    #' @examples
    #' # convert array of AnalyticsProductMetric (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert AnalyticsProductMetric to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      AnalyticsProductMetricObject <- list()
      if (!is.null(self$`items_sold`)) {
        AnalyticsProductMetricObject[["items_sold"]] <-
          self$`items_sold`
      }
      if (!is.null(self$`orders_count`)) {
        AnalyticsProductMetricObject[["orders_count"]] <-
          self$`orders_count`
      }
      if (!is.null(self$`gross_sales`)) {
        AnalyticsProductMetricObject[["gross_sales"]] <-
          self$`gross_sales`
      }
      if (!is.null(self$`net_sales`)) {
        AnalyticsProductMetricObject[["net_sales"]] <-
          self$`net_sales`
      }
      if (!is.null(self$`discounts`)) {
        AnalyticsProductMetricObject[["discounts"]] <-
          self$`discounts`
      }
      if (!is.null(self$`refunds`)) {
        AnalyticsProductMetricObject[["refunds"]] <-
          self$`refunds`
      }
      if (!is.null(self$`currency_id`)) {
        AnalyticsProductMetricObject[["currency_id"]] <-
          self$`currency_id`
      }
      if (!is.null(self$`additional_fields`)) {
        AnalyticsProductMetricObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        AnalyticsProductMetricObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(AnalyticsProductMetricObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of AnalyticsProductMetric
    #'
    #' @param input_json the JSON input
    #' @return the instance of AnalyticsProductMetric
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`items_sold`)) {
        self$`items_sold` <- this_object$`items_sold`
      }
      if (!is.null(this_object$`orders_count`)) {
        self$`orders_count` <- this_object$`orders_count`
      }
      if (!is.null(this_object$`gross_sales`)) {
        self$`gross_sales` <- this_object$`gross_sales`
      }
      if (!is.null(this_object$`net_sales`)) {
        self$`net_sales` <- this_object$`net_sales`
      }
      if (!is.null(this_object$`discounts`)) {
        self$`discounts` <- this_object$`discounts`
      }
      if (!is.null(this_object$`refunds`)) {
        self$`refunds` <- this_object$`refunds`
      }
      if (!is.null(this_object$`currency_id`)) {
        self$`currency_id` <- this_object$`currency_id`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return AnalyticsProductMetric in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of AnalyticsProductMetric
    #'
    #' @param input_json the JSON input
    #' @return the instance of AnalyticsProductMetric
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`items_sold` <- this_object$`items_sold`
      self$`orders_count` <- this_object$`orders_count`
      self$`gross_sales` <- this_object$`gross_sales`
      self$`net_sales` <- this_object$`net_sales`
      self$`discounts` <- this_object$`discounts`
      self$`refunds` <- this_object$`refunds`
      self$`currency_id` <- this_object$`currency_id`
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to AnalyticsProductMetric and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of AnalyticsProductMetric
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# AnalyticsProductMetric$unlock()
#
## Below is an example to define the print function
# AnalyticsProductMetric$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# AnalyticsProductMetric$lock()

