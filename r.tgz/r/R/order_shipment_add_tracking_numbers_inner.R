#' Create a new OrderShipmentAddTrackingNumbersInner
#'
#' @description
#' OrderShipmentAddTrackingNumbersInner Class
#'
#' @docType class
#' @title OrderShipmentAddTrackingNumbersInner
#' @description OrderShipmentAddTrackingNumbersInner Class
#' @format An \code{R6Class} generator object
#' @field carrier_id  character [optional]
#' @field tracking_number  character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
OrderShipmentAddTrackingNumbersInner <- R6::R6Class(
  "OrderShipmentAddTrackingNumbersInner",
  public = list(
    `carrier_id` = NULL,
    `tracking_number` = NULL,

    #' @description
    #' Initialize a new OrderShipmentAddTrackingNumbersInner class.
    #'
    #' @param carrier_id carrier_id
    #' @param tracking_number tracking_number
    #' @param ... Other optional arguments.
    initialize = function(`carrier_id` = NULL, `tracking_number` = NULL, ...) {
      if (!is.null(`carrier_id`)) {
        if (!(is.character(`carrier_id`) && length(`carrier_id`) == 1)) {
          stop(paste("Error! Invalid data for `carrier_id`. Must be a string:", `carrier_id`))
        }
        self$`carrier_id` <- `carrier_id`
      }
      if (!is.null(`tracking_number`)) {
        if (!(is.character(`tracking_number`) && length(`tracking_number`) == 1)) {
          stop(paste("Error! Invalid data for `tracking_number`. Must be a string:", `tracking_number`))
        }
        self$`tracking_number` <- `tracking_number`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return OrderShipmentAddTrackingNumbersInner as a base R list.
    #' @examples
    #' # convert array of OrderShipmentAddTrackingNumbersInner (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert OrderShipmentAddTrackingNumbersInner to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      OrderShipmentAddTrackingNumbersInnerObject <- list()
      if (!is.null(self$`carrier_id`)) {
        OrderShipmentAddTrackingNumbersInnerObject[["carrier_id"]] <-
          self$`carrier_id`
      }
      if (!is.null(self$`tracking_number`)) {
        OrderShipmentAddTrackingNumbersInnerObject[["tracking_number"]] <-
          self$`tracking_number`
      }
      return(OrderShipmentAddTrackingNumbersInnerObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderShipmentAddTrackingNumbersInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderShipmentAddTrackingNumbersInner
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`carrier_id`)) {
        self$`carrier_id` <- this_object$`carrier_id`
      }
      if (!is.null(this_object$`tracking_number`)) {
        self$`tracking_number` <- this_object$`tracking_number`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return OrderShipmentAddTrackingNumbersInner in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderShipmentAddTrackingNumbersInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderShipmentAddTrackingNumbersInner
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`carrier_id` <- this_object$`carrier_id`
      self$`tracking_number` <- this_object$`tracking_number`
      self
    },

    #' @description
    #' Validate JSON input with respect to OrderShipmentAddTrackingNumbersInner and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of OrderShipmentAddTrackingNumbersInner
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# OrderShipmentAddTrackingNumbersInner$unlock()
#
## Below is an example to define the print function
# OrderShipmentAddTrackingNumbersInner$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# OrderShipmentAddTrackingNumbersInner$lock()

