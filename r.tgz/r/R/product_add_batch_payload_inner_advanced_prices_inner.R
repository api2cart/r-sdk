#' Create a new ProductAddBatchPayloadInnerAdvancedPricesInner
#'
#' @description
#' ProductAddBatchPayloadInnerAdvancedPricesInner Class
#'
#' @docType class
#' @title ProductAddBatchPayloadInnerAdvancedPricesInner
#' @description ProductAddBatchPayloadInnerAdvancedPricesInner Class
#' @format An \code{R6Class} generator object
#' @field value  numeric
#' @field group_id  integer [optional]
#' @field quantity  numeric
#' @field start_time  character [optional]
#' @field expire_time  character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductAddBatchPayloadInnerAdvancedPricesInner <- R6::R6Class(
  "ProductAddBatchPayloadInnerAdvancedPricesInner",
  public = list(
    `value` = NULL,
    `group_id` = NULL,
    `quantity` = NULL,
    `start_time` = NULL,
    `expire_time` = NULL,

    #' @description
    #' Initialize a new ProductAddBatchPayloadInnerAdvancedPricesInner class.
    #'
    #' @param value value
    #' @param quantity quantity
    #' @param group_id group_id
    #' @param start_time start_time
    #' @param expire_time expire_time
    #' @param ... Other optional arguments.
    initialize = function(`value`, `quantity`, `group_id` = NULL, `start_time` = NULL, `expire_time` = NULL, ...) {
      if (!missing(`value`)) {
        self$`value` <- `value`
      }
      if (!missing(`quantity`)) {
        self$`quantity` <- `quantity`
      }
      if (!is.null(`group_id`)) {
        if (!(is.numeric(`group_id`) && length(`group_id`) == 1)) {
          stop(paste("Error! Invalid data for `group_id`. Must be an integer:", `group_id`))
        }
        self$`group_id` <- `group_id`
      }
      if (!is.null(`start_time`)) {
        if (!(is.character(`start_time`) && length(`start_time`) == 1)) {
          stop(paste("Error! Invalid data for `start_time`. Must be a string:", `start_time`))
        }
        self$`start_time` <- `start_time`
      }
      if (!is.null(`expire_time`)) {
        if (!(is.character(`expire_time`) && length(`expire_time`) == 1)) {
          stop(paste("Error! Invalid data for `expire_time`. Must be a string:", `expire_time`))
        }
        self$`expire_time` <- `expire_time`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductAddBatchPayloadInnerAdvancedPricesInner as a base R list.
    #' @examples
    #' # convert array of ProductAddBatchPayloadInnerAdvancedPricesInner (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductAddBatchPayloadInnerAdvancedPricesInner to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductAddBatchPayloadInnerAdvancedPricesInnerObject <- list()
      if (!is.null(self$`value`)) {
        ProductAddBatchPayloadInnerAdvancedPricesInnerObject[["value"]] <-
          self$`value`
      }
      if (!is.null(self$`group_id`)) {
        ProductAddBatchPayloadInnerAdvancedPricesInnerObject[["group_id"]] <-
          self$`group_id`
      }
      if (!is.null(self$`quantity`)) {
        ProductAddBatchPayloadInnerAdvancedPricesInnerObject[["quantity"]] <-
          self$`quantity`
      }
      if (!is.null(self$`start_time`)) {
        ProductAddBatchPayloadInnerAdvancedPricesInnerObject[["start_time"]] <-
          self$`start_time`
      }
      if (!is.null(self$`expire_time`)) {
        ProductAddBatchPayloadInnerAdvancedPricesInnerObject[["expire_time"]] <-
          self$`expire_time`
      }
      return(ProductAddBatchPayloadInnerAdvancedPricesInnerObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductAddBatchPayloadInnerAdvancedPricesInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductAddBatchPayloadInnerAdvancedPricesInner
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`value`)) {
        self$`value` <- this_object$`value`
      }
      if (!is.null(this_object$`group_id`)) {
        self$`group_id` <- this_object$`group_id`
      }
      if (!is.null(this_object$`quantity`)) {
        self$`quantity` <- this_object$`quantity`
      }
      if (!is.null(this_object$`start_time`)) {
        self$`start_time` <- this_object$`start_time`
      }
      if (!is.null(this_object$`expire_time`)) {
        self$`expire_time` <- this_object$`expire_time`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductAddBatchPayloadInnerAdvancedPricesInner in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductAddBatchPayloadInnerAdvancedPricesInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductAddBatchPayloadInnerAdvancedPricesInner
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`value` <- this_object$`value`
      self$`group_id` <- this_object$`group_id`
      self$`quantity` <- this_object$`quantity`
      self$`start_time` <- this_object$`start_time`
      self$`expire_time` <- this_object$`expire_time`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductAddBatchPayloadInnerAdvancedPricesInner and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
      # check the required field `value`
      if (!is.null(input_json$`value`)) {
      } else {
        stop(paste("The JSON input `", input, "` is invalid for ProductAddBatchPayloadInnerAdvancedPricesInner: the required field `value` is missing."))
      }
      # check the required field `quantity`
      if (!is.null(input_json$`quantity`)) {
      } else {
        stop(paste("The JSON input `", input, "` is invalid for ProductAddBatchPayloadInnerAdvancedPricesInner: the required field `quantity` is missing."))
      }
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductAddBatchPayloadInnerAdvancedPricesInner
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      # check if the required `value` is null
      if (is.null(self$`value`)) {
        return(FALSE)
      }

      # check if the required `quantity` is null
      if (is.null(self$`quantity`)) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      # check if the required `value` is null
      if (is.null(self$`value`)) {
        invalid_fields["value"] <- "Non-nullable required field `value` cannot be null."
      }

      # check if the required `quantity` is null
      if (is.null(self$`quantity`)) {
        invalid_fields["quantity"] <- "Non-nullable required field `quantity` cannot be null."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductAddBatchPayloadInnerAdvancedPricesInner$unlock()
#
## Below is an example to define the print function
# ProductAddBatchPayloadInnerAdvancedPricesInner$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductAddBatchPayloadInnerAdvancedPricesInner$lock()

