#' Create a new ResponseAnalyticsReportResult
#'
#' @description
#' ResponseAnalyticsReportResult Class
#'
#' @docType class
#' @title ResponseAnalyticsReportResult
#' @description ResponseAnalyticsReportResult Class
#' @format An \code{R6Class} generator object
#' @field period  \link{AnalyticsPeriod} [optional]
#' @field total_metrics  \link{AnalyticsMetric} [optional]
#' @field intervals  list(\link{AnalyticsInterval}) [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ResponseAnalyticsReportResult <- R6::R6Class(
  "ResponseAnalyticsReportResult",
  public = list(
    `period` = NULL,
    `total_metrics` = NULL,
    `intervals` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new ResponseAnalyticsReportResult class.
    #'
    #' @param period period
    #' @param total_metrics total_metrics
    #' @param intervals intervals
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`period` = NULL, `total_metrics` = NULL, `intervals` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`period`)) {
        stopifnot(R6::is.R6(`period`))
        self$`period` <- `period`
      }
      if (!is.null(`total_metrics`)) {
        stopifnot(R6::is.R6(`total_metrics`))
        self$`total_metrics` <- `total_metrics`
      }
      if (!is.null(`intervals`)) {
        stopifnot(is.vector(`intervals`), length(`intervals`) != 0)
        sapply(`intervals`, function(x) stopifnot(R6::is.R6(x)))
        self$`intervals` <- `intervals`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ResponseAnalyticsReportResult as a base R list.
    #' @examples
    #' # convert array of ResponseAnalyticsReportResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ResponseAnalyticsReportResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ResponseAnalyticsReportResultObject <- list()
      if (!is.null(self$`period`)) {
        ResponseAnalyticsReportResultObject[["period"]] <-
          self$`period`$toSimpleType()
      }
      if (!is.null(self$`total_metrics`)) {
        ResponseAnalyticsReportResultObject[["total_metrics"]] <-
          self$`total_metrics`$toSimpleType()
      }
      if (!is.null(self$`intervals`)) {
        ResponseAnalyticsReportResultObject[["intervals"]] <-
          lapply(self$`intervals`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`additional_fields`)) {
        ResponseAnalyticsReportResultObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        ResponseAnalyticsReportResultObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(ResponseAnalyticsReportResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ResponseAnalyticsReportResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ResponseAnalyticsReportResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`period`)) {
        `period_object` <- AnalyticsPeriod$new()
        `period_object`$fromJSON(jsonlite::toJSON(this_object$`period`, auto_unbox = TRUE, digits = NA))
        self$`period` <- `period_object`
      }
      if (!is.null(this_object$`total_metrics`)) {
        `total_metrics_object` <- AnalyticsMetric$new()
        `total_metrics_object`$fromJSON(jsonlite::toJSON(this_object$`total_metrics`, auto_unbox = TRUE, digits = NA))
        self$`total_metrics` <- `total_metrics_object`
      }
      if (!is.null(this_object$`intervals`)) {
        self$`intervals` <- ApiClient$new()$deserializeObj(this_object$`intervals`, "array[AnalyticsInterval]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ResponseAnalyticsReportResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ResponseAnalyticsReportResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ResponseAnalyticsReportResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`period` <- AnalyticsPeriod$new()$fromJSON(jsonlite::toJSON(this_object$`period`, auto_unbox = TRUE, digits = NA))
      self$`total_metrics` <- AnalyticsMetric$new()$fromJSON(jsonlite::toJSON(this_object$`total_metrics`, auto_unbox = TRUE, digits = NA))
      self$`intervals` <- ApiClient$new()$deserializeObj(this_object$`intervals`, "array[AnalyticsInterval]", loadNamespace("openapi"))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to ResponseAnalyticsReportResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ResponseAnalyticsReportResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ResponseAnalyticsReportResult$unlock()
#
## Below is an example to define the print function
# ResponseAnalyticsReportResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ResponseAnalyticsReportResult$lock()

