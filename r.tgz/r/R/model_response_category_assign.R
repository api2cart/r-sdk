#' Create a new ModelResponseCategoryAssign
#'
#' @description
#' ModelResponseCategoryAssign Class
#'
#' @docType class
#' @title ModelResponseCategoryAssign
#' @description ModelResponseCategoryAssign Class
#' @format An \code{R6Class} generator object
#' @field return_code  integer [optional]
#' @field return_message  character [optional]
#' @field result  \link{ResponseCategoryAssignResult} [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ModelResponseCategoryAssign <- R6::R6Class(
  "ModelResponseCategoryAssign",
  public = list(
    `return_code` = NULL,
    `return_message` = NULL,
    `result` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new ModelResponseCategoryAssign class.
    #'
    #' @param return_code return_code
    #' @param return_message return_message
    #' @param result result
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`return_code` = NULL, `return_message` = NULL, `result` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`return_code`)) {
        if (!(is.numeric(`return_code`) && length(`return_code`) == 1)) {
          stop(paste("Error! Invalid data for `return_code`. Must be an integer:", `return_code`))
        }
        self$`return_code` <- `return_code`
      }
      if (!is.null(`return_message`)) {
        if (!(is.character(`return_message`) && length(`return_message`) == 1)) {
          stop(paste("Error! Invalid data for `return_message`. Must be a string:", `return_message`))
        }
        self$`return_message` <- `return_message`
      }
      if (!is.null(`result`)) {
        stopifnot(R6::is.R6(`result`))
        self$`result` <- `result`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ModelResponseCategoryAssign as a base R list.
    #' @examples
    #' # convert array of ModelResponseCategoryAssign (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ModelResponseCategoryAssign to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ModelResponseCategoryAssignObject <- list()
      if (!is.null(self$`return_code`)) {
        ModelResponseCategoryAssignObject[["return_code"]] <-
          self$`return_code`
      }
      if (!is.null(self$`return_message`)) {
        ModelResponseCategoryAssignObject[["return_message"]] <-
          self$`return_message`
      }
      if (!is.null(self$`result`)) {
        ModelResponseCategoryAssignObject[["result"]] <-
          self$`result`$toSimpleType()
      }
      if (!is.null(self$`additional_fields`)) {
        ModelResponseCategoryAssignObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        ModelResponseCategoryAssignObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(ModelResponseCategoryAssignObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ModelResponseCategoryAssign
    #'
    #' @param input_json the JSON input
    #' @return the instance of ModelResponseCategoryAssign
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`return_code`)) {
        self$`return_code` <- this_object$`return_code`
      }
      if (!is.null(this_object$`return_message`)) {
        self$`return_message` <- this_object$`return_message`
      }
      if (!is.null(this_object$`result`)) {
        `result_object` <- ResponseCategoryAssignResult$new()
        `result_object`$fromJSON(jsonlite::toJSON(this_object$`result`, auto_unbox = TRUE, digits = NA))
        self$`result` <- `result_object`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ModelResponseCategoryAssign in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ModelResponseCategoryAssign
    #'
    #' @param input_json the JSON input
    #' @return the instance of ModelResponseCategoryAssign
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`return_code` <- this_object$`return_code`
      self$`return_message` <- this_object$`return_message`
      self$`result` <- ResponseCategoryAssignResult$new()$fromJSON(jsonlite::toJSON(this_object$`result`, auto_unbox = TRUE, digits = NA))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to ModelResponseCategoryAssign and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ModelResponseCategoryAssign
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ModelResponseCategoryAssign$unlock()
#
## Below is an example to define the print function
# ModelResponseCategoryAssign$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ModelResponseCategoryAssign$lock()

