#' Create a new Discount
#'
#' @description
#' Discount Class
#'
#' @docType class
#' @title Discount
#' @description Discount Class
#' @format An \code{R6Class} generator object
#' @field id  character [optional]
#' @field name  character [optional]
#' @field modifier_type  character [optional]
#' @field value  numeric [optional]
#' @field from_time  character [optional]
#' @field to_time  character [optional]
#' @field customer_group_ids  character [optional]
#' @field sort_order  integer [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
Discount <- R6::R6Class(
  "Discount",
  public = list(
    `id` = NULL,
    `name` = NULL,
    `modifier_type` = NULL,
    `value` = NULL,
    `from_time` = NULL,
    `to_time` = NULL,
    `customer_group_ids` = NULL,
    `sort_order` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new Discount class.
    #'
    #' @param id id
    #' @param name name
    #' @param modifier_type modifier_type
    #' @param value value
    #' @param from_time from_time
    #' @param to_time to_time
    #' @param customer_group_ids customer_group_ids
    #' @param sort_order sort_order
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `name` = NULL, `modifier_type` = NULL, `value` = NULL, `from_time` = NULL, `to_time` = NULL, `customer_group_ids` = NULL, `sort_order` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`modifier_type`)) {
        if (!(is.character(`modifier_type`) && length(`modifier_type`) == 1)) {
          stop(paste("Error! Invalid data for `modifier_type`. Must be a string:", `modifier_type`))
        }
        self$`modifier_type` <- `modifier_type`
      }
      if (!is.null(`value`)) {
        self$`value` <- `value`
      }
      if (!is.null(`from_time`)) {
        if (!(is.character(`from_time`) && length(`from_time`) == 1)) {
          stop(paste("Error! Invalid data for `from_time`. Must be a string:", `from_time`))
        }
        self$`from_time` <- `from_time`
      }
      if (!is.null(`to_time`)) {
        if (!(is.character(`to_time`) && length(`to_time`) == 1)) {
          stop(paste("Error! Invalid data for `to_time`. Must be a string:", `to_time`))
        }
        self$`to_time` <- `to_time`
      }
      if (!is.null(`customer_group_ids`)) {
        if (!(is.character(`customer_group_ids`) && length(`customer_group_ids`) == 1)) {
          stop(paste("Error! Invalid data for `customer_group_ids`. Must be a string:", `customer_group_ids`))
        }
        self$`customer_group_ids` <- `customer_group_ids`
      }
      if (!is.null(`sort_order`)) {
        if (!(is.numeric(`sort_order`) && length(`sort_order`) == 1)) {
          stop(paste("Error! Invalid data for `sort_order`. Must be an integer:", `sort_order`))
        }
        self$`sort_order` <- `sort_order`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return Discount as a base R list.
    #' @examples
    #' # convert array of Discount (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert Discount to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      DiscountObject <- list()
      if (!is.null(self$`id`)) {
        DiscountObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`name`)) {
        DiscountObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`modifier_type`)) {
        DiscountObject[["modifier_type"]] <-
          self$`modifier_type`
      }
      if (!is.null(self$`value`)) {
        DiscountObject[["value"]] <-
          self$`value`
      }
      if (!is.null(self$`from_time`)) {
        DiscountObject[["from_time"]] <-
          self$`from_time`
      }
      if (!is.null(self$`to_time`)) {
        DiscountObject[["to_time"]] <-
          self$`to_time`
      }
      if (!is.null(self$`customer_group_ids`)) {
        DiscountObject[["customer_group_ids"]] <-
          self$`customer_group_ids`
      }
      if (!is.null(self$`sort_order`)) {
        DiscountObject[["sort_order"]] <-
          self$`sort_order`
      }
      if (!is.null(self$`additional_fields`)) {
        DiscountObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        DiscountObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(DiscountObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of Discount
    #'
    #' @param input_json the JSON input
    #' @return the instance of Discount
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`modifier_type`)) {
        self$`modifier_type` <- this_object$`modifier_type`
      }
      if (!is.null(this_object$`value`)) {
        self$`value` <- this_object$`value`
      }
      if (!is.null(this_object$`from_time`)) {
        self$`from_time` <- this_object$`from_time`
      }
      if (!is.null(this_object$`to_time`)) {
        self$`to_time` <- this_object$`to_time`
      }
      if (!is.null(this_object$`customer_group_ids`)) {
        self$`customer_group_ids` <- this_object$`customer_group_ids`
      }
      if (!is.null(this_object$`sort_order`)) {
        self$`sort_order` <- this_object$`sort_order`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return Discount in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of Discount
    #'
    #' @param input_json the JSON input
    #' @return the instance of Discount
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`name` <- this_object$`name`
      self$`modifier_type` <- this_object$`modifier_type`
      self$`value` <- this_object$`value`
      self$`from_time` <- this_object$`from_time`
      self$`to_time` <- this_object$`to_time`
      self$`customer_group_ids` <- this_object$`customer_group_ids`
      self$`sort_order` <- this_object$`sort_order`
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to Discount and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of Discount
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# Discount$unlock()
#
## Below is an example to define the print function
# Discount$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# Discount$lock()

