#' Create a new CartCouponAdd
#'
#' @description
#' CartCouponAdd Class
#'
#' @docType class
#' @title CartCouponAdd
#' @description CartCouponAdd Class
#' @format An \code{R6Class} generator object
#' @field code Coupon code character
#' @field action_type Coupon discount type character
#' @field action_apply_to Defines where discount should be applied character
#' @field action_scope Specify how discount should be applied. If scope=matching_items, then discount will be applied to each of the items that match action conditions. Scope order means that discount will be applied once. character
#' @field action_amount Defines the discount amount value. numeric
#' @field codes Entity codes list(character) [optional]
#' @field name Coupon name character [optional]
#' @field date_start Date start character [optional]
#' @field date_end Defines when discount code will be expired. character [optional]
#' @field usage_limit Usage limit for coupon. integer [optional]
#' @field usage_limit_per_customer Usage limit per customer. integer [optional]
#' @field action_condition_entity Defines entity for action condition. character [optional]
#' @field action_condition_key Defines entity attribute code for action condition. character [optional]
#' @field action_condition_operator Defines condition operator. character [optional]
#' @field action_condition_value Defines condition attribute value/s. Can be comma separated string. character [optional]
#' @field include_tax Indicates whether to apply a discount for taxes. character [optional]
#' @field store_id Store Id character [optional]
#' @field free_cash_on_delivery Defines whether the coupon provides free cash on delivery character [optional]
#' @field customer_id Retrieves orders specified by customer id character [optional]
#' @field idempotency_key A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong> character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
CartCouponAdd <- R6::R6Class(
  "CartCouponAdd",
  public = list(
    `code` = NULL,
    `action_type` = NULL,
    `action_apply_to` = NULL,
    `action_scope` = NULL,
    `action_amount` = NULL,
    `codes` = NULL,
    `name` = NULL,
    `date_start` = NULL,
    `date_end` = NULL,
    `usage_limit` = NULL,
    `usage_limit_per_customer` = NULL,
    `action_condition_entity` = NULL,
    `action_condition_key` = NULL,
    `action_condition_operator` = NULL,
    `action_condition_value` = NULL,
    `include_tax` = NULL,
    `store_id` = NULL,
    `free_cash_on_delivery` = NULL,
    `customer_id` = NULL,
    `idempotency_key` = NULL,

    #' @description
    #' Initialize a new CartCouponAdd class.
    #'
    #' @param code Coupon code
    #' @param action_type Coupon discount type
    #' @param action_apply_to Defines where discount should be applied
    #' @param action_scope Specify how discount should be applied. If scope=matching_items, then discount will be applied to each of the items that match action conditions. Scope order means that discount will be applied once.
    #' @param action_amount Defines the discount amount value.
    #' @param codes Entity codes
    #' @param name Coupon name
    #' @param date_start Date start. Default to "now".
    #' @param date_end Defines when discount code will be expired.
    #' @param usage_limit Usage limit for coupon.
    #' @param usage_limit_per_customer Usage limit per customer.
    #' @param action_condition_entity Defines entity for action condition.
    #' @param action_condition_key Defines entity attribute code for action condition.
    #' @param action_condition_operator Defines condition operator.
    #' @param action_condition_value Defines condition attribute value/s. Can be comma separated string.
    #' @param include_tax Indicates whether to apply a discount for taxes.. Default to FALSE.
    #' @param store_id Store Id
    #' @param free_cash_on_delivery Defines whether the coupon provides free cash on delivery
    #' @param customer_id Retrieves orders specified by customer id
    #' @param idempotency_key A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong>
    #' @param ... Other optional arguments.
    initialize = function(`code`, `action_type`, `action_apply_to`, `action_scope`, `action_amount`, `codes` = NULL, `name` = NULL, `date_start` = "now", `date_end` = NULL, `usage_limit` = NULL, `usage_limit_per_customer` = NULL, `action_condition_entity` = NULL, `action_condition_key` = NULL, `action_condition_operator` = NULL, `action_condition_value` = NULL, `include_tax` = FALSE, `store_id` = NULL, `free_cash_on_delivery` = NULL, `customer_id` = NULL, `idempotency_key` = NULL, ...) {
      if (!missing(`code`)) {
        if (!(is.character(`code`) && length(`code`) == 1)) {
          stop(paste("Error! Invalid data for `code`. Must be a string:", `code`))
        }
        self$`code` <- `code`
      }
      if (!missing(`action_type`)) {
        if (!(`action_type` %in% c("percent", "fixed"))) {
          stop(paste("Error! \"", `action_type`, "\" cannot be assigned to `action_type`. Must be \"percent\", \"fixed\".", sep = ""))
        }
        if (!(is.character(`action_type`) && length(`action_type`) == 1)) {
          stop(paste("Error! Invalid data for `action_type`. Must be a string:", `action_type`))
        }
        self$`action_type` <- `action_type`
      }
      if (!missing(`action_apply_to`)) {
        if (!(`action_apply_to` %in% c("order_total", "item_price", "shipping"))) {
          stop(paste("Error! \"", `action_apply_to`, "\" cannot be assigned to `action_apply_to`. Must be \"order_total\", \"item_price\", \"shipping\".", sep = ""))
        }
        if (!(is.character(`action_apply_to`) && length(`action_apply_to`) == 1)) {
          stop(paste("Error! Invalid data for `action_apply_to`. Must be a string:", `action_apply_to`))
        }
        self$`action_apply_to` <- `action_apply_to`
      }
      if (!missing(`action_scope`)) {
        if (!(`action_scope` %in% c("order", "matching_items"))) {
          stop(paste("Error! \"", `action_scope`, "\" cannot be assigned to `action_scope`. Must be \"order\", \"matching_items\".", sep = ""))
        }
        if (!(is.character(`action_scope`) && length(`action_scope`) == 1)) {
          stop(paste("Error! Invalid data for `action_scope`. Must be a string:", `action_scope`))
        }
        self$`action_scope` <- `action_scope`
      }
      if (!missing(`action_amount`)) {
        self$`action_amount` <- `action_amount`
      }
      if (!is.null(`codes`)) {
        stopifnot(is.vector(`codes`), length(`codes`) != 0)
        sapply(`codes`, function(x) stopifnot(is.character(x)))
        self$`codes` <- `codes`
      }
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`date_start`)) {
        if (!(is.character(`date_start`) && length(`date_start`) == 1)) {
          stop(paste("Error! Invalid data for `date_start`. Must be a string:", `date_start`))
        }
        self$`date_start` <- `date_start`
      }
      if (!is.null(`date_end`)) {
        if (!(is.character(`date_end`) && length(`date_end`) == 1)) {
          stop(paste("Error! Invalid data for `date_end`. Must be a string:", `date_end`))
        }
        self$`date_end` <- `date_end`
      }
      if (!is.null(`usage_limit`)) {
        if (!(is.numeric(`usage_limit`) && length(`usage_limit`) == 1)) {
          stop(paste("Error! Invalid data for `usage_limit`. Must be an integer:", `usage_limit`))
        }
        self$`usage_limit` <- `usage_limit`
      }
      if (!is.null(`usage_limit_per_customer`)) {
        if (!(is.numeric(`usage_limit_per_customer`) && length(`usage_limit_per_customer`) == 1)) {
          stop(paste("Error! Invalid data for `usage_limit_per_customer`. Must be an integer:", `usage_limit_per_customer`))
        }
        self$`usage_limit_per_customer` <- `usage_limit_per_customer`
      }
      if (!is.null(`action_condition_entity`)) {
        if (!(is.character(`action_condition_entity`) && length(`action_condition_entity`) == 1)) {
          stop(paste("Error! Invalid data for `action_condition_entity`. Must be a string:", `action_condition_entity`))
        }
        self$`action_condition_entity` <- `action_condition_entity`
      }
      if (!is.null(`action_condition_key`)) {
        if (!(is.character(`action_condition_key`) && length(`action_condition_key`) == 1)) {
          stop(paste("Error! Invalid data for `action_condition_key`. Must be a string:", `action_condition_key`))
        }
        self$`action_condition_key` <- `action_condition_key`
      }
      if (!is.null(`action_condition_operator`)) {
        if (!(is.character(`action_condition_operator`) && length(`action_condition_operator`) == 1)) {
          stop(paste("Error! Invalid data for `action_condition_operator`. Must be a string:", `action_condition_operator`))
        }
        self$`action_condition_operator` <- `action_condition_operator`
      }
      if (!is.null(`action_condition_value`)) {
        if (!(is.character(`action_condition_value`) && length(`action_condition_value`) == 1)) {
          stop(paste("Error! Invalid data for `action_condition_value`. Must be a string:", `action_condition_value`))
        }
        self$`action_condition_value` <- `action_condition_value`
      }
      if (!is.null(`include_tax`)) {
        if (!(is.logical(`include_tax`) && length(`include_tax`) == 1)) {
          stop(paste("Error! Invalid data for `include_tax`. Must be a boolean:", `include_tax`))
        }
        self$`include_tax` <- `include_tax`
      }
      if (!is.null(`store_id`)) {
        if (!(is.character(`store_id`) && length(`store_id`) == 1)) {
          stop(paste("Error! Invalid data for `store_id`. Must be a string:", `store_id`))
        }
        self$`store_id` <- `store_id`
      }
      if (!is.null(`free_cash_on_delivery`)) {
        if (!(is.logical(`free_cash_on_delivery`) && length(`free_cash_on_delivery`) == 1)) {
          stop(paste("Error! Invalid data for `free_cash_on_delivery`. Must be a boolean:", `free_cash_on_delivery`))
        }
        self$`free_cash_on_delivery` <- `free_cash_on_delivery`
      }
      if (!is.null(`customer_id`)) {
        if (!(is.character(`customer_id`) && length(`customer_id`) == 1)) {
          stop(paste("Error! Invalid data for `customer_id`. Must be a string:", `customer_id`))
        }
        self$`customer_id` <- `customer_id`
      }
      if (!is.null(`idempotency_key`)) {
        if (!(is.character(`idempotency_key`) && length(`idempotency_key`) == 1)) {
          stop(paste("Error! Invalid data for `idempotency_key`. Must be a string:", `idempotency_key`))
        }
        self$`idempotency_key` <- `idempotency_key`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return CartCouponAdd as a base R list.
    #' @examples
    #' # convert array of CartCouponAdd (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert CartCouponAdd to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      CartCouponAddObject <- list()
      if (!is.null(self$`code`)) {
        CartCouponAddObject[["code"]] <-
          self$`code`
      }
      if (!is.null(self$`action_type`)) {
        CartCouponAddObject[["action_type"]] <-
          self$`action_type`
      }
      if (!is.null(self$`action_apply_to`)) {
        CartCouponAddObject[["action_apply_to"]] <-
          self$`action_apply_to`
      }
      if (!is.null(self$`action_scope`)) {
        CartCouponAddObject[["action_scope"]] <-
          self$`action_scope`
      }
      if (!is.null(self$`action_amount`)) {
        CartCouponAddObject[["action_amount"]] <-
          self$`action_amount`
      }
      if (!is.null(self$`codes`)) {
        CartCouponAddObject[["codes"]] <-
          self$`codes`
      }
      if (!is.null(self$`name`)) {
        CartCouponAddObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`date_start`)) {
        CartCouponAddObject[["date_start"]] <-
          self$`date_start`
      }
      if (!is.null(self$`date_end`)) {
        CartCouponAddObject[["date_end"]] <-
          self$`date_end`
      }
      if (!is.null(self$`usage_limit`)) {
        CartCouponAddObject[["usage_limit"]] <-
          self$`usage_limit`
      }
      if (!is.null(self$`usage_limit_per_customer`)) {
        CartCouponAddObject[["usage_limit_per_customer"]] <-
          self$`usage_limit_per_customer`
      }
      if (!is.null(self$`action_condition_entity`)) {
        CartCouponAddObject[["action_condition_entity"]] <-
          self$`action_condition_entity`
      }
      if (!is.null(self$`action_condition_key`)) {
        CartCouponAddObject[["action_condition_key"]] <-
          self$`action_condition_key`
      }
      if (!is.null(self$`action_condition_operator`)) {
        CartCouponAddObject[["action_condition_operator"]] <-
          self$`action_condition_operator`
      }
      if (!is.null(self$`action_condition_value`)) {
        CartCouponAddObject[["action_condition_value"]] <-
          self$`action_condition_value`
      }
      if (!is.null(self$`include_tax`)) {
        CartCouponAddObject[["include_tax"]] <-
          self$`include_tax`
      }
      if (!is.null(self$`store_id`)) {
        CartCouponAddObject[["store_id"]] <-
          self$`store_id`
      }
      if (!is.null(self$`free_cash_on_delivery`)) {
        CartCouponAddObject[["free_cash_on_delivery"]] <-
          self$`free_cash_on_delivery`
      }
      if (!is.null(self$`customer_id`)) {
        CartCouponAddObject[["customer_id"]] <-
          self$`customer_id`
      }
      if (!is.null(self$`idempotency_key`)) {
        CartCouponAddObject[["idempotency_key"]] <-
          self$`idempotency_key`
      }
      return(CartCouponAddObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of CartCouponAdd
    #'
    #' @param input_json the JSON input
    #' @return the instance of CartCouponAdd
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`code`)) {
        self$`code` <- this_object$`code`
      }
      if (!is.null(this_object$`action_type`)) {
        if (!is.null(this_object$`action_type`) && !(this_object$`action_type` %in% c("percent", "fixed"))) {
          stop(paste("Error! \"", this_object$`action_type`, "\" cannot be assigned to `action_type`. Must be \"percent\", \"fixed\".", sep = ""))
        }
        self$`action_type` <- this_object$`action_type`
      }
      if (!is.null(this_object$`action_apply_to`)) {
        if (!is.null(this_object$`action_apply_to`) && !(this_object$`action_apply_to` %in% c("order_total", "item_price", "shipping"))) {
          stop(paste("Error! \"", this_object$`action_apply_to`, "\" cannot be assigned to `action_apply_to`. Must be \"order_total\", \"item_price\", \"shipping\".", sep = ""))
        }
        self$`action_apply_to` <- this_object$`action_apply_to`
      }
      if (!is.null(this_object$`action_scope`)) {
        if (!is.null(this_object$`action_scope`) && !(this_object$`action_scope` %in% c("order", "matching_items"))) {
          stop(paste("Error! \"", this_object$`action_scope`, "\" cannot be assigned to `action_scope`. Must be \"order\", \"matching_items\".", sep = ""))
        }
        self$`action_scope` <- this_object$`action_scope`
      }
      if (!is.null(this_object$`action_amount`)) {
        self$`action_amount` <- this_object$`action_amount`
      }
      if (!is.null(this_object$`codes`)) {
        self$`codes` <- ApiClient$new()$deserializeObj(this_object$`codes`, "array[character]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`date_start`)) {
        self$`date_start` <- this_object$`date_start`
      }
      if (!is.null(this_object$`date_end`)) {
        self$`date_end` <- this_object$`date_end`
      }
      if (!is.null(this_object$`usage_limit`)) {
        self$`usage_limit` <- this_object$`usage_limit`
      }
      if (!is.null(this_object$`usage_limit_per_customer`)) {
        self$`usage_limit_per_customer` <- this_object$`usage_limit_per_customer`
      }
      if (!is.null(this_object$`action_condition_entity`)) {
        self$`action_condition_entity` <- this_object$`action_condition_entity`
      }
      if (!is.null(this_object$`action_condition_key`)) {
        self$`action_condition_key` <- this_object$`action_condition_key`
      }
      if (!is.null(this_object$`action_condition_operator`)) {
        self$`action_condition_operator` <- this_object$`action_condition_operator`
      }
      if (!is.null(this_object$`action_condition_value`)) {
        self$`action_condition_value` <- this_object$`action_condition_value`
      }
      if (!is.null(this_object$`include_tax`)) {
        self$`include_tax` <- this_object$`include_tax`
      }
      if (!is.null(this_object$`store_id`)) {
        self$`store_id` <- this_object$`store_id`
      }
      if (!is.null(this_object$`free_cash_on_delivery`)) {
        self$`free_cash_on_delivery` <- this_object$`free_cash_on_delivery`
      }
      if (!is.null(this_object$`customer_id`)) {
        self$`customer_id` <- this_object$`customer_id`
      }
      if (!is.null(this_object$`idempotency_key`)) {
        self$`idempotency_key` <- this_object$`idempotency_key`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return CartCouponAdd in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of CartCouponAdd
    #'
    #' @param input_json the JSON input
    #' @return the instance of CartCouponAdd
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`code` <- this_object$`code`
      if (!is.null(this_object$`action_type`) && !(this_object$`action_type` %in% c("percent", "fixed"))) {
        stop(paste("Error! \"", this_object$`action_type`, "\" cannot be assigned to `action_type`. Must be \"percent\", \"fixed\".", sep = ""))
      }
      self$`action_type` <- this_object$`action_type`
      if (!is.null(this_object$`action_apply_to`) && !(this_object$`action_apply_to` %in% c("order_total", "item_price", "shipping"))) {
        stop(paste("Error! \"", this_object$`action_apply_to`, "\" cannot be assigned to `action_apply_to`. Must be \"order_total\", \"item_price\", \"shipping\".", sep = ""))
      }
      self$`action_apply_to` <- this_object$`action_apply_to`
      if (!is.null(this_object$`action_scope`) && !(this_object$`action_scope` %in% c("order", "matching_items"))) {
        stop(paste("Error! \"", this_object$`action_scope`, "\" cannot be assigned to `action_scope`. Must be \"order\", \"matching_items\".", sep = ""))
      }
      self$`action_scope` <- this_object$`action_scope`
      self$`action_amount` <- this_object$`action_amount`
      self$`codes` <- ApiClient$new()$deserializeObj(this_object$`codes`, "array[character]", loadNamespace("openapi"))
      self$`name` <- this_object$`name`
      self$`date_start` <- this_object$`date_start`
      self$`date_end` <- this_object$`date_end`
      self$`usage_limit` <- this_object$`usage_limit`
      self$`usage_limit_per_customer` <- this_object$`usage_limit_per_customer`
      self$`action_condition_entity` <- this_object$`action_condition_entity`
      self$`action_condition_key` <- this_object$`action_condition_key`
      self$`action_condition_operator` <- this_object$`action_condition_operator`
      self$`action_condition_value` <- this_object$`action_condition_value`
      self$`include_tax` <- this_object$`include_tax`
      self$`store_id` <- this_object$`store_id`
      self$`free_cash_on_delivery` <- this_object$`free_cash_on_delivery`
      self$`customer_id` <- this_object$`customer_id`
      self$`idempotency_key` <- this_object$`idempotency_key`
      self
    },

    #' @description
    #' Validate JSON input with respect to CartCouponAdd and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
      # check the required field `code`
      if (!is.null(input_json$`code`)) {
        if (!(is.character(input_json$`code`) && length(input_json$`code`) == 1)) {
          stop(paste("Error! Invalid data for `code`. Must be a string:", input_json$`code`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for CartCouponAdd: the required field `code` is missing."))
      }
      # check the required field `action_type`
      if (!is.null(input_json$`action_type`)) {
        if (!(is.character(input_json$`action_type`) && length(input_json$`action_type`) == 1)) {
          stop(paste("Error! Invalid data for `action_type`. Must be a string:", input_json$`action_type`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for CartCouponAdd: the required field `action_type` is missing."))
      }
      # check the required field `action_apply_to`
      if (!is.null(input_json$`action_apply_to`)) {
        if (!(is.character(input_json$`action_apply_to`) && length(input_json$`action_apply_to`) == 1)) {
          stop(paste("Error! Invalid data for `action_apply_to`. Must be a string:", input_json$`action_apply_to`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for CartCouponAdd: the required field `action_apply_to` is missing."))
      }
      # check the required field `action_scope`
      if (!is.null(input_json$`action_scope`)) {
        if (!(is.character(input_json$`action_scope`) && length(input_json$`action_scope`) == 1)) {
          stop(paste("Error! Invalid data for `action_scope`. Must be a string:", input_json$`action_scope`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for CartCouponAdd: the required field `action_scope` is missing."))
      }
      # check the required field `action_amount`
      if (!is.null(input_json$`action_amount`)) {
      } else {
        stop(paste("The JSON input `", input, "` is invalid for CartCouponAdd: the required field `action_amount` is missing."))
      }
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of CartCouponAdd
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      # check if the required `code` is null
      if (is.null(self$`code`)) {
        return(FALSE)
      }

      # check if the required `action_type` is null
      if (is.null(self$`action_type`)) {
        return(FALSE)
      }

      # check if the required `action_apply_to` is null
      if (is.null(self$`action_apply_to`)) {
        return(FALSE)
      }

      # check if the required `action_scope` is null
      if (is.null(self$`action_scope`)) {
        return(FALSE)
      }

      # check if the required `action_amount` is null
      if (is.null(self$`action_amount`)) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      # check if the required `code` is null
      if (is.null(self$`code`)) {
        invalid_fields["code"] <- "Non-nullable required field `code` cannot be null."
      }

      # check if the required `action_type` is null
      if (is.null(self$`action_type`)) {
        invalid_fields["action_type"] <- "Non-nullable required field `action_type` cannot be null."
      }

      # check if the required `action_apply_to` is null
      if (is.null(self$`action_apply_to`)) {
        invalid_fields["action_apply_to"] <- "Non-nullable required field `action_apply_to` cannot be null."
      }

      # check if the required `action_scope` is null
      if (is.null(self$`action_scope`)) {
        invalid_fields["action_scope"] <- "Non-nullable required field `action_scope` cannot be null."
      }

      # check if the required `action_amount` is null
      if (is.null(self$`action_amount`)) {
        invalid_fields["action_amount"] <- "Non-nullable required field `action_amount` cannot be null."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# CartCouponAdd$unlock()
#
## Below is an example to define the print function
# CartCouponAdd$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# CartCouponAdd$lock()

