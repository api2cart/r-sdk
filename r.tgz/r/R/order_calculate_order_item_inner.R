#' Create a new OrderCalculateOrderItemInner
#'
#' @description
#' OrderCalculateOrderItemInner Class
#'
#' @docType class
#' @title OrderCalculateOrderItemInner
#' @description OrderCalculateOrderItemInner Class
#' @format An \code{R6Class} generator object
#' @field order_item_id Defines orders specified by order item id character
#' @field order_item_quantity Defines orders specified by order item quantity integer
#' @field order_item_variant_id Ordered product variant. Where x is order item ID character [optional]
#' @field order_item_parent Index of the parent grouped/bundle product integer [optional]
#' @field order_item_parent_option_name Option name of the parent grouped/bundle product character [optional]
#' @field order_item_option  list(\link{OrderCalculateOrderItemInnerOrderItemOptionInner}) [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
OrderCalculateOrderItemInner <- R6::R6Class(
  "OrderCalculateOrderItemInner",
  public = list(
    `order_item_id` = NULL,
    `order_item_quantity` = NULL,
    `order_item_variant_id` = NULL,
    `order_item_parent` = NULL,
    `order_item_parent_option_name` = NULL,
    `order_item_option` = NULL,

    #' @description
    #' Initialize a new OrderCalculateOrderItemInner class.
    #'
    #' @param order_item_id Defines orders specified by order item id
    #' @param order_item_quantity Defines orders specified by order item quantity
    #' @param order_item_variant_id Ordered product variant. Where x is order item ID
    #' @param order_item_parent Index of the parent grouped/bundle product
    #' @param order_item_parent_option_name Option name of the parent grouped/bundle product
    #' @param order_item_option order_item_option
    #' @param ... Other optional arguments.
    initialize = function(`order_item_id`, `order_item_quantity`, `order_item_variant_id` = NULL, `order_item_parent` = NULL, `order_item_parent_option_name` = NULL, `order_item_option` = NULL, ...) {
      if (!missing(`order_item_id`)) {
        if (!(is.character(`order_item_id`) && length(`order_item_id`) == 1)) {
          stop(paste("Error! Invalid data for `order_item_id`. Must be a string:", `order_item_id`))
        }
        self$`order_item_id` <- `order_item_id`
      }
      if (!missing(`order_item_quantity`)) {
        if (!(is.numeric(`order_item_quantity`) && length(`order_item_quantity`) == 1)) {
          stop(paste("Error! Invalid data for `order_item_quantity`. Must be an integer:", `order_item_quantity`))
        }
        self$`order_item_quantity` <- `order_item_quantity`
      }
      if (!is.null(`order_item_variant_id`)) {
        if (!(is.character(`order_item_variant_id`) && length(`order_item_variant_id`) == 1)) {
          stop(paste("Error! Invalid data for `order_item_variant_id`. Must be a string:", `order_item_variant_id`))
        }
        self$`order_item_variant_id` <- `order_item_variant_id`
      }
      if (!is.null(`order_item_parent`)) {
        if (!(is.numeric(`order_item_parent`) && length(`order_item_parent`) == 1)) {
          stop(paste("Error! Invalid data for `order_item_parent`. Must be an integer:", `order_item_parent`))
        }
        self$`order_item_parent` <- `order_item_parent`
      }
      if (!is.null(`order_item_parent_option_name`)) {
        if (!(is.character(`order_item_parent_option_name`) && length(`order_item_parent_option_name`) == 1)) {
          stop(paste("Error! Invalid data for `order_item_parent_option_name`. Must be a string:", `order_item_parent_option_name`))
        }
        self$`order_item_parent_option_name` <- `order_item_parent_option_name`
      }
      if (!is.null(`order_item_option`)) {
        stopifnot(is.vector(`order_item_option`), length(`order_item_option`) != 0)
        sapply(`order_item_option`, function(x) stopifnot(R6::is.R6(x)))
        self$`order_item_option` <- `order_item_option`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return OrderCalculateOrderItemInner as a base R list.
    #' @examples
    #' # convert array of OrderCalculateOrderItemInner (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert OrderCalculateOrderItemInner to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      OrderCalculateOrderItemInnerObject <- list()
      if (!is.null(self$`order_item_id`)) {
        OrderCalculateOrderItemInnerObject[["order_item_id"]] <-
          self$`order_item_id`
      }
      if (!is.null(self$`order_item_quantity`)) {
        OrderCalculateOrderItemInnerObject[["order_item_quantity"]] <-
          self$`order_item_quantity`
      }
      if (!is.null(self$`order_item_variant_id`)) {
        OrderCalculateOrderItemInnerObject[["order_item_variant_id"]] <-
          self$`order_item_variant_id`
      }
      if (!is.null(self$`order_item_parent`)) {
        OrderCalculateOrderItemInnerObject[["order_item_parent"]] <-
          self$`order_item_parent`
      }
      if (!is.null(self$`order_item_parent_option_name`)) {
        OrderCalculateOrderItemInnerObject[["order_item_parent_option_name"]] <-
          self$`order_item_parent_option_name`
      }
      if (!is.null(self$`order_item_option`)) {
        OrderCalculateOrderItemInnerObject[["order_item_option"]] <-
          lapply(self$`order_item_option`, function(x) x$toSimpleType())
      }
      return(OrderCalculateOrderItemInnerObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderCalculateOrderItemInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderCalculateOrderItemInner
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`order_item_id`)) {
        self$`order_item_id` <- this_object$`order_item_id`
      }
      if (!is.null(this_object$`order_item_quantity`)) {
        self$`order_item_quantity` <- this_object$`order_item_quantity`
      }
      if (!is.null(this_object$`order_item_variant_id`)) {
        self$`order_item_variant_id` <- this_object$`order_item_variant_id`
      }
      if (!is.null(this_object$`order_item_parent`)) {
        self$`order_item_parent` <- this_object$`order_item_parent`
      }
      if (!is.null(this_object$`order_item_parent_option_name`)) {
        self$`order_item_parent_option_name` <- this_object$`order_item_parent_option_name`
      }
      if (!is.null(this_object$`order_item_option`)) {
        self$`order_item_option` <- ApiClient$new()$deserializeObj(this_object$`order_item_option`, "array[OrderCalculateOrderItemInnerOrderItemOptionInner]", loadNamespace("openapi"))
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return OrderCalculateOrderItemInner in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderCalculateOrderItemInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderCalculateOrderItemInner
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`order_item_id` <- this_object$`order_item_id`
      self$`order_item_quantity` <- this_object$`order_item_quantity`
      self$`order_item_variant_id` <- this_object$`order_item_variant_id`
      self$`order_item_parent` <- this_object$`order_item_parent`
      self$`order_item_parent_option_name` <- this_object$`order_item_parent_option_name`
      self$`order_item_option` <- ApiClient$new()$deserializeObj(this_object$`order_item_option`, "array[OrderCalculateOrderItemInnerOrderItemOptionInner]", loadNamespace("openapi"))
      self
    },

    #' @description
    #' Validate JSON input with respect to OrderCalculateOrderItemInner and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
      # check the required field `order_item_id`
      if (!is.null(input_json$`order_item_id`)) {
        if (!(is.character(input_json$`order_item_id`) && length(input_json$`order_item_id`) == 1)) {
          stop(paste("Error! Invalid data for `order_item_id`. Must be a string:", input_json$`order_item_id`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for OrderCalculateOrderItemInner: the required field `order_item_id` is missing."))
      }
      # check the required field `order_item_quantity`
      if (!is.null(input_json$`order_item_quantity`)) {
        if (!(is.numeric(input_json$`order_item_quantity`) && length(input_json$`order_item_quantity`) == 1)) {
          stop(paste("Error! Invalid data for `order_item_quantity`. Must be an integer:", input_json$`order_item_quantity`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for OrderCalculateOrderItemInner: the required field `order_item_quantity` is missing."))
      }
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of OrderCalculateOrderItemInner
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      # check if the required `order_item_id` is null
      if (is.null(self$`order_item_id`)) {
        return(FALSE)
      }

      # check if the required `order_item_quantity` is null
      if (is.null(self$`order_item_quantity`)) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      # check if the required `order_item_id` is null
      if (is.null(self$`order_item_id`)) {
        invalid_fields["order_item_id"] <- "Non-nullable required field `order_item_id` cannot be null."
      }

      # check if the required `order_item_quantity` is null
      if (is.null(self$`order_item_quantity`)) {
        invalid_fields["order_item_quantity"] <- "Non-nullable required field `order_item_quantity` cannot be null."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# OrderCalculateOrderItemInner$unlock()
#
## Below is an example to define the print function
# OrderCalculateOrderItemInner$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# OrderCalculateOrderItemInner$lock()

