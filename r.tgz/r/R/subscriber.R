#' Create a new Subscriber
#'
#' @description
#' Subscriber Class
#'
#' @docType class
#' @title Subscriber
#' @description Subscriber Class
#' @format An \code{R6Class} generator object
#' @field id  character [optional]
#' @field customer_id  character [optional]
#' @field email  character [optional]
#' @field subscribed  character [optional]
#' @field first_name  character [optional]
#' @field last_name  character [optional]
#' @field stores_ids  list(character) [optional]
#' @field created_time  character [optional]
#' @field modified_time  character [optional]
#' @field lang_id  character [optional]
#' @field gender  character [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
Subscriber <- R6::R6Class(
  "Subscriber",
  public = list(
    `id` = NULL,
    `customer_id` = NULL,
    `email` = NULL,
    `subscribed` = NULL,
    `first_name` = NULL,
    `last_name` = NULL,
    `stores_ids` = NULL,
    `created_time` = NULL,
    `modified_time` = NULL,
    `lang_id` = NULL,
    `gender` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new Subscriber class.
    #'
    #' @param id id
    #' @param customer_id customer_id
    #' @param email email
    #' @param subscribed subscribed
    #' @param first_name first_name
    #' @param last_name last_name
    #' @param stores_ids stores_ids
    #' @param created_time created_time
    #' @param modified_time modified_time
    #' @param lang_id lang_id
    #' @param gender gender
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `customer_id` = NULL, `email` = NULL, `subscribed` = NULL, `first_name` = NULL, `last_name` = NULL, `stores_ids` = NULL, `created_time` = NULL, `modified_time` = NULL, `lang_id` = NULL, `gender` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`customer_id`)) {
        if (!(is.character(`customer_id`) && length(`customer_id`) == 1)) {
          stop(paste("Error! Invalid data for `customer_id`. Must be a string:", `customer_id`))
        }
        self$`customer_id` <- `customer_id`
      }
      if (!is.null(`email`)) {
        if (!(is.character(`email`) && length(`email`) == 1)) {
          stop(paste("Error! Invalid data for `email`. Must be a string:", `email`))
        }
        self$`email` <- `email`
      }
      if (!is.null(`subscribed`)) {
        if (!(is.logical(`subscribed`) && length(`subscribed`) == 1)) {
          stop(paste("Error! Invalid data for `subscribed`. Must be a boolean:", `subscribed`))
        }
        self$`subscribed` <- `subscribed`
      }
      if (!is.null(`first_name`)) {
        if (!(is.character(`first_name`) && length(`first_name`) == 1)) {
          stop(paste("Error! Invalid data for `first_name`. Must be a string:", `first_name`))
        }
        self$`first_name` <- `first_name`
      }
      if (!is.null(`last_name`)) {
        if (!(is.character(`last_name`) && length(`last_name`) == 1)) {
          stop(paste("Error! Invalid data for `last_name`. Must be a string:", `last_name`))
        }
        self$`last_name` <- `last_name`
      }
      if (!is.null(`stores_ids`)) {
        stopifnot(is.vector(`stores_ids`), length(`stores_ids`) != 0)
        sapply(`stores_ids`, function(x) stopifnot(is.character(x)))
        self$`stores_ids` <- `stores_ids`
      }
      if (!is.null(`created_time`)) {
        if (!(is.character(`created_time`) && length(`created_time`) == 1)) {
          stop(paste("Error! Invalid data for `created_time`. Must be a string:", `created_time`))
        }
        self$`created_time` <- `created_time`
      }
      if (!is.null(`modified_time`)) {
        if (!(is.character(`modified_time`) && length(`modified_time`) == 1)) {
          stop(paste("Error! Invalid data for `modified_time`. Must be a string:", `modified_time`))
        }
        self$`modified_time` <- `modified_time`
      }
      if (!is.null(`lang_id`)) {
        if (!(is.character(`lang_id`) && length(`lang_id`) == 1)) {
          stop(paste("Error! Invalid data for `lang_id`. Must be a string:", `lang_id`))
        }
        self$`lang_id` <- `lang_id`
      }
      if (!is.null(`gender`)) {
        if (!(is.character(`gender`) && length(`gender`) == 1)) {
          stop(paste("Error! Invalid data for `gender`. Must be a string:", `gender`))
        }
        self$`gender` <- `gender`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return Subscriber as a base R list.
    #' @examples
    #' # convert array of Subscriber (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert Subscriber to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      SubscriberObject <- list()
      if (!is.null(self$`id`)) {
        SubscriberObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`customer_id`)) {
        SubscriberObject[["customer_id"]] <-
          self$`customer_id`
      }
      if (!is.null(self$`email`)) {
        SubscriberObject[["email"]] <-
          self$`email`
      }
      if (!is.null(self$`subscribed`)) {
        SubscriberObject[["subscribed"]] <-
          self$`subscribed`
      }
      if (!is.null(self$`first_name`)) {
        SubscriberObject[["first_name"]] <-
          self$`first_name`
      }
      if (!is.null(self$`last_name`)) {
        SubscriberObject[["last_name"]] <-
          self$`last_name`
      }
      if (!is.null(self$`stores_ids`)) {
        SubscriberObject[["stores_ids"]] <-
          self$`stores_ids`
      }
      if (!is.null(self$`created_time`)) {
        SubscriberObject[["created_time"]] <-
          self$`created_time`
      }
      if (!is.null(self$`modified_time`)) {
        SubscriberObject[["modified_time"]] <-
          self$`modified_time`
      }
      if (!is.null(self$`lang_id`)) {
        SubscriberObject[["lang_id"]] <-
          self$`lang_id`
      }
      if (!is.null(self$`gender`)) {
        SubscriberObject[["gender"]] <-
          self$`gender`
      }
      if (!is.null(self$`additional_fields`)) {
        SubscriberObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        SubscriberObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(SubscriberObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of Subscriber
    #'
    #' @param input_json the JSON input
    #' @return the instance of Subscriber
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`customer_id`)) {
        self$`customer_id` <- this_object$`customer_id`
      }
      if (!is.null(this_object$`email`)) {
        self$`email` <- this_object$`email`
      }
      if (!is.null(this_object$`subscribed`)) {
        self$`subscribed` <- this_object$`subscribed`
      }
      if (!is.null(this_object$`first_name`)) {
        self$`first_name` <- this_object$`first_name`
      }
      if (!is.null(this_object$`last_name`)) {
        self$`last_name` <- this_object$`last_name`
      }
      if (!is.null(this_object$`stores_ids`)) {
        self$`stores_ids` <- ApiClient$new()$deserializeObj(this_object$`stores_ids`, "array[character]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`created_time`)) {
        self$`created_time` <- this_object$`created_time`
      }
      if (!is.null(this_object$`modified_time`)) {
        self$`modified_time` <- this_object$`modified_time`
      }
      if (!is.null(this_object$`lang_id`)) {
        self$`lang_id` <- this_object$`lang_id`
      }
      if (!is.null(this_object$`gender`)) {
        self$`gender` <- this_object$`gender`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return Subscriber in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of Subscriber
    #'
    #' @param input_json the JSON input
    #' @return the instance of Subscriber
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`customer_id` <- this_object$`customer_id`
      self$`email` <- this_object$`email`
      self$`subscribed` <- this_object$`subscribed`
      self$`first_name` <- this_object$`first_name`
      self$`last_name` <- this_object$`last_name`
      self$`stores_ids` <- ApiClient$new()$deserializeObj(this_object$`stores_ids`, "array[character]", loadNamespace("openapi"))
      self$`created_time` <- this_object$`created_time`
      self$`modified_time` <- this_object$`modified_time`
      self$`lang_id` <- this_object$`lang_id`
      self$`gender` <- this_object$`gender`
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to Subscriber and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of Subscriber
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# Subscriber$unlock()
#
## Below is an example to define the print function
# Subscriber$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# Subscriber$lock()

