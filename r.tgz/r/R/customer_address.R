#' Create a new CustomerAddress
#'
#' @description
#' CustomerAddress Class
#'
#' @docType class
#' @title CustomerAddress
#' @description CustomerAddress Class
#' @format An \code{R6Class} generator object
#' @field id  character [optional]
#' @field type  character [optional]
#' @field first_name  character [optional]
#' @field last_name  character [optional]
#' @field postcode  character [optional]
#' @field address1  character [optional]
#' @field address2  character [optional]
#' @field phone  character [optional]
#' @field phone_mobile  character [optional]
#' @field city  character [optional]
#' @field country  \link{Country} [optional]
#' @field state  \link{State} [optional]
#' @field company  character [optional]
#' @field fax  character [optional]
#' @field website  character [optional]
#' @field gender  character [optional]
#' @field region  character [optional]
#' @field default  character [optional]
#' @field tax_id  character [optional]
#' @field identification_number  character [optional]
#' @field alias  character [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
CustomerAddress <- R6::R6Class(
  "CustomerAddress",
  public = list(
    `id` = NULL,
    `type` = NULL,
    `first_name` = NULL,
    `last_name` = NULL,
    `postcode` = NULL,
    `address1` = NULL,
    `address2` = NULL,
    `phone` = NULL,
    `phone_mobile` = NULL,
    `city` = NULL,
    `country` = NULL,
    `state` = NULL,
    `company` = NULL,
    `fax` = NULL,
    `website` = NULL,
    `gender` = NULL,
    `region` = NULL,
    `default` = NULL,
    `tax_id` = NULL,
    `identification_number` = NULL,
    `alias` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new CustomerAddress class.
    #'
    #' @param id id
    #' @param type type
    #' @param first_name first_name
    #' @param last_name last_name
    #' @param postcode postcode
    #' @param address1 address1
    #' @param address2 address2
    #' @param phone phone
    #' @param phone_mobile phone_mobile
    #' @param city city
    #' @param country country
    #' @param state state
    #' @param company company
    #' @param fax fax
    #' @param website website
    #' @param gender gender
    #' @param region region
    #' @param default default
    #' @param tax_id tax_id
    #' @param identification_number identification_number
    #' @param alias alias
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `type` = NULL, `first_name` = NULL, `last_name` = NULL, `postcode` = NULL, `address1` = NULL, `address2` = NULL, `phone` = NULL, `phone_mobile` = NULL, `city` = NULL, `country` = NULL, `state` = NULL, `company` = NULL, `fax` = NULL, `website` = NULL, `gender` = NULL, `region` = NULL, `default` = NULL, `tax_id` = NULL, `identification_number` = NULL, `alias` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`type`)) {
        if (!(is.character(`type`) && length(`type`) == 1)) {
          stop(paste("Error! Invalid data for `type`. Must be a string:", `type`))
        }
        self$`type` <- `type`
      }
      if (!is.null(`first_name`)) {
        if (!(is.character(`first_name`) && length(`first_name`) == 1)) {
          stop(paste("Error! Invalid data for `first_name`. Must be a string:", `first_name`))
        }
        self$`first_name` <- `first_name`
      }
      if (!is.null(`last_name`)) {
        if (!(is.character(`last_name`) && length(`last_name`) == 1)) {
          stop(paste("Error! Invalid data for `last_name`. Must be a string:", `last_name`))
        }
        self$`last_name` <- `last_name`
      }
      if (!is.null(`postcode`)) {
        if (!(is.character(`postcode`) && length(`postcode`) == 1)) {
          stop(paste("Error! Invalid data for `postcode`. Must be a string:", `postcode`))
        }
        self$`postcode` <- `postcode`
      }
      if (!is.null(`address1`)) {
        if (!(is.character(`address1`) && length(`address1`) == 1)) {
          stop(paste("Error! Invalid data for `address1`. Must be a string:", `address1`))
        }
        self$`address1` <- `address1`
      }
      if (!is.null(`address2`)) {
        if (!(is.character(`address2`) && length(`address2`) == 1)) {
          stop(paste("Error! Invalid data for `address2`. Must be a string:", `address2`))
        }
        self$`address2` <- `address2`
      }
      if (!is.null(`phone`)) {
        if (!(is.character(`phone`) && length(`phone`) == 1)) {
          stop(paste("Error! Invalid data for `phone`. Must be a string:", `phone`))
        }
        self$`phone` <- `phone`
      }
      if (!is.null(`phone_mobile`)) {
        if (!(is.character(`phone_mobile`) && length(`phone_mobile`) == 1)) {
          stop(paste("Error! Invalid data for `phone_mobile`. Must be a string:", `phone_mobile`))
        }
        self$`phone_mobile` <- `phone_mobile`
      }
      if (!is.null(`city`)) {
        if (!(is.character(`city`) && length(`city`) == 1)) {
          stop(paste("Error! Invalid data for `city`. Must be a string:", `city`))
        }
        self$`city` <- `city`
      }
      if (!is.null(`country`)) {
        stopifnot(R6::is.R6(`country`))
        self$`country` <- `country`
      }
      if (!is.null(`state`)) {
        stopifnot(R6::is.R6(`state`))
        self$`state` <- `state`
      }
      if (!is.null(`company`)) {
        if (!(is.character(`company`) && length(`company`) == 1)) {
          stop(paste("Error! Invalid data for `company`. Must be a string:", `company`))
        }
        self$`company` <- `company`
      }
      if (!is.null(`fax`)) {
        if (!(is.character(`fax`) && length(`fax`) == 1)) {
          stop(paste("Error! Invalid data for `fax`. Must be a string:", `fax`))
        }
        self$`fax` <- `fax`
      }
      if (!is.null(`website`)) {
        if (!(is.character(`website`) && length(`website`) == 1)) {
          stop(paste("Error! Invalid data for `website`. Must be a string:", `website`))
        }
        self$`website` <- `website`
      }
      if (!is.null(`gender`)) {
        if (!(is.character(`gender`) && length(`gender`) == 1)) {
          stop(paste("Error! Invalid data for `gender`. Must be a string:", `gender`))
        }
        self$`gender` <- `gender`
      }
      if (!is.null(`region`)) {
        if (!(is.character(`region`) && length(`region`) == 1)) {
          stop(paste("Error! Invalid data for `region`. Must be a string:", `region`))
        }
        self$`region` <- `region`
      }
      if (!is.null(`default`)) {
        if (!(is.logical(`default`) && length(`default`) == 1)) {
          stop(paste("Error! Invalid data for `default`. Must be a boolean:", `default`))
        }
        self$`default` <- `default`
      }
      if (!is.null(`tax_id`)) {
        if (!(is.character(`tax_id`) && length(`tax_id`) == 1)) {
          stop(paste("Error! Invalid data for `tax_id`. Must be a string:", `tax_id`))
        }
        self$`tax_id` <- `tax_id`
      }
      if (!is.null(`identification_number`)) {
        if (!(is.character(`identification_number`) && length(`identification_number`) == 1)) {
          stop(paste("Error! Invalid data for `identification_number`. Must be a string:", `identification_number`))
        }
        self$`identification_number` <- `identification_number`
      }
      if (!is.null(`alias`)) {
        if (!(is.character(`alias`) && length(`alias`) == 1)) {
          stop(paste("Error! Invalid data for `alias`. Must be a string:", `alias`))
        }
        self$`alias` <- `alias`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return CustomerAddress as a base R list.
    #' @examples
    #' # convert array of CustomerAddress (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert CustomerAddress to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      CustomerAddressObject <- list()
      if (!is.null(self$`id`)) {
        CustomerAddressObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`type`)) {
        CustomerAddressObject[["type"]] <-
          self$`type`
      }
      if (!is.null(self$`first_name`)) {
        CustomerAddressObject[["first_name"]] <-
          self$`first_name`
      }
      if (!is.null(self$`last_name`)) {
        CustomerAddressObject[["last_name"]] <-
          self$`last_name`
      }
      if (!is.null(self$`postcode`)) {
        CustomerAddressObject[["postcode"]] <-
          self$`postcode`
      }
      if (!is.null(self$`address1`)) {
        CustomerAddressObject[["address1"]] <-
          self$`address1`
      }
      if (!is.null(self$`address2`)) {
        CustomerAddressObject[["address2"]] <-
          self$`address2`
      }
      if (!is.null(self$`phone`)) {
        CustomerAddressObject[["phone"]] <-
          self$`phone`
      }
      if (!is.null(self$`phone_mobile`)) {
        CustomerAddressObject[["phone_mobile"]] <-
          self$`phone_mobile`
      }
      if (!is.null(self$`city`)) {
        CustomerAddressObject[["city"]] <-
          self$`city`
      }
      if (!is.null(self$`country`)) {
        CustomerAddressObject[["country"]] <-
          self$`country`$toSimpleType()
      }
      if (!is.null(self$`state`)) {
        CustomerAddressObject[["state"]] <-
          self$`state`$toSimpleType()
      }
      if (!is.null(self$`company`)) {
        CustomerAddressObject[["company"]] <-
          self$`company`
      }
      if (!is.null(self$`fax`)) {
        CustomerAddressObject[["fax"]] <-
          self$`fax`
      }
      if (!is.null(self$`website`)) {
        CustomerAddressObject[["website"]] <-
          self$`website`
      }
      if (!is.null(self$`gender`)) {
        CustomerAddressObject[["gender"]] <-
          self$`gender`
      }
      if (!is.null(self$`region`)) {
        CustomerAddressObject[["region"]] <-
          self$`region`
      }
      if (!is.null(self$`default`)) {
        CustomerAddressObject[["default"]] <-
          self$`default`
      }
      if (!is.null(self$`tax_id`)) {
        CustomerAddressObject[["tax_id"]] <-
          self$`tax_id`
      }
      if (!is.null(self$`identification_number`)) {
        CustomerAddressObject[["identification_number"]] <-
          self$`identification_number`
      }
      if (!is.null(self$`alias`)) {
        CustomerAddressObject[["alias"]] <-
          self$`alias`
      }
      if (!is.null(self$`additional_fields`)) {
        CustomerAddressObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        CustomerAddressObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(CustomerAddressObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of CustomerAddress
    #'
    #' @param input_json the JSON input
    #' @return the instance of CustomerAddress
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`type`)) {
        self$`type` <- this_object$`type`
      }
      if (!is.null(this_object$`first_name`)) {
        self$`first_name` <- this_object$`first_name`
      }
      if (!is.null(this_object$`last_name`)) {
        self$`last_name` <- this_object$`last_name`
      }
      if (!is.null(this_object$`postcode`)) {
        self$`postcode` <- this_object$`postcode`
      }
      if (!is.null(this_object$`address1`)) {
        self$`address1` <- this_object$`address1`
      }
      if (!is.null(this_object$`address2`)) {
        self$`address2` <- this_object$`address2`
      }
      if (!is.null(this_object$`phone`)) {
        self$`phone` <- this_object$`phone`
      }
      if (!is.null(this_object$`phone_mobile`)) {
        self$`phone_mobile` <- this_object$`phone_mobile`
      }
      if (!is.null(this_object$`city`)) {
        self$`city` <- this_object$`city`
      }
      if (!is.null(this_object$`country`)) {
        `country_object` <- Country$new()
        `country_object`$fromJSON(jsonlite::toJSON(this_object$`country`, auto_unbox = TRUE, digits = NA))
        self$`country` <- `country_object`
      }
      if (!is.null(this_object$`state`)) {
        `state_object` <- State$new()
        `state_object`$fromJSON(jsonlite::toJSON(this_object$`state`, auto_unbox = TRUE, digits = NA))
        self$`state` <- `state_object`
      }
      if (!is.null(this_object$`company`)) {
        self$`company` <- this_object$`company`
      }
      if (!is.null(this_object$`fax`)) {
        self$`fax` <- this_object$`fax`
      }
      if (!is.null(this_object$`website`)) {
        self$`website` <- this_object$`website`
      }
      if (!is.null(this_object$`gender`)) {
        self$`gender` <- this_object$`gender`
      }
      if (!is.null(this_object$`region`)) {
        self$`region` <- this_object$`region`
      }
      if (!is.null(this_object$`default`)) {
        self$`default` <- this_object$`default`
      }
      if (!is.null(this_object$`tax_id`)) {
        self$`tax_id` <- this_object$`tax_id`
      }
      if (!is.null(this_object$`identification_number`)) {
        self$`identification_number` <- this_object$`identification_number`
      }
      if (!is.null(this_object$`alias`)) {
        self$`alias` <- this_object$`alias`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return CustomerAddress in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of CustomerAddress
    #'
    #' @param input_json the JSON input
    #' @return the instance of CustomerAddress
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`type` <- this_object$`type`
      self$`first_name` <- this_object$`first_name`
      self$`last_name` <- this_object$`last_name`
      self$`postcode` <- this_object$`postcode`
      self$`address1` <- this_object$`address1`
      self$`address2` <- this_object$`address2`
      self$`phone` <- this_object$`phone`
      self$`phone_mobile` <- this_object$`phone_mobile`
      self$`city` <- this_object$`city`
      self$`country` <- Country$new()$fromJSON(jsonlite::toJSON(this_object$`country`, auto_unbox = TRUE, digits = NA))
      self$`state` <- State$new()$fromJSON(jsonlite::toJSON(this_object$`state`, auto_unbox = TRUE, digits = NA))
      self$`company` <- this_object$`company`
      self$`fax` <- this_object$`fax`
      self$`website` <- this_object$`website`
      self$`gender` <- this_object$`gender`
      self$`region` <- this_object$`region`
      self$`default` <- this_object$`default`
      self$`tax_id` <- this_object$`tax_id`
      self$`identification_number` <- this_object$`identification_number`
      self$`alias` <- this_object$`alias`
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to CustomerAddress and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of CustomerAddress
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# CustomerAddress$unlock()
#
## Below is an example to define the print function
# CustomerAddress$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# CustomerAddress$lock()

