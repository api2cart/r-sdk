#' Create a new AnalyticsCustomer
#'
#' @description
#' AnalyticsCustomer Class
#'
#' @docType class
#' @title AnalyticsCustomer
#' @description AnalyticsCustomer Class
#' @format An \code{R6Class} generator object
#' @field customer_id  character [optional]
#' @field name  character [optional]
#' @field email  character [optional]
#' @field customer_type  character [optional]
#' @field metrics  \link{AnalyticsCustomerMetric} [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
AnalyticsCustomer <- R6::R6Class(
  "AnalyticsCustomer",
  public = list(
    `customer_id` = NULL,
    `name` = NULL,
    `email` = NULL,
    `customer_type` = NULL,
    `metrics` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new AnalyticsCustomer class.
    #'
    #' @param customer_id customer_id
    #' @param name name
    #' @param email email
    #' @param customer_type customer_type
    #' @param metrics metrics
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`customer_id` = NULL, `name` = NULL, `email` = NULL, `customer_type` = NULL, `metrics` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`customer_id`)) {
        if (!(is.character(`customer_id`) && length(`customer_id`) == 1)) {
          stop(paste("Error! Invalid data for `customer_id`. Must be a string:", `customer_id`))
        }
        self$`customer_id` <- `customer_id`
      }
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`email`)) {
        if (!(is.character(`email`) && length(`email`) == 1)) {
          stop(paste("Error! Invalid data for `email`. Must be a string:", `email`))
        }
        self$`email` <- `email`
      }
      if (!is.null(`customer_type`)) {
        if (!(is.character(`customer_type`) && length(`customer_type`) == 1)) {
          stop(paste("Error! Invalid data for `customer_type`. Must be a string:", `customer_type`))
        }
        self$`customer_type` <- `customer_type`
      }
      if (!is.null(`metrics`)) {
        stopifnot(R6::is.R6(`metrics`))
        self$`metrics` <- `metrics`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return AnalyticsCustomer as a base R list.
    #' @examples
    #' # convert array of AnalyticsCustomer (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert AnalyticsCustomer to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      AnalyticsCustomerObject <- list()
      if (!is.null(self$`customer_id`)) {
        AnalyticsCustomerObject[["customer_id"]] <-
          self$`customer_id`
      }
      if (!is.null(self$`name`)) {
        AnalyticsCustomerObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`email`)) {
        AnalyticsCustomerObject[["email"]] <-
          self$`email`
      }
      if (!is.null(self$`customer_type`)) {
        AnalyticsCustomerObject[["customer_type"]] <-
          self$`customer_type`
      }
      if (!is.null(self$`metrics`)) {
        AnalyticsCustomerObject[["metrics"]] <-
          self$`metrics`$toSimpleType()
      }
      if (!is.null(self$`additional_fields`)) {
        AnalyticsCustomerObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        AnalyticsCustomerObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(AnalyticsCustomerObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of AnalyticsCustomer
    #'
    #' @param input_json the JSON input
    #' @return the instance of AnalyticsCustomer
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`customer_id`)) {
        self$`customer_id` <- this_object$`customer_id`
      }
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`email`)) {
        self$`email` <- this_object$`email`
      }
      if (!is.null(this_object$`customer_type`)) {
        self$`customer_type` <- this_object$`customer_type`
      }
      if (!is.null(this_object$`metrics`)) {
        `metrics_object` <- AnalyticsCustomerMetric$new()
        `metrics_object`$fromJSON(jsonlite::toJSON(this_object$`metrics`, auto_unbox = TRUE, digits = NA))
        self$`metrics` <- `metrics_object`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return AnalyticsCustomer in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of AnalyticsCustomer
    #'
    #' @param input_json the JSON input
    #' @return the instance of AnalyticsCustomer
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`customer_id` <- this_object$`customer_id`
      self$`name` <- this_object$`name`
      self$`email` <- this_object$`email`
      self$`customer_type` <- this_object$`customer_type`
      self$`metrics` <- AnalyticsCustomerMetric$new()$fromJSON(jsonlite::toJSON(this_object$`metrics`, auto_unbox = TRUE, digits = NA))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to AnalyticsCustomer and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of AnalyticsCustomer
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# AnalyticsCustomer$unlock()
#
## Below is an example to define the print function
# AnalyticsCustomer$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# AnalyticsCustomer$lock()

