#' Create a new OrderCalculateSubtotal
#'
#' @description
#' OrderCalculateSubtotal Class
#'
#' @docType class
#' @title OrderCalculateSubtotal
#' @description OrderCalculateSubtotal Class
#' @format An \code{R6Class} generator object
#' @field value  numeric [optional]
#' @field tax  numeric [optional]
#' @field discount  numeric [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
OrderCalculateSubtotal <- R6::R6Class(
  "OrderCalculateSubtotal",
  public = list(
    `value` = NULL,
    `tax` = NULL,
    `discount` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new OrderCalculateSubtotal class.
    #'
    #' @param value value
    #' @param tax tax
    #' @param discount discount
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`value` = NULL, `tax` = NULL, `discount` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`value`)) {
        self$`value` <- `value`
      }
      if (!is.null(`tax`)) {
        self$`tax` <- `tax`
      }
      if (!is.null(`discount`)) {
        self$`discount` <- `discount`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return OrderCalculateSubtotal as a base R list.
    #' @examples
    #' # convert array of OrderCalculateSubtotal (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert OrderCalculateSubtotal to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      OrderCalculateSubtotalObject <- list()
      if (!is.null(self$`value`)) {
        OrderCalculateSubtotalObject[["value"]] <-
          self$`value`
      }
      if (!is.null(self$`tax`)) {
        OrderCalculateSubtotalObject[["tax"]] <-
          self$`tax`
      }
      if (!is.null(self$`discount`)) {
        OrderCalculateSubtotalObject[["discount"]] <-
          self$`discount`
      }
      if (!is.null(self$`additional_fields`)) {
        OrderCalculateSubtotalObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        OrderCalculateSubtotalObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(OrderCalculateSubtotalObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderCalculateSubtotal
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderCalculateSubtotal
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`value`)) {
        self$`value` <- this_object$`value`
      }
      if (!is.null(this_object$`tax`)) {
        self$`tax` <- this_object$`tax`
      }
      if (!is.null(this_object$`discount`)) {
        self$`discount` <- this_object$`discount`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return OrderCalculateSubtotal in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderCalculateSubtotal
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderCalculateSubtotal
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`value` <- this_object$`value`
      self$`tax` <- this_object$`tax`
      self$`discount` <- this_object$`discount`
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to OrderCalculateSubtotal and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of OrderCalculateSubtotal
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# OrderCalculateSubtotal$unlock()
#
## Below is an example to define the print function
# OrderCalculateSubtotal$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# OrderCalculateSubtotal$lock()

