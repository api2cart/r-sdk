#' Create a new ProductAddSizeChart
#'
#' @description
#' A size chart for the product. Only one property is supported.
#'
#' @docType class
#' @title ProductAddSizeChart
#' @description ProductAddSizeChart Class
#' @format An \code{R6Class} generator object
#' @field id Defines a pre-generated size chart template character [optional]
#' @field url Defines a size chart image URL character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductAddSizeChart <- R6::R6Class(
  "ProductAddSizeChart",
  public = list(
    `id` = NULL,
    `url` = NULL,

    #' @description
    #' Initialize a new ProductAddSizeChart class.
    #'
    #' @param id Defines a pre-generated size chart template
    #' @param url Defines a size chart image URL
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `url` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`url`)) {
        if (!(is.character(`url`) && length(`url`) == 1)) {
          stop(paste("Error! Invalid data for `url`. Must be a string:", `url`))
        }
        self$`url` <- `url`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductAddSizeChart as a base R list.
    #' @examples
    #' # convert array of ProductAddSizeChart (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductAddSizeChart to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductAddSizeChartObject <- list()
      if (!is.null(self$`id`)) {
        ProductAddSizeChartObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`url`)) {
        ProductAddSizeChartObject[["url"]] <-
          self$`url`
      }
      return(ProductAddSizeChartObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductAddSizeChart
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductAddSizeChart
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`url`)) {
        self$`url` <- this_object$`url`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductAddSizeChart in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductAddSizeChart
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductAddSizeChart
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`url` <- this_object$`url`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductAddSizeChart and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductAddSizeChart
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      if (nchar(self$`id`) < 1) {
        return(FALSE)
      }

      if (nchar(self$`url`) < 1) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      if (nchar(self$`id`) < 1) {
        invalid_fields["id"] <- "Invalid length for `id`, must be bigger than or equal to 1."
      }

      if (nchar(self$`url`) < 1) {
        invalid_fields["url"] <- "Invalid length for `url`, must be bigger than or equal to 1."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductAddSizeChart$unlock()
#
## Below is an example to define the print function
# ProductAddSizeChart$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductAddSizeChart$lock()

