#' Create a new CustomerAdd
#'
#' @description
#' CustomerAdd Class
#'
#' @docType class
#' @title CustomerAdd
#' @description CustomerAdd Class
#' @format An \code{R6Class} generator object
#' @field email Defines customer's email character
#' @field first_name Defines customer's first name character [optional]
#' @field last_name Defines customer's last name character [optional]
#' @field password Defines customer's unique password character [optional]
#' @field group Defines the group where the customer character [optional]
#' @field group_id Customer group_id character [optional]
#' @field group_ids Groups that will be assigned to a customer character [optional]
#' @field status Defines customer's status character [optional]
#' @field created_time Entity's date creation character [optional]
#' @field modified_time Entity's date modification character [optional]
#' @field login Specifies customer's login name character [optional]
#' @field last_login Defines customer's last login time character [optional]
#' @field birth_day Defines customer's birthday character [optional]
#' @field news_letter_subscription Defines whether the newsletter subscription is available for the user character [optional]
#' @field consents Defines consents to notifications list(\link{CustomerAddConsentsInner}) [optional]
#' @field gender Defines customer's gender character [optional]
#' @field website Link to customer website character [optional]
#' @field fax Defines customer's fax character [optional]
#' @field company Defines customer's company character [optional]
#' @field phone Defines customer's phone number character [optional]
#' @field note The customer note. character [optional]
#' @field country Specifies ISO code or name of country character [optional]
#' @field currency_id Currency Id character [optional]
#' @field is_tax_exempt Marks a customer as tax-exempt (B2B/wholesale). character [optional]
#' @field vendor_id Vendor Id character [optional]
#' @field store_id Store Id character [optional]
#' @field idempotency_key A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong> character [optional]
#' @field address  list(\link{CustomerAddAddressInner}) [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
CustomerAdd <- R6::R6Class(
  "CustomerAdd",
  public = list(
    `email` = NULL,
    `first_name` = NULL,
    `last_name` = NULL,
    `password` = NULL,
    `group` = NULL,
    `group_id` = NULL,
    `group_ids` = NULL,
    `status` = NULL,
    `created_time` = NULL,
    `modified_time` = NULL,
    `login` = NULL,
    `last_login` = NULL,
    `birth_day` = NULL,
    `news_letter_subscription` = NULL,
    `consents` = NULL,
    `gender` = NULL,
    `website` = NULL,
    `fax` = NULL,
    `company` = NULL,
    `phone` = NULL,
    `note` = NULL,
    `country` = NULL,
    `currency_id` = NULL,
    `is_tax_exempt` = NULL,
    `vendor_id` = NULL,
    `store_id` = NULL,
    `idempotency_key` = NULL,
    `address` = NULL,

    #' @description
    #' Initialize a new CustomerAdd class.
    #'
    #' @param email Defines customer's email
    #' @param first_name Defines customer's first name
    #' @param last_name Defines customer's last name
    #' @param password Defines customer's unique password
    #' @param group Defines the group where the customer
    #' @param group_id Customer group_id
    #' @param group_ids Groups that will be assigned to a customer
    #' @param status Defines customer's status. Default to "enabled".
    #' @param created_time Entity's date creation
    #' @param modified_time Entity's date modification
    #' @param login Specifies customer's login name
    #' @param last_login Defines customer's last login time
    #' @param birth_day Defines customer's birthday
    #' @param news_letter_subscription Defines whether the newsletter subscription is available for the user
    #' @param consents Defines consents to notifications
    #' @param gender Defines customer's gender
    #' @param website Link to customer website
    #' @param fax Defines customer's fax
    #' @param company Defines customer's company
    #' @param phone Defines customer's phone number
    #' @param note The customer note.
    #' @param country Specifies ISO code or name of country
    #' @param currency_id Currency Id
    #' @param is_tax_exempt Marks a customer as tax-exempt (B2B/wholesale).
    #' @param vendor_id Vendor Id
    #' @param store_id Store Id
    #' @param idempotency_key A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong>
    #' @param address address
    #' @param ... Other optional arguments.
    initialize = function(`email`, `first_name` = NULL, `last_name` = NULL, `password` = NULL, `group` = NULL, `group_id` = NULL, `group_ids` = NULL, `status` = "enabled", `created_time` = NULL, `modified_time` = NULL, `login` = NULL, `last_login` = NULL, `birth_day` = NULL, `news_letter_subscription` = NULL, `consents` = NULL, `gender` = NULL, `website` = NULL, `fax` = NULL, `company` = NULL, `phone` = NULL, `note` = NULL, `country` = NULL, `currency_id` = NULL, `is_tax_exempt` = NULL, `vendor_id` = NULL, `store_id` = NULL, `idempotency_key` = NULL, `address` = NULL, ...) {
      if (!missing(`email`)) {
        if (!(is.character(`email`) && length(`email`) == 1)) {
          stop(paste("Error! Invalid data for `email`. Must be a string:", `email`))
        }
        self$`email` <- `email`
      }
      if (!is.null(`first_name`)) {
        if (!(is.character(`first_name`) && length(`first_name`) == 1)) {
          stop(paste("Error! Invalid data for `first_name`. Must be a string:", `first_name`))
        }
        self$`first_name` <- `first_name`
      }
      if (!is.null(`last_name`)) {
        if (!(is.character(`last_name`) && length(`last_name`) == 1)) {
          stop(paste("Error! Invalid data for `last_name`. Must be a string:", `last_name`))
        }
        self$`last_name` <- `last_name`
      }
      if (!is.null(`password`)) {
        if (!(is.character(`password`) && length(`password`) == 1)) {
          stop(paste("Error! Invalid data for `password`. Must be a string:", `password`))
        }
        self$`password` <- `password`
      }
      if (!is.null(`group`)) {
        if (!(is.character(`group`) && length(`group`) == 1)) {
          stop(paste("Error! Invalid data for `group`. Must be a string:", `group`))
        }
        self$`group` <- `group`
      }
      if (!is.null(`group_id`)) {
        if (!(is.character(`group_id`) && length(`group_id`) == 1)) {
          stop(paste("Error! Invalid data for `group_id`. Must be a string:", `group_id`))
        }
        self$`group_id` <- `group_id`
      }
      if (!is.null(`group_ids`)) {
        if (!(is.character(`group_ids`) && length(`group_ids`) == 1)) {
          stop(paste("Error! Invalid data for `group_ids`. Must be a string:", `group_ids`))
        }
        self$`group_ids` <- `group_ids`
      }
      if (!is.null(`status`)) {
        if (!(is.character(`status`) && length(`status`) == 1)) {
          stop(paste("Error! Invalid data for `status`. Must be a string:", `status`))
        }
        self$`status` <- `status`
      }
      if (!is.null(`created_time`)) {
        if (!(is.character(`created_time`) && length(`created_time`) == 1)) {
          stop(paste("Error! Invalid data for `created_time`. Must be a string:", `created_time`))
        }
        self$`created_time` <- `created_time`
      }
      if (!is.null(`modified_time`)) {
        if (!(is.character(`modified_time`) && length(`modified_time`) == 1)) {
          stop(paste("Error! Invalid data for `modified_time`. Must be a string:", `modified_time`))
        }
        self$`modified_time` <- `modified_time`
      }
      if (!is.null(`login`)) {
        if (!(is.character(`login`) && length(`login`) == 1)) {
          stop(paste("Error! Invalid data for `login`. Must be a string:", `login`))
        }
        self$`login` <- `login`
      }
      if (!is.null(`last_login`)) {
        if (!(is.character(`last_login`) && length(`last_login`) == 1)) {
          stop(paste("Error! Invalid data for `last_login`. Must be a string:", `last_login`))
        }
        self$`last_login` <- `last_login`
      }
      if (!is.null(`birth_day`)) {
        if (!(is.character(`birth_day`) && length(`birth_day`) == 1)) {
          stop(paste("Error! Invalid data for `birth_day`. Must be a string:", `birth_day`))
        }
        self$`birth_day` <- `birth_day`
      }
      if (!is.null(`news_letter_subscription`)) {
        if (!(is.logical(`news_letter_subscription`) && length(`news_letter_subscription`) == 1)) {
          stop(paste("Error! Invalid data for `news_letter_subscription`. Must be a boolean:", `news_letter_subscription`))
        }
        self$`news_letter_subscription` <- `news_letter_subscription`
      }
      if (!is.null(`consents`)) {
        stopifnot(is.vector(`consents`), length(`consents`) != 0)
        sapply(`consents`, function(x) stopifnot(R6::is.R6(x)))
        self$`consents` <- `consents`
      }
      if (!is.null(`gender`)) {
        if (!(is.character(`gender`) && length(`gender`) == 1)) {
          stop(paste("Error! Invalid data for `gender`. Must be a string:", `gender`))
        }
        self$`gender` <- `gender`
      }
      if (!is.null(`website`)) {
        if (!(is.character(`website`) && length(`website`) == 1)) {
          stop(paste("Error! Invalid data for `website`. Must be a string:", `website`))
        }
        self$`website` <- `website`
      }
      if (!is.null(`fax`)) {
        if (!(is.character(`fax`) && length(`fax`) == 1)) {
          stop(paste("Error! Invalid data for `fax`. Must be a string:", `fax`))
        }
        self$`fax` <- `fax`
      }
      if (!is.null(`company`)) {
        if (!(is.character(`company`) && length(`company`) == 1)) {
          stop(paste("Error! Invalid data for `company`. Must be a string:", `company`))
        }
        self$`company` <- `company`
      }
      if (!is.null(`phone`)) {
        if (!(is.character(`phone`) && length(`phone`) == 1)) {
          stop(paste("Error! Invalid data for `phone`. Must be a string:", `phone`))
        }
        self$`phone` <- `phone`
      }
      if (!is.null(`note`)) {
        if (!(is.character(`note`) && length(`note`) == 1)) {
          stop(paste("Error! Invalid data for `note`. Must be a string:", `note`))
        }
        self$`note` <- `note`
      }
      if (!is.null(`country`)) {
        if (!(is.character(`country`) && length(`country`) == 1)) {
          stop(paste("Error! Invalid data for `country`. Must be a string:", `country`))
        }
        self$`country` <- `country`
      }
      if (!is.null(`currency_id`)) {
        if (!(is.character(`currency_id`) && length(`currency_id`) == 1)) {
          stop(paste("Error! Invalid data for `currency_id`. Must be a string:", `currency_id`))
        }
        self$`currency_id` <- `currency_id`
      }
      if (!is.null(`is_tax_exempt`)) {
        if (!(is.logical(`is_tax_exempt`) && length(`is_tax_exempt`) == 1)) {
          stop(paste("Error! Invalid data for `is_tax_exempt`. Must be a boolean:", `is_tax_exempt`))
        }
        self$`is_tax_exempt` <- `is_tax_exempt`
      }
      if (!is.null(`vendor_id`)) {
        if (!(is.character(`vendor_id`) && length(`vendor_id`) == 1)) {
          stop(paste("Error! Invalid data for `vendor_id`. Must be a string:", `vendor_id`))
        }
        self$`vendor_id` <- `vendor_id`
      }
      if (!is.null(`store_id`)) {
        if (!(is.character(`store_id`) && length(`store_id`) == 1)) {
          stop(paste("Error! Invalid data for `store_id`. Must be a string:", `store_id`))
        }
        self$`store_id` <- `store_id`
      }
      if (!is.null(`idempotency_key`)) {
        if (!(is.character(`idempotency_key`) && length(`idempotency_key`) == 1)) {
          stop(paste("Error! Invalid data for `idempotency_key`. Must be a string:", `idempotency_key`))
        }
        self$`idempotency_key` <- `idempotency_key`
      }
      if (!is.null(`address`)) {
        stopifnot(is.vector(`address`), length(`address`) != 0)
        sapply(`address`, function(x) stopifnot(R6::is.R6(x)))
        self$`address` <- `address`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return CustomerAdd as a base R list.
    #' @examples
    #' # convert array of CustomerAdd (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert CustomerAdd to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      CustomerAddObject <- list()
      if (!is.null(self$`email`)) {
        CustomerAddObject[["email"]] <-
          self$`email`
      }
      if (!is.null(self$`first_name`)) {
        CustomerAddObject[["first_name"]] <-
          self$`first_name`
      }
      if (!is.null(self$`last_name`)) {
        CustomerAddObject[["last_name"]] <-
          self$`last_name`
      }
      if (!is.null(self$`password`)) {
        CustomerAddObject[["password"]] <-
          self$`password`
      }
      if (!is.null(self$`group`)) {
        CustomerAddObject[["group"]] <-
          self$`group`
      }
      if (!is.null(self$`group_id`)) {
        CustomerAddObject[["group_id"]] <-
          self$`group_id`
      }
      if (!is.null(self$`group_ids`)) {
        CustomerAddObject[["group_ids"]] <-
          self$`group_ids`
      }
      if (!is.null(self$`status`)) {
        CustomerAddObject[["status"]] <-
          self$`status`
      }
      if (!is.null(self$`created_time`)) {
        CustomerAddObject[["created_time"]] <-
          self$`created_time`
      }
      if (!is.null(self$`modified_time`)) {
        CustomerAddObject[["modified_time"]] <-
          self$`modified_time`
      }
      if (!is.null(self$`login`)) {
        CustomerAddObject[["login"]] <-
          self$`login`
      }
      if (!is.null(self$`last_login`)) {
        CustomerAddObject[["last_login"]] <-
          self$`last_login`
      }
      if (!is.null(self$`birth_day`)) {
        CustomerAddObject[["birth_day"]] <-
          self$`birth_day`
      }
      if (!is.null(self$`news_letter_subscription`)) {
        CustomerAddObject[["news_letter_subscription"]] <-
          self$`news_letter_subscription`
      }
      if (!is.null(self$`consents`)) {
        CustomerAddObject[["consents"]] <-
          lapply(self$`consents`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`gender`)) {
        CustomerAddObject[["gender"]] <-
          self$`gender`
      }
      if (!is.null(self$`website`)) {
        CustomerAddObject[["website"]] <-
          self$`website`
      }
      if (!is.null(self$`fax`)) {
        CustomerAddObject[["fax"]] <-
          self$`fax`
      }
      if (!is.null(self$`company`)) {
        CustomerAddObject[["company"]] <-
          self$`company`
      }
      if (!is.null(self$`phone`)) {
        CustomerAddObject[["phone"]] <-
          self$`phone`
      }
      if (!is.null(self$`note`)) {
        CustomerAddObject[["note"]] <-
          self$`note`
      }
      if (!is.null(self$`country`)) {
        CustomerAddObject[["country"]] <-
          self$`country`
      }
      if (!is.null(self$`currency_id`)) {
        CustomerAddObject[["currency_id"]] <-
          self$`currency_id`
      }
      if (!is.null(self$`is_tax_exempt`)) {
        CustomerAddObject[["is_tax_exempt"]] <-
          self$`is_tax_exempt`
      }
      if (!is.null(self$`vendor_id`)) {
        CustomerAddObject[["vendor_id"]] <-
          self$`vendor_id`
      }
      if (!is.null(self$`store_id`)) {
        CustomerAddObject[["store_id"]] <-
          self$`store_id`
      }
      if (!is.null(self$`idempotency_key`)) {
        CustomerAddObject[["idempotency_key"]] <-
          self$`idempotency_key`
      }
      if (!is.null(self$`address`)) {
        CustomerAddObject[["address"]] <-
          lapply(self$`address`, function(x) x$toSimpleType())
      }
      return(CustomerAddObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of CustomerAdd
    #'
    #' @param input_json the JSON input
    #' @return the instance of CustomerAdd
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`email`)) {
        self$`email` <- this_object$`email`
      }
      if (!is.null(this_object$`first_name`)) {
        self$`first_name` <- this_object$`first_name`
      }
      if (!is.null(this_object$`last_name`)) {
        self$`last_name` <- this_object$`last_name`
      }
      if (!is.null(this_object$`password`)) {
        self$`password` <- this_object$`password`
      }
      if (!is.null(this_object$`group`)) {
        self$`group` <- this_object$`group`
      }
      if (!is.null(this_object$`group_id`)) {
        self$`group_id` <- this_object$`group_id`
      }
      if (!is.null(this_object$`group_ids`)) {
        self$`group_ids` <- this_object$`group_ids`
      }
      if (!is.null(this_object$`status`)) {
        self$`status` <- this_object$`status`
      }
      if (!is.null(this_object$`created_time`)) {
        self$`created_time` <- this_object$`created_time`
      }
      if (!is.null(this_object$`modified_time`)) {
        self$`modified_time` <- this_object$`modified_time`
      }
      if (!is.null(this_object$`login`)) {
        self$`login` <- this_object$`login`
      }
      if (!is.null(this_object$`last_login`)) {
        self$`last_login` <- this_object$`last_login`
      }
      if (!is.null(this_object$`birth_day`)) {
        self$`birth_day` <- this_object$`birth_day`
      }
      if (!is.null(this_object$`news_letter_subscription`)) {
        self$`news_letter_subscription` <- this_object$`news_letter_subscription`
      }
      if (!is.null(this_object$`consents`)) {
        self$`consents` <- ApiClient$new()$deserializeObj(this_object$`consents`, "array[CustomerAddConsentsInner]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`gender`)) {
        self$`gender` <- this_object$`gender`
      }
      if (!is.null(this_object$`website`)) {
        self$`website` <- this_object$`website`
      }
      if (!is.null(this_object$`fax`)) {
        self$`fax` <- this_object$`fax`
      }
      if (!is.null(this_object$`company`)) {
        self$`company` <- this_object$`company`
      }
      if (!is.null(this_object$`phone`)) {
        self$`phone` <- this_object$`phone`
      }
      if (!is.null(this_object$`note`)) {
        self$`note` <- this_object$`note`
      }
      if (!is.null(this_object$`country`)) {
        self$`country` <- this_object$`country`
      }
      if (!is.null(this_object$`currency_id`)) {
        self$`currency_id` <- this_object$`currency_id`
      }
      if (!is.null(this_object$`is_tax_exempt`)) {
        self$`is_tax_exempt` <- this_object$`is_tax_exempt`
      }
      if (!is.null(this_object$`vendor_id`)) {
        self$`vendor_id` <- this_object$`vendor_id`
      }
      if (!is.null(this_object$`store_id`)) {
        self$`store_id` <- this_object$`store_id`
      }
      if (!is.null(this_object$`idempotency_key`)) {
        self$`idempotency_key` <- this_object$`idempotency_key`
      }
      if (!is.null(this_object$`address`)) {
        self$`address` <- ApiClient$new()$deserializeObj(this_object$`address`, "array[CustomerAddAddressInner]", loadNamespace("openapi"))
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return CustomerAdd in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of CustomerAdd
    #'
    #' @param input_json the JSON input
    #' @return the instance of CustomerAdd
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`email` <- this_object$`email`
      self$`first_name` <- this_object$`first_name`
      self$`last_name` <- this_object$`last_name`
      self$`password` <- this_object$`password`
      self$`group` <- this_object$`group`
      self$`group_id` <- this_object$`group_id`
      self$`group_ids` <- this_object$`group_ids`
      self$`status` <- this_object$`status`
      self$`created_time` <- this_object$`created_time`
      self$`modified_time` <- this_object$`modified_time`
      self$`login` <- this_object$`login`
      self$`last_login` <- this_object$`last_login`
      self$`birth_day` <- this_object$`birth_day`
      self$`news_letter_subscription` <- this_object$`news_letter_subscription`
      self$`consents` <- ApiClient$new()$deserializeObj(this_object$`consents`, "array[CustomerAddConsentsInner]", loadNamespace("openapi"))
      self$`gender` <- this_object$`gender`
      self$`website` <- this_object$`website`
      self$`fax` <- this_object$`fax`
      self$`company` <- this_object$`company`
      self$`phone` <- this_object$`phone`
      self$`note` <- this_object$`note`
      self$`country` <- this_object$`country`
      self$`currency_id` <- this_object$`currency_id`
      self$`is_tax_exempt` <- this_object$`is_tax_exempt`
      self$`vendor_id` <- this_object$`vendor_id`
      self$`store_id` <- this_object$`store_id`
      self$`idempotency_key` <- this_object$`idempotency_key`
      self$`address` <- ApiClient$new()$deserializeObj(this_object$`address`, "array[CustomerAddAddressInner]", loadNamespace("openapi"))
      self
    },

    #' @description
    #' Validate JSON input with respect to CustomerAdd and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
      # check the required field `email`
      if (!is.null(input_json$`email`)) {
        if (!(is.character(input_json$`email`) && length(input_json$`email`) == 1)) {
          stop(paste("Error! Invalid data for `email`. Must be a string:", input_json$`email`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for CustomerAdd: the required field `email` is missing."))
      }
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of CustomerAdd
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      # check if the required `email` is null
      if (is.null(self$`email`)) {
        return(FALSE)
      }

      if (length(self$`consents`) < 1) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      # check if the required `email` is null
      if (is.null(self$`email`)) {
        invalid_fields["email"] <- "Non-nullable required field `email` cannot be null."
      }

      if (length(self$`consents`) < 1) {
        invalid_fields["consents"] <- "Invalid length for ``, number of items must be greater than or equal to 1."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# CustomerAdd$unlock()
#
## Below is an example to define the print function
# CustomerAdd$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# CustomerAdd$lock()

