#' Create a new AnalyticsInterval
#'
#' @description
#' AnalyticsInterval Class
#'
#' @docType class
#' @title AnalyticsInterval
#' @description AnalyticsInterval Class
#' @format An \code{R6Class} generator object
#' @field date_from  character [optional]
#' @field date_to  character [optional]
#' @field metrics  \link{AnalyticsMetric} [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
AnalyticsInterval <- R6::R6Class(
  "AnalyticsInterval",
  public = list(
    `date_from` = NULL,
    `date_to` = NULL,
    `metrics` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new AnalyticsInterval class.
    #'
    #' @param date_from date_from
    #' @param date_to date_to
    #' @param metrics metrics
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`date_from` = NULL, `date_to` = NULL, `metrics` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`date_from`)) {
        if (!(is.character(`date_from`) && length(`date_from`) == 1)) {
          stop(paste("Error! Invalid data for `date_from`. Must be a string:", `date_from`))
        }
        self$`date_from` <- `date_from`
      }
      if (!is.null(`date_to`)) {
        if (!(is.character(`date_to`) && length(`date_to`) == 1)) {
          stop(paste("Error! Invalid data for `date_to`. Must be a string:", `date_to`))
        }
        self$`date_to` <- `date_to`
      }
      if (!is.null(`metrics`)) {
        stopifnot(R6::is.R6(`metrics`))
        self$`metrics` <- `metrics`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return AnalyticsInterval as a base R list.
    #' @examples
    #' # convert array of AnalyticsInterval (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert AnalyticsInterval to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      AnalyticsIntervalObject <- list()
      if (!is.null(self$`date_from`)) {
        AnalyticsIntervalObject[["date_from"]] <-
          self$`date_from`
      }
      if (!is.null(self$`date_to`)) {
        AnalyticsIntervalObject[["date_to"]] <-
          self$`date_to`
      }
      if (!is.null(self$`metrics`)) {
        AnalyticsIntervalObject[["metrics"]] <-
          self$`metrics`$toSimpleType()
      }
      if (!is.null(self$`additional_fields`)) {
        AnalyticsIntervalObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        AnalyticsIntervalObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(AnalyticsIntervalObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of AnalyticsInterval
    #'
    #' @param input_json the JSON input
    #' @return the instance of AnalyticsInterval
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`date_from`)) {
        self$`date_from` <- this_object$`date_from`
      }
      if (!is.null(this_object$`date_to`)) {
        self$`date_to` <- this_object$`date_to`
      }
      if (!is.null(this_object$`metrics`)) {
        `metrics_object` <- AnalyticsMetric$new()
        `metrics_object`$fromJSON(jsonlite::toJSON(this_object$`metrics`, auto_unbox = TRUE, digits = NA))
        self$`metrics` <- `metrics_object`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return AnalyticsInterval in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of AnalyticsInterval
    #'
    #' @param input_json the JSON input
    #' @return the instance of AnalyticsInterval
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`date_from` <- this_object$`date_from`
      self$`date_to` <- this_object$`date_to`
      self$`metrics` <- AnalyticsMetric$new()$fromJSON(jsonlite::toJSON(this_object$`metrics`, auto_unbox = TRUE, digits = NA))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to AnalyticsInterval and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of AnalyticsInterval
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# AnalyticsInterval$unlock()
#
## Below is an example to define the print function
# AnalyticsInterval$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# AnalyticsInterval$lock()

