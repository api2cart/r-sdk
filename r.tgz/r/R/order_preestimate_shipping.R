#' Create a new OrderPreestimateShipping
#'
#' @description
#' OrderPreestimateShipping Class
#'
#' @docType class
#' @title OrderPreestimateShipping
#' @description OrderPreestimateShipping Class
#' @format An \code{R6Class} generator object
#' @field method_code  character [optional]
#' @field method_name  character [optional]
#' @field carrier_code  character [optional]
#' @field carrier_name  character [optional]
#' @field description  character [optional]
#' @field price  numeric [optional]
#' @field price_inc_tax  numeric [optional]
#' @field delivery_time  character [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
OrderPreestimateShipping <- R6::R6Class(
  "OrderPreestimateShipping",
  public = list(
    `method_code` = NULL,
    `method_name` = NULL,
    `carrier_code` = NULL,
    `carrier_name` = NULL,
    `description` = NULL,
    `price` = NULL,
    `price_inc_tax` = NULL,
    `delivery_time` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new OrderPreestimateShipping class.
    #'
    #' @param method_code method_code
    #' @param method_name method_name
    #' @param carrier_code carrier_code
    #' @param carrier_name carrier_name
    #' @param description description
    #' @param price price
    #' @param price_inc_tax price_inc_tax
    #' @param delivery_time delivery_time
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`method_code` = NULL, `method_name` = NULL, `carrier_code` = NULL, `carrier_name` = NULL, `description` = NULL, `price` = NULL, `price_inc_tax` = NULL, `delivery_time` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`method_code`)) {
        if (!(is.character(`method_code`) && length(`method_code`) == 1)) {
          stop(paste("Error! Invalid data for `method_code`. Must be a string:", `method_code`))
        }
        self$`method_code` <- `method_code`
      }
      if (!is.null(`method_name`)) {
        if (!(is.character(`method_name`) && length(`method_name`) == 1)) {
          stop(paste("Error! Invalid data for `method_name`. Must be a string:", `method_name`))
        }
        self$`method_name` <- `method_name`
      }
      if (!is.null(`carrier_code`)) {
        if (!(is.character(`carrier_code`) && length(`carrier_code`) == 1)) {
          stop(paste("Error! Invalid data for `carrier_code`. Must be a string:", `carrier_code`))
        }
        self$`carrier_code` <- `carrier_code`
      }
      if (!is.null(`carrier_name`)) {
        if (!(is.character(`carrier_name`) && length(`carrier_name`) == 1)) {
          stop(paste("Error! Invalid data for `carrier_name`. Must be a string:", `carrier_name`))
        }
        self$`carrier_name` <- `carrier_name`
      }
      if (!is.null(`description`)) {
        if (!(is.character(`description`) && length(`description`) == 1)) {
          stop(paste("Error! Invalid data for `description`. Must be a string:", `description`))
        }
        self$`description` <- `description`
      }
      if (!is.null(`price`)) {
        self$`price` <- `price`
      }
      if (!is.null(`price_inc_tax`)) {
        self$`price_inc_tax` <- `price_inc_tax`
      }
      if (!is.null(`delivery_time`)) {
        if (!(is.character(`delivery_time`) && length(`delivery_time`) == 1)) {
          stop(paste("Error! Invalid data for `delivery_time`. Must be a string:", `delivery_time`))
        }
        self$`delivery_time` <- `delivery_time`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return OrderPreestimateShipping as a base R list.
    #' @examples
    #' # convert array of OrderPreestimateShipping (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert OrderPreestimateShipping to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      OrderPreestimateShippingObject <- list()
      if (!is.null(self$`method_code`)) {
        OrderPreestimateShippingObject[["method_code"]] <-
          self$`method_code`
      }
      if (!is.null(self$`method_name`)) {
        OrderPreestimateShippingObject[["method_name"]] <-
          self$`method_name`
      }
      if (!is.null(self$`carrier_code`)) {
        OrderPreestimateShippingObject[["carrier_code"]] <-
          self$`carrier_code`
      }
      if (!is.null(self$`carrier_name`)) {
        OrderPreestimateShippingObject[["carrier_name"]] <-
          self$`carrier_name`
      }
      if (!is.null(self$`description`)) {
        OrderPreestimateShippingObject[["description"]] <-
          self$`description`
      }
      if (!is.null(self$`price`)) {
        OrderPreestimateShippingObject[["price"]] <-
          self$`price`
      }
      if (!is.null(self$`price_inc_tax`)) {
        OrderPreestimateShippingObject[["price_inc_tax"]] <-
          self$`price_inc_tax`
      }
      if (!is.null(self$`delivery_time`)) {
        OrderPreestimateShippingObject[["delivery_time"]] <-
          self$`delivery_time`
      }
      if (!is.null(self$`additional_fields`)) {
        OrderPreestimateShippingObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        OrderPreestimateShippingObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(OrderPreestimateShippingObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderPreestimateShipping
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderPreestimateShipping
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`method_code`)) {
        self$`method_code` <- this_object$`method_code`
      }
      if (!is.null(this_object$`method_name`)) {
        self$`method_name` <- this_object$`method_name`
      }
      if (!is.null(this_object$`carrier_code`)) {
        self$`carrier_code` <- this_object$`carrier_code`
      }
      if (!is.null(this_object$`carrier_name`)) {
        self$`carrier_name` <- this_object$`carrier_name`
      }
      if (!is.null(this_object$`description`)) {
        self$`description` <- this_object$`description`
      }
      if (!is.null(this_object$`price`)) {
        self$`price` <- this_object$`price`
      }
      if (!is.null(this_object$`price_inc_tax`)) {
        self$`price_inc_tax` <- this_object$`price_inc_tax`
      }
      if (!is.null(this_object$`delivery_time`)) {
        self$`delivery_time` <- this_object$`delivery_time`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return OrderPreestimateShipping in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderPreestimateShipping
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderPreestimateShipping
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`method_code` <- this_object$`method_code`
      self$`method_name` <- this_object$`method_name`
      self$`carrier_code` <- this_object$`carrier_code`
      self$`carrier_name` <- this_object$`carrier_name`
      self$`description` <- this_object$`description`
      self$`price` <- this_object$`price`
      self$`price_inc_tax` <- this_object$`price_inc_tax`
      self$`delivery_time` <- this_object$`delivery_time`
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to OrderPreestimateShipping and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of OrderPreestimateShipping
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# OrderPreestimateShipping$unlock()
#
## Below is an example to define the print function
# OrderPreestimateShipping$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# OrderPreestimateShipping$lock()

