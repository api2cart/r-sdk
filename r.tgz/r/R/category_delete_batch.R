#' Create a new CategoryDeleteBatch
#'
#' @description
#' CategoryDeleteBatch Class
#'
#' @docType class
#' @title CategoryDeleteBatch
#' @description CategoryDeleteBatch Class
#' @format An \code{R6Class} generator object
#' @field payload Contains an array of category IDs to delete. list(\link{CategoryDeleteBatchPayloadInner})
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
CategoryDeleteBatch <- R6::R6Class(
  "CategoryDeleteBatch",
  public = list(
    `payload` = NULL,

    #' @description
    #' Initialize a new CategoryDeleteBatch class.
    #'
    #' @param payload Contains an array of category IDs to delete.
    #' @param ... Other optional arguments.
    initialize = function(`payload`, ...) {
      if (!missing(`payload`)) {
        stopifnot(is.vector(`payload`), length(`payload`) != 0)
        sapply(`payload`, function(x) stopifnot(R6::is.R6(x)))
        self$`payload` <- `payload`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return CategoryDeleteBatch as a base R list.
    #' @examples
    #' # convert array of CategoryDeleteBatch (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert CategoryDeleteBatch to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      CategoryDeleteBatchObject <- list()
      if (!is.null(self$`payload`)) {
        CategoryDeleteBatchObject[["payload"]] <-
          lapply(self$`payload`, function(x) x$toSimpleType())
      }
      return(CategoryDeleteBatchObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of CategoryDeleteBatch
    #'
    #' @param input_json the JSON input
    #' @return the instance of CategoryDeleteBatch
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`payload`)) {
        self$`payload` <- ApiClient$new()$deserializeObj(this_object$`payload`, "array[CategoryDeleteBatchPayloadInner]", loadNamespace("openapi"))
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return CategoryDeleteBatch in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of CategoryDeleteBatch
    #'
    #' @param input_json the JSON input
    #' @return the instance of CategoryDeleteBatch
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`payload` <- ApiClient$new()$deserializeObj(this_object$`payload`, "array[CategoryDeleteBatchPayloadInner]", loadNamespace("openapi"))
      self
    },

    #' @description
    #' Validate JSON input with respect to CategoryDeleteBatch and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
      # check the required field `payload`
      if (!is.null(input_json$`payload`)) {
        stopifnot(is.vector(input_json$`payload`), length(input_json$`payload`) != 0)
        tmp <- sapply(input_json$`payload`, function(x) stopifnot(R6::is.R6(x)))
      } else {
        stop(paste("The JSON input `", input, "` is invalid for CategoryDeleteBatch: the required field `payload` is missing."))
      }
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of CategoryDeleteBatch
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      # check if the required `payload` is null
      if (is.null(self$`payload`)) {
        return(FALSE)
      }

      if (length(self$`payload`) > 250) {
        return(FALSE)
      }
      if (length(self$`payload`) < 1) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      # check if the required `payload` is null
      if (is.null(self$`payload`)) {
        invalid_fields["payload"] <- "Non-nullable required field `payload` cannot be null."
      }

      if (length(self$`payload`) > 250) {
        invalid_fields["payload"] <- "Invalid length for `payload`, number of items must be less than or equal to 250."
      }
      if (length(self$`payload`) < 1) {
        invalid_fields["payload"] <- "Invalid length for ``, number of items must be greater than or equal to 1."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# CategoryDeleteBatch$unlock()
#
## Below is an example to define the print function
# CategoryDeleteBatch$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# CategoryDeleteBatch$lock()

