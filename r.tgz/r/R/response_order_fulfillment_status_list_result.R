#' Create a new ResponseOrderFulfillmentStatusListResult
#'
#' @description
#' ResponseOrderFulfillmentStatusListResult Class
#'
#' @docType class
#' @title ResponseOrderFulfillmentStatusListResult
#' @description ResponseOrderFulfillmentStatusListResult Class
#' @format An \code{R6Class} generator object
#' @field count  integer [optional]
#' @field order_fulfillment_statuses  list(\link{Status}) [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ResponseOrderFulfillmentStatusListResult <- R6::R6Class(
  "ResponseOrderFulfillmentStatusListResult",
  public = list(
    `count` = NULL,
    `order_fulfillment_statuses` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new ResponseOrderFulfillmentStatusListResult class.
    #'
    #' @param count count
    #' @param order_fulfillment_statuses order_fulfillment_statuses
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`count` = NULL, `order_fulfillment_statuses` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`count`)) {
        if (!(is.numeric(`count`) && length(`count`) == 1)) {
          stop(paste("Error! Invalid data for `count`. Must be an integer:", `count`))
        }
        self$`count` <- `count`
      }
      if (!is.null(`order_fulfillment_statuses`)) {
        stopifnot(is.vector(`order_fulfillment_statuses`), length(`order_fulfillment_statuses`) != 0)
        sapply(`order_fulfillment_statuses`, function(x) stopifnot(R6::is.R6(x)))
        self$`order_fulfillment_statuses` <- `order_fulfillment_statuses`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ResponseOrderFulfillmentStatusListResult as a base R list.
    #' @examples
    #' # convert array of ResponseOrderFulfillmentStatusListResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ResponseOrderFulfillmentStatusListResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ResponseOrderFulfillmentStatusListResultObject <- list()
      if (!is.null(self$`count`)) {
        ResponseOrderFulfillmentStatusListResultObject[["count"]] <-
          self$`count`
      }
      if (!is.null(self$`order_fulfillment_statuses`)) {
        ResponseOrderFulfillmentStatusListResultObject[["order_fulfillment_statuses"]] <-
          lapply(self$`order_fulfillment_statuses`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`additional_fields`)) {
        ResponseOrderFulfillmentStatusListResultObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        ResponseOrderFulfillmentStatusListResultObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(ResponseOrderFulfillmentStatusListResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ResponseOrderFulfillmentStatusListResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ResponseOrderFulfillmentStatusListResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`count`)) {
        self$`count` <- this_object$`count`
      }
      if (!is.null(this_object$`order_fulfillment_statuses`)) {
        self$`order_fulfillment_statuses` <- ApiClient$new()$deserializeObj(this_object$`order_fulfillment_statuses`, "array[Status]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ResponseOrderFulfillmentStatusListResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ResponseOrderFulfillmentStatusListResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ResponseOrderFulfillmentStatusListResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`count` <- this_object$`count`
      self$`order_fulfillment_statuses` <- ApiClient$new()$deserializeObj(this_object$`order_fulfillment_statuses`, "array[Status]", loadNamespace("openapi"))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to ResponseOrderFulfillmentStatusListResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ResponseOrderFulfillmentStatusListResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ResponseOrderFulfillmentStatusListResult$unlock()
#
## Below is an example to define the print function
# ResponseOrderFulfillmentStatusListResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ResponseOrderFulfillmentStatusListResult$lock()

