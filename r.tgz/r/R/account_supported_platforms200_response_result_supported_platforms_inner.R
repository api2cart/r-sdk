#' Create a new AccountSupportedPlatforms200ResponseResultSupportedPlatformsInner
#'
#' @description
#' AccountSupportedPlatforms200ResponseResultSupportedPlatformsInner Class
#'
#' @docType class
#' @title AccountSupportedPlatforms200ResponseResultSupportedPlatformsInner
#' @description AccountSupportedPlatforms200ResponseResultSupportedPlatformsInner Class
#' @format An \code{R6Class} generator object
#' @field cart_id  character [optional]
#' @field cart_name  character [optional]
#' @field cart_versions  character [optional]
#' @field cart_method  character [optional]
#' @field params  \link{AccountSupportedPlatforms200ResponseResultSupportedPlatformsInnerParams} [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
AccountSupportedPlatforms200ResponseResultSupportedPlatformsInner <- R6::R6Class(
  "AccountSupportedPlatforms200ResponseResultSupportedPlatformsInner",
  public = list(
    `cart_id` = NULL,
    `cart_name` = NULL,
    `cart_versions` = NULL,
    `cart_method` = NULL,
    `params` = NULL,

    #' @description
    #' Initialize a new AccountSupportedPlatforms200ResponseResultSupportedPlatformsInner class.
    #'
    #' @param cart_id cart_id
    #' @param cart_name cart_name
    #' @param cart_versions cart_versions
    #' @param cart_method cart_method
    #' @param params params
    #' @param ... Other optional arguments.
    initialize = function(`cart_id` = NULL, `cart_name` = NULL, `cart_versions` = NULL, `cart_method` = NULL, `params` = NULL, ...) {
      if (!is.null(`cart_id`)) {
        if (!(is.character(`cart_id`) && length(`cart_id`) == 1)) {
          stop(paste("Error! Invalid data for `cart_id`. Must be a string:", `cart_id`))
        }
        self$`cart_id` <- `cart_id`
      }
      if (!is.null(`cart_name`)) {
        if (!(is.character(`cart_name`) && length(`cart_name`) == 1)) {
          stop(paste("Error! Invalid data for `cart_name`. Must be a string:", `cart_name`))
        }
        self$`cart_name` <- `cart_name`
      }
      if (!is.null(`cart_versions`)) {
        if (!(is.character(`cart_versions`) && length(`cart_versions`) == 1)) {
          stop(paste("Error! Invalid data for `cart_versions`. Must be a string:", `cart_versions`))
        }
        self$`cart_versions` <- `cart_versions`
      }
      if (!is.null(`cart_method`)) {
        if (!(is.character(`cart_method`) && length(`cart_method`) == 1)) {
          stop(paste("Error! Invalid data for `cart_method`. Must be a string:", `cart_method`))
        }
        self$`cart_method` <- `cart_method`
      }
      if (!is.null(`params`)) {
        stopifnot(R6::is.R6(`params`))
        self$`params` <- `params`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return AccountSupportedPlatforms200ResponseResultSupportedPlatformsInner as a base R list.
    #' @examples
    #' # convert array of AccountSupportedPlatforms200ResponseResultSupportedPlatformsInner (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert AccountSupportedPlatforms200ResponseResultSupportedPlatformsInner to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      AccountSupportedPlatforms200ResponseResultSupportedPlatformsInnerObject <- list()
      if (!is.null(self$`cart_id`)) {
        AccountSupportedPlatforms200ResponseResultSupportedPlatformsInnerObject[["cart_id"]] <-
          self$`cart_id`
      }
      if (!is.null(self$`cart_name`)) {
        AccountSupportedPlatforms200ResponseResultSupportedPlatformsInnerObject[["cart_name"]] <-
          self$`cart_name`
      }
      if (!is.null(self$`cart_versions`)) {
        AccountSupportedPlatforms200ResponseResultSupportedPlatformsInnerObject[["cart_versions"]] <-
          self$`cart_versions`
      }
      if (!is.null(self$`cart_method`)) {
        AccountSupportedPlatforms200ResponseResultSupportedPlatformsInnerObject[["cart_method"]] <-
          self$`cart_method`
      }
      if (!is.null(self$`params`)) {
        AccountSupportedPlatforms200ResponseResultSupportedPlatformsInnerObject[["params"]] <-
          self$`params`$toSimpleType()
      }
      return(AccountSupportedPlatforms200ResponseResultSupportedPlatformsInnerObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of AccountSupportedPlatforms200ResponseResultSupportedPlatformsInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of AccountSupportedPlatforms200ResponseResultSupportedPlatformsInner
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`cart_id`)) {
        self$`cart_id` <- this_object$`cart_id`
      }
      if (!is.null(this_object$`cart_name`)) {
        self$`cart_name` <- this_object$`cart_name`
      }
      if (!is.null(this_object$`cart_versions`)) {
        self$`cart_versions` <- this_object$`cart_versions`
      }
      if (!is.null(this_object$`cart_method`)) {
        self$`cart_method` <- this_object$`cart_method`
      }
      if (!is.null(this_object$`params`)) {
        `params_object` <- AccountSupportedPlatforms200ResponseResultSupportedPlatformsInnerParams$new()
        `params_object`$fromJSON(jsonlite::toJSON(this_object$`params`, auto_unbox = TRUE, digits = NA))
        self$`params` <- `params_object`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return AccountSupportedPlatforms200ResponseResultSupportedPlatformsInner in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of AccountSupportedPlatforms200ResponseResultSupportedPlatformsInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of AccountSupportedPlatforms200ResponseResultSupportedPlatformsInner
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`cart_id` <- this_object$`cart_id`
      self$`cart_name` <- this_object$`cart_name`
      self$`cart_versions` <- this_object$`cart_versions`
      self$`cart_method` <- this_object$`cart_method`
      self$`params` <- AccountSupportedPlatforms200ResponseResultSupportedPlatformsInnerParams$new()$fromJSON(jsonlite::toJSON(this_object$`params`, auto_unbox = TRUE, digits = NA))
      self
    },

    #' @description
    #' Validate JSON input with respect to AccountSupportedPlatforms200ResponseResultSupportedPlatformsInner and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of AccountSupportedPlatforms200ResponseResultSupportedPlatformsInner
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# AccountSupportedPlatforms200ResponseResultSupportedPlatformsInner$unlock()
#
## Below is an example to define the print function
# AccountSupportedPlatforms200ResponseResultSupportedPlatformsInner$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# AccountSupportedPlatforms200ResponseResultSupportedPlatformsInner$lock()

