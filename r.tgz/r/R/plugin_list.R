#' Create a new PluginList
#'
#' @description
#' PluginList Class
#'
#' @docType class
#' @title PluginList
#' @description PluginList Class
#' @format An \code{R6Class} generator object
#' @field all_plugins  integer [optional]
#' @field plugins  list(\link{Plugin}) [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
PluginList <- R6::R6Class(
  "PluginList",
  public = list(
    `all_plugins` = NULL,
    `plugins` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new PluginList class.
    #'
    #' @param all_plugins all_plugins
    #' @param plugins plugins
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`all_plugins` = NULL, `plugins` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`all_plugins`)) {
        if (!(is.numeric(`all_plugins`) && length(`all_plugins`) == 1)) {
          stop(paste("Error! Invalid data for `all_plugins`. Must be an integer:", `all_plugins`))
        }
        self$`all_plugins` <- `all_plugins`
      }
      if (!is.null(`plugins`)) {
        stopifnot(is.vector(`plugins`), length(`plugins`) != 0)
        sapply(`plugins`, function(x) stopifnot(R6::is.R6(x)))
        self$`plugins` <- `plugins`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return PluginList as a base R list.
    #' @examples
    #' # convert array of PluginList (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert PluginList to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      PluginListObject <- list()
      if (!is.null(self$`all_plugins`)) {
        PluginListObject[["all_plugins"]] <-
          self$`all_plugins`
      }
      if (!is.null(self$`plugins`)) {
        PluginListObject[["plugins"]] <-
          lapply(self$`plugins`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`additional_fields`)) {
        PluginListObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        PluginListObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(PluginListObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of PluginList
    #'
    #' @param input_json the JSON input
    #' @return the instance of PluginList
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`all_plugins`)) {
        self$`all_plugins` <- this_object$`all_plugins`
      }
      if (!is.null(this_object$`plugins`)) {
        self$`plugins` <- ApiClient$new()$deserializeObj(this_object$`plugins`, "array[Plugin]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return PluginList in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of PluginList
    #'
    #' @param input_json the JSON input
    #' @return the instance of PluginList
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`all_plugins` <- this_object$`all_plugins`
      self$`plugins` <- ApiClient$new()$deserializeObj(this_object$`plugins`, "array[Plugin]", loadNamespace("openapi"))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to PluginList and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of PluginList
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# PluginList$unlock()
#
## Below is an example to define the print function
# PluginList$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# PluginList$lock()

