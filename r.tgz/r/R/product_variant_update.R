#' Create a new ProductVariantUpdate
#'
#' @description
#' ProductVariantUpdate Class
#'
#' @docType class
#' @title ProductVariantUpdate
#' @description ProductVariantUpdate Class
#' @format An \code{R6Class} generator object
#' @field id Defines variant update specified by variant id character [optional]
#' @field product_id Defines product's id where the variant has to be updated character [optional]
#' @field store_id Defines store id where the variant should be found character [optional]
#' @field lang_id Language id character [optional]
#' @field options Defines variant's options list list(\link{ProductVariantUpdateOptionsInner}) [optional]
#' @field name Defines variant's name that has to be updated character [optional]
#' @field description Specifies variant's description character [optional]
#' @field short_description Defines short description character [optional]
#' @field model Specifies variant's model that has to be added character [optional]
#' @field sku Defines new product's variant sku character [optional]
#' @field visible Set visibility status character [optional]
#' @field status Defines product variant's status character [optional]
#' @field backorder_status Set backorder status character [optional]
#' @field low_stock_threshold Specify the quantity threshold below which the product is considered low in stock numeric [optional]
#' @field available_for_sale Specifies the set of visible/invisible product's variants for sale character [optional]
#' @field avail Defines category's visibility status character [optional]
#' @field is_default Defines as a default variant character [optional]
#' @field is_free_shipping Specifies variant's free shipping flag that has to be added character [optional]
#' @field taxable Specifies whether a tax is charged character [optional]
#' @field tax_class_id Defines tax classes where entity has to be added character [optional]
#' @field is_virtual Defines whether the product is virtual character [optional]
#' @field manage_stock Defines inventory tracking for product variant character [optional]
#' @field in_stock Set stock status character [optional]
#' @field warehouse_id This parameter is used for selecting a warehouse where you need to set/modify a product quantity. character [optional]
#' @field reserve_quantity This parameter allows to reserve/unreserve product variants quantity. numeric [optional]
#' @field quantity Defines new products' variants quantity numeric [optional]
#' @field increase_quantity Defines the incremental changes in product quantity numeric [optional]
#' @field reduce_quantity Defines the decrement changes in product quantity numeric [optional]
#' @field prices_inc_tax Indicates whether prices include tax. character [optional]
#' @field price Defines new product's variant price numeric [optional]
#' @field special_price Defines new product's variant special price numeric [optional]
#' @field retail_price Defines new product's retail price numeric [optional]
#' @field old_price Defines product's old price numeric [optional]
#' @field cost_price Defines new product's cost price numeric [optional]
#' @field fixed_cost_shipping_price Specifies fixed cost shipping price numeric [optional]
#' @field sprice_create Defines the date of special price creation character [optional]
#' @field sprice_expire Defines the term of special price offer duration character [optional]
#' @field measure_unit Unit for the price per unit. Must be in allowed list character [optional]
#' @field unit_price Defines new product's unit price numeric [optional]
#' @field weight Weight numeric [optional]
#' @field barcode A barcode is a unique code composed of numbers used as a product identifier. character [optional]
#' @field width Defines product's width numeric [optional]
#' @field weight_unit Weight Unit character [optional]
#' @field height Defines product's height numeric [optional]
#' @field length Defines product's length numeric [optional]
#' @field gtin Global Trade Item Number. An GTIN is an identifier for trade items. character [optional]
#' @field upc Universal Product Code. A UPC (UPC-A) is a commonly used identifer for many different products. character [optional]
#' @field mpn Manufacturer Part Number. A MPN is an identifier of a particular part design or material used. character [optional]
#' @field ean European Article Number. An EAN is a unique 8 or 13-digit identifier that many industries (such as book publishers) use to identify products. character [optional]
#' @field isbn International Standard Book Number. An ISBN is a unique identifier for books. character [optional]
#' @field harmonized_system_code Harmonized System Code. An HSC is a 6-digit identifier that allows participating countries to classify traded goods on a common basis for customs purposes character [optional]
#' @field country_of_origin The country where the inventory item was made character [optional]
#' @field meta_title Defines unique meta title for each entity character [optional]
#' @field meta_description Defines unique meta description of a entity character [optional]
#' @field meta_keywords Defines unique meta keywords for each entity character [optional]
#' @field manufacturer Specifies the product variant's manufacturer character [optional]
#' @field reindex Is reindex required character [optional]
#' @field clear_cache Is cache clear required character [optional]
#' @field processing_profile_id The numeric ID of the processing profile (readiness state) for physical products in Etsy. You can find possible values in the \"cart.info\" API method response, in the field processing_profiles[]->readiness_state_id. integer [optional]
#' @field idempotency_key A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong> character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductVariantUpdate <- R6::R6Class(
  "ProductVariantUpdate",
  public = list(
    `id` = NULL,
    `product_id` = NULL,
    `store_id` = NULL,
    `lang_id` = NULL,
    `options` = NULL,
    `name` = NULL,
    `description` = NULL,
    `short_description` = NULL,
    `model` = NULL,
    `sku` = NULL,
    `visible` = NULL,
    `status` = NULL,
    `backorder_status` = NULL,
    `low_stock_threshold` = NULL,
    `available_for_sale` = NULL,
    `avail` = NULL,
    `is_default` = NULL,
    `is_free_shipping` = NULL,
    `taxable` = NULL,
    `tax_class_id` = NULL,
    `is_virtual` = NULL,
    `manage_stock` = NULL,
    `in_stock` = NULL,
    `warehouse_id` = NULL,
    `reserve_quantity` = NULL,
    `quantity` = NULL,
    `increase_quantity` = NULL,
    `reduce_quantity` = NULL,
    `prices_inc_tax` = NULL,
    `price` = NULL,
    `special_price` = NULL,
    `retail_price` = NULL,
    `old_price` = NULL,
    `cost_price` = NULL,
    `fixed_cost_shipping_price` = NULL,
    `sprice_create` = NULL,
    `sprice_expire` = NULL,
    `measure_unit` = NULL,
    `unit_price` = NULL,
    `weight` = NULL,
    `barcode` = NULL,
    `width` = NULL,
    `weight_unit` = NULL,
    `height` = NULL,
    `length` = NULL,
    `gtin` = NULL,
    `upc` = NULL,
    `mpn` = NULL,
    `ean` = NULL,
    `isbn` = NULL,
    `harmonized_system_code` = NULL,
    `country_of_origin` = NULL,
    `meta_title` = NULL,
    `meta_description` = NULL,
    `meta_keywords` = NULL,
    `manufacturer` = NULL,
    `reindex` = NULL,
    `clear_cache` = NULL,
    `processing_profile_id` = NULL,
    `idempotency_key` = NULL,

    #' @description
    #' Initialize a new ProductVariantUpdate class.
    #'
    #' @param id Defines variant update specified by variant id
    #' @param product_id Defines product's id where the variant has to be updated
    #' @param store_id Defines store id where the variant should be found
    #' @param lang_id Language id
    #' @param options Defines variant's options list
    #' @param name Defines variant's name that has to be updated
    #' @param description Specifies variant's description
    #' @param short_description Defines short description
    #' @param model Specifies variant's model that has to be added
    #' @param sku Defines new product's variant sku
    #' @param visible Set visibility status
    #' @param status Defines product variant's status
    #' @param backorder_status Set backorder status
    #' @param low_stock_threshold Specify the quantity threshold below which the product is considered low in stock
    #' @param available_for_sale Specifies the set of visible/invisible product's variants for sale. Default to TRUE.
    #' @param avail Defines category's visibility status. Default to TRUE.
    #' @param is_default Defines as a default variant
    #' @param is_free_shipping Specifies variant's free shipping flag that has to be added
    #' @param taxable Specifies whether a tax is charged
    #' @param tax_class_id Defines tax classes where entity has to be added
    #' @param is_virtual Defines whether the product is virtual. Default to FALSE.
    #' @param manage_stock Defines inventory tracking for product variant
    #' @param in_stock Set stock status
    #' @param warehouse_id This parameter is used for selecting a warehouse where you need to set/modify a product quantity.
    #' @param reserve_quantity This parameter allows to reserve/unreserve product variants quantity.
    #' @param quantity Defines new products' variants quantity
    #' @param increase_quantity Defines the incremental changes in product quantity. Default to 0.
    #' @param reduce_quantity Defines the decrement changes in product quantity. Default to 0.
    #' @param prices_inc_tax Indicates whether prices include tax.. Default to FALSE.
    #' @param price Defines new product's variant price
    #' @param special_price Defines new product's variant special price
    #' @param retail_price Defines new product's retail price
    #' @param old_price Defines product's old price
    #' @param cost_price Defines new product's cost price
    #' @param fixed_cost_shipping_price Specifies fixed cost shipping price
    #' @param sprice_create Defines the date of special price creation
    #' @param sprice_expire Defines the term of special price offer duration
    #' @param measure_unit Unit for the price per unit. Must be in allowed list
    #' @param unit_price Defines new product's unit price
    #' @param weight Weight. Default to 0.
    #' @param barcode A barcode is a unique code composed of numbers used as a product identifier.
    #' @param width Defines product's width
    #' @param weight_unit Weight Unit
    #' @param height Defines product's height
    #' @param length Defines product's length
    #' @param gtin Global Trade Item Number. An GTIN is an identifier for trade items.
    #' @param upc Universal Product Code. A UPC (UPC-A) is a commonly used identifer for many different products.
    #' @param mpn Manufacturer Part Number. A MPN is an identifier of a particular part design or material used.
    #' @param ean European Article Number. An EAN is a unique 8 or 13-digit identifier that many industries (such as book publishers) use to identify products.
    #' @param isbn International Standard Book Number. An ISBN is a unique identifier for books.
    #' @param harmonized_system_code Harmonized System Code. An HSC is a 6-digit identifier that allows participating countries to classify traded goods on a common basis for customs purposes
    #' @param country_of_origin The country where the inventory item was made
    #' @param meta_title Defines unique meta title for each entity
    #' @param meta_description Defines unique meta description of a entity
    #' @param meta_keywords Defines unique meta keywords for each entity
    #' @param manufacturer Specifies the product variant's manufacturer
    #' @param reindex Is reindex required. Default to TRUE.
    #' @param clear_cache Is cache clear required. Default to TRUE.
    #' @param processing_profile_id The numeric ID of the processing profile (readiness state) for physical products in Etsy. You can find possible values in the \"cart.info\" API method response, in the field processing_profiles[]->readiness_state_id.
    #' @param idempotency_key A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong>
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `product_id` = NULL, `store_id` = NULL, `lang_id` = NULL, `options` = NULL, `name` = NULL, `description` = NULL, `short_description` = NULL, `model` = NULL, `sku` = NULL, `visible` = NULL, `status` = NULL, `backorder_status` = NULL, `low_stock_threshold` = NULL, `available_for_sale` = TRUE, `avail` = TRUE, `is_default` = NULL, `is_free_shipping` = NULL, `taxable` = NULL, `tax_class_id` = NULL, `is_virtual` = FALSE, `manage_stock` = NULL, `in_stock` = NULL, `warehouse_id` = NULL, `reserve_quantity` = NULL, `quantity` = NULL, `increase_quantity` = 0, `reduce_quantity` = 0, `prices_inc_tax` = FALSE, `price` = NULL, `special_price` = NULL, `retail_price` = NULL, `old_price` = NULL, `cost_price` = NULL, `fixed_cost_shipping_price` = NULL, `sprice_create` = NULL, `sprice_expire` = NULL, `measure_unit` = NULL, `unit_price` = NULL, `weight` = 0, `barcode` = NULL, `width` = NULL, `weight_unit` = NULL, `height` = NULL, `length` = NULL, `gtin` = NULL, `upc` = NULL, `mpn` = NULL, `ean` = NULL, `isbn` = NULL, `harmonized_system_code` = NULL, `country_of_origin` = NULL, `meta_title` = NULL, `meta_description` = NULL, `meta_keywords` = NULL, `manufacturer` = NULL, `reindex` = TRUE, `clear_cache` = TRUE, `processing_profile_id` = NULL, `idempotency_key` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`product_id`)) {
        if (!(is.character(`product_id`) && length(`product_id`) == 1)) {
          stop(paste("Error! Invalid data for `product_id`. Must be a string:", `product_id`))
        }
        self$`product_id` <- `product_id`
      }
      if (!is.null(`store_id`)) {
        if (!(is.character(`store_id`) && length(`store_id`) == 1)) {
          stop(paste("Error! Invalid data for `store_id`. Must be a string:", `store_id`))
        }
        self$`store_id` <- `store_id`
      }
      if (!is.null(`lang_id`)) {
        if (!(is.character(`lang_id`) && length(`lang_id`) == 1)) {
          stop(paste("Error! Invalid data for `lang_id`. Must be a string:", `lang_id`))
        }
        self$`lang_id` <- `lang_id`
      }
      if (!is.null(`options`)) {
        stopifnot(is.vector(`options`), length(`options`) != 0)
        sapply(`options`, function(x) stopifnot(R6::is.R6(x)))
        self$`options` <- `options`
      }
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`description`)) {
        if (!(is.character(`description`) && length(`description`) == 1)) {
          stop(paste("Error! Invalid data for `description`. Must be a string:", `description`))
        }
        self$`description` <- `description`
      }
      if (!is.null(`short_description`)) {
        if (!(is.character(`short_description`) && length(`short_description`) == 1)) {
          stop(paste("Error! Invalid data for `short_description`. Must be a string:", `short_description`))
        }
        self$`short_description` <- `short_description`
      }
      if (!is.null(`model`)) {
        if (!(is.character(`model`) && length(`model`) == 1)) {
          stop(paste("Error! Invalid data for `model`. Must be a string:", `model`))
        }
        self$`model` <- `model`
      }
      if (!is.null(`sku`)) {
        if (!(is.character(`sku`) && length(`sku`) == 1)) {
          stop(paste("Error! Invalid data for `sku`. Must be a string:", `sku`))
        }
        self$`sku` <- `sku`
      }
      if (!is.null(`visible`)) {
        if (!(is.character(`visible`) && length(`visible`) == 1)) {
          stop(paste("Error! Invalid data for `visible`. Must be a string:", `visible`))
        }
        self$`visible` <- `visible`
      }
      if (!is.null(`status`)) {
        if (!(is.character(`status`) && length(`status`) == 1)) {
          stop(paste("Error! Invalid data for `status`. Must be a string:", `status`))
        }
        self$`status` <- `status`
      }
      if (!is.null(`backorder_status`)) {
        if (!(is.character(`backorder_status`) && length(`backorder_status`) == 1)) {
          stop(paste("Error! Invalid data for `backorder_status`. Must be a string:", `backorder_status`))
        }
        self$`backorder_status` <- `backorder_status`
      }
      if (!is.null(`low_stock_threshold`)) {
        self$`low_stock_threshold` <- `low_stock_threshold`
      }
      if (!is.null(`available_for_sale`)) {
        if (!(is.logical(`available_for_sale`) && length(`available_for_sale`) == 1)) {
          stop(paste("Error! Invalid data for `available_for_sale`. Must be a boolean:", `available_for_sale`))
        }
        self$`available_for_sale` <- `available_for_sale`
      }
      if (!is.null(`avail`)) {
        if (!(is.logical(`avail`) && length(`avail`) == 1)) {
          stop(paste("Error! Invalid data for `avail`. Must be a boolean:", `avail`))
        }
        self$`avail` <- `avail`
      }
      if (!is.null(`is_default`)) {
        if (!(is.logical(`is_default`) && length(`is_default`) == 1)) {
          stop(paste("Error! Invalid data for `is_default`. Must be a boolean:", `is_default`))
        }
        self$`is_default` <- `is_default`
      }
      if (!is.null(`is_free_shipping`)) {
        if (!(is.logical(`is_free_shipping`) && length(`is_free_shipping`) == 1)) {
          stop(paste("Error! Invalid data for `is_free_shipping`. Must be a boolean:", `is_free_shipping`))
        }
        self$`is_free_shipping` <- `is_free_shipping`
      }
      if (!is.null(`taxable`)) {
        if (!(is.logical(`taxable`) && length(`taxable`) == 1)) {
          stop(paste("Error! Invalid data for `taxable`. Must be a boolean:", `taxable`))
        }
        self$`taxable` <- `taxable`
      }
      if (!is.null(`tax_class_id`)) {
        if (!(is.character(`tax_class_id`) && length(`tax_class_id`) == 1)) {
          stop(paste("Error! Invalid data for `tax_class_id`. Must be a string:", `tax_class_id`))
        }
        self$`tax_class_id` <- `tax_class_id`
      }
      if (!is.null(`is_virtual`)) {
        if (!(is.logical(`is_virtual`) && length(`is_virtual`) == 1)) {
          stop(paste("Error! Invalid data for `is_virtual`. Must be a boolean:", `is_virtual`))
        }
        self$`is_virtual` <- `is_virtual`
      }
      if (!is.null(`manage_stock`)) {
        if (!(is.logical(`manage_stock`) && length(`manage_stock`) == 1)) {
          stop(paste("Error! Invalid data for `manage_stock`. Must be a boolean:", `manage_stock`))
        }
        self$`manage_stock` <- `manage_stock`
      }
      if (!is.null(`in_stock`)) {
        if (!(is.logical(`in_stock`) && length(`in_stock`) == 1)) {
          stop(paste("Error! Invalid data for `in_stock`. Must be a boolean:", `in_stock`))
        }
        self$`in_stock` <- `in_stock`
      }
      if (!is.null(`warehouse_id`)) {
        if (!(is.character(`warehouse_id`) && length(`warehouse_id`) == 1)) {
          stop(paste("Error! Invalid data for `warehouse_id`. Must be a string:", `warehouse_id`))
        }
        self$`warehouse_id` <- `warehouse_id`
      }
      if (!is.null(`reserve_quantity`)) {
        self$`reserve_quantity` <- `reserve_quantity`
      }
      if (!is.null(`quantity`)) {
        self$`quantity` <- `quantity`
      }
      if (!is.null(`increase_quantity`)) {
        self$`increase_quantity` <- `increase_quantity`
      }
      if (!is.null(`reduce_quantity`)) {
        self$`reduce_quantity` <- `reduce_quantity`
      }
      if (!is.null(`prices_inc_tax`)) {
        if (!(is.logical(`prices_inc_tax`) && length(`prices_inc_tax`) == 1)) {
          stop(paste("Error! Invalid data for `prices_inc_tax`. Must be a boolean:", `prices_inc_tax`))
        }
        self$`prices_inc_tax` <- `prices_inc_tax`
      }
      if (!is.null(`price`)) {
        self$`price` <- `price`
      }
      if (!is.null(`special_price`)) {
        self$`special_price` <- `special_price`
      }
      if (!is.null(`retail_price`)) {
        self$`retail_price` <- `retail_price`
      }
      if (!is.null(`old_price`)) {
        self$`old_price` <- `old_price`
      }
      if (!is.null(`cost_price`)) {
        self$`cost_price` <- `cost_price`
      }
      if (!is.null(`fixed_cost_shipping_price`)) {
        self$`fixed_cost_shipping_price` <- `fixed_cost_shipping_price`
      }
      if (!is.null(`sprice_create`)) {
        if (!(is.character(`sprice_create`) && length(`sprice_create`) == 1)) {
          stop(paste("Error! Invalid data for `sprice_create`. Must be a string:", `sprice_create`))
        }
        self$`sprice_create` <- `sprice_create`
      }
      if (!is.null(`sprice_expire`)) {
        if (!(is.character(`sprice_expire`) && length(`sprice_expire`) == 1)) {
          stop(paste("Error! Invalid data for `sprice_expire`. Must be a string:", `sprice_expire`))
        }
        self$`sprice_expire` <- `sprice_expire`
      }
      if (!is.null(`measure_unit`)) {
        if (!(is.character(`measure_unit`) && length(`measure_unit`) == 1)) {
          stop(paste("Error! Invalid data for `measure_unit`. Must be a string:", `measure_unit`))
        }
        self$`measure_unit` <- `measure_unit`
      }
      if (!is.null(`unit_price`)) {
        self$`unit_price` <- `unit_price`
      }
      if (!is.null(`weight`)) {
        self$`weight` <- `weight`
      }
      if (!is.null(`barcode`)) {
        if (!(is.character(`barcode`) && length(`barcode`) == 1)) {
          stop(paste("Error! Invalid data for `barcode`. Must be a string:", `barcode`))
        }
        self$`barcode` <- `barcode`
      }
      if (!is.null(`width`)) {
        self$`width` <- `width`
      }
      if (!is.null(`weight_unit`)) {
        if (!(is.character(`weight_unit`) && length(`weight_unit`) == 1)) {
          stop(paste("Error! Invalid data for `weight_unit`. Must be a string:", `weight_unit`))
        }
        self$`weight_unit` <- `weight_unit`
      }
      if (!is.null(`height`)) {
        self$`height` <- `height`
      }
      if (!is.null(`length`)) {
        self$`length` <- `length`
      }
      if (!is.null(`gtin`)) {
        if (!(is.character(`gtin`) && length(`gtin`) == 1)) {
          stop(paste("Error! Invalid data for `gtin`. Must be a string:", `gtin`))
        }
        self$`gtin` <- `gtin`
      }
      if (!is.null(`upc`)) {
        if (!(is.character(`upc`) && length(`upc`) == 1)) {
          stop(paste("Error! Invalid data for `upc`. Must be a string:", `upc`))
        }
        self$`upc` <- `upc`
      }
      if (!is.null(`mpn`)) {
        if (!(is.character(`mpn`) && length(`mpn`) == 1)) {
          stop(paste("Error! Invalid data for `mpn`. Must be a string:", `mpn`))
        }
        self$`mpn` <- `mpn`
      }
      if (!is.null(`ean`)) {
        if (!(is.character(`ean`) && length(`ean`) == 1)) {
          stop(paste("Error! Invalid data for `ean`. Must be a string:", `ean`))
        }
        self$`ean` <- `ean`
      }
      if (!is.null(`isbn`)) {
        if (!(is.character(`isbn`) && length(`isbn`) == 1)) {
          stop(paste("Error! Invalid data for `isbn`. Must be a string:", `isbn`))
        }
        self$`isbn` <- `isbn`
      }
      if (!is.null(`harmonized_system_code`)) {
        if (!(is.character(`harmonized_system_code`) && length(`harmonized_system_code`) == 1)) {
          stop(paste("Error! Invalid data for `harmonized_system_code`. Must be a string:", `harmonized_system_code`))
        }
        self$`harmonized_system_code` <- `harmonized_system_code`
      }
      if (!is.null(`country_of_origin`)) {
        if (!(is.character(`country_of_origin`) && length(`country_of_origin`) == 1)) {
          stop(paste("Error! Invalid data for `country_of_origin`. Must be a string:", `country_of_origin`))
        }
        self$`country_of_origin` <- `country_of_origin`
      }
      if (!is.null(`meta_title`)) {
        if (!(is.character(`meta_title`) && length(`meta_title`) == 1)) {
          stop(paste("Error! Invalid data for `meta_title`. Must be a string:", `meta_title`))
        }
        self$`meta_title` <- `meta_title`
      }
      if (!is.null(`meta_description`)) {
        if (!(is.character(`meta_description`) && length(`meta_description`) == 1)) {
          stop(paste("Error! Invalid data for `meta_description`. Must be a string:", `meta_description`))
        }
        self$`meta_description` <- `meta_description`
      }
      if (!is.null(`meta_keywords`)) {
        if (!(is.character(`meta_keywords`) && length(`meta_keywords`) == 1)) {
          stop(paste("Error! Invalid data for `meta_keywords`. Must be a string:", `meta_keywords`))
        }
        self$`meta_keywords` <- `meta_keywords`
      }
      if (!is.null(`manufacturer`)) {
        if (!(is.character(`manufacturer`) && length(`manufacturer`) == 1)) {
          stop(paste("Error! Invalid data for `manufacturer`. Must be a string:", `manufacturer`))
        }
        self$`manufacturer` <- `manufacturer`
      }
      if (!is.null(`reindex`)) {
        if (!(is.logical(`reindex`) && length(`reindex`) == 1)) {
          stop(paste("Error! Invalid data for `reindex`. Must be a boolean:", `reindex`))
        }
        self$`reindex` <- `reindex`
      }
      if (!is.null(`clear_cache`)) {
        if (!(is.logical(`clear_cache`) && length(`clear_cache`) == 1)) {
          stop(paste("Error! Invalid data for `clear_cache`. Must be a boolean:", `clear_cache`))
        }
        self$`clear_cache` <- `clear_cache`
      }
      if (!is.null(`processing_profile_id`)) {
        if (!(is.numeric(`processing_profile_id`) && length(`processing_profile_id`) == 1)) {
          stop(paste("Error! Invalid data for `processing_profile_id`. Must be an integer:", `processing_profile_id`))
        }
        self$`processing_profile_id` <- `processing_profile_id`
      }
      if (!is.null(`idempotency_key`)) {
        if (!(is.character(`idempotency_key`) && length(`idempotency_key`) == 1)) {
          stop(paste("Error! Invalid data for `idempotency_key`. Must be a string:", `idempotency_key`))
        }
        self$`idempotency_key` <- `idempotency_key`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductVariantUpdate as a base R list.
    #' @examples
    #' # convert array of ProductVariantUpdate (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductVariantUpdate to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductVariantUpdateObject <- list()
      if (!is.null(self$`id`)) {
        ProductVariantUpdateObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`product_id`)) {
        ProductVariantUpdateObject[["product_id"]] <-
          self$`product_id`
      }
      if (!is.null(self$`store_id`)) {
        ProductVariantUpdateObject[["store_id"]] <-
          self$`store_id`
      }
      if (!is.null(self$`lang_id`)) {
        ProductVariantUpdateObject[["lang_id"]] <-
          self$`lang_id`
      }
      if (!is.null(self$`options`)) {
        ProductVariantUpdateObject[["options"]] <-
          lapply(self$`options`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`name`)) {
        ProductVariantUpdateObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`description`)) {
        ProductVariantUpdateObject[["description"]] <-
          self$`description`
      }
      if (!is.null(self$`short_description`)) {
        ProductVariantUpdateObject[["short_description"]] <-
          self$`short_description`
      }
      if (!is.null(self$`model`)) {
        ProductVariantUpdateObject[["model"]] <-
          self$`model`
      }
      if (!is.null(self$`sku`)) {
        ProductVariantUpdateObject[["sku"]] <-
          self$`sku`
      }
      if (!is.null(self$`visible`)) {
        ProductVariantUpdateObject[["visible"]] <-
          self$`visible`
      }
      if (!is.null(self$`status`)) {
        ProductVariantUpdateObject[["status"]] <-
          self$`status`
      }
      if (!is.null(self$`backorder_status`)) {
        ProductVariantUpdateObject[["backorder_status"]] <-
          self$`backorder_status`
      }
      if (!is.null(self$`low_stock_threshold`)) {
        ProductVariantUpdateObject[["low_stock_threshold"]] <-
          self$`low_stock_threshold`
      }
      if (!is.null(self$`available_for_sale`)) {
        ProductVariantUpdateObject[["available_for_sale"]] <-
          self$`available_for_sale`
      }
      if (!is.null(self$`avail`)) {
        ProductVariantUpdateObject[["avail"]] <-
          self$`avail`
      }
      if (!is.null(self$`is_default`)) {
        ProductVariantUpdateObject[["is_default"]] <-
          self$`is_default`
      }
      if (!is.null(self$`is_free_shipping`)) {
        ProductVariantUpdateObject[["is_free_shipping"]] <-
          self$`is_free_shipping`
      }
      if (!is.null(self$`taxable`)) {
        ProductVariantUpdateObject[["taxable"]] <-
          self$`taxable`
      }
      if (!is.null(self$`tax_class_id`)) {
        ProductVariantUpdateObject[["tax_class_id"]] <-
          self$`tax_class_id`
      }
      if (!is.null(self$`is_virtual`)) {
        ProductVariantUpdateObject[["is_virtual"]] <-
          self$`is_virtual`
      }
      if (!is.null(self$`manage_stock`)) {
        ProductVariantUpdateObject[["manage_stock"]] <-
          self$`manage_stock`
      }
      if (!is.null(self$`in_stock`)) {
        ProductVariantUpdateObject[["in_stock"]] <-
          self$`in_stock`
      }
      if (!is.null(self$`warehouse_id`)) {
        ProductVariantUpdateObject[["warehouse_id"]] <-
          self$`warehouse_id`
      }
      if (!is.null(self$`reserve_quantity`)) {
        ProductVariantUpdateObject[["reserve_quantity"]] <-
          self$`reserve_quantity`
      }
      if (!is.null(self$`quantity`)) {
        ProductVariantUpdateObject[["quantity"]] <-
          self$`quantity`
      }
      if (!is.null(self$`increase_quantity`)) {
        ProductVariantUpdateObject[["increase_quantity"]] <-
          self$`increase_quantity`
      }
      if (!is.null(self$`reduce_quantity`)) {
        ProductVariantUpdateObject[["reduce_quantity"]] <-
          self$`reduce_quantity`
      }
      if (!is.null(self$`prices_inc_tax`)) {
        ProductVariantUpdateObject[["prices_inc_tax"]] <-
          self$`prices_inc_tax`
      }
      if (!is.null(self$`price`)) {
        ProductVariantUpdateObject[["price"]] <-
          self$`price`
      }
      if (!is.null(self$`special_price`)) {
        ProductVariantUpdateObject[["special_price"]] <-
          self$`special_price`
      }
      if (!is.null(self$`retail_price`)) {
        ProductVariantUpdateObject[["retail_price"]] <-
          self$`retail_price`
      }
      if (!is.null(self$`old_price`)) {
        ProductVariantUpdateObject[["old_price"]] <-
          self$`old_price`
      }
      if (!is.null(self$`cost_price`)) {
        ProductVariantUpdateObject[["cost_price"]] <-
          self$`cost_price`
      }
      if (!is.null(self$`fixed_cost_shipping_price`)) {
        ProductVariantUpdateObject[["fixed_cost_shipping_price"]] <-
          self$`fixed_cost_shipping_price`
      }
      if (!is.null(self$`sprice_create`)) {
        ProductVariantUpdateObject[["sprice_create"]] <-
          self$`sprice_create`
      }
      if (!is.null(self$`sprice_expire`)) {
        ProductVariantUpdateObject[["sprice_expire"]] <-
          self$`sprice_expire`
      }
      if (!is.null(self$`measure_unit`)) {
        ProductVariantUpdateObject[["measure_unit"]] <-
          self$`measure_unit`
      }
      if (!is.null(self$`unit_price`)) {
        ProductVariantUpdateObject[["unit_price"]] <-
          self$`unit_price`
      }
      if (!is.null(self$`weight`)) {
        ProductVariantUpdateObject[["weight"]] <-
          self$`weight`
      }
      if (!is.null(self$`barcode`)) {
        ProductVariantUpdateObject[["barcode"]] <-
          self$`barcode`
      }
      if (!is.null(self$`width`)) {
        ProductVariantUpdateObject[["width"]] <-
          self$`width`
      }
      if (!is.null(self$`weight_unit`)) {
        ProductVariantUpdateObject[["weight_unit"]] <-
          self$`weight_unit`
      }
      if (!is.null(self$`height`)) {
        ProductVariantUpdateObject[["height"]] <-
          self$`height`
      }
      if (!is.null(self$`length`)) {
        ProductVariantUpdateObject[["length"]] <-
          self$`length`
      }
      if (!is.null(self$`gtin`)) {
        ProductVariantUpdateObject[["gtin"]] <-
          self$`gtin`
      }
      if (!is.null(self$`upc`)) {
        ProductVariantUpdateObject[["upc"]] <-
          self$`upc`
      }
      if (!is.null(self$`mpn`)) {
        ProductVariantUpdateObject[["mpn"]] <-
          self$`mpn`
      }
      if (!is.null(self$`ean`)) {
        ProductVariantUpdateObject[["ean"]] <-
          self$`ean`
      }
      if (!is.null(self$`isbn`)) {
        ProductVariantUpdateObject[["isbn"]] <-
          self$`isbn`
      }
      if (!is.null(self$`harmonized_system_code`)) {
        ProductVariantUpdateObject[["harmonized_system_code"]] <-
          self$`harmonized_system_code`
      }
      if (!is.null(self$`country_of_origin`)) {
        ProductVariantUpdateObject[["country_of_origin"]] <-
          self$`country_of_origin`
      }
      if (!is.null(self$`meta_title`)) {
        ProductVariantUpdateObject[["meta_title"]] <-
          self$`meta_title`
      }
      if (!is.null(self$`meta_description`)) {
        ProductVariantUpdateObject[["meta_description"]] <-
          self$`meta_description`
      }
      if (!is.null(self$`meta_keywords`)) {
        ProductVariantUpdateObject[["meta_keywords"]] <-
          self$`meta_keywords`
      }
      if (!is.null(self$`manufacturer`)) {
        ProductVariantUpdateObject[["manufacturer"]] <-
          self$`manufacturer`
      }
      if (!is.null(self$`reindex`)) {
        ProductVariantUpdateObject[["reindex"]] <-
          self$`reindex`
      }
      if (!is.null(self$`clear_cache`)) {
        ProductVariantUpdateObject[["clear_cache"]] <-
          self$`clear_cache`
      }
      if (!is.null(self$`processing_profile_id`)) {
        ProductVariantUpdateObject[["processing_profile_id"]] <-
          self$`processing_profile_id`
      }
      if (!is.null(self$`idempotency_key`)) {
        ProductVariantUpdateObject[["idempotency_key"]] <-
          self$`idempotency_key`
      }
      return(ProductVariantUpdateObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductVariantUpdate
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductVariantUpdate
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`product_id`)) {
        self$`product_id` <- this_object$`product_id`
      }
      if (!is.null(this_object$`store_id`)) {
        self$`store_id` <- this_object$`store_id`
      }
      if (!is.null(this_object$`lang_id`)) {
        self$`lang_id` <- this_object$`lang_id`
      }
      if (!is.null(this_object$`options`)) {
        self$`options` <- ApiClient$new()$deserializeObj(this_object$`options`, "array[ProductVariantUpdateOptionsInner]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`description`)) {
        self$`description` <- this_object$`description`
      }
      if (!is.null(this_object$`short_description`)) {
        self$`short_description` <- this_object$`short_description`
      }
      if (!is.null(this_object$`model`)) {
        self$`model` <- this_object$`model`
      }
      if (!is.null(this_object$`sku`)) {
        self$`sku` <- this_object$`sku`
      }
      if (!is.null(this_object$`visible`)) {
        self$`visible` <- this_object$`visible`
      }
      if (!is.null(this_object$`status`)) {
        self$`status` <- this_object$`status`
      }
      if (!is.null(this_object$`backorder_status`)) {
        self$`backorder_status` <- this_object$`backorder_status`
      }
      if (!is.null(this_object$`low_stock_threshold`)) {
        self$`low_stock_threshold` <- this_object$`low_stock_threshold`
      }
      if (!is.null(this_object$`available_for_sale`)) {
        self$`available_for_sale` <- this_object$`available_for_sale`
      }
      if (!is.null(this_object$`avail`)) {
        self$`avail` <- this_object$`avail`
      }
      if (!is.null(this_object$`is_default`)) {
        self$`is_default` <- this_object$`is_default`
      }
      if (!is.null(this_object$`is_free_shipping`)) {
        self$`is_free_shipping` <- this_object$`is_free_shipping`
      }
      if (!is.null(this_object$`taxable`)) {
        self$`taxable` <- this_object$`taxable`
      }
      if (!is.null(this_object$`tax_class_id`)) {
        self$`tax_class_id` <- this_object$`tax_class_id`
      }
      if (!is.null(this_object$`is_virtual`)) {
        self$`is_virtual` <- this_object$`is_virtual`
      }
      if (!is.null(this_object$`manage_stock`)) {
        self$`manage_stock` <- this_object$`manage_stock`
      }
      if (!is.null(this_object$`in_stock`)) {
        self$`in_stock` <- this_object$`in_stock`
      }
      if (!is.null(this_object$`warehouse_id`)) {
        self$`warehouse_id` <- this_object$`warehouse_id`
      }
      if (!is.null(this_object$`reserve_quantity`)) {
        self$`reserve_quantity` <- this_object$`reserve_quantity`
      }
      if (!is.null(this_object$`quantity`)) {
        self$`quantity` <- this_object$`quantity`
      }
      if (!is.null(this_object$`increase_quantity`)) {
        self$`increase_quantity` <- this_object$`increase_quantity`
      }
      if (!is.null(this_object$`reduce_quantity`)) {
        self$`reduce_quantity` <- this_object$`reduce_quantity`
      }
      if (!is.null(this_object$`prices_inc_tax`)) {
        self$`prices_inc_tax` <- this_object$`prices_inc_tax`
      }
      if (!is.null(this_object$`price`)) {
        self$`price` <- this_object$`price`
      }
      if (!is.null(this_object$`special_price`)) {
        self$`special_price` <- this_object$`special_price`
      }
      if (!is.null(this_object$`retail_price`)) {
        self$`retail_price` <- this_object$`retail_price`
      }
      if (!is.null(this_object$`old_price`)) {
        self$`old_price` <- this_object$`old_price`
      }
      if (!is.null(this_object$`cost_price`)) {
        self$`cost_price` <- this_object$`cost_price`
      }
      if (!is.null(this_object$`fixed_cost_shipping_price`)) {
        self$`fixed_cost_shipping_price` <- this_object$`fixed_cost_shipping_price`
      }
      if (!is.null(this_object$`sprice_create`)) {
        self$`sprice_create` <- this_object$`sprice_create`
      }
      if (!is.null(this_object$`sprice_expire`)) {
        self$`sprice_expire` <- this_object$`sprice_expire`
      }
      if (!is.null(this_object$`measure_unit`)) {
        self$`measure_unit` <- this_object$`measure_unit`
      }
      if (!is.null(this_object$`unit_price`)) {
        self$`unit_price` <- this_object$`unit_price`
      }
      if (!is.null(this_object$`weight`)) {
        self$`weight` <- this_object$`weight`
      }
      if (!is.null(this_object$`barcode`)) {
        self$`barcode` <- this_object$`barcode`
      }
      if (!is.null(this_object$`width`)) {
        self$`width` <- this_object$`width`
      }
      if (!is.null(this_object$`weight_unit`)) {
        self$`weight_unit` <- this_object$`weight_unit`
      }
      if (!is.null(this_object$`height`)) {
        self$`height` <- this_object$`height`
      }
      if (!is.null(this_object$`length`)) {
        self$`length` <- this_object$`length`
      }
      if (!is.null(this_object$`gtin`)) {
        self$`gtin` <- this_object$`gtin`
      }
      if (!is.null(this_object$`upc`)) {
        self$`upc` <- this_object$`upc`
      }
      if (!is.null(this_object$`mpn`)) {
        self$`mpn` <- this_object$`mpn`
      }
      if (!is.null(this_object$`ean`)) {
        self$`ean` <- this_object$`ean`
      }
      if (!is.null(this_object$`isbn`)) {
        self$`isbn` <- this_object$`isbn`
      }
      if (!is.null(this_object$`harmonized_system_code`)) {
        self$`harmonized_system_code` <- this_object$`harmonized_system_code`
      }
      if (!is.null(this_object$`country_of_origin`)) {
        self$`country_of_origin` <- this_object$`country_of_origin`
      }
      if (!is.null(this_object$`meta_title`)) {
        self$`meta_title` <- this_object$`meta_title`
      }
      if (!is.null(this_object$`meta_description`)) {
        self$`meta_description` <- this_object$`meta_description`
      }
      if (!is.null(this_object$`meta_keywords`)) {
        self$`meta_keywords` <- this_object$`meta_keywords`
      }
      if (!is.null(this_object$`manufacturer`)) {
        self$`manufacturer` <- this_object$`manufacturer`
      }
      if (!is.null(this_object$`reindex`)) {
        self$`reindex` <- this_object$`reindex`
      }
      if (!is.null(this_object$`clear_cache`)) {
        self$`clear_cache` <- this_object$`clear_cache`
      }
      if (!is.null(this_object$`processing_profile_id`)) {
        self$`processing_profile_id` <- this_object$`processing_profile_id`
      }
      if (!is.null(this_object$`idempotency_key`)) {
        self$`idempotency_key` <- this_object$`idempotency_key`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductVariantUpdate in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductVariantUpdate
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductVariantUpdate
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`product_id` <- this_object$`product_id`
      self$`store_id` <- this_object$`store_id`
      self$`lang_id` <- this_object$`lang_id`
      self$`options` <- ApiClient$new()$deserializeObj(this_object$`options`, "array[ProductVariantUpdateOptionsInner]", loadNamespace("openapi"))
      self$`name` <- this_object$`name`
      self$`description` <- this_object$`description`
      self$`short_description` <- this_object$`short_description`
      self$`model` <- this_object$`model`
      self$`sku` <- this_object$`sku`
      self$`visible` <- this_object$`visible`
      self$`status` <- this_object$`status`
      self$`backorder_status` <- this_object$`backorder_status`
      self$`low_stock_threshold` <- this_object$`low_stock_threshold`
      self$`available_for_sale` <- this_object$`available_for_sale`
      self$`avail` <- this_object$`avail`
      self$`is_default` <- this_object$`is_default`
      self$`is_free_shipping` <- this_object$`is_free_shipping`
      self$`taxable` <- this_object$`taxable`
      self$`tax_class_id` <- this_object$`tax_class_id`
      self$`is_virtual` <- this_object$`is_virtual`
      self$`manage_stock` <- this_object$`manage_stock`
      self$`in_stock` <- this_object$`in_stock`
      self$`warehouse_id` <- this_object$`warehouse_id`
      self$`reserve_quantity` <- this_object$`reserve_quantity`
      self$`quantity` <- this_object$`quantity`
      self$`increase_quantity` <- this_object$`increase_quantity`
      self$`reduce_quantity` <- this_object$`reduce_quantity`
      self$`prices_inc_tax` <- this_object$`prices_inc_tax`
      self$`price` <- this_object$`price`
      self$`special_price` <- this_object$`special_price`
      self$`retail_price` <- this_object$`retail_price`
      self$`old_price` <- this_object$`old_price`
      self$`cost_price` <- this_object$`cost_price`
      self$`fixed_cost_shipping_price` <- this_object$`fixed_cost_shipping_price`
      self$`sprice_create` <- this_object$`sprice_create`
      self$`sprice_expire` <- this_object$`sprice_expire`
      self$`measure_unit` <- this_object$`measure_unit`
      self$`unit_price` <- this_object$`unit_price`
      self$`weight` <- this_object$`weight`
      self$`barcode` <- this_object$`barcode`
      self$`width` <- this_object$`width`
      self$`weight_unit` <- this_object$`weight_unit`
      self$`height` <- this_object$`height`
      self$`length` <- this_object$`length`
      self$`gtin` <- this_object$`gtin`
      self$`upc` <- this_object$`upc`
      self$`mpn` <- this_object$`mpn`
      self$`ean` <- this_object$`ean`
      self$`isbn` <- this_object$`isbn`
      self$`harmonized_system_code` <- this_object$`harmonized_system_code`
      self$`country_of_origin` <- this_object$`country_of_origin`
      self$`meta_title` <- this_object$`meta_title`
      self$`meta_description` <- this_object$`meta_description`
      self$`meta_keywords` <- this_object$`meta_keywords`
      self$`manufacturer` <- this_object$`manufacturer`
      self$`reindex` <- this_object$`reindex`
      self$`clear_cache` <- this_object$`clear_cache`
      self$`processing_profile_id` <- this_object$`processing_profile_id`
      self$`idempotency_key` <- this_object$`idempotency_key`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductVariantUpdate and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductVariantUpdate
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductVariantUpdate$unlock()
#
## Below is an example to define the print function
# ProductVariantUpdate$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductVariantUpdate$lock()

