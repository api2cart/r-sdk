#' Create a new CategoryFind200ResponseResultCategoryInner
#'
#' @description
#' CategoryFind200ResponseResultCategoryInner Class
#'
#' @docType class
#' @title CategoryFind200ResponseResultCategoryInner
#' @description CategoryFind200ResponseResultCategoryInner Class
#' @format An \code{R6Class} generator object
#' @field id  character [optional]
#' @field name  character [optional]
#' @field description  character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
CategoryFind200ResponseResultCategoryInner <- R6::R6Class(
  "CategoryFind200ResponseResultCategoryInner",
  public = list(
    `id` = NULL,
    `name` = NULL,
    `description` = NULL,

    #' @description
    #' Initialize a new CategoryFind200ResponseResultCategoryInner class.
    #'
    #' @param id id
    #' @param name name
    #' @param description description
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `name` = NULL, `description` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`description`)) {
        if (!(is.character(`description`) && length(`description`) == 1)) {
          stop(paste("Error! Invalid data for `description`. Must be a string:", `description`))
        }
        self$`description` <- `description`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return CategoryFind200ResponseResultCategoryInner as a base R list.
    #' @examples
    #' # convert array of CategoryFind200ResponseResultCategoryInner (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert CategoryFind200ResponseResultCategoryInner to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      CategoryFind200ResponseResultCategoryInnerObject <- list()
      if (!is.null(self$`id`)) {
        CategoryFind200ResponseResultCategoryInnerObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`name`)) {
        CategoryFind200ResponseResultCategoryInnerObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`description`)) {
        CategoryFind200ResponseResultCategoryInnerObject[["description"]] <-
          self$`description`
      }
      return(CategoryFind200ResponseResultCategoryInnerObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of CategoryFind200ResponseResultCategoryInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of CategoryFind200ResponseResultCategoryInner
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`description`)) {
        self$`description` <- this_object$`description`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return CategoryFind200ResponseResultCategoryInner in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of CategoryFind200ResponseResultCategoryInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of CategoryFind200ResponseResultCategoryInner
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`name` <- this_object$`name`
      self$`description` <- this_object$`description`
      self
    },

    #' @description
    #' Validate JSON input with respect to CategoryFind200ResponseResultCategoryInner and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of CategoryFind200ResponseResultCategoryInner
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# CategoryFind200ResponseResultCategoryInner$unlock()
#
## Below is an example to define the print function
# CategoryFind200ResponseResultCategoryInner$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# CategoryFind200ResponseResultCategoryInner$lock()

