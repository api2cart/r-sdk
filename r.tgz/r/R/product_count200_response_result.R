#' Create a new ProductCount200ResponseResult
#'
#' @description
#' ProductCount200ResponseResult Class
#'
#' @docType class
#' @title ProductCount200ResponseResult
#' @description ProductCount200ResponseResult Class
#' @format An \code{R6Class} generator object
#' @field products_count  integer [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductCount200ResponseResult <- R6::R6Class(
  "ProductCount200ResponseResult",
  public = list(
    `products_count` = NULL,

    #' @description
    #' Initialize a new ProductCount200ResponseResult class.
    #'
    #' @param products_count products_count
    #' @param ... Other optional arguments.
    initialize = function(`products_count` = NULL, ...) {
      if (!is.null(`products_count`)) {
        if (!(is.numeric(`products_count`) && length(`products_count`) == 1)) {
          stop(paste("Error! Invalid data for `products_count`. Must be an integer:", `products_count`))
        }
        self$`products_count` <- `products_count`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductCount200ResponseResult as a base R list.
    #' @examples
    #' # convert array of ProductCount200ResponseResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductCount200ResponseResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductCount200ResponseResultObject <- list()
      if (!is.null(self$`products_count`)) {
        ProductCount200ResponseResultObject[["products_count"]] <-
          self$`products_count`
      }
      return(ProductCount200ResponseResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductCount200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductCount200ResponseResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`products_count`)) {
        self$`products_count` <- this_object$`products_count`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductCount200ResponseResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductCount200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductCount200ResponseResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`products_count` <- this_object$`products_count`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductCount200ResponseResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductCount200ResponseResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductCount200ResponseResult$unlock()
#
## Below is an example to define the print function
# ProductCount200ResponseResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductCount200ResponseResult$lock()

