#' Create a new WebhookEvents200ResponseResult
#'
#' @description
#' WebhookEvents200ResponseResult Class
#'
#' @docType class
#' @title WebhookEvents200ResponseResult
#' @description WebhookEvents200ResponseResult Class
#' @format An \code{R6Class} generator object
#' @field events  list(\link{WebhookEvents200ResponseResultEventsInner}) [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
WebhookEvents200ResponseResult <- R6::R6Class(
  "WebhookEvents200ResponseResult",
  public = list(
    `events` = NULL,

    #' @description
    #' Initialize a new WebhookEvents200ResponseResult class.
    #'
    #' @param events events
    #' @param ... Other optional arguments.
    initialize = function(`events` = NULL, ...) {
      if (!is.null(`events`)) {
        stopifnot(is.vector(`events`), length(`events`) != 0)
        sapply(`events`, function(x) stopifnot(R6::is.R6(x)))
        self$`events` <- `events`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return WebhookEvents200ResponseResult as a base R list.
    #' @examples
    #' # convert array of WebhookEvents200ResponseResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert WebhookEvents200ResponseResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      WebhookEvents200ResponseResultObject <- list()
      if (!is.null(self$`events`)) {
        WebhookEvents200ResponseResultObject[["events"]] <-
          lapply(self$`events`, function(x) x$toSimpleType())
      }
      return(WebhookEvents200ResponseResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of WebhookEvents200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of WebhookEvents200ResponseResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`events`)) {
        self$`events` <- ApiClient$new()$deserializeObj(this_object$`events`, "array[WebhookEvents200ResponseResultEventsInner]", loadNamespace("openapi"))
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return WebhookEvents200ResponseResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of WebhookEvents200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of WebhookEvents200ResponseResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`events` <- ApiClient$new()$deserializeObj(this_object$`events`, "array[WebhookEvents200ResponseResultEventsInner]", loadNamespace("openapi"))
      self
    },

    #' @description
    #' Validate JSON input with respect to WebhookEvents200ResponseResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of WebhookEvents200ResponseResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# WebhookEvents200ResponseResult$unlock()
#
## Below is an example to define the print function
# WebhookEvents200ResponseResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# WebhookEvents200ResponseResult$lock()

