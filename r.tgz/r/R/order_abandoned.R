#' Create a new OrderAbandoned
#'
#' @description
#' OrderAbandoned Class
#'
#' @docType class
#' @title OrderAbandoned
#' @description OrderAbandoned Class
#' @format An \code{R6Class} generator object
#' @field id  character [optional]
#' @field customer  \link{BaseCustomer} [optional]
#' @field basket_id  character [optional]
#' @field basket_url  character [optional]
#' @field created_at  \link{A2CDateTime} [optional]
#' @field modified_at  \link{A2CDateTime} [optional]
#' @field currency  \link{Currency} [optional]
#' @field totals  \link{OrderTotals} [optional]
#' @field order_products  list(\link{OrderItem}) [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
OrderAbandoned <- R6::R6Class(
  "OrderAbandoned",
  public = list(
    `id` = NULL,
    `customer` = NULL,
    `basket_id` = NULL,
    `basket_url` = NULL,
    `created_at` = NULL,
    `modified_at` = NULL,
    `currency` = NULL,
    `totals` = NULL,
    `order_products` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new OrderAbandoned class.
    #'
    #' @param id id
    #' @param customer customer
    #' @param basket_id basket_id
    #' @param basket_url basket_url
    #' @param created_at created_at
    #' @param modified_at modified_at
    #' @param currency currency
    #' @param totals totals
    #' @param order_products order_products
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `customer` = NULL, `basket_id` = NULL, `basket_url` = NULL, `created_at` = NULL, `modified_at` = NULL, `currency` = NULL, `totals` = NULL, `order_products` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`customer`)) {
        stopifnot(R6::is.R6(`customer`))
        self$`customer` <- `customer`
      }
      if (!is.null(`basket_id`)) {
        if (!(is.character(`basket_id`) && length(`basket_id`) == 1)) {
          stop(paste("Error! Invalid data for `basket_id`. Must be a string:", `basket_id`))
        }
        self$`basket_id` <- `basket_id`
      }
      if (!is.null(`basket_url`)) {
        if (!(is.character(`basket_url`) && length(`basket_url`) == 1)) {
          stop(paste("Error! Invalid data for `basket_url`. Must be a string:", `basket_url`))
        }
        self$`basket_url` <- `basket_url`
      }
      if (!is.null(`created_at`)) {
        stopifnot(R6::is.R6(`created_at`))
        self$`created_at` <- `created_at`
      }
      if (!is.null(`modified_at`)) {
        stopifnot(R6::is.R6(`modified_at`))
        self$`modified_at` <- `modified_at`
      }
      if (!is.null(`currency`)) {
        stopifnot(R6::is.R6(`currency`))
        self$`currency` <- `currency`
      }
      if (!is.null(`totals`)) {
        stopifnot(R6::is.R6(`totals`))
        self$`totals` <- `totals`
      }
      if (!is.null(`order_products`)) {
        stopifnot(is.vector(`order_products`), length(`order_products`) != 0)
        sapply(`order_products`, function(x) stopifnot(R6::is.R6(x)))
        self$`order_products` <- `order_products`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return OrderAbandoned as a base R list.
    #' @examples
    #' # convert array of OrderAbandoned (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert OrderAbandoned to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      OrderAbandonedObject <- list()
      if (!is.null(self$`id`)) {
        OrderAbandonedObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`customer`)) {
        OrderAbandonedObject[["customer"]] <-
          self$`customer`$toSimpleType()
      }
      if (!is.null(self$`basket_id`)) {
        OrderAbandonedObject[["basket_id"]] <-
          self$`basket_id`
      }
      if (!is.null(self$`basket_url`)) {
        OrderAbandonedObject[["basket_url"]] <-
          self$`basket_url`
      }
      if (!is.null(self$`created_at`)) {
        OrderAbandonedObject[["created_at"]] <-
          self$`created_at`$toSimpleType()
      }
      if (!is.null(self$`modified_at`)) {
        OrderAbandonedObject[["modified_at"]] <-
          self$`modified_at`$toSimpleType()
      }
      if (!is.null(self$`currency`)) {
        OrderAbandonedObject[["currency"]] <-
          self$`currency`$toSimpleType()
      }
      if (!is.null(self$`totals`)) {
        OrderAbandonedObject[["totals"]] <-
          self$`totals`$toSimpleType()
      }
      if (!is.null(self$`order_products`)) {
        OrderAbandonedObject[["order_products"]] <-
          lapply(self$`order_products`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`additional_fields`)) {
        OrderAbandonedObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        OrderAbandonedObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(OrderAbandonedObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderAbandoned
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderAbandoned
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`customer`)) {
        `customer_object` <- BaseCustomer$new()
        `customer_object`$fromJSON(jsonlite::toJSON(this_object$`customer`, auto_unbox = TRUE, digits = NA))
        self$`customer` <- `customer_object`
      }
      if (!is.null(this_object$`basket_id`)) {
        self$`basket_id` <- this_object$`basket_id`
      }
      if (!is.null(this_object$`basket_url`)) {
        self$`basket_url` <- this_object$`basket_url`
      }
      if (!is.null(this_object$`created_at`)) {
        `created_at_object` <- A2CDateTime$new()
        `created_at_object`$fromJSON(jsonlite::toJSON(this_object$`created_at`, auto_unbox = TRUE, digits = NA))
        self$`created_at` <- `created_at_object`
      }
      if (!is.null(this_object$`modified_at`)) {
        `modified_at_object` <- A2CDateTime$new()
        `modified_at_object`$fromJSON(jsonlite::toJSON(this_object$`modified_at`, auto_unbox = TRUE, digits = NA))
        self$`modified_at` <- `modified_at_object`
      }
      if (!is.null(this_object$`currency`)) {
        `currency_object` <- Currency$new()
        `currency_object`$fromJSON(jsonlite::toJSON(this_object$`currency`, auto_unbox = TRUE, digits = NA))
        self$`currency` <- `currency_object`
      }
      if (!is.null(this_object$`totals`)) {
        `totals_object` <- OrderTotals$new()
        `totals_object`$fromJSON(jsonlite::toJSON(this_object$`totals`, auto_unbox = TRUE, digits = NA))
        self$`totals` <- `totals_object`
      }
      if (!is.null(this_object$`order_products`)) {
        self$`order_products` <- ApiClient$new()$deserializeObj(this_object$`order_products`, "array[OrderItem]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return OrderAbandoned in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderAbandoned
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderAbandoned
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`customer` <- BaseCustomer$new()$fromJSON(jsonlite::toJSON(this_object$`customer`, auto_unbox = TRUE, digits = NA))
      self$`basket_id` <- this_object$`basket_id`
      self$`basket_url` <- this_object$`basket_url`
      self$`created_at` <- A2CDateTime$new()$fromJSON(jsonlite::toJSON(this_object$`created_at`, auto_unbox = TRUE, digits = NA))
      self$`modified_at` <- A2CDateTime$new()$fromJSON(jsonlite::toJSON(this_object$`modified_at`, auto_unbox = TRUE, digits = NA))
      self$`currency` <- Currency$new()$fromJSON(jsonlite::toJSON(this_object$`currency`, auto_unbox = TRUE, digits = NA))
      self$`totals` <- OrderTotals$new()$fromJSON(jsonlite::toJSON(this_object$`totals`, auto_unbox = TRUE, digits = NA))
      self$`order_products` <- ApiClient$new()$deserializeObj(this_object$`order_products`, "array[OrderItem]", loadNamespace("openapi"))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to OrderAbandoned and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of OrderAbandoned
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# OrderAbandoned$unlock()
#
## Below is an example to define the print function
# OrderAbandoned$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# OrderAbandoned$lock()

