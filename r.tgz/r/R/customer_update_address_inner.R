#' Create a new CustomerUpdateAddressInner
#'
#' @description
#' CustomerUpdateAddressInner Class
#'
#' @docType class
#' @title CustomerUpdateAddressInner
#' @description CustomerUpdateAddressInner Class
#' @format An \code{R6Class} generator object
#' @field address_book_id The ID of the address. character [optional]
#' @field address_book_first_name Specifies customer's first name in the address book character [optional]
#' @field address_book_last_name Specifies customer's last name in the address book character [optional]
#' @field address_book_company Specifies customer's company name in the address book character [optional]
#' @field address_book_fax Specifies customer's fax in the address book character [optional]
#' @field address_book_phone Specifies customer's phone number in the address book character [optional]
#' @field address_book_phone_mobile Specifies customer's mobile phone number in the address book character [optional]
#' @field address_book_address1 Specifies customer's first address in the address book character [optional]
#' @field address_book_address2 Specifies customer's second address in the address book character [optional]
#' @field address_book_city Specifies customer's city in the address book character [optional]
#' @field address_book_country ISO code or name of country character [optional]
#' @field address_book_state ISO code or name of state. character [optional]
#' @field address_book_postcode Specifies customer's postcode character [optional]
#' @field address_book_tax_id Add Tax Id character [optional]
#' @field address_book_identification_number The national ID card number of this person, or a unique tax identification number. character [optional]
#' @field address_book_gender Specifies customer's gender character [optional]
#' @field address_book_region Specifies customer's region character [optional]
#' @field address_book_alias Specifies customer's alias in the address book character [optional]
#' @field address_book_type Specifies customer's address type character [optional]
#' @field address_book_default Defines whether the address is used by default character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
CustomerUpdateAddressInner <- R6::R6Class(
  "CustomerUpdateAddressInner",
  public = list(
    `address_book_id` = NULL,
    `address_book_first_name` = NULL,
    `address_book_last_name` = NULL,
    `address_book_company` = NULL,
    `address_book_fax` = NULL,
    `address_book_phone` = NULL,
    `address_book_phone_mobile` = NULL,
    `address_book_address1` = NULL,
    `address_book_address2` = NULL,
    `address_book_city` = NULL,
    `address_book_country` = NULL,
    `address_book_state` = NULL,
    `address_book_postcode` = NULL,
    `address_book_tax_id` = NULL,
    `address_book_identification_number` = NULL,
    `address_book_gender` = NULL,
    `address_book_region` = NULL,
    `address_book_alias` = NULL,
    `address_book_type` = NULL,
    `address_book_default` = NULL,

    #' @description
    #' Initialize a new CustomerUpdateAddressInner class.
    #'
    #' @param address_book_id The ID of the address.
    #' @param address_book_first_name Specifies customer's first name in the address book
    #' @param address_book_last_name Specifies customer's last name in the address book
    #' @param address_book_company Specifies customer's company name in the address book
    #' @param address_book_fax Specifies customer's fax in the address book
    #' @param address_book_phone Specifies customer's phone number in the address book
    #' @param address_book_phone_mobile Specifies customer's mobile phone number in the address book
    #' @param address_book_address1 Specifies customer's first address in the address book
    #' @param address_book_address2 Specifies customer's second address in the address book
    #' @param address_book_city Specifies customer's city in the address book
    #' @param address_book_country ISO code or name of country
    #' @param address_book_state ISO code or name of state.
    #' @param address_book_postcode Specifies customer's postcode
    #' @param address_book_tax_id Add Tax Id
    #' @param address_book_identification_number The national ID card number of this person, or a unique tax identification number.
    #' @param address_book_gender Specifies customer's gender
    #' @param address_book_region Specifies customer's region
    #' @param address_book_alias Specifies customer's alias in the address book
    #' @param address_book_type Specifies customer's address type
    #' @param address_book_default Defines whether the address is used by default
    #' @param ... Other optional arguments.
    initialize = function(`address_book_id` = NULL, `address_book_first_name` = NULL, `address_book_last_name` = NULL, `address_book_company` = NULL, `address_book_fax` = NULL, `address_book_phone` = NULL, `address_book_phone_mobile` = NULL, `address_book_address1` = NULL, `address_book_address2` = NULL, `address_book_city` = NULL, `address_book_country` = NULL, `address_book_state` = NULL, `address_book_postcode` = NULL, `address_book_tax_id` = NULL, `address_book_identification_number` = NULL, `address_book_gender` = NULL, `address_book_region` = NULL, `address_book_alias` = NULL, `address_book_type` = NULL, `address_book_default` = NULL, ...) {
      if (!is.null(`address_book_id`)) {
        if (!(is.character(`address_book_id`) && length(`address_book_id`) == 1)) {
          stop(paste("Error! Invalid data for `address_book_id`. Must be a string:", `address_book_id`))
        }
        self$`address_book_id` <- `address_book_id`
      }
      if (!is.null(`address_book_first_name`)) {
        if (!(is.character(`address_book_first_name`) && length(`address_book_first_name`) == 1)) {
          stop(paste("Error! Invalid data for `address_book_first_name`. Must be a string:", `address_book_first_name`))
        }
        self$`address_book_first_name` <- `address_book_first_name`
      }
      if (!is.null(`address_book_last_name`)) {
        if (!(is.character(`address_book_last_name`) && length(`address_book_last_name`) == 1)) {
          stop(paste("Error! Invalid data for `address_book_last_name`. Must be a string:", `address_book_last_name`))
        }
        self$`address_book_last_name` <- `address_book_last_name`
      }
      if (!is.null(`address_book_company`)) {
        if (!(is.character(`address_book_company`) && length(`address_book_company`) == 1)) {
          stop(paste("Error! Invalid data for `address_book_company`. Must be a string:", `address_book_company`))
        }
        self$`address_book_company` <- `address_book_company`
      }
      if (!is.null(`address_book_fax`)) {
        if (!(is.character(`address_book_fax`) && length(`address_book_fax`) == 1)) {
          stop(paste("Error! Invalid data for `address_book_fax`. Must be a string:", `address_book_fax`))
        }
        self$`address_book_fax` <- `address_book_fax`
      }
      if (!is.null(`address_book_phone`)) {
        if (!(is.character(`address_book_phone`) && length(`address_book_phone`) == 1)) {
          stop(paste("Error! Invalid data for `address_book_phone`. Must be a string:", `address_book_phone`))
        }
        self$`address_book_phone` <- `address_book_phone`
      }
      if (!is.null(`address_book_phone_mobile`)) {
        if (!(is.character(`address_book_phone_mobile`) && length(`address_book_phone_mobile`) == 1)) {
          stop(paste("Error! Invalid data for `address_book_phone_mobile`. Must be a string:", `address_book_phone_mobile`))
        }
        self$`address_book_phone_mobile` <- `address_book_phone_mobile`
      }
      if (!is.null(`address_book_address1`)) {
        if (!(is.character(`address_book_address1`) && length(`address_book_address1`) == 1)) {
          stop(paste("Error! Invalid data for `address_book_address1`. Must be a string:", `address_book_address1`))
        }
        self$`address_book_address1` <- `address_book_address1`
      }
      if (!is.null(`address_book_address2`)) {
        if (!(is.character(`address_book_address2`) && length(`address_book_address2`) == 1)) {
          stop(paste("Error! Invalid data for `address_book_address2`. Must be a string:", `address_book_address2`))
        }
        self$`address_book_address2` <- `address_book_address2`
      }
      if (!is.null(`address_book_city`)) {
        if (!(is.character(`address_book_city`) && length(`address_book_city`) == 1)) {
          stop(paste("Error! Invalid data for `address_book_city`. Must be a string:", `address_book_city`))
        }
        self$`address_book_city` <- `address_book_city`
      }
      if (!is.null(`address_book_country`)) {
        if (!(is.character(`address_book_country`) && length(`address_book_country`) == 1)) {
          stop(paste("Error! Invalid data for `address_book_country`. Must be a string:", `address_book_country`))
        }
        self$`address_book_country` <- `address_book_country`
      }
      if (!is.null(`address_book_state`)) {
        if (!(is.character(`address_book_state`) && length(`address_book_state`) == 1)) {
          stop(paste("Error! Invalid data for `address_book_state`. Must be a string:", `address_book_state`))
        }
        self$`address_book_state` <- `address_book_state`
      }
      if (!is.null(`address_book_postcode`)) {
        if (!(is.character(`address_book_postcode`) && length(`address_book_postcode`) == 1)) {
          stop(paste("Error! Invalid data for `address_book_postcode`. Must be a string:", `address_book_postcode`))
        }
        self$`address_book_postcode` <- `address_book_postcode`
      }
      if (!is.null(`address_book_tax_id`)) {
        if (!(is.character(`address_book_tax_id`) && length(`address_book_tax_id`) == 1)) {
          stop(paste("Error! Invalid data for `address_book_tax_id`. Must be a string:", `address_book_tax_id`))
        }
        self$`address_book_tax_id` <- `address_book_tax_id`
      }
      if (!is.null(`address_book_identification_number`)) {
        if (!(is.character(`address_book_identification_number`) && length(`address_book_identification_number`) == 1)) {
          stop(paste("Error! Invalid data for `address_book_identification_number`. Must be a string:", `address_book_identification_number`))
        }
        self$`address_book_identification_number` <- `address_book_identification_number`
      }
      if (!is.null(`address_book_gender`)) {
        if (!(is.character(`address_book_gender`) && length(`address_book_gender`) == 1)) {
          stop(paste("Error! Invalid data for `address_book_gender`. Must be a string:", `address_book_gender`))
        }
        self$`address_book_gender` <- `address_book_gender`
      }
      if (!is.null(`address_book_region`)) {
        if (!(is.character(`address_book_region`) && length(`address_book_region`) == 1)) {
          stop(paste("Error! Invalid data for `address_book_region`. Must be a string:", `address_book_region`))
        }
        self$`address_book_region` <- `address_book_region`
      }
      if (!is.null(`address_book_alias`)) {
        if (!(is.character(`address_book_alias`) && length(`address_book_alias`) == 1)) {
          stop(paste("Error! Invalid data for `address_book_alias`. Must be a string:", `address_book_alias`))
        }
        self$`address_book_alias` <- `address_book_alias`
      }
      if (!is.null(`address_book_type`)) {
        if (!(is.character(`address_book_type`) && length(`address_book_type`) == 1)) {
          stop(paste("Error! Invalid data for `address_book_type`. Must be a string:", `address_book_type`))
        }
        self$`address_book_type` <- `address_book_type`
      }
      if (!is.null(`address_book_default`)) {
        if (!(is.logical(`address_book_default`) && length(`address_book_default`) == 1)) {
          stop(paste("Error! Invalid data for `address_book_default`. Must be a boolean:", `address_book_default`))
        }
        self$`address_book_default` <- `address_book_default`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return CustomerUpdateAddressInner as a base R list.
    #' @examples
    #' # convert array of CustomerUpdateAddressInner (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert CustomerUpdateAddressInner to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      CustomerUpdateAddressInnerObject <- list()
      if (!is.null(self$`address_book_id`)) {
        CustomerUpdateAddressInnerObject[["address_book_id"]] <-
          self$`address_book_id`
      }
      if (!is.null(self$`address_book_first_name`)) {
        CustomerUpdateAddressInnerObject[["address_book_first_name"]] <-
          self$`address_book_first_name`
      }
      if (!is.null(self$`address_book_last_name`)) {
        CustomerUpdateAddressInnerObject[["address_book_last_name"]] <-
          self$`address_book_last_name`
      }
      if (!is.null(self$`address_book_company`)) {
        CustomerUpdateAddressInnerObject[["address_book_company"]] <-
          self$`address_book_company`
      }
      if (!is.null(self$`address_book_fax`)) {
        CustomerUpdateAddressInnerObject[["address_book_fax"]] <-
          self$`address_book_fax`
      }
      if (!is.null(self$`address_book_phone`)) {
        CustomerUpdateAddressInnerObject[["address_book_phone"]] <-
          self$`address_book_phone`
      }
      if (!is.null(self$`address_book_phone_mobile`)) {
        CustomerUpdateAddressInnerObject[["address_book_phone_mobile"]] <-
          self$`address_book_phone_mobile`
      }
      if (!is.null(self$`address_book_address1`)) {
        CustomerUpdateAddressInnerObject[["address_book_address1"]] <-
          self$`address_book_address1`
      }
      if (!is.null(self$`address_book_address2`)) {
        CustomerUpdateAddressInnerObject[["address_book_address2"]] <-
          self$`address_book_address2`
      }
      if (!is.null(self$`address_book_city`)) {
        CustomerUpdateAddressInnerObject[["address_book_city"]] <-
          self$`address_book_city`
      }
      if (!is.null(self$`address_book_country`)) {
        CustomerUpdateAddressInnerObject[["address_book_country"]] <-
          self$`address_book_country`
      }
      if (!is.null(self$`address_book_state`)) {
        CustomerUpdateAddressInnerObject[["address_book_state"]] <-
          self$`address_book_state`
      }
      if (!is.null(self$`address_book_postcode`)) {
        CustomerUpdateAddressInnerObject[["address_book_postcode"]] <-
          self$`address_book_postcode`
      }
      if (!is.null(self$`address_book_tax_id`)) {
        CustomerUpdateAddressInnerObject[["address_book_tax_id"]] <-
          self$`address_book_tax_id`
      }
      if (!is.null(self$`address_book_identification_number`)) {
        CustomerUpdateAddressInnerObject[["address_book_identification_number"]] <-
          self$`address_book_identification_number`
      }
      if (!is.null(self$`address_book_gender`)) {
        CustomerUpdateAddressInnerObject[["address_book_gender"]] <-
          self$`address_book_gender`
      }
      if (!is.null(self$`address_book_region`)) {
        CustomerUpdateAddressInnerObject[["address_book_region"]] <-
          self$`address_book_region`
      }
      if (!is.null(self$`address_book_alias`)) {
        CustomerUpdateAddressInnerObject[["address_book_alias"]] <-
          self$`address_book_alias`
      }
      if (!is.null(self$`address_book_type`)) {
        CustomerUpdateAddressInnerObject[["address_book_type"]] <-
          self$`address_book_type`
      }
      if (!is.null(self$`address_book_default`)) {
        CustomerUpdateAddressInnerObject[["address_book_default"]] <-
          self$`address_book_default`
      }
      return(CustomerUpdateAddressInnerObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of CustomerUpdateAddressInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of CustomerUpdateAddressInner
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`address_book_id`)) {
        self$`address_book_id` <- this_object$`address_book_id`
      }
      if (!is.null(this_object$`address_book_first_name`)) {
        self$`address_book_first_name` <- this_object$`address_book_first_name`
      }
      if (!is.null(this_object$`address_book_last_name`)) {
        self$`address_book_last_name` <- this_object$`address_book_last_name`
      }
      if (!is.null(this_object$`address_book_company`)) {
        self$`address_book_company` <- this_object$`address_book_company`
      }
      if (!is.null(this_object$`address_book_fax`)) {
        self$`address_book_fax` <- this_object$`address_book_fax`
      }
      if (!is.null(this_object$`address_book_phone`)) {
        self$`address_book_phone` <- this_object$`address_book_phone`
      }
      if (!is.null(this_object$`address_book_phone_mobile`)) {
        self$`address_book_phone_mobile` <- this_object$`address_book_phone_mobile`
      }
      if (!is.null(this_object$`address_book_address1`)) {
        self$`address_book_address1` <- this_object$`address_book_address1`
      }
      if (!is.null(this_object$`address_book_address2`)) {
        self$`address_book_address2` <- this_object$`address_book_address2`
      }
      if (!is.null(this_object$`address_book_city`)) {
        self$`address_book_city` <- this_object$`address_book_city`
      }
      if (!is.null(this_object$`address_book_country`)) {
        self$`address_book_country` <- this_object$`address_book_country`
      }
      if (!is.null(this_object$`address_book_state`)) {
        self$`address_book_state` <- this_object$`address_book_state`
      }
      if (!is.null(this_object$`address_book_postcode`)) {
        self$`address_book_postcode` <- this_object$`address_book_postcode`
      }
      if (!is.null(this_object$`address_book_tax_id`)) {
        self$`address_book_tax_id` <- this_object$`address_book_tax_id`
      }
      if (!is.null(this_object$`address_book_identification_number`)) {
        self$`address_book_identification_number` <- this_object$`address_book_identification_number`
      }
      if (!is.null(this_object$`address_book_gender`)) {
        self$`address_book_gender` <- this_object$`address_book_gender`
      }
      if (!is.null(this_object$`address_book_region`)) {
        self$`address_book_region` <- this_object$`address_book_region`
      }
      if (!is.null(this_object$`address_book_alias`)) {
        self$`address_book_alias` <- this_object$`address_book_alias`
      }
      if (!is.null(this_object$`address_book_type`)) {
        self$`address_book_type` <- this_object$`address_book_type`
      }
      if (!is.null(this_object$`address_book_default`)) {
        self$`address_book_default` <- this_object$`address_book_default`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return CustomerUpdateAddressInner in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of CustomerUpdateAddressInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of CustomerUpdateAddressInner
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`address_book_id` <- this_object$`address_book_id`
      self$`address_book_first_name` <- this_object$`address_book_first_name`
      self$`address_book_last_name` <- this_object$`address_book_last_name`
      self$`address_book_company` <- this_object$`address_book_company`
      self$`address_book_fax` <- this_object$`address_book_fax`
      self$`address_book_phone` <- this_object$`address_book_phone`
      self$`address_book_phone_mobile` <- this_object$`address_book_phone_mobile`
      self$`address_book_address1` <- this_object$`address_book_address1`
      self$`address_book_address2` <- this_object$`address_book_address2`
      self$`address_book_city` <- this_object$`address_book_city`
      self$`address_book_country` <- this_object$`address_book_country`
      self$`address_book_state` <- this_object$`address_book_state`
      self$`address_book_postcode` <- this_object$`address_book_postcode`
      self$`address_book_tax_id` <- this_object$`address_book_tax_id`
      self$`address_book_identification_number` <- this_object$`address_book_identification_number`
      self$`address_book_gender` <- this_object$`address_book_gender`
      self$`address_book_region` <- this_object$`address_book_region`
      self$`address_book_alias` <- this_object$`address_book_alias`
      self$`address_book_type` <- this_object$`address_book_type`
      self$`address_book_default` <- this_object$`address_book_default`
      self
    },

    #' @description
    #' Validate JSON input with respect to CustomerUpdateAddressInner and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of CustomerUpdateAddressInner
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# CustomerUpdateAddressInner$unlock()
#
## Below is an example to define the print function
# CustomerUpdateAddressInner$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# CustomerUpdateAddressInner$lock()

