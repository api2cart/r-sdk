#' Create a new CustomerAddConsentsInner
#'
#' @description
#' CustomerAddConsentsInner Class
#'
#' @docType class
#' @title CustomerAddConsentsInner
#' @description CustomerAddConsentsInner Class
#' @format An \code{R6Class} generator object
#' @field type  character
#' @field status  character
#' @field opt_in_level  character
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
CustomerAddConsentsInner <- R6::R6Class(
  "CustomerAddConsentsInner",
  public = list(
    `type` = NULL,
    `status` = NULL,
    `opt_in_level` = NULL,

    #' @description
    #' Initialize a new CustomerAddConsentsInner class.
    #'
    #' @param type type
    #' @param status status
    #' @param opt_in_level opt_in_level
    #' @param ... Other optional arguments.
    initialize = function(`type`, `status`, `opt_in_level`, ...) {
      if (!missing(`type`)) {
        if (!(`type` %in% c("email", "sms"))) {
          stop(paste("Error! \"", `type`, "\" cannot be assigned to `type`. Must be \"email\", \"sms\".", sep = ""))
        }
        if (!(is.character(`type`) && length(`type`) == 1)) {
          stop(paste("Error! Invalid data for `type`. Must be a string:", `type`))
        }
        self$`type` <- `type`
      }
      if (!missing(`status`)) {
        if (!(is.character(`status`) && length(`status`) == 1)) {
          stop(paste("Error! Invalid data for `status`. Must be a string:", `status`))
        }
        self$`status` <- `status`
      }
      if (!missing(`opt_in_level`)) {
        if (!(is.character(`opt_in_level`) && length(`opt_in_level`) == 1)) {
          stop(paste("Error! Invalid data for `opt_in_level`. Must be a string:", `opt_in_level`))
        }
        self$`opt_in_level` <- `opt_in_level`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return CustomerAddConsentsInner as a base R list.
    #' @examples
    #' # convert array of CustomerAddConsentsInner (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert CustomerAddConsentsInner to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      CustomerAddConsentsInnerObject <- list()
      if (!is.null(self$`type`)) {
        CustomerAddConsentsInnerObject[["type"]] <-
          self$`type`
      }
      if (!is.null(self$`status`)) {
        CustomerAddConsentsInnerObject[["status"]] <-
          self$`status`
      }
      if (!is.null(self$`opt_in_level`)) {
        CustomerAddConsentsInnerObject[["opt_in_level"]] <-
          self$`opt_in_level`
      }
      return(CustomerAddConsentsInnerObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of CustomerAddConsentsInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of CustomerAddConsentsInner
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`type`)) {
        if (!is.null(this_object$`type`) && !(this_object$`type` %in% c("email", "sms"))) {
          stop(paste("Error! \"", this_object$`type`, "\" cannot be assigned to `type`. Must be \"email\", \"sms\".", sep = ""))
        }
        self$`type` <- this_object$`type`
      }
      if (!is.null(this_object$`status`)) {
        self$`status` <- this_object$`status`
      }
      if (!is.null(this_object$`opt_in_level`)) {
        self$`opt_in_level` <- this_object$`opt_in_level`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return CustomerAddConsentsInner in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of CustomerAddConsentsInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of CustomerAddConsentsInner
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`type`) && !(this_object$`type` %in% c("email", "sms"))) {
        stop(paste("Error! \"", this_object$`type`, "\" cannot be assigned to `type`. Must be \"email\", \"sms\".", sep = ""))
      }
      self$`type` <- this_object$`type`
      self$`status` <- this_object$`status`
      self$`opt_in_level` <- this_object$`opt_in_level`
      self
    },

    #' @description
    #' Validate JSON input with respect to CustomerAddConsentsInner and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
      # check the required field `type`
      if (!is.null(input_json$`type`)) {
        if (!(is.character(input_json$`type`) && length(input_json$`type`) == 1)) {
          stop(paste("Error! Invalid data for `type`. Must be a string:", input_json$`type`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for CustomerAddConsentsInner: the required field `type` is missing."))
      }
      # check the required field `status`
      if (!is.null(input_json$`status`)) {
        if (!(is.character(input_json$`status`) && length(input_json$`status`) == 1)) {
          stop(paste("Error! Invalid data for `status`. Must be a string:", input_json$`status`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for CustomerAddConsentsInner: the required field `status` is missing."))
      }
      # check the required field `opt_in_level`
      if (!is.null(input_json$`opt_in_level`)) {
        if (!(is.character(input_json$`opt_in_level`) && length(input_json$`opt_in_level`) == 1)) {
          stop(paste("Error! Invalid data for `opt_in_level`. Must be a string:", input_json$`opt_in_level`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for CustomerAddConsentsInner: the required field `opt_in_level` is missing."))
      }
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of CustomerAddConsentsInner
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      # check if the required `type` is null
      if (is.null(self$`type`)) {
        return(FALSE)
      }

      # check if the required `status` is null
      if (is.null(self$`status`)) {
        return(FALSE)
      }

      # check if the required `opt_in_level` is null
      if (is.null(self$`opt_in_level`)) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      # check if the required `type` is null
      if (is.null(self$`type`)) {
        invalid_fields["type"] <- "Non-nullable required field `type` cannot be null."
      }

      # check if the required `status` is null
      if (is.null(self$`status`)) {
        invalid_fields["status"] <- "Non-nullable required field `status` cannot be null."
      }

      # check if the required `opt_in_level` is null
      if (is.null(self$`opt_in_level`)) {
        invalid_fields["opt_in_level"] <- "Non-nullable required field `opt_in_level` cannot be null."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# CustomerAddConsentsInner$unlock()
#
## Below is an example to define the print function
# CustomerAddConsentsInner$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# CustomerAddConsentsInner$lock()

