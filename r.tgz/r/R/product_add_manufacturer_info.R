#' Create a new ProductAddManufacturerInfo
#'
#' @description
#' Manufacturer information.
#'
#' @docType class
#' @title ProductAddManufacturerInfo
#' @description ProductAddManufacturerInfo Class
#' @format An \code{R6Class} generator object
#' @field name Defines manufacturer`s name character [optional]
#' @field address Defines manufacturer`s address character [optional]
#' @field phone Defines manufacturer`s phone character [optional]
#' @field email Defines manufacturer`s email character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductAddManufacturerInfo <- R6::R6Class(
  "ProductAddManufacturerInfo",
  public = list(
    `name` = NULL,
    `address` = NULL,
    `phone` = NULL,
    `email` = NULL,

    #' @description
    #' Initialize a new ProductAddManufacturerInfo class.
    #'
    #' @param name Defines manufacturer`s name
    #' @param address Defines manufacturer`s address
    #' @param phone Defines manufacturer`s phone
    #' @param email Defines manufacturer`s email
    #' @param ... Other optional arguments.
    initialize = function(`name` = NULL, `address` = NULL, `phone` = NULL, `email` = NULL, ...) {
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`address`)) {
        if (!(is.character(`address`) && length(`address`) == 1)) {
          stop(paste("Error! Invalid data for `address`. Must be a string:", `address`))
        }
        self$`address` <- `address`
      }
      if (!is.null(`phone`)) {
        if (!(is.character(`phone`) && length(`phone`) == 1)) {
          stop(paste("Error! Invalid data for `phone`. Must be a string:", `phone`))
        }
        self$`phone` <- `phone`
      }
      if (!is.null(`email`)) {
        if (!(is.character(`email`) && length(`email`) == 1)) {
          stop(paste("Error! Invalid data for `email`. Must be a string:", `email`))
        }
        self$`email` <- `email`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductAddManufacturerInfo as a base R list.
    #' @examples
    #' # convert array of ProductAddManufacturerInfo (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductAddManufacturerInfo to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductAddManufacturerInfoObject <- list()
      if (!is.null(self$`name`)) {
        ProductAddManufacturerInfoObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`address`)) {
        ProductAddManufacturerInfoObject[["address"]] <-
          self$`address`
      }
      if (!is.null(self$`phone`)) {
        ProductAddManufacturerInfoObject[["phone"]] <-
          self$`phone`
      }
      if (!is.null(self$`email`)) {
        ProductAddManufacturerInfoObject[["email"]] <-
          self$`email`
      }
      return(ProductAddManufacturerInfoObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductAddManufacturerInfo
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductAddManufacturerInfo
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`address`)) {
        self$`address` <- this_object$`address`
      }
      if (!is.null(this_object$`phone`)) {
        self$`phone` <- this_object$`phone`
      }
      if (!is.null(this_object$`email`)) {
        self$`email` <- this_object$`email`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductAddManufacturerInfo in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductAddManufacturerInfo
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductAddManufacturerInfo
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`name` <- this_object$`name`
      self$`address` <- this_object$`address`
      self$`phone` <- this_object$`phone`
      self$`email` <- this_object$`email`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductAddManufacturerInfo and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductAddManufacturerInfo
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      if (nchar(self$`name`) < 1) {
        return(FALSE)
      }

      if (nchar(self$`address`) < 1) {
        return(FALSE)
      }

      if (nchar(self$`phone`) < 1) {
        return(FALSE)
      }

      if (nchar(self$`email`) < 1) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      if (nchar(self$`name`) < 1) {
        invalid_fields["name"] <- "Invalid length for `name`, must be bigger than or equal to 1."
      }

      if (nchar(self$`address`) < 1) {
        invalid_fields["address"] <- "Invalid length for `address`, must be bigger than or equal to 1."
      }

      if (nchar(self$`phone`) < 1) {
        invalid_fields["phone"] <- "Invalid length for `phone`, must be bigger than or equal to 1."
      }

      if (nchar(self$`email`) < 1) {
        invalid_fields["email"] <- "Invalid length for `email`, must be bigger than or equal to 1."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductAddManufacturerInfo$unlock()
#
## Below is an example to define the print function
# ProductAddManufacturerInfo$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductAddManufacturerInfo$lock()

