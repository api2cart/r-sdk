#' Create a new OrderTransaction
#'
#' @description
#' OrderTransaction Class
#'
#' @docType class
#' @title OrderTransaction
#' @description OrderTransaction Class
#' @format An \code{R6Class} generator object
#' @field id  character [optional]
#' @field transaction_id  character [optional]
#' @field order_id  character [optional]
#' @field parent_id  character [optional]
#' @field description  character [optional]
#' @field status  character [optional]
#' @field gateway  character [optional]
#' @field reference_number  character [optional]
#' @field currency  character [optional]
#' @field amount  numeric [optional]
#' @field created_time  \link{A2CDateTime} [optional]
#' @field settlement_currency  character [optional]
#' @field settlement_amount  numeric [optional]
#' @field settlement_created_time  \link{A2CDateTime} [optional]
#' @field card_brand  character [optional]
#' @field card_bin  character [optional]
#' @field card_last_four  character [optional]
#' @field avs_street_resp_code  character [optional]
#' @field avs_postal_resp_code  character [optional]
#' @field avs_message  character [optional]
#' @field cvv_code  character [optional]
#' @field cvv_message  character [optional]
#' @field is_test_mode  character [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
OrderTransaction <- R6::R6Class(
  "OrderTransaction",
  public = list(
    `id` = NULL,
    `transaction_id` = NULL,
    `order_id` = NULL,
    `parent_id` = NULL,
    `description` = NULL,
    `status` = NULL,
    `gateway` = NULL,
    `reference_number` = NULL,
    `currency` = NULL,
    `amount` = NULL,
    `created_time` = NULL,
    `settlement_currency` = NULL,
    `settlement_amount` = NULL,
    `settlement_created_time` = NULL,
    `card_brand` = NULL,
    `card_bin` = NULL,
    `card_last_four` = NULL,
    `avs_street_resp_code` = NULL,
    `avs_postal_resp_code` = NULL,
    `avs_message` = NULL,
    `cvv_code` = NULL,
    `cvv_message` = NULL,
    `is_test_mode` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new OrderTransaction class.
    #'
    #' @param id id
    #' @param transaction_id transaction_id
    #' @param order_id order_id
    #' @param parent_id parent_id
    #' @param description description
    #' @param status status
    #' @param gateway gateway
    #' @param reference_number reference_number
    #' @param currency currency
    #' @param amount amount
    #' @param created_time created_time
    #' @param settlement_currency settlement_currency
    #' @param settlement_amount settlement_amount
    #' @param settlement_created_time settlement_created_time
    #' @param card_brand card_brand
    #' @param card_bin card_bin
    #' @param card_last_four card_last_four
    #' @param avs_street_resp_code avs_street_resp_code
    #' @param avs_postal_resp_code avs_postal_resp_code
    #' @param avs_message avs_message
    #' @param cvv_code cvv_code
    #' @param cvv_message cvv_message
    #' @param is_test_mode is_test_mode
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `transaction_id` = NULL, `order_id` = NULL, `parent_id` = NULL, `description` = NULL, `status` = NULL, `gateway` = NULL, `reference_number` = NULL, `currency` = NULL, `amount` = NULL, `created_time` = NULL, `settlement_currency` = NULL, `settlement_amount` = NULL, `settlement_created_time` = NULL, `card_brand` = NULL, `card_bin` = NULL, `card_last_four` = NULL, `avs_street_resp_code` = NULL, `avs_postal_resp_code` = NULL, `avs_message` = NULL, `cvv_code` = NULL, `cvv_message` = NULL, `is_test_mode` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`transaction_id`)) {
        if (!(is.character(`transaction_id`) && length(`transaction_id`) == 1)) {
          stop(paste("Error! Invalid data for `transaction_id`. Must be a string:", `transaction_id`))
        }
        self$`transaction_id` <- `transaction_id`
      }
      if (!is.null(`order_id`)) {
        if (!(is.character(`order_id`) && length(`order_id`) == 1)) {
          stop(paste("Error! Invalid data for `order_id`. Must be a string:", `order_id`))
        }
        self$`order_id` <- `order_id`
      }
      if (!is.null(`parent_id`)) {
        if (!(is.character(`parent_id`) && length(`parent_id`) == 1)) {
          stop(paste("Error! Invalid data for `parent_id`. Must be a string:", `parent_id`))
        }
        self$`parent_id` <- `parent_id`
      }
      if (!is.null(`description`)) {
        if (!(is.character(`description`) && length(`description`) == 1)) {
          stop(paste("Error! Invalid data for `description`. Must be a string:", `description`))
        }
        self$`description` <- `description`
      }
      if (!is.null(`status`)) {
        if (!(is.character(`status`) && length(`status`) == 1)) {
          stop(paste("Error! Invalid data for `status`. Must be a string:", `status`))
        }
        self$`status` <- `status`
      }
      if (!is.null(`gateway`)) {
        if (!(is.character(`gateway`) && length(`gateway`) == 1)) {
          stop(paste("Error! Invalid data for `gateway`. Must be a string:", `gateway`))
        }
        self$`gateway` <- `gateway`
      }
      if (!is.null(`reference_number`)) {
        if (!(is.character(`reference_number`) && length(`reference_number`) == 1)) {
          stop(paste("Error! Invalid data for `reference_number`. Must be a string:", `reference_number`))
        }
        self$`reference_number` <- `reference_number`
      }
      if (!is.null(`currency`)) {
        if (!(is.character(`currency`) && length(`currency`) == 1)) {
          stop(paste("Error! Invalid data for `currency`. Must be a string:", `currency`))
        }
        self$`currency` <- `currency`
      }
      if (!is.null(`amount`)) {
        self$`amount` <- `amount`
      }
      if (!is.null(`created_time`)) {
        stopifnot(R6::is.R6(`created_time`))
        self$`created_time` <- `created_time`
      }
      if (!is.null(`settlement_currency`)) {
        if (!(is.character(`settlement_currency`) && length(`settlement_currency`) == 1)) {
          stop(paste("Error! Invalid data for `settlement_currency`. Must be a string:", `settlement_currency`))
        }
        self$`settlement_currency` <- `settlement_currency`
      }
      if (!is.null(`settlement_amount`)) {
        self$`settlement_amount` <- `settlement_amount`
      }
      if (!is.null(`settlement_created_time`)) {
        stopifnot(R6::is.R6(`settlement_created_time`))
        self$`settlement_created_time` <- `settlement_created_time`
      }
      if (!is.null(`card_brand`)) {
        if (!(is.character(`card_brand`) && length(`card_brand`) == 1)) {
          stop(paste("Error! Invalid data for `card_brand`. Must be a string:", `card_brand`))
        }
        self$`card_brand` <- `card_brand`
      }
      if (!is.null(`card_bin`)) {
        if (!(is.character(`card_bin`) && length(`card_bin`) == 1)) {
          stop(paste("Error! Invalid data for `card_bin`. Must be a string:", `card_bin`))
        }
        self$`card_bin` <- `card_bin`
      }
      if (!is.null(`card_last_four`)) {
        if (!(is.character(`card_last_four`) && length(`card_last_four`) == 1)) {
          stop(paste("Error! Invalid data for `card_last_four`. Must be a string:", `card_last_four`))
        }
        self$`card_last_four` <- `card_last_four`
      }
      if (!is.null(`avs_street_resp_code`)) {
        if (!(is.character(`avs_street_resp_code`) && length(`avs_street_resp_code`) == 1)) {
          stop(paste("Error! Invalid data for `avs_street_resp_code`. Must be a string:", `avs_street_resp_code`))
        }
        self$`avs_street_resp_code` <- `avs_street_resp_code`
      }
      if (!is.null(`avs_postal_resp_code`)) {
        if (!(is.character(`avs_postal_resp_code`) && length(`avs_postal_resp_code`) == 1)) {
          stop(paste("Error! Invalid data for `avs_postal_resp_code`. Must be a string:", `avs_postal_resp_code`))
        }
        self$`avs_postal_resp_code` <- `avs_postal_resp_code`
      }
      if (!is.null(`avs_message`)) {
        if (!(is.character(`avs_message`) && length(`avs_message`) == 1)) {
          stop(paste("Error! Invalid data for `avs_message`. Must be a string:", `avs_message`))
        }
        self$`avs_message` <- `avs_message`
      }
      if (!is.null(`cvv_code`)) {
        if (!(is.character(`cvv_code`) && length(`cvv_code`) == 1)) {
          stop(paste("Error! Invalid data for `cvv_code`. Must be a string:", `cvv_code`))
        }
        self$`cvv_code` <- `cvv_code`
      }
      if (!is.null(`cvv_message`)) {
        if (!(is.character(`cvv_message`) && length(`cvv_message`) == 1)) {
          stop(paste("Error! Invalid data for `cvv_message`. Must be a string:", `cvv_message`))
        }
        self$`cvv_message` <- `cvv_message`
      }
      if (!is.null(`is_test_mode`)) {
        if (!(is.logical(`is_test_mode`) && length(`is_test_mode`) == 1)) {
          stop(paste("Error! Invalid data for `is_test_mode`. Must be a boolean:", `is_test_mode`))
        }
        self$`is_test_mode` <- `is_test_mode`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return OrderTransaction as a base R list.
    #' @examples
    #' # convert array of OrderTransaction (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert OrderTransaction to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      OrderTransactionObject <- list()
      if (!is.null(self$`id`)) {
        OrderTransactionObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`transaction_id`)) {
        OrderTransactionObject[["transaction_id"]] <-
          self$`transaction_id`
      }
      if (!is.null(self$`order_id`)) {
        OrderTransactionObject[["order_id"]] <-
          self$`order_id`
      }
      if (!is.null(self$`parent_id`)) {
        OrderTransactionObject[["parent_id"]] <-
          self$`parent_id`
      }
      if (!is.null(self$`description`)) {
        OrderTransactionObject[["description"]] <-
          self$`description`
      }
      if (!is.null(self$`status`)) {
        OrderTransactionObject[["status"]] <-
          self$`status`
      }
      if (!is.null(self$`gateway`)) {
        OrderTransactionObject[["gateway"]] <-
          self$`gateway`
      }
      if (!is.null(self$`reference_number`)) {
        OrderTransactionObject[["reference_number"]] <-
          self$`reference_number`
      }
      if (!is.null(self$`currency`)) {
        OrderTransactionObject[["currency"]] <-
          self$`currency`
      }
      if (!is.null(self$`amount`)) {
        OrderTransactionObject[["amount"]] <-
          self$`amount`
      }
      if (!is.null(self$`created_time`)) {
        OrderTransactionObject[["created_time"]] <-
          self$`created_time`$toSimpleType()
      }
      if (!is.null(self$`settlement_currency`)) {
        OrderTransactionObject[["settlement_currency"]] <-
          self$`settlement_currency`
      }
      if (!is.null(self$`settlement_amount`)) {
        OrderTransactionObject[["settlement_amount"]] <-
          self$`settlement_amount`
      }
      if (!is.null(self$`settlement_created_time`)) {
        OrderTransactionObject[["settlement_created_time"]] <-
          self$`settlement_created_time`$toSimpleType()
      }
      if (!is.null(self$`card_brand`)) {
        OrderTransactionObject[["card_brand"]] <-
          self$`card_brand`
      }
      if (!is.null(self$`card_bin`)) {
        OrderTransactionObject[["card_bin"]] <-
          self$`card_bin`
      }
      if (!is.null(self$`card_last_four`)) {
        OrderTransactionObject[["card_last_four"]] <-
          self$`card_last_four`
      }
      if (!is.null(self$`avs_street_resp_code`)) {
        OrderTransactionObject[["avs_street_resp_code"]] <-
          self$`avs_street_resp_code`
      }
      if (!is.null(self$`avs_postal_resp_code`)) {
        OrderTransactionObject[["avs_postal_resp_code"]] <-
          self$`avs_postal_resp_code`
      }
      if (!is.null(self$`avs_message`)) {
        OrderTransactionObject[["avs_message"]] <-
          self$`avs_message`
      }
      if (!is.null(self$`cvv_code`)) {
        OrderTransactionObject[["cvv_code"]] <-
          self$`cvv_code`
      }
      if (!is.null(self$`cvv_message`)) {
        OrderTransactionObject[["cvv_message"]] <-
          self$`cvv_message`
      }
      if (!is.null(self$`is_test_mode`)) {
        OrderTransactionObject[["is_test_mode"]] <-
          self$`is_test_mode`
      }
      if (!is.null(self$`additional_fields`)) {
        OrderTransactionObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        OrderTransactionObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(OrderTransactionObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderTransaction
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderTransaction
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`transaction_id`)) {
        self$`transaction_id` <- this_object$`transaction_id`
      }
      if (!is.null(this_object$`order_id`)) {
        self$`order_id` <- this_object$`order_id`
      }
      if (!is.null(this_object$`parent_id`)) {
        self$`parent_id` <- this_object$`parent_id`
      }
      if (!is.null(this_object$`description`)) {
        self$`description` <- this_object$`description`
      }
      if (!is.null(this_object$`status`)) {
        self$`status` <- this_object$`status`
      }
      if (!is.null(this_object$`gateway`)) {
        self$`gateway` <- this_object$`gateway`
      }
      if (!is.null(this_object$`reference_number`)) {
        self$`reference_number` <- this_object$`reference_number`
      }
      if (!is.null(this_object$`currency`)) {
        self$`currency` <- this_object$`currency`
      }
      if (!is.null(this_object$`amount`)) {
        self$`amount` <- this_object$`amount`
      }
      if (!is.null(this_object$`created_time`)) {
        `created_time_object` <- A2CDateTime$new()
        `created_time_object`$fromJSON(jsonlite::toJSON(this_object$`created_time`, auto_unbox = TRUE, digits = NA))
        self$`created_time` <- `created_time_object`
      }
      if (!is.null(this_object$`settlement_currency`)) {
        self$`settlement_currency` <- this_object$`settlement_currency`
      }
      if (!is.null(this_object$`settlement_amount`)) {
        self$`settlement_amount` <- this_object$`settlement_amount`
      }
      if (!is.null(this_object$`settlement_created_time`)) {
        `settlement_created_time_object` <- A2CDateTime$new()
        `settlement_created_time_object`$fromJSON(jsonlite::toJSON(this_object$`settlement_created_time`, auto_unbox = TRUE, digits = NA))
        self$`settlement_created_time` <- `settlement_created_time_object`
      }
      if (!is.null(this_object$`card_brand`)) {
        self$`card_brand` <- this_object$`card_brand`
      }
      if (!is.null(this_object$`card_bin`)) {
        self$`card_bin` <- this_object$`card_bin`
      }
      if (!is.null(this_object$`card_last_four`)) {
        self$`card_last_four` <- this_object$`card_last_four`
      }
      if (!is.null(this_object$`avs_street_resp_code`)) {
        self$`avs_street_resp_code` <- this_object$`avs_street_resp_code`
      }
      if (!is.null(this_object$`avs_postal_resp_code`)) {
        self$`avs_postal_resp_code` <- this_object$`avs_postal_resp_code`
      }
      if (!is.null(this_object$`avs_message`)) {
        self$`avs_message` <- this_object$`avs_message`
      }
      if (!is.null(this_object$`cvv_code`)) {
        self$`cvv_code` <- this_object$`cvv_code`
      }
      if (!is.null(this_object$`cvv_message`)) {
        self$`cvv_message` <- this_object$`cvv_message`
      }
      if (!is.null(this_object$`is_test_mode`)) {
        self$`is_test_mode` <- this_object$`is_test_mode`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return OrderTransaction in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderTransaction
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderTransaction
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`transaction_id` <- this_object$`transaction_id`
      self$`order_id` <- this_object$`order_id`
      self$`parent_id` <- this_object$`parent_id`
      self$`description` <- this_object$`description`
      self$`status` <- this_object$`status`
      self$`gateway` <- this_object$`gateway`
      self$`reference_number` <- this_object$`reference_number`
      self$`currency` <- this_object$`currency`
      self$`amount` <- this_object$`amount`
      self$`created_time` <- A2CDateTime$new()$fromJSON(jsonlite::toJSON(this_object$`created_time`, auto_unbox = TRUE, digits = NA))
      self$`settlement_currency` <- this_object$`settlement_currency`
      self$`settlement_amount` <- this_object$`settlement_amount`
      self$`settlement_created_time` <- A2CDateTime$new()$fromJSON(jsonlite::toJSON(this_object$`settlement_created_time`, auto_unbox = TRUE, digits = NA))
      self$`card_brand` <- this_object$`card_brand`
      self$`card_bin` <- this_object$`card_bin`
      self$`card_last_four` <- this_object$`card_last_four`
      self$`avs_street_resp_code` <- this_object$`avs_street_resp_code`
      self$`avs_postal_resp_code` <- this_object$`avs_postal_resp_code`
      self$`avs_message` <- this_object$`avs_message`
      self$`cvv_code` <- this_object$`cvv_code`
      self$`cvv_message` <- this_object$`cvv_message`
      self$`is_test_mode` <- this_object$`is_test_mode`
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to OrderTransaction and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of OrderTransaction
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# OrderTransaction$unlock()
#
## Below is an example to define the print function
# OrderTransaction$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# OrderTransaction$lock()

