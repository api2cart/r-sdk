#' Create a new OrderCalculateDiscount
#'
#' @description
#' OrderCalculateDiscount Class
#'
#' @docType class
#' @title OrderCalculateDiscount
#' @description OrderCalculateDiscount Class
#' @format An \code{R6Class} generator object
#' @field code  character [optional]
#' @field value  numeric [optional]
#' @field type  character [optional]
#' @field free_shipping  character [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
OrderCalculateDiscount <- R6::R6Class(
  "OrderCalculateDiscount",
  public = list(
    `code` = NULL,
    `value` = NULL,
    `type` = NULL,
    `free_shipping` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new OrderCalculateDiscount class.
    #'
    #' @param code code
    #' @param value value
    #' @param type type
    #' @param free_shipping free_shipping
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`code` = NULL, `value` = NULL, `type` = NULL, `free_shipping` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`code`)) {
        if (!(is.character(`code`) && length(`code`) == 1)) {
          stop(paste("Error! Invalid data for `code`. Must be a string:", `code`))
        }
        self$`code` <- `code`
      }
      if (!is.null(`value`)) {
        self$`value` <- `value`
      }
      if (!is.null(`type`)) {
        if (!(is.character(`type`) && length(`type`) == 1)) {
          stop(paste("Error! Invalid data for `type`. Must be a string:", `type`))
        }
        self$`type` <- `type`
      }
      if (!is.null(`free_shipping`)) {
        if (!(is.logical(`free_shipping`) && length(`free_shipping`) == 1)) {
          stop(paste("Error! Invalid data for `free_shipping`. Must be a boolean:", `free_shipping`))
        }
        self$`free_shipping` <- `free_shipping`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return OrderCalculateDiscount as a base R list.
    #' @examples
    #' # convert array of OrderCalculateDiscount (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert OrderCalculateDiscount to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      OrderCalculateDiscountObject <- list()
      if (!is.null(self$`code`)) {
        OrderCalculateDiscountObject[["code"]] <-
          self$`code`
      }
      if (!is.null(self$`value`)) {
        OrderCalculateDiscountObject[["value"]] <-
          self$`value`
      }
      if (!is.null(self$`type`)) {
        OrderCalculateDiscountObject[["type"]] <-
          self$`type`
      }
      if (!is.null(self$`free_shipping`)) {
        OrderCalculateDiscountObject[["free_shipping"]] <-
          self$`free_shipping`
      }
      if (!is.null(self$`additional_fields`)) {
        OrderCalculateDiscountObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        OrderCalculateDiscountObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(OrderCalculateDiscountObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderCalculateDiscount
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderCalculateDiscount
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`code`)) {
        self$`code` <- this_object$`code`
      }
      if (!is.null(this_object$`value`)) {
        self$`value` <- this_object$`value`
      }
      if (!is.null(this_object$`type`)) {
        self$`type` <- this_object$`type`
      }
      if (!is.null(this_object$`free_shipping`)) {
        self$`free_shipping` <- this_object$`free_shipping`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return OrderCalculateDiscount in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderCalculateDiscount
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderCalculateDiscount
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`code` <- this_object$`code`
      self$`value` <- this_object$`value`
      self$`type` <- this_object$`type`
      self$`free_shipping` <- this_object$`free_shipping`
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to OrderCalculateDiscount and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of OrderCalculateDiscount
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# OrderCalculateDiscount$unlock()
#
## Below is an example to define the print function
# OrderCalculateDiscount$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# OrderCalculateDiscount$lock()

