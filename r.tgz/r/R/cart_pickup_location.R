#' Create a new CartPickupLocation
#'
#' @description
#' CartPickupLocation Class
#'
#' @docType class
#' @title CartPickupLocation
#' @description CartPickupLocation Class
#' @format An \code{R6Class} generator object
#' @field id  character [optional]
#' @field name  character [optional]
#' @field avail  character [optional]
#' @field address  \link{CustomerAddress} [optional]
#' @field pickup_instructions  character [optional]
#' @field expected_ready_time  character [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
CartPickupLocation <- R6::R6Class(
  "CartPickupLocation",
  public = list(
    `id` = NULL,
    `name` = NULL,
    `avail` = NULL,
    `address` = NULL,
    `pickup_instructions` = NULL,
    `expected_ready_time` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new CartPickupLocation class.
    #'
    #' @param id id
    #' @param name name
    #' @param avail avail
    #' @param address address
    #' @param pickup_instructions pickup_instructions
    #' @param expected_ready_time expected_ready_time
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `name` = NULL, `avail` = NULL, `address` = NULL, `pickup_instructions` = NULL, `expected_ready_time` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`avail`)) {
        if (!(is.logical(`avail`) && length(`avail`) == 1)) {
          stop(paste("Error! Invalid data for `avail`. Must be a boolean:", `avail`))
        }
        self$`avail` <- `avail`
      }
      if (!is.null(`address`)) {
        stopifnot(R6::is.R6(`address`))
        self$`address` <- `address`
      }
      if (!is.null(`pickup_instructions`)) {
        if (!(is.character(`pickup_instructions`) && length(`pickup_instructions`) == 1)) {
          stop(paste("Error! Invalid data for `pickup_instructions`. Must be a string:", `pickup_instructions`))
        }
        self$`pickup_instructions` <- `pickup_instructions`
      }
      if (!is.null(`expected_ready_time`)) {
        if (!(is.character(`expected_ready_time`) && length(`expected_ready_time`) == 1)) {
          stop(paste("Error! Invalid data for `expected_ready_time`. Must be a string:", `expected_ready_time`))
        }
        self$`expected_ready_time` <- `expected_ready_time`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return CartPickupLocation as a base R list.
    #' @examples
    #' # convert array of CartPickupLocation (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert CartPickupLocation to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      CartPickupLocationObject <- list()
      if (!is.null(self$`id`)) {
        CartPickupLocationObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`name`)) {
        CartPickupLocationObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`avail`)) {
        CartPickupLocationObject[["avail"]] <-
          self$`avail`
      }
      if (!is.null(self$`address`)) {
        CartPickupLocationObject[["address"]] <-
          self$`address`$toSimpleType()
      }
      if (!is.null(self$`pickup_instructions`)) {
        CartPickupLocationObject[["pickup_instructions"]] <-
          self$`pickup_instructions`
      }
      if (!is.null(self$`expected_ready_time`)) {
        CartPickupLocationObject[["expected_ready_time"]] <-
          self$`expected_ready_time`
      }
      if (!is.null(self$`additional_fields`)) {
        CartPickupLocationObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        CartPickupLocationObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(CartPickupLocationObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of CartPickupLocation
    #'
    #' @param input_json the JSON input
    #' @return the instance of CartPickupLocation
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`avail`)) {
        self$`avail` <- this_object$`avail`
      }
      if (!is.null(this_object$`address`)) {
        `address_object` <- CustomerAddress$new()
        `address_object`$fromJSON(jsonlite::toJSON(this_object$`address`, auto_unbox = TRUE, digits = NA))
        self$`address` <- `address_object`
      }
      if (!is.null(this_object$`pickup_instructions`)) {
        self$`pickup_instructions` <- this_object$`pickup_instructions`
      }
      if (!is.null(this_object$`expected_ready_time`)) {
        self$`expected_ready_time` <- this_object$`expected_ready_time`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return CartPickupLocation in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of CartPickupLocation
    #'
    #' @param input_json the JSON input
    #' @return the instance of CartPickupLocation
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`name` <- this_object$`name`
      self$`avail` <- this_object$`avail`
      self$`address` <- CustomerAddress$new()$fromJSON(jsonlite::toJSON(this_object$`address`, auto_unbox = TRUE, digits = NA))
      self$`pickup_instructions` <- this_object$`pickup_instructions`
      self$`expected_ready_time` <- this_object$`expected_ready_time`
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to CartPickupLocation and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of CartPickupLocation
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# CartPickupLocation$unlock()
#
## Below is an example to define the print function
# CartPickupLocation$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# CartPickupLocation$lock()

