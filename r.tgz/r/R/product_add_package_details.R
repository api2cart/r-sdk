#' Create a new ProductAddPackageDetails
#'
#' @description
#' If the seller is subscribed to \"Business Policies\", use the seller_profiles instead of the shipping_details, payment_methods and return_accepted params.<hr><div style=\"font-style:normal\">Param structure:<div style=\"margin-left: 2%;\"><code style=\"padding:0; background-color:#ffffff;font-size:85%;font-family:monospace;\">package_details[<b>measure_unit</b>] = string</br> Allowed measure_unit values: [English or Metric] </br> Default: Metric</br>package_details[<b>weigh_unit</b>] = string</br> Allowed weigh_unit values: [kg, g, lbs, oz]</br>package_details[<b>package_depth</b>] = decimal</br>package_details[<b>package_length</b>] = decimal</br>package_details[<b>package_width</b>] = decimal</br>package_details[<b>weight_major</b>] = decimal</br>package_details[<b>weight_minor</b>] = decimal</br>package_details[<b>shipping_package</b>] = string</br> See cart.info method, param `eBay_shipping_package_details`</code></div></div>
#'
#' @docType class
#' @title ProductAddPackageDetails
#' @description ProductAddPackageDetails Class
#' @format An \code{R6Class} generator object
#' @field measure_unit  character [optional]
#' @field weigh_unit  character [optional]
#' @field package_depth  numeric [optional]
#' @field package_length  numeric [optional]
#' @field package_width  numeric [optional]
#' @field weight_major  numeric [optional]
#' @field weight_minor  numeric [optional]
#' @field shipping_package  character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductAddPackageDetails <- R6::R6Class(
  "ProductAddPackageDetails",
  public = list(
    `measure_unit` = NULL,
    `weigh_unit` = NULL,
    `package_depth` = NULL,
    `package_length` = NULL,
    `package_width` = NULL,
    `weight_major` = NULL,
    `weight_minor` = NULL,
    `shipping_package` = NULL,

    #' @description
    #' Initialize a new ProductAddPackageDetails class.
    #'
    #' @param measure_unit measure_unit
    #' @param weigh_unit weigh_unit
    #' @param package_depth package_depth
    #' @param package_length package_length
    #' @param package_width package_width
    #' @param weight_major weight_major
    #' @param weight_minor weight_minor
    #' @param shipping_package shipping_package
    #' @param ... Other optional arguments.
    initialize = function(`measure_unit` = NULL, `weigh_unit` = NULL, `package_depth` = NULL, `package_length` = NULL, `package_width` = NULL, `weight_major` = NULL, `weight_minor` = NULL, `shipping_package` = NULL, ...) {
      if (!is.null(`measure_unit`)) {
        if (!(is.character(`measure_unit`) && length(`measure_unit`) == 1)) {
          stop(paste("Error! Invalid data for `measure_unit`. Must be a string:", `measure_unit`))
        }
        self$`measure_unit` <- `measure_unit`
      }
      if (!is.null(`weigh_unit`)) {
        if (!(is.character(`weigh_unit`) && length(`weigh_unit`) == 1)) {
          stop(paste("Error! Invalid data for `weigh_unit`. Must be a string:", `weigh_unit`))
        }
        self$`weigh_unit` <- `weigh_unit`
      }
      if (!is.null(`package_depth`)) {
        self$`package_depth` <- `package_depth`
      }
      if (!is.null(`package_length`)) {
        self$`package_length` <- `package_length`
      }
      if (!is.null(`package_width`)) {
        self$`package_width` <- `package_width`
      }
      if (!is.null(`weight_major`)) {
        self$`weight_major` <- `weight_major`
      }
      if (!is.null(`weight_minor`)) {
        self$`weight_minor` <- `weight_minor`
      }
      if (!is.null(`shipping_package`)) {
        if (!(is.character(`shipping_package`) && length(`shipping_package`) == 1)) {
          stop(paste("Error! Invalid data for `shipping_package`. Must be a string:", `shipping_package`))
        }
        self$`shipping_package` <- `shipping_package`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductAddPackageDetails as a base R list.
    #' @examples
    #' # convert array of ProductAddPackageDetails (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductAddPackageDetails to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductAddPackageDetailsObject <- list()
      if (!is.null(self$`measure_unit`)) {
        ProductAddPackageDetailsObject[["measure_unit"]] <-
          self$`measure_unit`
      }
      if (!is.null(self$`weigh_unit`)) {
        ProductAddPackageDetailsObject[["weigh_unit"]] <-
          self$`weigh_unit`
      }
      if (!is.null(self$`package_depth`)) {
        ProductAddPackageDetailsObject[["package_depth"]] <-
          self$`package_depth`
      }
      if (!is.null(self$`package_length`)) {
        ProductAddPackageDetailsObject[["package_length"]] <-
          self$`package_length`
      }
      if (!is.null(self$`package_width`)) {
        ProductAddPackageDetailsObject[["package_width"]] <-
          self$`package_width`
      }
      if (!is.null(self$`weight_major`)) {
        ProductAddPackageDetailsObject[["weight_major"]] <-
          self$`weight_major`
      }
      if (!is.null(self$`weight_minor`)) {
        ProductAddPackageDetailsObject[["weight_minor"]] <-
          self$`weight_minor`
      }
      if (!is.null(self$`shipping_package`)) {
        ProductAddPackageDetailsObject[["shipping_package"]] <-
          self$`shipping_package`
      }
      return(ProductAddPackageDetailsObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductAddPackageDetails
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductAddPackageDetails
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`measure_unit`)) {
        self$`measure_unit` <- this_object$`measure_unit`
      }
      if (!is.null(this_object$`weigh_unit`)) {
        self$`weigh_unit` <- this_object$`weigh_unit`
      }
      if (!is.null(this_object$`package_depth`)) {
        self$`package_depth` <- this_object$`package_depth`
      }
      if (!is.null(this_object$`package_length`)) {
        self$`package_length` <- this_object$`package_length`
      }
      if (!is.null(this_object$`package_width`)) {
        self$`package_width` <- this_object$`package_width`
      }
      if (!is.null(this_object$`weight_major`)) {
        self$`weight_major` <- this_object$`weight_major`
      }
      if (!is.null(this_object$`weight_minor`)) {
        self$`weight_minor` <- this_object$`weight_minor`
      }
      if (!is.null(this_object$`shipping_package`)) {
        self$`shipping_package` <- this_object$`shipping_package`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductAddPackageDetails in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductAddPackageDetails
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductAddPackageDetails
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`measure_unit` <- this_object$`measure_unit`
      self$`weigh_unit` <- this_object$`weigh_unit`
      self$`package_depth` <- this_object$`package_depth`
      self$`package_length` <- this_object$`package_length`
      self$`package_width` <- this_object$`package_width`
      self$`weight_major` <- this_object$`weight_major`
      self$`weight_minor` <- this_object$`weight_minor`
      self$`shipping_package` <- this_object$`shipping_package`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductAddPackageDetails and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductAddPackageDetails
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductAddPackageDetails$unlock()
#
## Below is an example to define the print function
# ProductAddPackageDetails$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductAddPackageDetails$lock()

