#' Create a new AccountSupportedPlatforms200ResponseResultSupportedPlatformsInnerParams
#'
#' @description
#' AccountSupportedPlatforms200ResponseResultSupportedPlatformsInnerParams Class
#'
#' @docType class
#' @title AccountSupportedPlatforms200ResponseResultSupportedPlatformsInnerParams
#' @description AccountSupportedPlatforms200ResponseResultSupportedPlatformsInnerParams Class
#' @format An \code{R6Class} generator object
#' @field required  list(list(\link{AccountSupportedPlatforms200ResponseResultSupportedPlatformsInnerParamsRequiredInnerInner})) [optional]
#' @field additional  list(\link{AccountSupportedPlatforms200ResponseResultSupportedPlatformsInnerParamsRequiredInnerInner}) [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
AccountSupportedPlatforms200ResponseResultSupportedPlatformsInnerParams <- R6::R6Class(
  "AccountSupportedPlatforms200ResponseResultSupportedPlatformsInnerParams",
  public = list(
    `required` = NULL,
    `additional` = NULL,

    #' @description
    #' Initialize a new AccountSupportedPlatforms200ResponseResultSupportedPlatformsInnerParams class.
    #'
    #' @param required required
    #' @param additional additional
    #' @param ... Other optional arguments.
    initialize = function(`required` = NULL, `additional` = NULL, ...) {
      if (!is.null(`required`)) {
        stopifnot(is.vector(`required`), length(`required`) != 0)
        sapply(`required`, function(x) stopifnot(R6::is.R6(x)))
        self$`required` <- `required`
      }
      if (!is.null(`additional`)) {
        stopifnot(is.vector(`additional`), length(`additional`) != 0)
        sapply(`additional`, function(x) stopifnot(R6::is.R6(x)))
        self$`additional` <- `additional`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return AccountSupportedPlatforms200ResponseResultSupportedPlatformsInnerParams as a base R list.
    #' @examples
    #' # convert array of AccountSupportedPlatforms200ResponseResultSupportedPlatformsInnerParams (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert AccountSupportedPlatforms200ResponseResultSupportedPlatformsInnerParams to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      AccountSupportedPlatforms200ResponseResultSupportedPlatformsInnerParamsObject <- list()
      if (!is.null(self$`required`)) {
        AccountSupportedPlatforms200ResponseResultSupportedPlatformsInnerParamsObject[["required"]] <-
          lapply(self$`required`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`additional`)) {
        AccountSupportedPlatforms200ResponseResultSupportedPlatformsInnerParamsObject[["additional"]] <-
          lapply(self$`additional`, function(x) x$toSimpleType())
      }
      return(AccountSupportedPlatforms200ResponseResultSupportedPlatformsInnerParamsObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of AccountSupportedPlatforms200ResponseResultSupportedPlatformsInnerParams
    #'
    #' @param input_json the JSON input
    #' @return the instance of AccountSupportedPlatforms200ResponseResultSupportedPlatformsInnerParams
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`required`)) {
        self$`required` <- ApiClient$new()$deserializeObj(this_object$`required`, "array[array[AccountSupportedPlatforms200ResponseResultSupportedPlatformsInnerParamsRequiredInnerInner]]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`additional`)) {
        self$`additional` <- ApiClient$new()$deserializeObj(this_object$`additional`, "array[AccountSupportedPlatforms200ResponseResultSupportedPlatformsInnerParamsRequiredInnerInner]", loadNamespace("openapi"))
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return AccountSupportedPlatforms200ResponseResultSupportedPlatformsInnerParams in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of AccountSupportedPlatforms200ResponseResultSupportedPlatformsInnerParams
    #'
    #' @param input_json the JSON input
    #' @return the instance of AccountSupportedPlatforms200ResponseResultSupportedPlatformsInnerParams
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`required` <- ApiClient$new()$deserializeObj(this_object$`required`, "array[array[AccountSupportedPlatforms200ResponseResultSupportedPlatformsInnerParamsRequiredInnerInner]]", loadNamespace("openapi"))
      self$`additional` <- ApiClient$new()$deserializeObj(this_object$`additional`, "array[AccountSupportedPlatforms200ResponseResultSupportedPlatformsInnerParamsRequiredInnerInner]", loadNamespace("openapi"))
      self
    },

    #' @description
    #' Validate JSON input with respect to AccountSupportedPlatforms200ResponseResultSupportedPlatformsInnerParams and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of AccountSupportedPlatforms200ResponseResultSupportedPlatformsInnerParams
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# AccountSupportedPlatforms200ResponseResultSupportedPlatformsInnerParams$unlock()
#
## Below is an example to define the print function
# AccountSupportedPlatforms200ResponseResultSupportedPlatformsInnerParams$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# AccountSupportedPlatforms200ResponseResultSupportedPlatformsInnerParams$lock()

