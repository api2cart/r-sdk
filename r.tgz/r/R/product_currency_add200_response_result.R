#' Create a new ProductCurrencyAdd200ResponseResult
#'
#' @description
#' ProductCurrencyAdd200ResponseResult Class
#'
#' @docType class
#' @title ProductCurrencyAdd200ResponseResult
#' @description ProductCurrencyAdd200ResponseResult Class
#' @format An \code{R6Class} generator object
#' @field currency_id  character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductCurrencyAdd200ResponseResult <- R6::R6Class(
  "ProductCurrencyAdd200ResponseResult",
  public = list(
    `currency_id` = NULL,

    #' @description
    #' Initialize a new ProductCurrencyAdd200ResponseResult class.
    #'
    #' @param currency_id currency_id
    #' @param ... Other optional arguments.
    initialize = function(`currency_id` = NULL, ...) {
      if (!is.null(`currency_id`)) {
        if (!(is.character(`currency_id`) && length(`currency_id`) == 1)) {
          stop(paste("Error! Invalid data for `currency_id`. Must be a string:", `currency_id`))
        }
        self$`currency_id` <- `currency_id`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductCurrencyAdd200ResponseResult as a base R list.
    #' @examples
    #' # convert array of ProductCurrencyAdd200ResponseResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductCurrencyAdd200ResponseResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductCurrencyAdd200ResponseResultObject <- list()
      if (!is.null(self$`currency_id`)) {
        ProductCurrencyAdd200ResponseResultObject[["currency_id"]] <-
          self$`currency_id`
      }
      return(ProductCurrencyAdd200ResponseResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductCurrencyAdd200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductCurrencyAdd200ResponseResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`currency_id`)) {
        self$`currency_id` <- this_object$`currency_id`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductCurrencyAdd200ResponseResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductCurrencyAdd200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductCurrencyAdd200ResponseResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`currency_id` <- this_object$`currency_id`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductCurrencyAdd200ResponseResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductCurrencyAdd200ResponseResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductCurrencyAdd200ResponseResult$unlock()
#
## Below is an example to define the print function
# ProductCurrencyAdd200ResponseResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductCurrencyAdd200ResponseResult$lock()

