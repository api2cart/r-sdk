#' Create a new WebhookUpdate
#'
#' @description
#' WebhookUpdate Class
#'
#' @docType class
#' @title WebhookUpdate
#' @description WebhookUpdate Class
#' @format An \code{R6Class} generator object
#' @field id Webhook id character
#' @field callback Callback where the webhook should send the POST request when the event occurs character [optional]
#' @field label The name you give to the webhook character [optional]
#' @field fields Fields the webhook should send character [optional]
#' @field response_fields Set this parameter to choose which entity fields to retrieve. Use comma-separated field names in curly braces, nested to match the response structure, e.g. {result{product{id,name}}}. The wildcard * returns every field at a level: {*} gives the whole response, {result{product{*}}} all product fields. character [optional]
#' @field active Webhook status character [optional]
#' @field lang_id Language id character [optional]
#' @field filtering_conditions <p>Defines the logic for filtering webhooks based on the entity's data. If provided, the webhook will only be sent if the entity matches the specified conditions. Pass <strong>null</strong> to disable filtering and receive all webhooks (for <strong>webhook.update</strong> method).</p><p>The filter accepts a recursive JSON object. The maximum nesting level is <strong>5</strong>. Exceeding this will result in a validation error. <p><strong>Strict Rule:</strong> Each level of the object must contain <strong>exactly one</strong> of the following keys:</p><ul><li><strong>Logical Groups:</strong><code>and</code>, <code>or</code>, <code>not</code> (used to combine multiple conditions).</li><li><strong>Condition:</strong><code>field</code>, <code>operator</code> and <code>value</code></li></ul><br/><p><strong>Logical Operators:</strong><ul><li><code>and</code>: Accepts an array of objects. All conditions must be true.</li><li><code>or</code>: Accepts an array of objects. At least one condition must be true.</li><li><code>not</code>: Accepts a single object. The condition inside must be false.</li></ul></p><br/><p><strong>Condition Object:</strong><ul><li><code>field</code>: The dot-notation path to the attribute (e.g., id, customer.email, items.price).</li><li><code>operator</code>: The comparison method (see list below).</li><li><code>value</code>: The value to compare against.</li></ul></p><br/><p>The list of available fields for filtering is returned by the <strong>webhook.events</strong> method in the <strong>filterable_fields</strong> property. The available fields depend on the webhook entity. If the list for a specific webhook is empty, it means that filtering is not supported for this entity or action.</p><p>The system validates operators against the field type defined in the entity schema.</p><p><ul><li><strong>string:</strong><code>eq</code>, <code>neq</code>, <code>in</code>, <code>not_in</code>, <code>like</code>, <code>not_like</code>.</li><li><strong>integer:</strong><code>eq</code>, <code>neq</code>, <code>gt</code>, <code>gte</code>, <code>lt</code>, <code>lte</code>.</li><li><strong>number:</strong><code>eq</code>, <code>neq</code>, <code>gt</code>, <code>gte</code>, <code>lt</code>, <code>lte</code>.</li><li><strong>boolean:</strong><code>eq</code>, <code>neq</code>.</li><li><strong>date:</strong><code>eq</code>, <code>neq</code>, <code>gt</code>, <code>gte</code>, <code>lt</code>, <code>lte</code>.</li><li><strong>array:</strong><code>eq</code>, <code>neq</code>, <code>in</code>, <code>not_in</code>.</li></ul></p><br/><p><strong>Operators:</strong><ul><li><code>eq</code>: Exact match. The field value must match the specified value exactly (case sensitive). For array-type fields, compares two arrays regardless of the element order.</li><li><code>neq</code>: Not equal. The field value must be different from the specified value.</li><li><code>like</code>: Partial match (SQL-style). Case-insensitive. Supported wildcards:<ul><li><strong>\%</strong> - matches any sequence of characters (0 or more).</li><li><strong>_</strong> - matches exactly one character.</li></ul> If the value contains the '\%' or '_' characters, they must be escaped using a backslash ('\\'). For example, if the string is 'demo_', the value should be specified as 'demo\\_'.</li><li><code>not_like</code>: Inverted Partial Match. Ensures the pattern does not match.</li><li><code>in</code>: In List. The field value must match one of the values in the provided array. For array-type fields, the condition is considered valid if at least one element from the provided list exists in the array.</li><li><code>not_in</code>: Not In List. The field value must not be present in the provided array. For array-type fields, the condition is considered valid if none of the elements in the array exist in the provided list.</li><li><code>lt</code>: Less (Strictly Less). The value is strictly less than value.</li><li><code>lte</code>: Less than or equal to.</li><li><code>gt</code>: Strictly Greater. The value is strictly greater than value.</li><li><code>gte</code>: Greater than or equal to.</li></ul></p><br/><p><strong>Please note: the filter is universal for all platforms; however, for some platforms, certain fields may never be populated. Before defining a filter, make sure that the field is populated for the specific platform. Otherwise, a webhook configured with such a filter may never be triggered.</strong></p><br/> \link{ParamDefinitionFilteringConditionsFilterCondition} [optional]
#' @field idempotency_key A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong> character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
WebhookUpdate <- R6::R6Class(
  "WebhookUpdate",
  public = list(
    `id` = NULL,
    `callback` = NULL,
    `label` = NULL,
    `fields` = NULL,
    `response_fields` = NULL,
    `active` = NULL,
    `lang_id` = NULL,
    `filtering_conditions` = NULL,
    `idempotency_key` = NULL,

    #' @description
    #' Initialize a new WebhookUpdate class.
    #'
    #' @param id Webhook id
    #' @param callback Callback where the webhook should send the POST request when the event occurs
    #' @param label The name you give to the webhook
    #' @param fields Fields the webhook should send
    #' @param response_fields Set this parameter to choose which entity fields to retrieve. Use comma-separated field names in curly braces, nested to match the response structure, e.g. {result{product{id,name}}}. The wildcard * returns every field at a level: {*} gives the whole response, {result{product{*}}} all product fields.
    #' @param active Webhook status
    #' @param lang_id Language id
    #' @param filtering_conditions <p>Defines the logic for filtering webhooks based on the entity's data. If provided, the webhook will only be sent if the entity matches the specified conditions. Pass <strong>null</strong> to disable filtering and receive all webhooks (for <strong>webhook.update</strong> method).</p><p>The filter accepts a recursive JSON object. The maximum nesting level is <strong>5</strong>. Exceeding this will result in a validation error. <p><strong>Strict Rule:</strong> Each level of the object must contain <strong>exactly one</strong> of the following keys:</p><ul><li><strong>Logical Groups:</strong><code>and</code>, <code>or</code>, <code>not</code> (used to combine multiple conditions).</li><li><strong>Condition:</strong><code>field</code>, <code>operator</code> and <code>value</code></li></ul><br/><p><strong>Logical Operators:</strong><ul><li><code>and</code>: Accepts an array of objects. All conditions must be true.</li><li><code>or</code>: Accepts an array of objects. At least one condition must be true.</li><li><code>not</code>: Accepts a single object. The condition inside must be false.</li></ul></p><br/><p><strong>Condition Object:</strong><ul><li><code>field</code>: The dot-notation path to the attribute (e.g., id, customer.email, items.price).</li><li><code>operator</code>: The comparison method (see list below).</li><li><code>value</code>: The value to compare against.</li></ul></p><br/><p>The list of available fields for filtering is returned by the <strong>webhook.events</strong> method in the <strong>filterable_fields</strong> property. The available fields depend on the webhook entity. If the list for a specific webhook is empty, it means that filtering is not supported for this entity or action.</p><p>The system validates operators against the field type defined in the entity schema.</p><p><ul><li><strong>string:</strong><code>eq</code>, <code>neq</code>, <code>in</code>, <code>not_in</code>, <code>like</code>, <code>not_like</code>.</li><li><strong>integer:</strong><code>eq</code>, <code>neq</code>, <code>gt</code>, <code>gte</code>, <code>lt</code>, <code>lte</code>.</li><li><strong>number:</strong><code>eq</code>, <code>neq</code>, <code>gt</code>, <code>gte</code>, <code>lt</code>, <code>lte</code>.</li><li><strong>boolean:</strong><code>eq</code>, <code>neq</code>.</li><li><strong>date:</strong><code>eq</code>, <code>neq</code>, <code>gt</code>, <code>gte</code>, <code>lt</code>, <code>lte</code>.</li><li><strong>array:</strong><code>eq</code>, <code>neq</code>, <code>in</code>, <code>not_in</code>.</li></ul></p><br/><p><strong>Operators:</strong><ul><li><code>eq</code>: Exact match. The field value must match the specified value exactly (case sensitive). For array-type fields, compares two arrays regardless of the element order.</li><li><code>neq</code>: Not equal. The field value must be different from the specified value.</li><li><code>like</code>: Partial match (SQL-style). Case-insensitive. Supported wildcards:<ul><li><strong>\%</strong> - matches any sequence of characters (0 or more).</li><li><strong>_</strong> - matches exactly one character.</li></ul> If the value contains the '\%' or '_' characters, they must be escaped using a backslash ('\\'). For example, if the string is 'demo_', the value should be specified as 'demo\\_'.</li><li><code>not_like</code>: Inverted Partial Match. Ensures the pattern does not match.</li><li><code>in</code>: In List. The field value must match one of the values in the provided array. For array-type fields, the condition is considered valid if at least one element from the provided list exists in the array.</li><li><code>not_in</code>: Not In List. The field value must not be present in the provided array. For array-type fields, the condition is considered valid if none of the elements in the array exist in the provided list.</li><li><code>lt</code>: Less (Strictly Less). The value is strictly less than value.</li><li><code>lte</code>: Less than or equal to.</li><li><code>gt</code>: Strictly Greater. The value is strictly greater than value.</li><li><code>gte</code>: Greater than or equal to.</li></ul></p><br/><p><strong>Please note: the filter is universal for all platforms; however, for some platforms, certain fields may never be populated. Before defining a filter, make sure that the field is populated for the specific platform. Otherwise, a webhook configured with such a filter may never be triggered.</strong></p><br/>
    #' @param idempotency_key A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong>
    #' @param ... Other optional arguments.
    initialize = function(`id`, `callback` = NULL, `label` = NULL, `fields` = NULL, `response_fields` = NULL, `active` = NULL, `lang_id` = NULL, `filtering_conditions` = NULL, `idempotency_key` = NULL, ...) {
      if (!missing(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`callback`)) {
        if (!(is.character(`callback`) && length(`callback`) == 1)) {
          stop(paste("Error! Invalid data for `callback`. Must be a string:", `callback`))
        }
        self$`callback` <- `callback`
      }
      if (!is.null(`label`)) {
        if (!(is.character(`label`) && length(`label`) == 1)) {
          stop(paste("Error! Invalid data for `label`. Must be a string:", `label`))
        }
        self$`label` <- `label`
      }
      if (!is.null(`fields`)) {
        if (!(is.character(`fields`) && length(`fields`) == 1)) {
          stop(paste("Error! Invalid data for `fields`. Must be a string:", `fields`))
        }
        self$`fields` <- `fields`
      }
      if (!is.null(`response_fields`)) {
        if (!(is.character(`response_fields`) && length(`response_fields`) == 1)) {
          stop(paste("Error! Invalid data for `response_fields`. Must be a string:", `response_fields`))
        }
        self$`response_fields` <- `response_fields`
      }
      if (!is.null(`active`)) {
        if (!(is.logical(`active`) && length(`active`) == 1)) {
          stop(paste("Error! Invalid data for `active`. Must be a boolean:", `active`))
        }
        self$`active` <- `active`
      }
      if (!is.null(`lang_id`)) {
        if (!(is.character(`lang_id`) && length(`lang_id`) == 1)) {
          stop(paste("Error! Invalid data for `lang_id`. Must be a string:", `lang_id`))
        }
        self$`lang_id` <- `lang_id`
      }
      if (!is.null(`filtering_conditions`)) {
        stopifnot(R6::is.R6(`filtering_conditions`))
        self$`filtering_conditions` <- `filtering_conditions`
      }
      if (!is.null(`idempotency_key`)) {
        if (!(is.character(`idempotency_key`) && length(`idempotency_key`) == 1)) {
          stop(paste("Error! Invalid data for `idempotency_key`. Must be a string:", `idempotency_key`))
        }
        self$`idempotency_key` <- `idempotency_key`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return WebhookUpdate as a base R list.
    #' @examples
    #' # convert array of WebhookUpdate (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert WebhookUpdate to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      WebhookUpdateObject <- list()
      if (!is.null(self$`id`)) {
        WebhookUpdateObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`callback`)) {
        WebhookUpdateObject[["callback"]] <-
          self$`callback`
      }
      if (!is.null(self$`label`)) {
        WebhookUpdateObject[["label"]] <-
          self$`label`
      }
      if (!is.null(self$`fields`)) {
        WebhookUpdateObject[["fields"]] <-
          self$`fields`
      }
      if (!is.null(self$`response_fields`)) {
        WebhookUpdateObject[["response_fields"]] <-
          self$`response_fields`
      }
      if (!is.null(self$`active`)) {
        WebhookUpdateObject[["active"]] <-
          self$`active`
      }
      if (!is.null(self$`lang_id`)) {
        WebhookUpdateObject[["lang_id"]] <-
          self$`lang_id`
      }
      if (!is.null(self$`filtering_conditions`)) {
        WebhookUpdateObject[["filtering_conditions"]] <-
          self$`filtering_conditions`$toSimpleType()
      }
      if (!is.null(self$`idempotency_key`)) {
        WebhookUpdateObject[["idempotency_key"]] <-
          self$`idempotency_key`
      }
      return(WebhookUpdateObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of WebhookUpdate
    #'
    #' @param input_json the JSON input
    #' @return the instance of WebhookUpdate
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`callback`)) {
        self$`callback` <- this_object$`callback`
      }
      if (!is.null(this_object$`label`)) {
        self$`label` <- this_object$`label`
      }
      if (!is.null(this_object$`fields`)) {
        self$`fields` <- this_object$`fields`
      }
      if (!is.null(this_object$`response_fields`)) {
        self$`response_fields` <- this_object$`response_fields`
      }
      if (!is.null(this_object$`active`)) {
        self$`active` <- this_object$`active`
      }
      if (!is.null(this_object$`lang_id`)) {
        self$`lang_id` <- this_object$`lang_id`
      }
      if (!is.null(this_object$`filtering_conditions`)) {
        `filtering_conditions_object` <- ParamDefinitionFilteringConditionsFilterCondition$new()
        `filtering_conditions_object`$fromJSON(jsonlite::toJSON(this_object$`filtering_conditions`, auto_unbox = TRUE, digits = NA))
        self$`filtering_conditions` <- `filtering_conditions_object`
      }
      if (!is.null(this_object$`idempotency_key`)) {
        self$`idempotency_key` <- this_object$`idempotency_key`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return WebhookUpdate in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of WebhookUpdate
    #'
    #' @param input_json the JSON input
    #' @return the instance of WebhookUpdate
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`callback` <- this_object$`callback`
      self$`label` <- this_object$`label`
      self$`fields` <- this_object$`fields`
      self$`response_fields` <- this_object$`response_fields`
      self$`active` <- this_object$`active`
      self$`lang_id` <- this_object$`lang_id`
      self$`filtering_conditions` <- ParamDefinitionFilteringConditionsFilterCondition$new()$fromJSON(jsonlite::toJSON(this_object$`filtering_conditions`, auto_unbox = TRUE, digits = NA))
      self$`idempotency_key` <- this_object$`idempotency_key`
      self
    },

    #' @description
    #' Validate JSON input with respect to WebhookUpdate and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
      # check the required field `id`
      if (!is.null(input_json$`id`)) {
        if (!(is.character(input_json$`id`) && length(input_json$`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", input_json$`id`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for WebhookUpdate: the required field `id` is missing."))
      }
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of WebhookUpdate
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      # check if the required `id` is null
      if (is.null(self$`id`)) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      # check if the required `id` is null
      if (is.null(self$`id`)) {
        invalid_fields["id"] <- "Non-nullable required field `id` cannot be null."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# WebhookUpdate$unlock()
#
## Below is an example to define the print function
# WebhookUpdate$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# WebhookUpdate$lock()

