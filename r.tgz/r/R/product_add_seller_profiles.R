#' Create a new ProductAddSellerProfiles
#'
#' @description
#' If the seller is subscribed to \"Business Policies\", use the seller_profiles instead of the shipping_details, payment_methods and return_accepted params.<hr><div style=\"font-style:normal\">Param structure:<div style=\"margin-left: 2%;\"><code style=\"padding:0; background-color:#ffffff;font-size:85%;font-family:monospace;\">seller_profiles[<b>shipping_profile_id</b>] = string</br>seller_profiles[<b>payment_profile_id</b>] = string</br>seller_profiles[<b>return_profile_id</b>] = string</br></code></div></div>
#'
#' @docType class
#' @title ProductAddSellerProfiles
#' @description ProductAddSellerProfiles Class
#' @format An \code{R6Class} generator object
#' @field shipping_profile_id  character [optional]
#' @field payment_profile_id  character [optional]
#' @field return_profile_id  character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductAddSellerProfiles <- R6::R6Class(
  "ProductAddSellerProfiles",
  public = list(
    `shipping_profile_id` = NULL,
    `payment_profile_id` = NULL,
    `return_profile_id` = NULL,

    #' @description
    #' Initialize a new ProductAddSellerProfiles class.
    #'
    #' @param shipping_profile_id shipping_profile_id
    #' @param payment_profile_id payment_profile_id
    #' @param return_profile_id return_profile_id
    #' @param ... Other optional arguments.
    initialize = function(`shipping_profile_id` = NULL, `payment_profile_id` = NULL, `return_profile_id` = NULL, ...) {
      if (!is.null(`shipping_profile_id`)) {
        if (!(is.character(`shipping_profile_id`) && length(`shipping_profile_id`) == 1)) {
          stop(paste("Error! Invalid data for `shipping_profile_id`. Must be a string:", `shipping_profile_id`))
        }
        self$`shipping_profile_id` <- `shipping_profile_id`
      }
      if (!is.null(`payment_profile_id`)) {
        if (!(is.character(`payment_profile_id`) && length(`payment_profile_id`) == 1)) {
          stop(paste("Error! Invalid data for `payment_profile_id`. Must be a string:", `payment_profile_id`))
        }
        self$`payment_profile_id` <- `payment_profile_id`
      }
      if (!is.null(`return_profile_id`)) {
        if (!(is.character(`return_profile_id`) && length(`return_profile_id`) == 1)) {
          stop(paste("Error! Invalid data for `return_profile_id`. Must be a string:", `return_profile_id`))
        }
        self$`return_profile_id` <- `return_profile_id`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductAddSellerProfiles as a base R list.
    #' @examples
    #' # convert array of ProductAddSellerProfiles (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductAddSellerProfiles to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductAddSellerProfilesObject <- list()
      if (!is.null(self$`shipping_profile_id`)) {
        ProductAddSellerProfilesObject[["shipping_profile_id"]] <-
          self$`shipping_profile_id`
      }
      if (!is.null(self$`payment_profile_id`)) {
        ProductAddSellerProfilesObject[["payment_profile_id"]] <-
          self$`payment_profile_id`
      }
      if (!is.null(self$`return_profile_id`)) {
        ProductAddSellerProfilesObject[["return_profile_id"]] <-
          self$`return_profile_id`
      }
      return(ProductAddSellerProfilesObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductAddSellerProfiles
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductAddSellerProfiles
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`shipping_profile_id`)) {
        self$`shipping_profile_id` <- this_object$`shipping_profile_id`
      }
      if (!is.null(this_object$`payment_profile_id`)) {
        self$`payment_profile_id` <- this_object$`payment_profile_id`
      }
      if (!is.null(this_object$`return_profile_id`)) {
        self$`return_profile_id` <- this_object$`return_profile_id`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductAddSellerProfiles in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductAddSellerProfiles
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductAddSellerProfiles
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`shipping_profile_id` <- this_object$`shipping_profile_id`
      self$`payment_profile_id` <- this_object$`payment_profile_id`
      self$`return_profile_id` <- this_object$`return_profile_id`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductAddSellerProfiles and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductAddSellerProfiles
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductAddSellerProfiles$unlock()
#
## Below is an example to define the print function
# ProductAddSellerProfiles$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductAddSellerProfiles$lock()

