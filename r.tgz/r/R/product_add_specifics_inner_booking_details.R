#' Create a new ProductAddSpecificsInnerBookingDetails
#'
#' @description
#' ProductAddSpecificsInnerBookingDetails Class
#'
#' @docType class
#' @title ProductAddSpecificsInnerBookingDetails
#' @description ProductAddSpecificsInnerBookingDetails Class
#' @format An \code{R6Class} generator object
#' @field location  character
#' @field type  character
#' @field session_duration  integer [optional]
#' @field session_gap  integer [optional]
#' @field sessions_count  integer
#' @field time_strict_value  numeric
#' @field time_strict_type  character
#' @field availabilities  list(\link{ProductAddSpecificsInnerBookingDetailsAvailabilitiesInner})
#' @field overrides  list(\link{ProductAddSpecificsInnerBookingDetailsOverridesInner}) [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductAddSpecificsInnerBookingDetails <- R6::R6Class(
  "ProductAddSpecificsInnerBookingDetails",
  public = list(
    `location` = NULL,
    `type` = NULL,
    `session_duration` = NULL,
    `session_gap` = NULL,
    `sessions_count` = NULL,
    `time_strict_value` = NULL,
    `time_strict_type` = NULL,
    `availabilities` = NULL,
    `overrides` = NULL,

    #' @description
    #' Initialize a new ProductAddSpecificsInnerBookingDetails class.
    #'
    #' @param location location
    #' @param type type
    #' @param sessions_count sessions_count
    #' @param time_strict_value time_strict_value
    #' @param time_strict_type time_strict_type
    #' @param availabilities availabilities
    #' @param session_duration session_duration
    #' @param session_gap session_gap
    #' @param overrides overrides
    #' @param ... Other optional arguments.
    initialize = function(`location`, `type`, `sessions_count`, `time_strict_value`, `time_strict_type`, `availabilities`, `session_duration` = NULL, `session_gap` = NULL, `overrides` = NULL, ...) {
      if (!missing(`location`)) {
        if (!(is.character(`location`) && length(`location`) == 1)) {
          stop(paste("Error! Invalid data for `location`. Must be a string:", `location`))
        }
        self$`location` <- `location`
      }
      if (!missing(`type`)) {
        if (!(`type` %in% c("date", "date_time"))) {
          stop(paste("Error! \"", `type`, "\" cannot be assigned to `type`. Must be \"date\", \"date_time\".", sep = ""))
        }
        if (!(is.character(`type`) && length(`type`) == 1)) {
          stop(paste("Error! Invalid data for `type`. Must be a string:", `type`))
        }
        self$`type` <- `type`
      }
      if (!missing(`sessions_count`)) {
        if (!(is.numeric(`sessions_count`) && length(`sessions_count`) == 1)) {
          stop(paste("Error! Invalid data for `sessions_count`. Must be an integer:", `sessions_count`))
        }
        self$`sessions_count` <- `sessions_count`
      }
      if (!missing(`time_strict_value`)) {
        self$`time_strict_value` <- `time_strict_value`
      }
      if (!missing(`time_strict_type`)) {
        if (!(`time_strict_type` %in% c("days", "hours", "minutes"))) {
          stop(paste("Error! \"", `time_strict_type`, "\" cannot be assigned to `time_strict_type`. Must be \"days\", \"hours\", \"minutes\".", sep = ""))
        }
        if (!(is.character(`time_strict_type`) && length(`time_strict_type`) == 1)) {
          stop(paste("Error! Invalid data for `time_strict_type`. Must be a string:", `time_strict_type`))
        }
        self$`time_strict_type` <- `time_strict_type`
      }
      if (!missing(`availabilities`)) {
        stopifnot(is.vector(`availabilities`), length(`availabilities`) != 0)
        sapply(`availabilities`, function(x) stopifnot(R6::is.R6(x)))
        self$`availabilities` <- `availabilities`
      }
      if (!is.null(`session_duration`)) {
        if (!(is.numeric(`session_duration`) && length(`session_duration`) == 1)) {
          stop(paste("Error! Invalid data for `session_duration`. Must be an integer:", `session_duration`))
        }
        self$`session_duration` <- `session_duration`
      }
      if (!is.null(`session_gap`)) {
        if (!(is.numeric(`session_gap`) && length(`session_gap`) == 1)) {
          stop(paste("Error! Invalid data for `session_gap`. Must be an integer:", `session_gap`))
        }
        self$`session_gap` <- `session_gap`
      }
      if (!is.null(`overrides`)) {
        stopifnot(is.vector(`overrides`), length(`overrides`) != 0)
        sapply(`overrides`, function(x) stopifnot(R6::is.R6(x)))
        self$`overrides` <- `overrides`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductAddSpecificsInnerBookingDetails as a base R list.
    #' @examples
    #' # convert array of ProductAddSpecificsInnerBookingDetails (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductAddSpecificsInnerBookingDetails to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductAddSpecificsInnerBookingDetailsObject <- list()
      if (!is.null(self$`location`)) {
        ProductAddSpecificsInnerBookingDetailsObject[["location"]] <-
          self$`location`
      }
      if (!is.null(self$`type`)) {
        ProductAddSpecificsInnerBookingDetailsObject[["type"]] <-
          self$`type`
      }
      if (!is.null(self$`session_duration`)) {
        ProductAddSpecificsInnerBookingDetailsObject[["session_duration"]] <-
          self$`session_duration`
      }
      if (!is.null(self$`session_gap`)) {
        ProductAddSpecificsInnerBookingDetailsObject[["session_gap"]] <-
          self$`session_gap`
      }
      if (!is.null(self$`sessions_count`)) {
        ProductAddSpecificsInnerBookingDetailsObject[["sessions_count"]] <-
          self$`sessions_count`
      }
      if (!is.null(self$`time_strict_value`)) {
        ProductAddSpecificsInnerBookingDetailsObject[["time_strict_value"]] <-
          self$`time_strict_value`
      }
      if (!is.null(self$`time_strict_type`)) {
        ProductAddSpecificsInnerBookingDetailsObject[["time_strict_type"]] <-
          self$`time_strict_type`
      }
      if (!is.null(self$`availabilities`)) {
        ProductAddSpecificsInnerBookingDetailsObject[["availabilities"]] <-
          lapply(self$`availabilities`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`overrides`)) {
        ProductAddSpecificsInnerBookingDetailsObject[["overrides"]] <-
          lapply(self$`overrides`, function(x) x$toSimpleType())
      }
      return(ProductAddSpecificsInnerBookingDetailsObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductAddSpecificsInnerBookingDetails
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductAddSpecificsInnerBookingDetails
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`location`)) {
        self$`location` <- this_object$`location`
      }
      if (!is.null(this_object$`type`)) {
        if (!is.null(this_object$`type`) && !(this_object$`type` %in% c("date", "date_time"))) {
          stop(paste("Error! \"", this_object$`type`, "\" cannot be assigned to `type`. Must be \"date\", \"date_time\".", sep = ""))
        }
        self$`type` <- this_object$`type`
      }
      if (!is.null(this_object$`session_duration`)) {
        self$`session_duration` <- this_object$`session_duration`
      }
      if (!is.null(this_object$`session_gap`)) {
        self$`session_gap` <- this_object$`session_gap`
      }
      if (!is.null(this_object$`sessions_count`)) {
        self$`sessions_count` <- this_object$`sessions_count`
      }
      if (!is.null(this_object$`time_strict_value`)) {
        self$`time_strict_value` <- this_object$`time_strict_value`
      }
      if (!is.null(this_object$`time_strict_type`)) {
        if (!is.null(this_object$`time_strict_type`) && !(this_object$`time_strict_type` %in% c("days", "hours", "minutes"))) {
          stop(paste("Error! \"", this_object$`time_strict_type`, "\" cannot be assigned to `time_strict_type`. Must be \"days\", \"hours\", \"minutes\".", sep = ""))
        }
        self$`time_strict_type` <- this_object$`time_strict_type`
      }
      if (!is.null(this_object$`availabilities`)) {
        self$`availabilities` <- ApiClient$new()$deserializeObj(this_object$`availabilities`, "array[ProductAddSpecificsInnerBookingDetailsAvailabilitiesInner]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`overrides`)) {
        self$`overrides` <- ApiClient$new()$deserializeObj(this_object$`overrides`, "array[ProductAddSpecificsInnerBookingDetailsOverridesInner]", loadNamespace("openapi"))
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductAddSpecificsInnerBookingDetails in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductAddSpecificsInnerBookingDetails
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductAddSpecificsInnerBookingDetails
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`location` <- this_object$`location`
      if (!is.null(this_object$`type`) && !(this_object$`type` %in% c("date", "date_time"))) {
        stop(paste("Error! \"", this_object$`type`, "\" cannot be assigned to `type`. Must be \"date\", \"date_time\".", sep = ""))
      }
      self$`type` <- this_object$`type`
      self$`session_duration` <- this_object$`session_duration`
      self$`session_gap` <- this_object$`session_gap`
      self$`sessions_count` <- this_object$`sessions_count`
      self$`time_strict_value` <- this_object$`time_strict_value`
      if (!is.null(this_object$`time_strict_type`) && !(this_object$`time_strict_type` %in% c("days", "hours", "minutes"))) {
        stop(paste("Error! \"", this_object$`time_strict_type`, "\" cannot be assigned to `time_strict_type`. Must be \"days\", \"hours\", \"minutes\".", sep = ""))
      }
      self$`time_strict_type` <- this_object$`time_strict_type`
      self$`availabilities` <- ApiClient$new()$deserializeObj(this_object$`availabilities`, "array[ProductAddSpecificsInnerBookingDetailsAvailabilitiesInner]", loadNamespace("openapi"))
      self$`overrides` <- ApiClient$new()$deserializeObj(this_object$`overrides`, "array[ProductAddSpecificsInnerBookingDetailsOverridesInner]", loadNamespace("openapi"))
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductAddSpecificsInnerBookingDetails and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
      # check the required field `location`
      if (!is.null(input_json$`location`)) {
        if (!(is.character(input_json$`location`) && length(input_json$`location`) == 1)) {
          stop(paste("Error! Invalid data for `location`. Must be a string:", input_json$`location`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for ProductAddSpecificsInnerBookingDetails: the required field `location` is missing."))
      }
      # check the required field `type`
      if (!is.null(input_json$`type`)) {
        if (!(is.character(input_json$`type`) && length(input_json$`type`) == 1)) {
          stop(paste("Error! Invalid data for `type`. Must be a string:", input_json$`type`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for ProductAddSpecificsInnerBookingDetails: the required field `type` is missing."))
      }
      # check the required field `sessions_count`
      if (!is.null(input_json$`sessions_count`)) {
        if (!(is.numeric(input_json$`sessions_count`) && length(input_json$`sessions_count`) == 1)) {
          stop(paste("Error! Invalid data for `sessions_count`. Must be an integer:", input_json$`sessions_count`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for ProductAddSpecificsInnerBookingDetails: the required field `sessions_count` is missing."))
      }
      # check the required field `time_strict_value`
      if (!is.null(input_json$`time_strict_value`)) {
      } else {
        stop(paste("The JSON input `", input, "` is invalid for ProductAddSpecificsInnerBookingDetails: the required field `time_strict_value` is missing."))
      }
      # check the required field `time_strict_type`
      if (!is.null(input_json$`time_strict_type`)) {
        if (!(is.character(input_json$`time_strict_type`) && length(input_json$`time_strict_type`) == 1)) {
          stop(paste("Error! Invalid data for `time_strict_type`. Must be a string:", input_json$`time_strict_type`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for ProductAddSpecificsInnerBookingDetails: the required field `time_strict_type` is missing."))
      }
      # check the required field `availabilities`
      if (!is.null(input_json$`availabilities`)) {
        stopifnot(is.vector(input_json$`availabilities`), length(input_json$`availabilities`) != 0)
        tmp <- sapply(input_json$`availabilities`, function(x) stopifnot(R6::is.R6(x)))
      } else {
        stop(paste("The JSON input `", input, "` is invalid for ProductAddSpecificsInnerBookingDetails: the required field `availabilities` is missing."))
      }
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductAddSpecificsInnerBookingDetails
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      # check if the required `location` is null
      if (is.null(self$`location`)) {
        return(FALSE)
      }

      if (nchar(self$`location`) < 1) {
        return(FALSE)
      }

      # check if the required `type` is null
      if (is.null(self$`type`)) {
        return(FALSE)
      }

      # check if the required `sessions_count` is null
      if (is.null(self$`sessions_count`)) {
        return(FALSE)
      }

      # check if the required `time_strict_value` is null
      if (is.null(self$`time_strict_value`)) {
        return(FALSE)
      }

      # check if the required `time_strict_type` is null
      if (is.null(self$`time_strict_type`)) {
        return(FALSE)
      }

      # check if the required `availabilities` is null
      if (is.null(self$`availabilities`)) {
        return(FALSE)
      }

      if (length(self$`availabilities`) < 1) {
        return(FALSE)
      }

      if (length(self$`overrides`) < 1) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      # check if the required `location` is null
      if (is.null(self$`location`)) {
        invalid_fields["location"] <- "Non-nullable required field `location` cannot be null."
      }

      if (nchar(self$`location`) < 1) {
        invalid_fields["location"] <- "Invalid length for `location`, must be bigger than or equal to 1."
      }

      # check if the required `type` is null
      if (is.null(self$`type`)) {
        invalid_fields["type"] <- "Non-nullable required field `type` cannot be null."
      }

      # check if the required `sessions_count` is null
      if (is.null(self$`sessions_count`)) {
        invalid_fields["sessions_count"] <- "Non-nullable required field `sessions_count` cannot be null."
      }

      # check if the required `time_strict_value` is null
      if (is.null(self$`time_strict_value`)) {
        invalid_fields["time_strict_value"] <- "Non-nullable required field `time_strict_value` cannot be null."
      }

      # check if the required `time_strict_type` is null
      if (is.null(self$`time_strict_type`)) {
        invalid_fields["time_strict_type"] <- "Non-nullable required field `time_strict_type` cannot be null."
      }

      # check if the required `availabilities` is null
      if (is.null(self$`availabilities`)) {
        invalid_fields["availabilities"] <- "Non-nullable required field `availabilities` cannot be null."
      }

      if (length(self$`availabilities`) < 1) {
        invalid_fields["availabilities"] <- "Invalid length for ``, number of items must be greater than or equal to 1."
      }

      if (length(self$`overrides`) < 1) {
        invalid_fields["overrides"] <- "Invalid length for ``, number of items must be greater than or equal to 1."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductAddSpecificsInnerBookingDetails$unlock()
#
## Below is an example to define the print function
# ProductAddSpecificsInnerBookingDetails$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductAddSpecificsInnerBookingDetails$lock()

