#' Create a new ReturnCount200ResponseResult
#'
#' @description
#' ReturnCount200ResponseResult Class
#'
#' @docType class
#' @title ReturnCount200ResponseResult
#' @description ReturnCount200ResponseResult Class
#' @format An \code{R6Class} generator object
#' @field returns_count  integer [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ReturnCount200ResponseResult <- R6::R6Class(
  "ReturnCount200ResponseResult",
  public = list(
    `returns_count` = NULL,

    #' @description
    #' Initialize a new ReturnCount200ResponseResult class.
    #'
    #' @param returns_count returns_count
    #' @param ... Other optional arguments.
    initialize = function(`returns_count` = NULL, ...) {
      if (!is.null(`returns_count`)) {
        if (!(is.numeric(`returns_count`) && length(`returns_count`) == 1)) {
          stop(paste("Error! Invalid data for `returns_count`. Must be an integer:", `returns_count`))
        }
        self$`returns_count` <- `returns_count`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ReturnCount200ResponseResult as a base R list.
    #' @examples
    #' # convert array of ReturnCount200ResponseResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ReturnCount200ResponseResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ReturnCount200ResponseResultObject <- list()
      if (!is.null(self$`returns_count`)) {
        ReturnCount200ResponseResultObject[["returns_count"]] <-
          self$`returns_count`
      }
      return(ReturnCount200ResponseResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ReturnCount200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ReturnCount200ResponseResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`returns_count`)) {
        self$`returns_count` <- this_object$`returns_count`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ReturnCount200ResponseResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ReturnCount200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ReturnCount200ResponseResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`returns_count` <- this_object$`returns_count`
      self
    },

    #' @description
    #' Validate JSON input with respect to ReturnCount200ResponseResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ReturnCount200ResponseResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ReturnCount200ResponseResult$unlock()
#
## Below is an example to define the print function
# ReturnCount200ResponseResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ReturnCount200ResponseResult$lock()

