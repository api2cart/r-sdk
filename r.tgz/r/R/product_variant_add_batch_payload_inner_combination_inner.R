#' Create a new ProductVariantAddBatchPayloadInnerCombinationInner
#'
#' @description
#' ProductVariantAddBatchPayloadInnerCombinationInner Class
#'
#' @docType class
#' @title ProductVariantAddBatchPayloadInnerCombinationInner
#' @description ProductVariantAddBatchPayloadInnerCombinationInner Class
#' @format An \code{R6Class} generator object
#' @field option_name  character
#' @field option_value_name  character
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductVariantAddBatchPayloadInnerCombinationInner <- R6::R6Class(
  "ProductVariantAddBatchPayloadInnerCombinationInner",
  public = list(
    `option_name` = NULL,
    `option_value_name` = NULL,

    #' @description
    #' Initialize a new ProductVariantAddBatchPayloadInnerCombinationInner class.
    #'
    #' @param option_name option_name
    #' @param option_value_name option_value_name
    #' @param ... Other optional arguments.
    initialize = function(`option_name`, `option_value_name`, ...) {
      if (!missing(`option_name`)) {
        if (!(is.character(`option_name`) && length(`option_name`) == 1)) {
          stop(paste("Error! Invalid data for `option_name`. Must be a string:", `option_name`))
        }
        self$`option_name` <- `option_name`
      }
      if (!missing(`option_value_name`)) {
        if (!(is.character(`option_value_name`) && length(`option_value_name`) == 1)) {
          stop(paste("Error! Invalid data for `option_value_name`. Must be a string:", `option_value_name`))
        }
        self$`option_value_name` <- `option_value_name`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductVariantAddBatchPayloadInnerCombinationInner as a base R list.
    #' @examples
    #' # convert array of ProductVariantAddBatchPayloadInnerCombinationInner (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductVariantAddBatchPayloadInnerCombinationInner to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductVariantAddBatchPayloadInnerCombinationInnerObject <- list()
      if (!is.null(self$`option_name`)) {
        ProductVariantAddBatchPayloadInnerCombinationInnerObject[["option_name"]] <-
          self$`option_name`
      }
      if (!is.null(self$`option_value_name`)) {
        ProductVariantAddBatchPayloadInnerCombinationInnerObject[["option_value_name"]] <-
          self$`option_value_name`
      }
      return(ProductVariantAddBatchPayloadInnerCombinationInnerObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductVariantAddBatchPayloadInnerCombinationInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductVariantAddBatchPayloadInnerCombinationInner
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`option_name`)) {
        self$`option_name` <- this_object$`option_name`
      }
      if (!is.null(this_object$`option_value_name`)) {
        self$`option_value_name` <- this_object$`option_value_name`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductVariantAddBatchPayloadInnerCombinationInner in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductVariantAddBatchPayloadInnerCombinationInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductVariantAddBatchPayloadInnerCombinationInner
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`option_name` <- this_object$`option_name`
      self$`option_value_name` <- this_object$`option_value_name`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductVariantAddBatchPayloadInnerCombinationInner and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
      # check the required field `option_name`
      if (!is.null(input_json$`option_name`)) {
        if (!(is.character(input_json$`option_name`) && length(input_json$`option_name`) == 1)) {
          stop(paste("Error! Invalid data for `option_name`. Must be a string:", input_json$`option_name`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for ProductVariantAddBatchPayloadInnerCombinationInner: the required field `option_name` is missing."))
      }
      # check the required field `option_value_name`
      if (!is.null(input_json$`option_value_name`)) {
        if (!(is.character(input_json$`option_value_name`) && length(input_json$`option_value_name`) == 1)) {
          stop(paste("Error! Invalid data for `option_value_name`. Must be a string:", input_json$`option_value_name`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for ProductVariantAddBatchPayloadInnerCombinationInner: the required field `option_value_name` is missing."))
      }
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductVariantAddBatchPayloadInnerCombinationInner
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      # check if the required `option_name` is null
      if (is.null(self$`option_name`)) {
        return(FALSE)
      }

      # check if the required `option_value_name` is null
      if (is.null(self$`option_value_name`)) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      # check if the required `option_name` is null
      if (is.null(self$`option_name`)) {
        invalid_fields["option_name"] <- "Non-nullable required field `option_name` cannot be null."
      }

      # check if the required `option_value_name` is null
      if (is.null(self$`option_value_name`)) {
        invalid_fields["option_value_name"] <- "Non-nullable required field `option_value_name` cannot be null."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductVariantAddBatchPayloadInnerCombinationInner$unlock()
#
## Below is an example to define the print function
# ProductVariantAddBatchPayloadInnerCombinationInner$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductVariantAddBatchPayloadInnerCombinationInner$lock()

