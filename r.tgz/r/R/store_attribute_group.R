#' Create a new StoreAttributeGroup
#'
#' @description
#' StoreAttributeGroup Class
#'
#' @docType class
#' @title StoreAttributeGroup
#' @description StoreAttributeGroup Class
#' @format An \code{R6Class} generator object
#' @field id  character [optional]
#' @field name  character [optional]
#' @field position  integer [optional]
#' @field attribute_set_id  character [optional]
#' @field assigned_attribute_ids  list(character) [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
StoreAttributeGroup <- R6::R6Class(
  "StoreAttributeGroup",
  public = list(
    `id` = NULL,
    `name` = NULL,
    `position` = NULL,
    `attribute_set_id` = NULL,
    `assigned_attribute_ids` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new StoreAttributeGroup class.
    #'
    #' @param id id
    #' @param name name
    #' @param position position
    #' @param attribute_set_id attribute_set_id
    #' @param assigned_attribute_ids assigned_attribute_ids
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `name` = NULL, `position` = NULL, `attribute_set_id` = NULL, `assigned_attribute_ids` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`position`)) {
        if (!(is.numeric(`position`) && length(`position`) == 1)) {
          stop(paste("Error! Invalid data for `position`. Must be an integer:", `position`))
        }
        self$`position` <- `position`
      }
      if (!is.null(`attribute_set_id`)) {
        if (!(is.character(`attribute_set_id`) && length(`attribute_set_id`) == 1)) {
          stop(paste("Error! Invalid data for `attribute_set_id`. Must be a string:", `attribute_set_id`))
        }
        self$`attribute_set_id` <- `attribute_set_id`
      }
      if (!is.null(`assigned_attribute_ids`)) {
        stopifnot(is.vector(`assigned_attribute_ids`), length(`assigned_attribute_ids`) != 0)
        sapply(`assigned_attribute_ids`, function(x) stopifnot(is.character(x)))
        self$`assigned_attribute_ids` <- `assigned_attribute_ids`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return StoreAttributeGroup as a base R list.
    #' @examples
    #' # convert array of StoreAttributeGroup (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert StoreAttributeGroup to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      StoreAttributeGroupObject <- list()
      if (!is.null(self$`id`)) {
        StoreAttributeGroupObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`name`)) {
        StoreAttributeGroupObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`position`)) {
        StoreAttributeGroupObject[["position"]] <-
          self$`position`
      }
      if (!is.null(self$`attribute_set_id`)) {
        StoreAttributeGroupObject[["attribute_set_id"]] <-
          self$`attribute_set_id`
      }
      if (!is.null(self$`assigned_attribute_ids`)) {
        StoreAttributeGroupObject[["assigned_attribute_ids"]] <-
          self$`assigned_attribute_ids`
      }
      if (!is.null(self$`additional_fields`)) {
        StoreAttributeGroupObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        StoreAttributeGroupObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(StoreAttributeGroupObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of StoreAttributeGroup
    #'
    #' @param input_json the JSON input
    #' @return the instance of StoreAttributeGroup
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`position`)) {
        self$`position` <- this_object$`position`
      }
      if (!is.null(this_object$`attribute_set_id`)) {
        self$`attribute_set_id` <- this_object$`attribute_set_id`
      }
      if (!is.null(this_object$`assigned_attribute_ids`)) {
        self$`assigned_attribute_ids` <- ApiClient$new()$deserializeObj(this_object$`assigned_attribute_ids`, "array[character]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return StoreAttributeGroup in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of StoreAttributeGroup
    #'
    #' @param input_json the JSON input
    #' @return the instance of StoreAttributeGroup
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`name` <- this_object$`name`
      self$`position` <- this_object$`position`
      self$`attribute_set_id` <- this_object$`attribute_set_id`
      self$`assigned_attribute_ids` <- ApiClient$new()$deserializeObj(this_object$`assigned_attribute_ids`, "array[character]", loadNamespace("openapi"))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to StoreAttributeGroup and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of StoreAttributeGroup
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# StoreAttributeGroup$unlock()
#
## Below is an example to define the print function
# StoreAttributeGroup$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# StoreAttributeGroup$lock()

