#' Create a new CartStoreInfo
#'
#' @description
#' CartStoreInfo Class
#'
#' @docType class
#' @title CartStoreInfo
#' @description CartStoreInfo Class
#' @format An \code{R6Class} generator object
#' @field store_id  character [optional]
#' @field name  character [optional]
#' @field language  character [optional]
#' @field store_languages  list(\link{Language}) [optional]
#' @field currency  \link{Currency} [optional]
#' @field store_currencies  list(\link{Currency}) [optional]
#' @field timezone  character [optional]
#' @field country  character [optional]
#' @field root_category_id  character [optional]
#' @field multi_store_url  character [optional]
#' @field active  character [optional]
#' @field weight_unit  character [optional]
#' @field dimension_unit  character [optional]
#' @field prices_include_tax  character [optional]
#' @field carrier_info  list(\link{Carrier}) [optional]
#' @field store_owner_info  \link{Info} [optional]
#' @field default_warehouse_id  character [optional]
#' @field channels  list(\link{CartChannel}) [optional]
#' @field pickup_locations  list(\link{CartPickupLocation}) [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
CartStoreInfo <- R6::R6Class(
  "CartStoreInfo",
  public = list(
    `store_id` = NULL,
    `name` = NULL,
    `language` = NULL,
    `store_languages` = NULL,
    `currency` = NULL,
    `store_currencies` = NULL,
    `timezone` = NULL,
    `country` = NULL,
    `root_category_id` = NULL,
    `multi_store_url` = NULL,
    `active` = NULL,
    `weight_unit` = NULL,
    `dimension_unit` = NULL,
    `prices_include_tax` = NULL,
    `carrier_info` = NULL,
    `store_owner_info` = NULL,
    `default_warehouse_id` = NULL,
    `channels` = NULL,
    `pickup_locations` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new CartStoreInfo class.
    #'
    #' @param store_id store_id
    #' @param name name
    #' @param language language
    #' @param store_languages store_languages
    #' @param currency currency
    #' @param store_currencies store_currencies
    #' @param timezone timezone
    #' @param country country
    #' @param root_category_id root_category_id
    #' @param multi_store_url multi_store_url
    #' @param active active
    #' @param weight_unit weight_unit
    #' @param dimension_unit dimension_unit
    #' @param prices_include_tax prices_include_tax
    #' @param carrier_info carrier_info
    #' @param store_owner_info store_owner_info
    #' @param default_warehouse_id default_warehouse_id
    #' @param channels channels
    #' @param pickup_locations pickup_locations
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`store_id` = NULL, `name` = NULL, `language` = NULL, `store_languages` = NULL, `currency` = NULL, `store_currencies` = NULL, `timezone` = NULL, `country` = NULL, `root_category_id` = NULL, `multi_store_url` = NULL, `active` = NULL, `weight_unit` = NULL, `dimension_unit` = NULL, `prices_include_tax` = NULL, `carrier_info` = NULL, `store_owner_info` = NULL, `default_warehouse_id` = NULL, `channels` = NULL, `pickup_locations` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`store_id`)) {
        if (!(is.character(`store_id`) && length(`store_id`) == 1)) {
          stop(paste("Error! Invalid data for `store_id`. Must be a string:", `store_id`))
        }
        self$`store_id` <- `store_id`
      }
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`language`)) {
        if (!(is.character(`language`) && length(`language`) == 1)) {
          stop(paste("Error! Invalid data for `language`. Must be a string:", `language`))
        }
        self$`language` <- `language`
      }
      if (!is.null(`store_languages`)) {
        stopifnot(is.vector(`store_languages`), length(`store_languages`) != 0)
        sapply(`store_languages`, function(x) stopifnot(R6::is.R6(x)))
        self$`store_languages` <- `store_languages`
      }
      if (!is.null(`currency`)) {
        stopifnot(R6::is.R6(`currency`))
        self$`currency` <- `currency`
      }
      if (!is.null(`store_currencies`)) {
        stopifnot(is.vector(`store_currencies`), length(`store_currencies`) != 0)
        sapply(`store_currencies`, function(x) stopifnot(R6::is.R6(x)))
        self$`store_currencies` <- `store_currencies`
      }
      if (!is.null(`timezone`)) {
        if (!(is.character(`timezone`) && length(`timezone`) == 1)) {
          stop(paste("Error! Invalid data for `timezone`. Must be a string:", `timezone`))
        }
        self$`timezone` <- `timezone`
      }
      if (!is.null(`country`)) {
        if (!(is.character(`country`) && length(`country`) == 1)) {
          stop(paste("Error! Invalid data for `country`. Must be a string:", `country`))
        }
        self$`country` <- `country`
      }
      if (!is.null(`root_category_id`)) {
        if (!(is.character(`root_category_id`) && length(`root_category_id`) == 1)) {
          stop(paste("Error! Invalid data for `root_category_id`. Must be a string:", `root_category_id`))
        }
        self$`root_category_id` <- `root_category_id`
      }
      if (!is.null(`multi_store_url`)) {
        if (!(is.character(`multi_store_url`) && length(`multi_store_url`) == 1)) {
          stop(paste("Error! Invalid data for `multi_store_url`. Must be a string:", `multi_store_url`))
        }
        self$`multi_store_url` <- `multi_store_url`
      }
      if (!is.null(`active`)) {
        if (!(is.logical(`active`) && length(`active`) == 1)) {
          stop(paste("Error! Invalid data for `active`. Must be a boolean:", `active`))
        }
        self$`active` <- `active`
      }
      if (!is.null(`weight_unit`)) {
        if (!(is.character(`weight_unit`) && length(`weight_unit`) == 1)) {
          stop(paste("Error! Invalid data for `weight_unit`. Must be a string:", `weight_unit`))
        }
        self$`weight_unit` <- `weight_unit`
      }
      if (!is.null(`dimension_unit`)) {
        if (!(is.character(`dimension_unit`) && length(`dimension_unit`) == 1)) {
          stop(paste("Error! Invalid data for `dimension_unit`. Must be a string:", `dimension_unit`))
        }
        self$`dimension_unit` <- `dimension_unit`
      }
      if (!is.null(`prices_include_tax`)) {
        if (!(is.logical(`prices_include_tax`) && length(`prices_include_tax`) == 1)) {
          stop(paste("Error! Invalid data for `prices_include_tax`. Must be a boolean:", `prices_include_tax`))
        }
        self$`prices_include_tax` <- `prices_include_tax`
      }
      if (!is.null(`carrier_info`)) {
        stopifnot(is.vector(`carrier_info`), length(`carrier_info`) != 0)
        sapply(`carrier_info`, function(x) stopifnot(R6::is.R6(x)))
        self$`carrier_info` <- `carrier_info`
      }
      if (!is.null(`store_owner_info`)) {
        stopifnot(R6::is.R6(`store_owner_info`))
        self$`store_owner_info` <- `store_owner_info`
      }
      if (!is.null(`default_warehouse_id`)) {
        if (!(is.character(`default_warehouse_id`) && length(`default_warehouse_id`) == 1)) {
          stop(paste("Error! Invalid data for `default_warehouse_id`. Must be a string:", `default_warehouse_id`))
        }
        self$`default_warehouse_id` <- `default_warehouse_id`
      }
      if (!is.null(`channels`)) {
        stopifnot(is.vector(`channels`), length(`channels`) != 0)
        sapply(`channels`, function(x) stopifnot(R6::is.R6(x)))
        self$`channels` <- `channels`
      }
      if (!is.null(`pickup_locations`)) {
        stopifnot(is.vector(`pickup_locations`), length(`pickup_locations`) != 0)
        sapply(`pickup_locations`, function(x) stopifnot(R6::is.R6(x)))
        self$`pickup_locations` <- `pickup_locations`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return CartStoreInfo as a base R list.
    #' @examples
    #' # convert array of CartStoreInfo (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert CartStoreInfo to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      CartStoreInfoObject <- list()
      if (!is.null(self$`store_id`)) {
        CartStoreInfoObject[["store_id"]] <-
          self$`store_id`
      }
      if (!is.null(self$`name`)) {
        CartStoreInfoObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`language`)) {
        CartStoreInfoObject[["language"]] <-
          self$`language`
      }
      if (!is.null(self$`store_languages`)) {
        CartStoreInfoObject[["store_languages"]] <-
          lapply(self$`store_languages`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`currency`)) {
        CartStoreInfoObject[["currency"]] <-
          self$`currency`$toSimpleType()
      }
      if (!is.null(self$`store_currencies`)) {
        CartStoreInfoObject[["store_currencies"]] <-
          lapply(self$`store_currencies`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`timezone`)) {
        CartStoreInfoObject[["timezone"]] <-
          self$`timezone`
      }
      if (!is.null(self$`country`)) {
        CartStoreInfoObject[["country"]] <-
          self$`country`
      }
      if (!is.null(self$`root_category_id`)) {
        CartStoreInfoObject[["root_category_id"]] <-
          self$`root_category_id`
      }
      if (!is.null(self$`multi_store_url`)) {
        CartStoreInfoObject[["multi_store_url"]] <-
          self$`multi_store_url`
      }
      if (!is.null(self$`active`)) {
        CartStoreInfoObject[["active"]] <-
          self$`active`
      }
      if (!is.null(self$`weight_unit`)) {
        CartStoreInfoObject[["weight_unit"]] <-
          self$`weight_unit`
      }
      if (!is.null(self$`dimension_unit`)) {
        CartStoreInfoObject[["dimension_unit"]] <-
          self$`dimension_unit`
      }
      if (!is.null(self$`prices_include_tax`)) {
        CartStoreInfoObject[["prices_include_tax"]] <-
          self$`prices_include_tax`
      }
      if (!is.null(self$`carrier_info`)) {
        CartStoreInfoObject[["carrier_info"]] <-
          lapply(self$`carrier_info`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`store_owner_info`)) {
        CartStoreInfoObject[["store_owner_info"]] <-
          self$`store_owner_info`$toSimpleType()
      }
      if (!is.null(self$`default_warehouse_id`)) {
        CartStoreInfoObject[["default_warehouse_id"]] <-
          self$`default_warehouse_id`
      }
      if (!is.null(self$`channels`)) {
        CartStoreInfoObject[["channels"]] <-
          lapply(self$`channels`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`pickup_locations`)) {
        CartStoreInfoObject[["pickup_locations"]] <-
          lapply(self$`pickup_locations`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`additional_fields`)) {
        CartStoreInfoObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        CartStoreInfoObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(CartStoreInfoObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of CartStoreInfo
    #'
    #' @param input_json the JSON input
    #' @return the instance of CartStoreInfo
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`store_id`)) {
        self$`store_id` <- this_object$`store_id`
      }
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`language`)) {
        self$`language` <- this_object$`language`
      }
      if (!is.null(this_object$`store_languages`)) {
        self$`store_languages` <- ApiClient$new()$deserializeObj(this_object$`store_languages`, "array[Language]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`currency`)) {
        `currency_object` <- Currency$new()
        `currency_object`$fromJSON(jsonlite::toJSON(this_object$`currency`, auto_unbox = TRUE, digits = NA))
        self$`currency` <- `currency_object`
      }
      if (!is.null(this_object$`store_currencies`)) {
        self$`store_currencies` <- ApiClient$new()$deserializeObj(this_object$`store_currencies`, "array[Currency]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`timezone`)) {
        self$`timezone` <- this_object$`timezone`
      }
      if (!is.null(this_object$`country`)) {
        self$`country` <- this_object$`country`
      }
      if (!is.null(this_object$`root_category_id`)) {
        self$`root_category_id` <- this_object$`root_category_id`
      }
      if (!is.null(this_object$`multi_store_url`)) {
        self$`multi_store_url` <- this_object$`multi_store_url`
      }
      if (!is.null(this_object$`active`)) {
        self$`active` <- this_object$`active`
      }
      if (!is.null(this_object$`weight_unit`)) {
        self$`weight_unit` <- this_object$`weight_unit`
      }
      if (!is.null(this_object$`dimension_unit`)) {
        self$`dimension_unit` <- this_object$`dimension_unit`
      }
      if (!is.null(this_object$`prices_include_tax`)) {
        self$`prices_include_tax` <- this_object$`prices_include_tax`
      }
      if (!is.null(this_object$`carrier_info`)) {
        self$`carrier_info` <- ApiClient$new()$deserializeObj(this_object$`carrier_info`, "array[Carrier]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`store_owner_info`)) {
        `store_owner_info_object` <- Info$new()
        `store_owner_info_object`$fromJSON(jsonlite::toJSON(this_object$`store_owner_info`, auto_unbox = TRUE, digits = NA))
        self$`store_owner_info` <- `store_owner_info_object`
      }
      if (!is.null(this_object$`default_warehouse_id`)) {
        self$`default_warehouse_id` <- this_object$`default_warehouse_id`
      }
      if (!is.null(this_object$`channels`)) {
        self$`channels` <- ApiClient$new()$deserializeObj(this_object$`channels`, "array[CartChannel]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`pickup_locations`)) {
        self$`pickup_locations` <- ApiClient$new()$deserializeObj(this_object$`pickup_locations`, "array[CartPickupLocation]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return CartStoreInfo in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of CartStoreInfo
    #'
    #' @param input_json the JSON input
    #' @return the instance of CartStoreInfo
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`store_id` <- this_object$`store_id`
      self$`name` <- this_object$`name`
      self$`language` <- this_object$`language`
      self$`store_languages` <- ApiClient$new()$deserializeObj(this_object$`store_languages`, "array[Language]", loadNamespace("openapi"))
      self$`currency` <- Currency$new()$fromJSON(jsonlite::toJSON(this_object$`currency`, auto_unbox = TRUE, digits = NA))
      self$`store_currencies` <- ApiClient$new()$deserializeObj(this_object$`store_currencies`, "array[Currency]", loadNamespace("openapi"))
      self$`timezone` <- this_object$`timezone`
      self$`country` <- this_object$`country`
      self$`root_category_id` <- this_object$`root_category_id`
      self$`multi_store_url` <- this_object$`multi_store_url`
      self$`active` <- this_object$`active`
      self$`weight_unit` <- this_object$`weight_unit`
      self$`dimension_unit` <- this_object$`dimension_unit`
      self$`prices_include_tax` <- this_object$`prices_include_tax`
      self$`carrier_info` <- ApiClient$new()$deserializeObj(this_object$`carrier_info`, "array[Carrier]", loadNamespace("openapi"))
      self$`store_owner_info` <- Info$new()$fromJSON(jsonlite::toJSON(this_object$`store_owner_info`, auto_unbox = TRUE, digits = NA))
      self$`default_warehouse_id` <- this_object$`default_warehouse_id`
      self$`channels` <- ApiClient$new()$deserializeObj(this_object$`channels`, "array[CartChannel]", loadNamespace("openapi"))
      self$`pickup_locations` <- ApiClient$new()$deserializeObj(this_object$`pickup_locations`, "array[CartPickupLocation]", loadNamespace("openapi"))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to CartStoreInfo and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of CartStoreInfo
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# CartStoreInfo$unlock()
#
## Below is an example to define the print function
# CartStoreInfo$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# CartStoreInfo$lock()

