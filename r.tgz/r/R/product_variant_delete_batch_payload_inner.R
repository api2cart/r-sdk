#' Create a new ProductVariantDeleteBatchPayloadInner
#'
#' @description
#' ProductVariantDeleteBatchPayloadInner Class
#'
#' @docType class
#' @title ProductVariantDeleteBatchPayloadInner
#' @description ProductVariantDeleteBatchPayloadInner Class
#' @format An \code{R6Class} generator object
#' @field product_id  character
#' @field id  character
#' @field store_id  character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductVariantDeleteBatchPayloadInner <- R6::R6Class(
  "ProductVariantDeleteBatchPayloadInner",
  public = list(
    `product_id` = NULL,
    `id` = NULL,
    `store_id` = NULL,

    #' @description
    #' Initialize a new ProductVariantDeleteBatchPayloadInner class.
    #'
    #' @param product_id product_id
    #' @param id id
    #' @param store_id store_id
    #' @param ... Other optional arguments.
    initialize = function(`product_id`, `id`, `store_id` = NULL, ...) {
      if (!missing(`product_id`)) {
        if (!(is.character(`product_id`) && length(`product_id`) == 1)) {
          stop(paste("Error! Invalid data for `product_id`. Must be a string:", `product_id`))
        }
        self$`product_id` <- `product_id`
      }
      if (!missing(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`store_id`)) {
        if (!(is.character(`store_id`) && length(`store_id`) == 1)) {
          stop(paste("Error! Invalid data for `store_id`. Must be a string:", `store_id`))
        }
        self$`store_id` <- `store_id`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductVariantDeleteBatchPayloadInner as a base R list.
    #' @examples
    #' # convert array of ProductVariantDeleteBatchPayloadInner (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductVariantDeleteBatchPayloadInner to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductVariantDeleteBatchPayloadInnerObject <- list()
      if (!is.null(self$`product_id`)) {
        ProductVariantDeleteBatchPayloadInnerObject[["product_id"]] <-
          self$`product_id`
      }
      if (!is.null(self$`id`)) {
        ProductVariantDeleteBatchPayloadInnerObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`store_id`)) {
        ProductVariantDeleteBatchPayloadInnerObject[["store_id"]] <-
          self$`store_id`
      }
      return(ProductVariantDeleteBatchPayloadInnerObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductVariantDeleteBatchPayloadInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductVariantDeleteBatchPayloadInner
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`product_id`)) {
        self$`product_id` <- this_object$`product_id`
      }
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`store_id`)) {
        self$`store_id` <- this_object$`store_id`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductVariantDeleteBatchPayloadInner in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductVariantDeleteBatchPayloadInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductVariantDeleteBatchPayloadInner
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`product_id` <- this_object$`product_id`
      self$`id` <- this_object$`id`
      self$`store_id` <- this_object$`store_id`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductVariantDeleteBatchPayloadInner and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
      # check the required field `product_id`
      if (!is.null(input_json$`product_id`)) {
        if (!(is.character(input_json$`product_id`) && length(input_json$`product_id`) == 1)) {
          stop(paste("Error! Invalid data for `product_id`. Must be a string:", input_json$`product_id`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for ProductVariantDeleteBatchPayloadInner: the required field `product_id` is missing."))
      }
      # check the required field `id`
      if (!is.null(input_json$`id`)) {
        if (!(is.character(input_json$`id`) && length(input_json$`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", input_json$`id`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for ProductVariantDeleteBatchPayloadInner: the required field `id` is missing."))
      }
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductVariantDeleteBatchPayloadInner
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      # check if the required `product_id` is null
      if (is.null(self$`product_id`)) {
        return(FALSE)
      }

      # check if the required `id` is null
      if (is.null(self$`id`)) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      # check if the required `product_id` is null
      if (is.null(self$`product_id`)) {
        invalid_fields["product_id"] <- "Non-nullable required field `product_id` cannot be null."
      }

      # check if the required `id` is null
      if (is.null(self$`id`)) {
        invalid_fields["id"] <- "Non-nullable required field `id` cannot be null."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductVariantDeleteBatchPayloadInner$unlock()
#
## Below is an example to define the print function
# ProductVariantDeleteBatchPayloadInner$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductVariantDeleteBatchPayloadInner$lock()

