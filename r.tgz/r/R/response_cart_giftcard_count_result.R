#' Create a new ResponseCartGiftcardCountResult
#'
#' @description
#' ResponseCartGiftcardCountResult Class
#'
#' @docType class
#' @title ResponseCartGiftcardCountResult
#' @description ResponseCartGiftcardCountResult Class
#' @format An \code{R6Class} generator object
#' @field gift_cards_count  integer [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ResponseCartGiftcardCountResult <- R6::R6Class(
  "ResponseCartGiftcardCountResult",
  public = list(
    `gift_cards_count` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new ResponseCartGiftcardCountResult class.
    #'
    #' @param gift_cards_count gift_cards_count
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`gift_cards_count` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`gift_cards_count`)) {
        if (!(is.numeric(`gift_cards_count`) && length(`gift_cards_count`) == 1)) {
          stop(paste("Error! Invalid data for `gift_cards_count`. Must be an integer:", `gift_cards_count`))
        }
        self$`gift_cards_count` <- `gift_cards_count`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ResponseCartGiftcardCountResult as a base R list.
    #' @examples
    #' # convert array of ResponseCartGiftcardCountResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ResponseCartGiftcardCountResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ResponseCartGiftcardCountResultObject <- list()
      if (!is.null(self$`gift_cards_count`)) {
        ResponseCartGiftcardCountResultObject[["gift_cards_count"]] <-
          self$`gift_cards_count`
      }
      if (!is.null(self$`additional_fields`)) {
        ResponseCartGiftcardCountResultObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        ResponseCartGiftcardCountResultObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(ResponseCartGiftcardCountResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ResponseCartGiftcardCountResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ResponseCartGiftcardCountResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`gift_cards_count`)) {
        self$`gift_cards_count` <- this_object$`gift_cards_count`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ResponseCartGiftcardCountResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ResponseCartGiftcardCountResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ResponseCartGiftcardCountResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`gift_cards_count` <- this_object$`gift_cards_count`
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to ResponseCartGiftcardCountResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ResponseCartGiftcardCountResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ResponseCartGiftcardCountResult$unlock()
#
## Below is an example to define the print function
# ResponseCartGiftcardCountResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ResponseCartGiftcardCountResult$lock()

