#' Create a new Brand
#'
#' @description
#' Brand Class
#'
#' @docType class
#' @title Brand
#' @description Brand Class
#' @format An \code{R6Class} generator object
#' @field id  character [optional]
#' @field name  character [optional]
#' @field created_time  character [optional]
#' @field modified_time  character [optional]
#' @field full_description  character [optional]
#' @field short_description  character [optional]
#' @field stores_ids  list(character) [optional]
#' @field active  character [optional]
#' @field url  character [optional]
#' @field meta_title  character [optional]
#' @field meta_keywords  character [optional]
#' @field meta_description  character [optional]
#' @field images  list(\link{Image}) [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
Brand <- R6::R6Class(
  "Brand",
  public = list(
    `id` = NULL,
    `name` = NULL,
    `created_time` = NULL,
    `modified_time` = NULL,
    `full_description` = NULL,
    `short_description` = NULL,
    `stores_ids` = NULL,
    `active` = NULL,
    `url` = NULL,
    `meta_title` = NULL,
    `meta_keywords` = NULL,
    `meta_description` = NULL,
    `images` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new Brand class.
    #'
    #' @param id id
    #' @param name name
    #' @param created_time created_time
    #' @param modified_time modified_time
    #' @param full_description full_description
    #' @param short_description short_description
    #' @param stores_ids stores_ids
    #' @param active active
    #' @param url url
    #' @param meta_title meta_title
    #' @param meta_keywords meta_keywords
    #' @param meta_description meta_description
    #' @param images images
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `name` = NULL, `created_time` = NULL, `modified_time` = NULL, `full_description` = NULL, `short_description` = NULL, `stores_ids` = NULL, `active` = NULL, `url` = NULL, `meta_title` = NULL, `meta_keywords` = NULL, `meta_description` = NULL, `images` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`created_time`)) {
        if (!(is.character(`created_time`) && length(`created_time`) == 1)) {
          stop(paste("Error! Invalid data for `created_time`. Must be a string:", `created_time`))
        }
        self$`created_time` <- `created_time`
      }
      if (!is.null(`modified_time`)) {
        if (!(is.character(`modified_time`) && length(`modified_time`) == 1)) {
          stop(paste("Error! Invalid data for `modified_time`. Must be a string:", `modified_time`))
        }
        self$`modified_time` <- `modified_time`
      }
      if (!is.null(`full_description`)) {
        if (!(is.character(`full_description`) && length(`full_description`) == 1)) {
          stop(paste("Error! Invalid data for `full_description`. Must be a string:", `full_description`))
        }
        self$`full_description` <- `full_description`
      }
      if (!is.null(`short_description`)) {
        if (!(is.character(`short_description`) && length(`short_description`) == 1)) {
          stop(paste("Error! Invalid data for `short_description`. Must be a string:", `short_description`))
        }
        self$`short_description` <- `short_description`
      }
      if (!is.null(`stores_ids`)) {
        stopifnot(is.vector(`stores_ids`), length(`stores_ids`) != 0)
        sapply(`stores_ids`, function(x) stopifnot(is.character(x)))
        self$`stores_ids` <- `stores_ids`
      }
      if (!is.null(`active`)) {
        if (!(is.logical(`active`) && length(`active`) == 1)) {
          stop(paste("Error! Invalid data for `active`. Must be a boolean:", `active`))
        }
        self$`active` <- `active`
      }
      if (!is.null(`url`)) {
        if (!(is.character(`url`) && length(`url`) == 1)) {
          stop(paste("Error! Invalid data for `url`. Must be a string:", `url`))
        }
        self$`url` <- `url`
      }
      if (!is.null(`meta_title`)) {
        if (!(is.character(`meta_title`) && length(`meta_title`) == 1)) {
          stop(paste("Error! Invalid data for `meta_title`. Must be a string:", `meta_title`))
        }
        self$`meta_title` <- `meta_title`
      }
      if (!is.null(`meta_keywords`)) {
        if (!(is.character(`meta_keywords`) && length(`meta_keywords`) == 1)) {
          stop(paste("Error! Invalid data for `meta_keywords`. Must be a string:", `meta_keywords`))
        }
        self$`meta_keywords` <- `meta_keywords`
      }
      if (!is.null(`meta_description`)) {
        if (!(is.character(`meta_description`) && length(`meta_description`) == 1)) {
          stop(paste("Error! Invalid data for `meta_description`. Must be a string:", `meta_description`))
        }
        self$`meta_description` <- `meta_description`
      }
      if (!is.null(`images`)) {
        stopifnot(is.vector(`images`), length(`images`) != 0)
        sapply(`images`, function(x) stopifnot(R6::is.R6(x)))
        self$`images` <- `images`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return Brand as a base R list.
    #' @examples
    #' # convert array of Brand (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert Brand to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      BrandObject <- list()
      if (!is.null(self$`id`)) {
        BrandObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`name`)) {
        BrandObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`created_time`)) {
        BrandObject[["created_time"]] <-
          self$`created_time`
      }
      if (!is.null(self$`modified_time`)) {
        BrandObject[["modified_time"]] <-
          self$`modified_time`
      }
      if (!is.null(self$`full_description`)) {
        BrandObject[["full_description"]] <-
          self$`full_description`
      }
      if (!is.null(self$`short_description`)) {
        BrandObject[["short_description"]] <-
          self$`short_description`
      }
      if (!is.null(self$`stores_ids`)) {
        BrandObject[["stores_ids"]] <-
          self$`stores_ids`
      }
      if (!is.null(self$`active`)) {
        BrandObject[["active"]] <-
          self$`active`
      }
      if (!is.null(self$`url`)) {
        BrandObject[["url"]] <-
          self$`url`
      }
      if (!is.null(self$`meta_title`)) {
        BrandObject[["meta_title"]] <-
          self$`meta_title`
      }
      if (!is.null(self$`meta_keywords`)) {
        BrandObject[["meta_keywords"]] <-
          self$`meta_keywords`
      }
      if (!is.null(self$`meta_description`)) {
        BrandObject[["meta_description"]] <-
          self$`meta_description`
      }
      if (!is.null(self$`images`)) {
        BrandObject[["images"]] <-
          lapply(self$`images`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`additional_fields`)) {
        BrandObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        BrandObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(BrandObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of Brand
    #'
    #' @param input_json the JSON input
    #' @return the instance of Brand
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`created_time`)) {
        self$`created_time` <- this_object$`created_time`
      }
      if (!is.null(this_object$`modified_time`)) {
        self$`modified_time` <- this_object$`modified_time`
      }
      if (!is.null(this_object$`full_description`)) {
        self$`full_description` <- this_object$`full_description`
      }
      if (!is.null(this_object$`short_description`)) {
        self$`short_description` <- this_object$`short_description`
      }
      if (!is.null(this_object$`stores_ids`)) {
        self$`stores_ids` <- ApiClient$new()$deserializeObj(this_object$`stores_ids`, "array[character]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`active`)) {
        self$`active` <- this_object$`active`
      }
      if (!is.null(this_object$`url`)) {
        self$`url` <- this_object$`url`
      }
      if (!is.null(this_object$`meta_title`)) {
        self$`meta_title` <- this_object$`meta_title`
      }
      if (!is.null(this_object$`meta_keywords`)) {
        self$`meta_keywords` <- this_object$`meta_keywords`
      }
      if (!is.null(this_object$`meta_description`)) {
        self$`meta_description` <- this_object$`meta_description`
      }
      if (!is.null(this_object$`images`)) {
        self$`images` <- ApiClient$new()$deserializeObj(this_object$`images`, "array[Image]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return Brand in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of Brand
    #'
    #' @param input_json the JSON input
    #' @return the instance of Brand
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`name` <- this_object$`name`
      self$`created_time` <- this_object$`created_time`
      self$`modified_time` <- this_object$`modified_time`
      self$`full_description` <- this_object$`full_description`
      self$`short_description` <- this_object$`short_description`
      self$`stores_ids` <- ApiClient$new()$deserializeObj(this_object$`stores_ids`, "array[character]", loadNamespace("openapi"))
      self$`active` <- this_object$`active`
      self$`url` <- this_object$`url`
      self$`meta_title` <- this_object$`meta_title`
      self$`meta_keywords` <- this_object$`meta_keywords`
      self$`meta_description` <- this_object$`meta_description`
      self$`images` <- ApiClient$new()$deserializeObj(this_object$`images`, "array[Image]", loadNamespace("openapi"))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to Brand and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of Brand
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# Brand$unlock()
#
## Below is an example to define the print function
# Brand$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# Brand$lock()

