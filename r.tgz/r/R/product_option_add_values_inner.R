#' Create a new ProductOptionAddValuesInner
#'
#' @description
#' ProductOptionAddValuesInner Class
#'
#' @docType class
#' @title ProductOptionAddValuesInner
#' @description ProductOptionAddValuesInner Class
#' @format An \code{R6Class} generator object
#' @field value  character
#' @field display_value  character [optional]
#' @field is_default  character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductOptionAddValuesInner <- R6::R6Class(
  "ProductOptionAddValuesInner",
  public = list(
    `value` = NULL,
    `display_value` = NULL,
    `is_default` = NULL,

    #' @description
    #' Initialize a new ProductOptionAddValuesInner class.
    #'
    #' @param value value
    #' @param display_value display_value
    #' @param is_default is_default. Default to FALSE.
    #' @param ... Other optional arguments.
    initialize = function(`value`, `display_value` = NULL, `is_default` = FALSE, ...) {
      if (!missing(`value`)) {
        if (!(is.character(`value`) && length(`value`) == 1)) {
          stop(paste("Error! Invalid data for `value`. Must be a string:", `value`))
        }
        self$`value` <- `value`
      }
      if (!is.null(`display_value`)) {
        if (!(is.character(`display_value`) && length(`display_value`) == 1)) {
          stop(paste("Error! Invalid data for `display_value`. Must be a string:", `display_value`))
        }
        self$`display_value` <- `display_value`
      }
      if (!is.null(`is_default`)) {
        if (!(is.logical(`is_default`) && length(`is_default`) == 1)) {
          stop(paste("Error! Invalid data for `is_default`. Must be a boolean:", `is_default`))
        }
        self$`is_default` <- `is_default`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductOptionAddValuesInner as a base R list.
    #' @examples
    #' # convert array of ProductOptionAddValuesInner (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductOptionAddValuesInner to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductOptionAddValuesInnerObject <- list()
      if (!is.null(self$`value`)) {
        ProductOptionAddValuesInnerObject[["value"]] <-
          self$`value`
      }
      if (!is.null(self$`display_value`)) {
        ProductOptionAddValuesInnerObject[["display_value"]] <-
          self$`display_value`
      }
      if (!is.null(self$`is_default`)) {
        ProductOptionAddValuesInnerObject[["is_default"]] <-
          self$`is_default`
      }
      return(ProductOptionAddValuesInnerObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductOptionAddValuesInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductOptionAddValuesInner
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`value`)) {
        self$`value` <- this_object$`value`
      }
      if (!is.null(this_object$`display_value`)) {
        self$`display_value` <- this_object$`display_value`
      }
      if (!is.null(this_object$`is_default`)) {
        self$`is_default` <- this_object$`is_default`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductOptionAddValuesInner in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductOptionAddValuesInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductOptionAddValuesInner
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`value` <- this_object$`value`
      self$`display_value` <- this_object$`display_value`
      self$`is_default` <- this_object$`is_default`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductOptionAddValuesInner and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
      # check the required field `value`
      if (!is.null(input_json$`value`)) {
        if (!(is.character(input_json$`value`) && length(input_json$`value`) == 1)) {
          stop(paste("Error! Invalid data for `value`. Must be a string:", input_json$`value`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for ProductOptionAddValuesInner: the required field `value` is missing."))
      }
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductOptionAddValuesInner
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      # check if the required `value` is null
      if (is.null(self$`value`)) {
        return(FALSE)
      }

      if (nchar(self$`value`) < 1) {
        return(FALSE)
      }

      if (nchar(self$`display_value`) < 1) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      # check if the required `value` is null
      if (is.null(self$`value`)) {
        invalid_fields["value"] <- "Non-nullable required field `value` cannot be null."
      }

      if (nchar(self$`value`) < 1) {
        invalid_fields["value"] <- "Invalid length for `value`, must be bigger than or equal to 1."
      }

      if (nchar(self$`display_value`) < 1) {
        invalid_fields["display_value"] <- "Invalid length for `display_value`, must be bigger than or equal to 1."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductOptionAddValuesInner$unlock()
#
## Below is an example to define the print function
# ProductOptionAddValuesInner$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductOptionAddValuesInner$lock()

