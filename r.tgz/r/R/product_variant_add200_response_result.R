#' Create a new ProductVariantAdd200ResponseResult
#'
#' @description
#' ProductVariantAdd200ResponseResult Class
#'
#' @docType class
#' @title ProductVariantAdd200ResponseResult
#' @description ProductVariantAdd200ResponseResult Class
#' @format An \code{R6Class} generator object
#' @field product_variant_id  character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductVariantAdd200ResponseResult <- R6::R6Class(
  "ProductVariantAdd200ResponseResult",
  public = list(
    `product_variant_id` = NULL,

    #' @description
    #' Initialize a new ProductVariantAdd200ResponseResult class.
    #'
    #' @param product_variant_id product_variant_id
    #' @param ... Other optional arguments.
    initialize = function(`product_variant_id` = NULL, ...) {
      if (!is.null(`product_variant_id`)) {
        if (!(is.character(`product_variant_id`) && length(`product_variant_id`) == 1)) {
          stop(paste("Error! Invalid data for `product_variant_id`. Must be a string:", `product_variant_id`))
        }
        self$`product_variant_id` <- `product_variant_id`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductVariantAdd200ResponseResult as a base R list.
    #' @examples
    #' # convert array of ProductVariantAdd200ResponseResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductVariantAdd200ResponseResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductVariantAdd200ResponseResultObject <- list()
      if (!is.null(self$`product_variant_id`)) {
        ProductVariantAdd200ResponseResultObject[["product_variant_id"]] <-
          self$`product_variant_id`
      }
      return(ProductVariantAdd200ResponseResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductVariantAdd200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductVariantAdd200ResponseResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`product_variant_id`)) {
        self$`product_variant_id` <- this_object$`product_variant_id`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductVariantAdd200ResponseResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductVariantAdd200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductVariantAdd200ResponseResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`product_variant_id` <- this_object$`product_variant_id`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductVariantAdd200ResponseResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductVariantAdd200ResponseResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductVariantAdd200ResponseResult$unlock()
#
## Below is an example to define the print function
# ProductVariantAdd200ResponseResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductVariantAdd200ResponseResult$lock()

