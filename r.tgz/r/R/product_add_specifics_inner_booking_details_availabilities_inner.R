#' Create a new ProductAddSpecificsInnerBookingDetailsAvailabilitiesInner
#'
#' @description
#' ProductAddSpecificsInnerBookingDetailsAvailabilitiesInner Class
#'
#' @docType class
#' @title ProductAddSpecificsInnerBookingDetailsAvailabilitiesInner
#' @description ProductAddSpecificsInnerBookingDetailsAvailabilitiesInner Class
#' @format An \code{R6Class} generator object
#' @field day  character
#' @field is_available  character [optional]
#' @field times  list(\link{ProductAddSpecificsInnerBookingDetailsAvailabilitiesInnerTimesInner}) [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductAddSpecificsInnerBookingDetailsAvailabilitiesInner <- R6::R6Class(
  "ProductAddSpecificsInnerBookingDetailsAvailabilitiesInner",
  public = list(
    `day` = NULL,
    `is_available` = NULL,
    `times` = NULL,

    #' @description
    #' Initialize a new ProductAddSpecificsInnerBookingDetailsAvailabilitiesInner class.
    #'
    #' @param day day
    #' @param is_available is_available. Default to TRUE.
    #' @param times times
    #' @param ... Other optional arguments.
    initialize = function(`day`, `is_available` = TRUE, `times` = NULL, ...) {
      if (!missing(`day`)) {
        if (!(`day` %in% c("sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"))) {
          stop(paste("Error! \"", `day`, "\" cannot be assigned to `day`. Must be \"sunday\", \"monday\", \"tuesday\", \"wednesday\", \"thursday\", \"friday\", \"saturday\".", sep = ""))
        }
        if (!(is.character(`day`) && length(`day`) == 1)) {
          stop(paste("Error! Invalid data for `day`. Must be a string:", `day`))
        }
        self$`day` <- `day`
      }
      if (!is.null(`is_available`)) {
        if (!(is.logical(`is_available`) && length(`is_available`) == 1)) {
          stop(paste("Error! Invalid data for `is_available`. Must be a boolean:", `is_available`))
        }
        self$`is_available` <- `is_available`
      }
      if (!is.null(`times`)) {
        stopifnot(is.vector(`times`), length(`times`) != 0)
        sapply(`times`, function(x) stopifnot(R6::is.R6(x)))
        self$`times` <- `times`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductAddSpecificsInnerBookingDetailsAvailabilitiesInner as a base R list.
    #' @examples
    #' # convert array of ProductAddSpecificsInnerBookingDetailsAvailabilitiesInner (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductAddSpecificsInnerBookingDetailsAvailabilitiesInner to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductAddSpecificsInnerBookingDetailsAvailabilitiesInnerObject <- list()
      if (!is.null(self$`day`)) {
        ProductAddSpecificsInnerBookingDetailsAvailabilitiesInnerObject[["day"]] <-
          self$`day`
      }
      if (!is.null(self$`is_available`)) {
        ProductAddSpecificsInnerBookingDetailsAvailabilitiesInnerObject[["is_available"]] <-
          self$`is_available`
      }
      if (!is.null(self$`times`)) {
        ProductAddSpecificsInnerBookingDetailsAvailabilitiesInnerObject[["times"]] <-
          lapply(self$`times`, function(x) x$toSimpleType())
      }
      return(ProductAddSpecificsInnerBookingDetailsAvailabilitiesInnerObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductAddSpecificsInnerBookingDetailsAvailabilitiesInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductAddSpecificsInnerBookingDetailsAvailabilitiesInner
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`day`)) {
        if (!is.null(this_object$`day`) && !(this_object$`day` %in% c("sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"))) {
          stop(paste("Error! \"", this_object$`day`, "\" cannot be assigned to `day`. Must be \"sunday\", \"monday\", \"tuesday\", \"wednesday\", \"thursday\", \"friday\", \"saturday\".", sep = ""))
        }
        self$`day` <- this_object$`day`
      }
      if (!is.null(this_object$`is_available`)) {
        self$`is_available` <- this_object$`is_available`
      }
      if (!is.null(this_object$`times`)) {
        self$`times` <- ApiClient$new()$deserializeObj(this_object$`times`, "array[ProductAddSpecificsInnerBookingDetailsAvailabilitiesInnerTimesInner]", loadNamespace("openapi"))
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductAddSpecificsInnerBookingDetailsAvailabilitiesInner in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductAddSpecificsInnerBookingDetailsAvailabilitiesInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductAddSpecificsInnerBookingDetailsAvailabilitiesInner
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`day`) && !(this_object$`day` %in% c("sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"))) {
        stop(paste("Error! \"", this_object$`day`, "\" cannot be assigned to `day`. Must be \"sunday\", \"monday\", \"tuesday\", \"wednesday\", \"thursday\", \"friday\", \"saturday\".", sep = ""))
      }
      self$`day` <- this_object$`day`
      self$`is_available` <- this_object$`is_available`
      self$`times` <- ApiClient$new()$deserializeObj(this_object$`times`, "array[ProductAddSpecificsInnerBookingDetailsAvailabilitiesInnerTimesInner]", loadNamespace("openapi"))
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductAddSpecificsInnerBookingDetailsAvailabilitiesInner and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
      # check the required field `day`
      if (!is.null(input_json$`day`)) {
        if (!(is.character(input_json$`day`) && length(input_json$`day`) == 1)) {
          stop(paste("Error! Invalid data for `day`. Must be a string:", input_json$`day`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for ProductAddSpecificsInnerBookingDetailsAvailabilitiesInner: the required field `day` is missing."))
      }
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductAddSpecificsInnerBookingDetailsAvailabilitiesInner
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      # check if the required `day` is null
      if (is.null(self$`day`)) {
        return(FALSE)
      }

      if (length(self$`times`) < 1) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      # check if the required `day` is null
      if (is.null(self$`day`)) {
        invalid_fields["day"] <- "Non-nullable required field `day` cannot be null."
      }

      if (length(self$`times`) < 1) {
        invalid_fields["times"] <- "Invalid length for ``, number of items must be greater than or equal to 1."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductAddSpecificsInnerBookingDetailsAvailabilitiesInner$unlock()
#
## Below is an example to define the print function
# ProductAddSpecificsInnerBookingDetailsAvailabilitiesInner$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductAddSpecificsInnerBookingDetailsAvailabilitiesInner$lock()

