#' Create a new CartScriptAdd200ResponseResult
#'
#' @description
#' CartScriptAdd200ResponseResult Class
#'
#' @docType class
#' @title CartScriptAdd200ResponseResult
#' @description CartScriptAdd200ResponseResult Class
#' @format An \code{R6Class} generator object
#' @field script_id  character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
CartScriptAdd200ResponseResult <- R6::R6Class(
  "CartScriptAdd200ResponseResult",
  public = list(
    `script_id` = NULL,

    #' @description
    #' Initialize a new CartScriptAdd200ResponseResult class.
    #'
    #' @param script_id script_id
    #' @param ... Other optional arguments.
    initialize = function(`script_id` = NULL, ...) {
      if (!is.null(`script_id`)) {
        if (!(is.character(`script_id`) && length(`script_id`) == 1)) {
          stop(paste("Error! Invalid data for `script_id`. Must be a string:", `script_id`))
        }
        self$`script_id` <- `script_id`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return CartScriptAdd200ResponseResult as a base R list.
    #' @examples
    #' # convert array of CartScriptAdd200ResponseResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert CartScriptAdd200ResponseResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      CartScriptAdd200ResponseResultObject <- list()
      if (!is.null(self$`script_id`)) {
        CartScriptAdd200ResponseResultObject[["script_id"]] <-
          self$`script_id`
      }
      return(CartScriptAdd200ResponseResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of CartScriptAdd200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of CartScriptAdd200ResponseResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`script_id`)) {
        self$`script_id` <- this_object$`script_id`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return CartScriptAdd200ResponseResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of CartScriptAdd200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of CartScriptAdd200ResponseResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`script_id` <- this_object$`script_id`
      self
    },

    #' @description
    #' Validate JSON input with respect to CartScriptAdd200ResponseResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of CartScriptAdd200ResponseResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# CartScriptAdd200ResponseResult$unlock()
#
## Below is an example to define the print function
# CartScriptAdd200ResponseResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# CartScriptAdd200ResponseResult$lock()

