#' Create a new ReturnReasonList200ResponseResult
#'
#' @description
#' ReturnReasonList200ResponseResult Class
#'
#' @docType class
#' @title ReturnReasonList200ResponseResult
#' @description ReturnReasonList200ResponseResult Class
#' @format An \code{R6Class} generator object
#' @field return_reasons  list(\link{OrderFinancialStatusList200ResponseResultOrderFinancialStatusesInner}) [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ReturnReasonList200ResponseResult <- R6::R6Class(
  "ReturnReasonList200ResponseResult",
  public = list(
    `return_reasons` = NULL,

    #' @description
    #' Initialize a new ReturnReasonList200ResponseResult class.
    #'
    #' @param return_reasons return_reasons
    #' @param ... Other optional arguments.
    initialize = function(`return_reasons` = NULL, ...) {
      if (!is.null(`return_reasons`)) {
        stopifnot(is.vector(`return_reasons`), length(`return_reasons`) != 0)
        sapply(`return_reasons`, function(x) stopifnot(R6::is.R6(x)))
        self$`return_reasons` <- `return_reasons`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ReturnReasonList200ResponseResult as a base R list.
    #' @examples
    #' # convert array of ReturnReasonList200ResponseResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ReturnReasonList200ResponseResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ReturnReasonList200ResponseResultObject <- list()
      if (!is.null(self$`return_reasons`)) {
        ReturnReasonList200ResponseResultObject[["return_reasons"]] <-
          lapply(self$`return_reasons`, function(x) x$toSimpleType())
      }
      return(ReturnReasonList200ResponseResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ReturnReasonList200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ReturnReasonList200ResponseResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`return_reasons`)) {
        self$`return_reasons` <- ApiClient$new()$deserializeObj(this_object$`return_reasons`, "array[OrderFinancialStatusList200ResponseResultOrderFinancialStatusesInner]", loadNamespace("openapi"))
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ReturnReasonList200ResponseResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ReturnReasonList200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ReturnReasonList200ResponseResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`return_reasons` <- ApiClient$new()$deserializeObj(this_object$`return_reasons`, "array[OrderFinancialStatusList200ResponseResultOrderFinancialStatusesInner]", loadNamespace("openapi"))
      self
    },

    #' @description
    #' Validate JSON input with respect to ReturnReasonList200ResponseResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ReturnReasonList200ResponseResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ReturnReasonList200ResponseResult$unlock()
#
## Below is an example to define the print function
# ReturnReasonList200ResponseResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ReturnReasonList200ResponseResult$lock()

