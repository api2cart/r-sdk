#' Create a new ProductFind200ResponseResult
#'
#' @description
#' ProductFind200ResponseResult Class
#'
#' @docType class
#' @title ProductFind200ResponseResult
#' @description ProductFind200ResponseResult Class
#' @format An \code{R6Class} generator object
#' @field product  list(\link{ProductFind200ResponseResultProductInner}) [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductFind200ResponseResult <- R6::R6Class(
  "ProductFind200ResponseResult",
  public = list(
    `product` = NULL,

    #' @description
    #' Initialize a new ProductFind200ResponseResult class.
    #'
    #' @param product product
    #' @param ... Other optional arguments.
    initialize = function(`product` = NULL, ...) {
      if (!is.null(`product`)) {
        stopifnot(is.vector(`product`), length(`product`) != 0)
        sapply(`product`, function(x) stopifnot(R6::is.R6(x)))
        self$`product` <- `product`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductFind200ResponseResult as a base R list.
    #' @examples
    #' # convert array of ProductFind200ResponseResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductFind200ResponseResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductFind200ResponseResultObject <- list()
      if (!is.null(self$`product`)) {
        ProductFind200ResponseResultObject[["product"]] <-
          lapply(self$`product`, function(x) x$toSimpleType())
      }
      return(ProductFind200ResponseResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductFind200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductFind200ResponseResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`product`)) {
        self$`product` <- ApiClient$new()$deserializeObj(this_object$`product`, "array[ProductFind200ResponseResultProductInner]", loadNamespace("openapi"))
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductFind200ResponseResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductFind200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductFind200ResponseResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`product` <- ApiClient$new()$deserializeObj(this_object$`product`, "array[ProductFind200ResponseResultProductInner]", loadNamespace("openapi"))
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductFind200ResponseResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductFind200ResponseResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductFind200ResponseResult$unlock()
#
## Below is an example to define the print function
# ProductFind200ResponseResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductFind200ResponseResult$lock()

