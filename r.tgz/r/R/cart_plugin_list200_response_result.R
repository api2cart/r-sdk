#' Create a new CartPluginList200ResponseResult
#'
#' @description
#' CartPluginList200ResponseResult Class
#'
#' @docType class
#' @title CartPluginList200ResponseResult
#' @description CartPluginList200ResponseResult Class
#' @format An \code{R6Class} generator object
#' @field all_plugins  integer [optional]
#' @field plugins  list(\link{PluginList}) [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
CartPluginList200ResponseResult <- R6::R6Class(
  "CartPluginList200ResponseResult",
  public = list(
    `all_plugins` = NULL,
    `plugins` = NULL,

    #' @description
    #' Initialize a new CartPluginList200ResponseResult class.
    #'
    #' @param all_plugins all_plugins
    #' @param plugins plugins
    #' @param ... Other optional arguments.
    initialize = function(`all_plugins` = NULL, `plugins` = NULL, ...) {
      if (!is.null(`all_plugins`)) {
        if (!(is.numeric(`all_plugins`) && length(`all_plugins`) == 1)) {
          stop(paste("Error! Invalid data for `all_plugins`. Must be an integer:", `all_plugins`))
        }
        self$`all_plugins` <- `all_plugins`
      }
      if (!is.null(`plugins`)) {
        stopifnot(is.vector(`plugins`), length(`plugins`) != 0)
        sapply(`plugins`, function(x) stopifnot(R6::is.R6(x)))
        self$`plugins` <- `plugins`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return CartPluginList200ResponseResult as a base R list.
    #' @examples
    #' # convert array of CartPluginList200ResponseResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert CartPluginList200ResponseResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      CartPluginList200ResponseResultObject <- list()
      if (!is.null(self$`all_plugins`)) {
        CartPluginList200ResponseResultObject[["all_plugins"]] <-
          self$`all_plugins`
      }
      if (!is.null(self$`plugins`)) {
        CartPluginList200ResponseResultObject[["plugins"]] <-
          lapply(self$`plugins`, function(x) x$toSimpleType())
      }
      return(CartPluginList200ResponseResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of CartPluginList200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of CartPluginList200ResponseResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`all_plugins`)) {
        self$`all_plugins` <- this_object$`all_plugins`
      }
      if (!is.null(this_object$`plugins`)) {
        self$`plugins` <- ApiClient$new()$deserializeObj(this_object$`plugins`, "array[PluginList]", loadNamespace("openapi"))
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return CartPluginList200ResponseResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of CartPluginList200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of CartPluginList200ResponseResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`all_plugins` <- this_object$`all_plugins`
      self$`plugins` <- ApiClient$new()$deserializeObj(this_object$`plugins`, "array[PluginList]", loadNamespace("openapi"))
      self
    },

    #' @description
    #' Validate JSON input with respect to CartPluginList200ResponseResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of CartPluginList200ResponseResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# CartPluginList200ResponseResult$unlock()
#
## Below is an example to define the print function
# CartPluginList200ResponseResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# CartPluginList200ResponseResult$lock()

