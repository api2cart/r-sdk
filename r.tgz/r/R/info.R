#' Create a new Info
#'
#' @description
#' Info Class
#'
#' @docType class
#' @title Info
#' @description Info Class
#' @format An \code{R6Class} generator object
#' @field owner  character [optional]
#' @field country  character [optional]
#' @field state  character [optional]
#' @field state_code  character [optional]
#' @field city  character [optional]
#' @field street_address  character [optional]
#' @field street_address_line_2  character [optional]
#' @field zip_code  character [optional]
#' @field email  character [optional]
#' @field phone  character [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
Info <- R6::R6Class(
  "Info",
  public = list(
    `owner` = NULL,
    `country` = NULL,
    `state` = NULL,
    `state_code` = NULL,
    `city` = NULL,
    `street_address` = NULL,
    `street_address_line_2` = NULL,
    `zip_code` = NULL,
    `email` = NULL,
    `phone` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new Info class.
    #'
    #' @param owner owner
    #' @param country country
    #' @param state state
    #' @param state_code state_code
    #' @param city city
    #' @param street_address street_address
    #' @param street_address_line_2 street_address_line_2
    #' @param zip_code zip_code
    #' @param email email
    #' @param phone phone
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`owner` = NULL, `country` = NULL, `state` = NULL, `state_code` = NULL, `city` = NULL, `street_address` = NULL, `street_address_line_2` = NULL, `zip_code` = NULL, `email` = NULL, `phone` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`owner`)) {
        if (!(is.character(`owner`) && length(`owner`) == 1)) {
          stop(paste("Error! Invalid data for `owner`. Must be a string:", `owner`))
        }
        self$`owner` <- `owner`
      }
      if (!is.null(`country`)) {
        if (!(is.character(`country`) && length(`country`) == 1)) {
          stop(paste("Error! Invalid data for `country`. Must be a string:", `country`))
        }
        self$`country` <- `country`
      }
      if (!is.null(`state`)) {
        if (!(is.character(`state`) && length(`state`) == 1)) {
          stop(paste("Error! Invalid data for `state`. Must be a string:", `state`))
        }
        self$`state` <- `state`
      }
      if (!is.null(`state_code`)) {
        if (!(is.character(`state_code`) && length(`state_code`) == 1)) {
          stop(paste("Error! Invalid data for `state_code`. Must be a string:", `state_code`))
        }
        self$`state_code` <- `state_code`
      }
      if (!is.null(`city`)) {
        if (!(is.character(`city`) && length(`city`) == 1)) {
          stop(paste("Error! Invalid data for `city`. Must be a string:", `city`))
        }
        self$`city` <- `city`
      }
      if (!is.null(`street_address`)) {
        if (!(is.character(`street_address`) && length(`street_address`) == 1)) {
          stop(paste("Error! Invalid data for `street_address`. Must be a string:", `street_address`))
        }
        self$`street_address` <- `street_address`
      }
      if (!is.null(`street_address_line_2`)) {
        if (!(is.character(`street_address_line_2`) && length(`street_address_line_2`) == 1)) {
          stop(paste("Error! Invalid data for `street_address_line_2`. Must be a string:", `street_address_line_2`))
        }
        self$`street_address_line_2` <- `street_address_line_2`
      }
      if (!is.null(`zip_code`)) {
        if (!(is.character(`zip_code`) && length(`zip_code`) == 1)) {
          stop(paste("Error! Invalid data for `zip_code`. Must be a string:", `zip_code`))
        }
        self$`zip_code` <- `zip_code`
      }
      if (!is.null(`email`)) {
        if (!(is.character(`email`) && length(`email`) == 1)) {
          stop(paste("Error! Invalid data for `email`. Must be a string:", `email`))
        }
        self$`email` <- `email`
      }
      if (!is.null(`phone`)) {
        if (!(is.character(`phone`) && length(`phone`) == 1)) {
          stop(paste("Error! Invalid data for `phone`. Must be a string:", `phone`))
        }
        self$`phone` <- `phone`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return Info as a base R list.
    #' @examples
    #' # convert array of Info (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert Info to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      InfoObject <- list()
      if (!is.null(self$`owner`)) {
        InfoObject[["owner"]] <-
          self$`owner`
      }
      if (!is.null(self$`country`)) {
        InfoObject[["country"]] <-
          self$`country`
      }
      if (!is.null(self$`state`)) {
        InfoObject[["state"]] <-
          self$`state`
      }
      if (!is.null(self$`state_code`)) {
        InfoObject[["state_code"]] <-
          self$`state_code`
      }
      if (!is.null(self$`city`)) {
        InfoObject[["city"]] <-
          self$`city`
      }
      if (!is.null(self$`street_address`)) {
        InfoObject[["street_address"]] <-
          self$`street_address`
      }
      if (!is.null(self$`street_address_line_2`)) {
        InfoObject[["street_address_line_2"]] <-
          self$`street_address_line_2`
      }
      if (!is.null(self$`zip_code`)) {
        InfoObject[["zip_code"]] <-
          self$`zip_code`
      }
      if (!is.null(self$`email`)) {
        InfoObject[["email"]] <-
          self$`email`
      }
      if (!is.null(self$`phone`)) {
        InfoObject[["phone"]] <-
          self$`phone`
      }
      if (!is.null(self$`additional_fields`)) {
        InfoObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        InfoObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(InfoObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of Info
    #'
    #' @param input_json the JSON input
    #' @return the instance of Info
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`owner`)) {
        self$`owner` <- this_object$`owner`
      }
      if (!is.null(this_object$`country`)) {
        self$`country` <- this_object$`country`
      }
      if (!is.null(this_object$`state`)) {
        self$`state` <- this_object$`state`
      }
      if (!is.null(this_object$`state_code`)) {
        self$`state_code` <- this_object$`state_code`
      }
      if (!is.null(this_object$`city`)) {
        self$`city` <- this_object$`city`
      }
      if (!is.null(this_object$`street_address`)) {
        self$`street_address` <- this_object$`street_address`
      }
      if (!is.null(this_object$`street_address_line_2`)) {
        self$`street_address_line_2` <- this_object$`street_address_line_2`
      }
      if (!is.null(this_object$`zip_code`)) {
        self$`zip_code` <- this_object$`zip_code`
      }
      if (!is.null(this_object$`email`)) {
        self$`email` <- this_object$`email`
      }
      if (!is.null(this_object$`phone`)) {
        self$`phone` <- this_object$`phone`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return Info in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of Info
    #'
    #' @param input_json the JSON input
    #' @return the instance of Info
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`owner` <- this_object$`owner`
      self$`country` <- this_object$`country`
      self$`state` <- this_object$`state`
      self$`state_code` <- this_object$`state_code`
      self$`city` <- this_object$`city`
      self$`street_address` <- this_object$`street_address`
      self$`street_address_line_2` <- this_object$`street_address_line_2`
      self$`zip_code` <- this_object$`zip_code`
      self$`email` <- this_object$`email`
      self$`phone` <- this_object$`phone`
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to Info and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of Info
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# Info$unlock()
#
## Below is an example to define the print function
# Info$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# Info$lock()

