#' Create a new ReturnOrderProduct
#'
#' @description
#' ReturnOrderProduct Class
#'
#' @docType class
#' @title ReturnOrderProduct
#' @description ReturnOrderProduct Class
#' @format An \code{R6Class} generator object
#' @field product_id  character [optional]
#' @field order_product_id  character [optional]
#' @field sku  character [optional]
#' @field name  character [optional]
#' @field quantity  integer [optional]
#' @field reason  \link{ReturnReason} [optional]
#' @field action  \link{ReturnAction} [optional]
#' @field condition  character [optional]
#' @field customer_comment  character [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ReturnOrderProduct <- R6::R6Class(
  "ReturnOrderProduct",
  public = list(
    `product_id` = NULL,
    `order_product_id` = NULL,
    `sku` = NULL,
    `name` = NULL,
    `quantity` = NULL,
    `reason` = NULL,
    `action` = NULL,
    `condition` = NULL,
    `customer_comment` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new ReturnOrderProduct class.
    #'
    #' @param product_id product_id
    #' @param order_product_id order_product_id
    #' @param sku sku
    #' @param name name
    #' @param quantity quantity
    #' @param reason reason
    #' @param action action
    #' @param condition condition
    #' @param customer_comment customer_comment
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`product_id` = NULL, `order_product_id` = NULL, `sku` = NULL, `name` = NULL, `quantity` = NULL, `reason` = NULL, `action` = NULL, `condition` = NULL, `customer_comment` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`product_id`)) {
        if (!(is.character(`product_id`) && length(`product_id`) == 1)) {
          stop(paste("Error! Invalid data for `product_id`. Must be a string:", `product_id`))
        }
        self$`product_id` <- `product_id`
      }
      if (!is.null(`order_product_id`)) {
        if (!(is.character(`order_product_id`) && length(`order_product_id`) == 1)) {
          stop(paste("Error! Invalid data for `order_product_id`. Must be a string:", `order_product_id`))
        }
        self$`order_product_id` <- `order_product_id`
      }
      if (!is.null(`sku`)) {
        if (!(is.character(`sku`) && length(`sku`) == 1)) {
          stop(paste("Error! Invalid data for `sku`. Must be a string:", `sku`))
        }
        self$`sku` <- `sku`
      }
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`quantity`)) {
        if (!(is.numeric(`quantity`) && length(`quantity`) == 1)) {
          stop(paste("Error! Invalid data for `quantity`. Must be an integer:", `quantity`))
        }
        self$`quantity` <- `quantity`
      }
      if (!is.null(`reason`)) {
        stopifnot(R6::is.R6(`reason`))
        self$`reason` <- `reason`
      }
      if (!is.null(`action`)) {
        stopifnot(R6::is.R6(`action`))
        self$`action` <- `action`
      }
      if (!is.null(`condition`)) {
        if (!(is.character(`condition`) && length(`condition`) == 1)) {
          stop(paste("Error! Invalid data for `condition`. Must be a string:", `condition`))
        }
        self$`condition` <- `condition`
      }
      if (!is.null(`customer_comment`)) {
        if (!(is.character(`customer_comment`) && length(`customer_comment`) == 1)) {
          stop(paste("Error! Invalid data for `customer_comment`. Must be a string:", `customer_comment`))
        }
        self$`customer_comment` <- `customer_comment`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ReturnOrderProduct as a base R list.
    #' @examples
    #' # convert array of ReturnOrderProduct (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ReturnOrderProduct to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ReturnOrderProductObject <- list()
      if (!is.null(self$`product_id`)) {
        ReturnOrderProductObject[["product_id"]] <-
          self$`product_id`
      }
      if (!is.null(self$`order_product_id`)) {
        ReturnOrderProductObject[["order_product_id"]] <-
          self$`order_product_id`
      }
      if (!is.null(self$`sku`)) {
        ReturnOrderProductObject[["sku"]] <-
          self$`sku`
      }
      if (!is.null(self$`name`)) {
        ReturnOrderProductObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`quantity`)) {
        ReturnOrderProductObject[["quantity"]] <-
          self$`quantity`
      }
      if (!is.null(self$`reason`)) {
        ReturnOrderProductObject[["reason"]] <-
          self$`reason`$toSimpleType()
      }
      if (!is.null(self$`action`)) {
        ReturnOrderProductObject[["action"]] <-
          self$`action`$toSimpleType()
      }
      if (!is.null(self$`condition`)) {
        ReturnOrderProductObject[["condition"]] <-
          self$`condition`
      }
      if (!is.null(self$`customer_comment`)) {
        ReturnOrderProductObject[["customer_comment"]] <-
          self$`customer_comment`
      }
      if (!is.null(self$`additional_fields`)) {
        ReturnOrderProductObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        ReturnOrderProductObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(ReturnOrderProductObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ReturnOrderProduct
    #'
    #' @param input_json the JSON input
    #' @return the instance of ReturnOrderProduct
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`product_id`)) {
        self$`product_id` <- this_object$`product_id`
      }
      if (!is.null(this_object$`order_product_id`)) {
        self$`order_product_id` <- this_object$`order_product_id`
      }
      if (!is.null(this_object$`sku`)) {
        self$`sku` <- this_object$`sku`
      }
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`quantity`)) {
        self$`quantity` <- this_object$`quantity`
      }
      if (!is.null(this_object$`reason`)) {
        `reason_object` <- ReturnReason$new()
        `reason_object`$fromJSON(jsonlite::toJSON(this_object$`reason`, auto_unbox = TRUE, digits = NA))
        self$`reason` <- `reason_object`
      }
      if (!is.null(this_object$`action`)) {
        `action_object` <- ReturnAction$new()
        `action_object`$fromJSON(jsonlite::toJSON(this_object$`action`, auto_unbox = TRUE, digits = NA))
        self$`action` <- `action_object`
      }
      if (!is.null(this_object$`condition`)) {
        self$`condition` <- this_object$`condition`
      }
      if (!is.null(this_object$`customer_comment`)) {
        self$`customer_comment` <- this_object$`customer_comment`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ReturnOrderProduct in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ReturnOrderProduct
    #'
    #' @param input_json the JSON input
    #' @return the instance of ReturnOrderProduct
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`product_id` <- this_object$`product_id`
      self$`order_product_id` <- this_object$`order_product_id`
      self$`sku` <- this_object$`sku`
      self$`name` <- this_object$`name`
      self$`quantity` <- this_object$`quantity`
      self$`reason` <- ReturnReason$new()$fromJSON(jsonlite::toJSON(this_object$`reason`, auto_unbox = TRUE, digits = NA))
      self$`action` <- ReturnAction$new()$fromJSON(jsonlite::toJSON(this_object$`action`, auto_unbox = TRUE, digits = NA))
      self$`condition` <- this_object$`condition`
      self$`customer_comment` <- this_object$`customer_comment`
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to ReturnOrderProduct and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ReturnOrderProduct
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ReturnOrderProduct$unlock()
#
## Below is an example to define the print function
# ReturnOrderProduct$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ReturnOrderProduct$lock()

