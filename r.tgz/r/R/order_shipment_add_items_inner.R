#' Create a new OrderShipmentAddItemsInner
#'
#' @description
#' OrderShipmentAddItemsInner Class
#'
#' @docType class
#' @title OrderShipmentAddItemsInner
#' @description OrderShipmentAddItemsInner Class
#' @format An \code{R6Class} generator object
#' @field order_product_id  character [optional]
#' @field quantity  numeric [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
OrderShipmentAddItemsInner <- R6::R6Class(
  "OrderShipmentAddItemsInner",
  public = list(
    `order_product_id` = NULL,
    `quantity` = NULL,

    #' @description
    #' Initialize a new OrderShipmentAddItemsInner class.
    #'
    #' @param order_product_id order_product_id
    #' @param quantity quantity
    #' @param ... Other optional arguments.
    initialize = function(`order_product_id` = NULL, `quantity` = NULL, ...) {
      if (!is.null(`order_product_id`)) {
        if (!(is.character(`order_product_id`) && length(`order_product_id`) == 1)) {
          stop(paste("Error! Invalid data for `order_product_id`. Must be a string:", `order_product_id`))
        }
        self$`order_product_id` <- `order_product_id`
      }
      if (!is.null(`quantity`)) {
        self$`quantity` <- `quantity`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return OrderShipmentAddItemsInner as a base R list.
    #' @examples
    #' # convert array of OrderShipmentAddItemsInner (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert OrderShipmentAddItemsInner to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      OrderShipmentAddItemsInnerObject <- list()
      if (!is.null(self$`order_product_id`)) {
        OrderShipmentAddItemsInnerObject[["order_product_id"]] <-
          self$`order_product_id`
      }
      if (!is.null(self$`quantity`)) {
        OrderShipmentAddItemsInnerObject[["quantity"]] <-
          self$`quantity`
      }
      return(OrderShipmentAddItemsInnerObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderShipmentAddItemsInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderShipmentAddItemsInner
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`order_product_id`)) {
        self$`order_product_id` <- this_object$`order_product_id`
      }
      if (!is.null(this_object$`quantity`)) {
        self$`quantity` <- this_object$`quantity`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return OrderShipmentAddItemsInner in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderShipmentAddItemsInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderShipmentAddItemsInner
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`order_product_id` <- this_object$`order_product_id`
      self$`quantity` <- this_object$`quantity`
      self
    },

    #' @description
    #' Validate JSON input with respect to OrderShipmentAddItemsInner and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of OrderShipmentAddItemsInner
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# OrderShipmentAddItemsInner$unlock()
#
## Below is an example to define the print function
# OrderShipmentAddItemsInner$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# OrderShipmentAddItemsInner$lock()

