#' Create a new OrderCalculateShippingRate
#'
#' @description
#' OrderCalculateShippingRate Class
#'
#' @docType class
#' @title OrderCalculateShippingRate
#' @description OrderCalculateShippingRate Class
#' @format An \code{R6Class} generator object
#' @field code  character [optional]
#' @field name  character [optional]
#' @field price  numeric [optional]
#' @field price_inc_tax  numeric [optional]
#' @field tax  numeric [optional]
#' @field tax_rate  numeric [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
OrderCalculateShippingRate <- R6::R6Class(
  "OrderCalculateShippingRate",
  public = list(
    `code` = NULL,
    `name` = NULL,
    `price` = NULL,
    `price_inc_tax` = NULL,
    `tax` = NULL,
    `tax_rate` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new OrderCalculateShippingRate class.
    #'
    #' @param code code
    #' @param name name
    #' @param price price
    #' @param price_inc_tax price_inc_tax
    #' @param tax tax
    #' @param tax_rate tax_rate
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`code` = NULL, `name` = NULL, `price` = NULL, `price_inc_tax` = NULL, `tax` = NULL, `tax_rate` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`code`)) {
        if (!(is.character(`code`) && length(`code`) == 1)) {
          stop(paste("Error! Invalid data for `code`. Must be a string:", `code`))
        }
        self$`code` <- `code`
      }
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`price`)) {
        self$`price` <- `price`
      }
      if (!is.null(`price_inc_tax`)) {
        self$`price_inc_tax` <- `price_inc_tax`
      }
      if (!is.null(`tax`)) {
        self$`tax` <- `tax`
      }
      if (!is.null(`tax_rate`)) {
        self$`tax_rate` <- `tax_rate`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return OrderCalculateShippingRate as a base R list.
    #' @examples
    #' # convert array of OrderCalculateShippingRate (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert OrderCalculateShippingRate to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      OrderCalculateShippingRateObject <- list()
      if (!is.null(self$`code`)) {
        OrderCalculateShippingRateObject[["code"]] <-
          self$`code`
      }
      if (!is.null(self$`name`)) {
        OrderCalculateShippingRateObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`price`)) {
        OrderCalculateShippingRateObject[["price"]] <-
          self$`price`
      }
      if (!is.null(self$`price_inc_tax`)) {
        OrderCalculateShippingRateObject[["price_inc_tax"]] <-
          self$`price_inc_tax`
      }
      if (!is.null(self$`tax`)) {
        OrderCalculateShippingRateObject[["tax"]] <-
          self$`tax`
      }
      if (!is.null(self$`tax_rate`)) {
        OrderCalculateShippingRateObject[["tax_rate"]] <-
          self$`tax_rate`
      }
      if (!is.null(self$`additional_fields`)) {
        OrderCalculateShippingRateObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        OrderCalculateShippingRateObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(OrderCalculateShippingRateObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderCalculateShippingRate
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderCalculateShippingRate
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`code`)) {
        self$`code` <- this_object$`code`
      }
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`price`)) {
        self$`price` <- this_object$`price`
      }
      if (!is.null(this_object$`price_inc_tax`)) {
        self$`price_inc_tax` <- this_object$`price_inc_tax`
      }
      if (!is.null(this_object$`tax`)) {
        self$`tax` <- this_object$`tax`
      }
      if (!is.null(this_object$`tax_rate`)) {
        self$`tax_rate` <- this_object$`tax_rate`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return OrderCalculateShippingRate in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderCalculateShippingRate
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderCalculateShippingRate
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`code` <- this_object$`code`
      self$`name` <- this_object$`name`
      self$`price` <- this_object$`price`
      self$`price_inc_tax` <- this_object$`price_inc_tax`
      self$`tax` <- this_object$`tax`
      self$`tax_rate` <- this_object$`tax_rate`
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to OrderCalculateShippingRate and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of OrderCalculateShippingRate
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# OrderCalculateShippingRate$unlock()
#
## Below is an example to define the print function
# OrderCalculateShippingRate$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# OrderCalculateShippingRate$lock()

