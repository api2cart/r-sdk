#' Create a new ParamDefinitionFilteringConditionsFilterGroup
#'
#' @description
#' ParamDefinitionFilteringConditionsFilterGroup Class
#'
#' @docType class
#' @title ParamDefinitionFilteringConditionsFilterGroup
#' @description ParamDefinitionFilteringConditionsFilterGroup Class
#' @format An \code{R6Class} generator object
#' @field and  list(object) [optional]
#' @field or  list(object) [optional]
#' @field not  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ParamDefinitionFilteringConditionsFilterGroup <- R6::R6Class(
  "ParamDefinitionFilteringConditionsFilterGroup",
  public = list(
    `and` = NULL,
    `or` = NULL,
    `not` = NULL,

    #' @description
    #' Initialize a new ParamDefinitionFilteringConditionsFilterGroup class.
    #'
    #' @param and and
    #' @param or or
    #' @param not not
    #' @param ... Other optional arguments.
    initialize = function(`and` = NULL, `or` = NULL, `not` = NULL, ...) {
      if (!is.null(`and`)) {
        stopifnot(is.vector(`and`), length(`and`) != 0)
        sapply(`and`, function(x) stopifnot(is.character(x)))
        self$`and` <- `and`
      }
      if (!is.null(`or`)) {
        stopifnot(is.vector(`or`), length(`or`) != 0)
        sapply(`or`, function(x) stopifnot(is.character(x)))
        self$`or` <- `or`
      }
      if (!is.null(`not`)) {
        self$`not` <- `not`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ParamDefinitionFilteringConditionsFilterGroup as a base R list.
    #' @examples
    #' # convert array of ParamDefinitionFilteringConditionsFilterGroup (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ParamDefinitionFilteringConditionsFilterGroup to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ParamDefinitionFilteringConditionsFilterGroupObject <- list()
      if (!is.null(self$`and`)) {
        ParamDefinitionFilteringConditionsFilterGroupObject[["and"]] <-
          self$`and`
      }
      if (!is.null(self$`or`)) {
        ParamDefinitionFilteringConditionsFilterGroupObject[["or"]] <-
          self$`or`
      }
      if (!is.null(self$`not`)) {
        ParamDefinitionFilteringConditionsFilterGroupObject[["not"]] <-
          self$`not`
      }
      return(ParamDefinitionFilteringConditionsFilterGroupObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ParamDefinitionFilteringConditionsFilterGroup
    #'
    #' @param input_json the JSON input
    #' @return the instance of ParamDefinitionFilteringConditionsFilterGroup
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`and`)) {
        self$`and` <- ApiClient$new()$deserializeObj(this_object$`and`, "array[object]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`or`)) {
        self$`or` <- ApiClient$new()$deserializeObj(this_object$`or`, "array[object]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`not`)) {
        self$`not` <- this_object$`not`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ParamDefinitionFilteringConditionsFilterGroup in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ParamDefinitionFilteringConditionsFilterGroup
    #'
    #' @param input_json the JSON input
    #' @return the instance of ParamDefinitionFilteringConditionsFilterGroup
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`and` <- ApiClient$new()$deserializeObj(this_object$`and`, "array[object]", loadNamespace("openapi"))
      self$`or` <- ApiClient$new()$deserializeObj(this_object$`or`, "array[object]", loadNamespace("openapi"))
      self$`not` <- this_object$`not`
      self
    },

    #' @description
    #' Validate JSON input with respect to ParamDefinitionFilteringConditionsFilterGroup and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ParamDefinitionFilteringConditionsFilterGroup
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ParamDefinitionFilteringConditionsFilterGroup$unlock()
#
## Below is an example to define the print function
# ParamDefinitionFilteringConditionsFilterGroup$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ParamDefinitionFilteringConditionsFilterGroup$lock()

