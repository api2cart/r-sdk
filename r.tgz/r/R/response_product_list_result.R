#' Create a new ResponseProductListResult
#'
#' @description
#' ResponseProductListResult Class
#'
#' @docType class
#' @title ResponseProductListResult
#' @description ResponseProductListResult Class
#' @format An \code{R6Class} generator object
#' @field products_count  integer [optional]
#' @field product  list(\link{Product}) [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ResponseProductListResult <- R6::R6Class(
  "ResponseProductListResult",
  public = list(
    `products_count` = NULL,
    `product` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new ResponseProductListResult class.
    #'
    #' @param products_count products_count
    #' @param product product
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`products_count` = NULL, `product` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`products_count`)) {
        if (!(is.numeric(`products_count`) && length(`products_count`) == 1)) {
          stop(paste("Error! Invalid data for `products_count`. Must be an integer:", `products_count`))
        }
        self$`products_count` <- `products_count`
      }
      if (!is.null(`product`)) {
        stopifnot(is.vector(`product`), length(`product`) != 0)
        sapply(`product`, function(x) stopifnot(R6::is.R6(x)))
        self$`product` <- `product`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ResponseProductListResult as a base R list.
    #' @examples
    #' # convert array of ResponseProductListResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ResponseProductListResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ResponseProductListResultObject <- list()
      if (!is.null(self$`products_count`)) {
        ResponseProductListResultObject[["products_count"]] <-
          self$`products_count`
      }
      if (!is.null(self$`product`)) {
        ResponseProductListResultObject[["product"]] <-
          lapply(self$`product`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`additional_fields`)) {
        ResponseProductListResultObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        ResponseProductListResultObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(ResponseProductListResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ResponseProductListResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ResponseProductListResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`products_count`)) {
        self$`products_count` <- this_object$`products_count`
      }
      if (!is.null(this_object$`product`)) {
        self$`product` <- ApiClient$new()$deserializeObj(this_object$`product`, "array[Product]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ResponseProductListResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ResponseProductListResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ResponseProductListResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`products_count` <- this_object$`products_count`
      self$`product` <- ApiClient$new()$deserializeObj(this_object$`product`, "array[Product]", loadNamespace("openapi"))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to ResponseProductListResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ResponseProductListResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ResponseProductListResult$unlock()
#
## Below is an example to define the print function
# ResponseProductListResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ResponseProductListResult$lock()

