#' Create a new CategoryAddBatchPayloadInnerImagesInner
#'
#' @description
#' CategoryAddBatchPayloadInnerImagesInner Class
#'
#' @docType class
#' @title CategoryAddBatchPayloadInnerImagesInner
#' @description CategoryAddBatchPayloadInnerImagesInner Class
#' @format An \code{R6Class} generator object
#' @field url  character
#' @field image_name  character [optional]
#' @field type  character [optional]
#' @field label  character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
CategoryAddBatchPayloadInnerImagesInner <- R6::R6Class(
  "CategoryAddBatchPayloadInnerImagesInner",
  public = list(
    `url` = NULL,
    `image_name` = NULL,
    `type` = NULL,
    `label` = NULL,

    #' @description
    #' Initialize a new CategoryAddBatchPayloadInnerImagesInner class.
    #'
    #' @param url url
    #' @param image_name image_name
    #' @param type type
    #' @param label label
    #' @param ... Other optional arguments.
    initialize = function(`url`, `image_name` = NULL, `type` = NULL, `label` = NULL, ...) {
      if (!missing(`url`)) {
        if (!(is.character(`url`) && length(`url`) == 1)) {
          stop(paste("Error! Invalid data for `url`. Must be a string:", `url`))
        }
        self$`url` <- `url`
      }
      if (!is.null(`image_name`)) {
        if (!(is.character(`image_name`) && length(`image_name`) == 1)) {
          stop(paste("Error! Invalid data for `image_name`. Must be a string:", `image_name`))
        }
        self$`image_name` <- `image_name`
      }
      if (!is.null(`type`)) {
        if (!(is.character(`type`) && length(`type`) == 1)) {
          stop(paste("Error! Invalid data for `type`. Must be a string:", `type`))
        }
        self$`type` <- `type`
      }
      if (!is.null(`label`)) {
        if (!(is.character(`label`) && length(`label`) == 1)) {
          stop(paste("Error! Invalid data for `label`. Must be a string:", `label`))
        }
        self$`label` <- `label`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return CategoryAddBatchPayloadInnerImagesInner as a base R list.
    #' @examples
    #' # convert array of CategoryAddBatchPayloadInnerImagesInner (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert CategoryAddBatchPayloadInnerImagesInner to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      CategoryAddBatchPayloadInnerImagesInnerObject <- list()
      if (!is.null(self$`url`)) {
        CategoryAddBatchPayloadInnerImagesInnerObject[["url"]] <-
          self$`url`
      }
      if (!is.null(self$`image_name`)) {
        CategoryAddBatchPayloadInnerImagesInnerObject[["image_name"]] <-
          self$`image_name`
      }
      if (!is.null(self$`type`)) {
        CategoryAddBatchPayloadInnerImagesInnerObject[["type"]] <-
          self$`type`
      }
      if (!is.null(self$`label`)) {
        CategoryAddBatchPayloadInnerImagesInnerObject[["label"]] <-
          self$`label`
      }
      return(CategoryAddBatchPayloadInnerImagesInnerObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of CategoryAddBatchPayloadInnerImagesInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of CategoryAddBatchPayloadInnerImagesInner
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`url`)) {
        self$`url` <- this_object$`url`
      }
      if (!is.null(this_object$`image_name`)) {
        self$`image_name` <- this_object$`image_name`
      }
      if (!is.null(this_object$`type`)) {
        self$`type` <- this_object$`type`
      }
      if (!is.null(this_object$`label`)) {
        self$`label` <- this_object$`label`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return CategoryAddBatchPayloadInnerImagesInner in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of CategoryAddBatchPayloadInnerImagesInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of CategoryAddBatchPayloadInnerImagesInner
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`url` <- this_object$`url`
      self$`image_name` <- this_object$`image_name`
      self$`type` <- this_object$`type`
      self$`label` <- this_object$`label`
      self
    },

    #' @description
    #' Validate JSON input with respect to CategoryAddBatchPayloadInnerImagesInner and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
      # check the required field `url`
      if (!is.null(input_json$`url`)) {
        if (!(is.character(input_json$`url`) && length(input_json$`url`) == 1)) {
          stop(paste("Error! Invalid data for `url`. Must be a string:", input_json$`url`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for CategoryAddBatchPayloadInnerImagesInner: the required field `url` is missing."))
      }
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of CategoryAddBatchPayloadInnerImagesInner
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      # check if the required `url` is null
      if (is.null(self$`url`)) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      # check if the required `url` is null
      if (is.null(self$`url`)) {
        invalid_fields["url"] <- "Non-nullable required field `url` cannot be null."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# CategoryAddBatchPayloadInnerImagesInner$unlock()
#
## Below is an example to define the print function
# CategoryAddBatchPayloadInnerImagesInner$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# CategoryAddBatchPayloadInnerImagesInner$lock()

