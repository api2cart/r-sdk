#' Create a new OrderInvoiceAdd
#'
#' @description
#' OrderInvoiceAdd Class
#'
#' @docType class
#' @title OrderInvoiceAdd
#' @description OrderInvoiceAdd Class
#' @format An \code{R6Class} generator object
#' @field order_id Defines the order the document is uploaded for character [optional]
#' @field shipment_id Defines the shipment of the order the document is for. Required when the order was shipped in several shipments character [optional]
#' @field store_id Defines the store of the order. The store of the order is taken when not specified character [optional]
#' @field number Defines the number of the invoice or credit note as printed on the document character
#' @field document_type Defines whether the document is an invoice or a credit note for a refund or return character [optional]
#' @field transaction_id Defines the refund or return transaction the credit note is issued for. Required when document_type is credit_note character [optional]
#' @field total_price Defines the total amount of the document, VAT included. When specified, it must match the total the store calculated for the order or shipment. For sellers with VAT Calculation Service Option 2 Amazon requires both total_price and tax_price, otherwise it rejects the feed after processing numeric [optional]
#' @field tax_price Defines the total VAT amount of the document. When specified, it must match the VAT the store calculated for the order or shipment. For sellers with VAT Calculation Service Option 2 Amazon requires both total_price and tax_price, otherwise it rejects the feed after processing numeric [optional]
#' @field url Defines the public URL of the PDF document. Required if content is not specified character [optional]
#' @field content Defines the PDF document encoded in base64. Required if url is not specified character [optional]
#' @field idempotency_key A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong> character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
OrderInvoiceAdd <- R6::R6Class(
  "OrderInvoiceAdd",
  public = list(
    `order_id` = NULL,
    `shipment_id` = NULL,
    `store_id` = NULL,
    `number` = NULL,
    `document_type` = NULL,
    `transaction_id` = NULL,
    `total_price` = NULL,
    `tax_price` = NULL,
    `url` = NULL,
    `content` = NULL,
    `idempotency_key` = NULL,

    #' @description
    #' Initialize a new OrderInvoiceAdd class.
    #'
    #' @param number Defines the number of the invoice or credit note as printed on the document
    #' @param order_id Defines the order the document is uploaded for
    #' @param shipment_id Defines the shipment of the order the document is for. Required when the order was shipped in several shipments
    #' @param store_id Defines the store of the order. The store of the order is taken when not specified
    #' @param document_type Defines whether the document is an invoice or a credit note for a refund or return. Default to "invoice".
    #' @param transaction_id Defines the refund or return transaction the credit note is issued for. Required when document_type is credit_note
    #' @param total_price Defines the total amount of the document, VAT included. When specified, it must match the total the store calculated for the order or shipment. For sellers with VAT Calculation Service Option 2 Amazon requires both total_price and tax_price, otherwise it rejects the feed after processing
    #' @param tax_price Defines the total VAT amount of the document. When specified, it must match the VAT the store calculated for the order or shipment. For sellers with VAT Calculation Service Option 2 Amazon requires both total_price and tax_price, otherwise it rejects the feed after processing
    #' @param url Defines the public URL of the PDF document. Required if content is not specified
    #' @param content Defines the PDF document encoded in base64. Required if url is not specified
    #' @param idempotency_key A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong>
    #' @param ... Other optional arguments.
    initialize = function(`number`, `order_id` = NULL, `shipment_id` = NULL, `store_id` = NULL, `document_type` = "invoice", `transaction_id` = NULL, `total_price` = NULL, `tax_price` = NULL, `url` = NULL, `content` = NULL, `idempotency_key` = NULL, ...) {
      if (!missing(`number`)) {
        if (!(is.character(`number`) && length(`number`) == 1)) {
          stop(paste("Error! Invalid data for `number`. Must be a string:", `number`))
        }
        self$`number` <- `number`
      }
      if (!is.null(`order_id`)) {
        if (!(is.character(`order_id`) && length(`order_id`) == 1)) {
          stop(paste("Error! Invalid data for `order_id`. Must be a string:", `order_id`))
        }
        self$`order_id` <- `order_id`
      }
      if (!is.null(`shipment_id`)) {
        if (!(is.character(`shipment_id`) && length(`shipment_id`) == 1)) {
          stop(paste("Error! Invalid data for `shipment_id`. Must be a string:", `shipment_id`))
        }
        self$`shipment_id` <- `shipment_id`
      }
      if (!is.null(`store_id`)) {
        if (!(is.character(`store_id`) && length(`store_id`) == 1)) {
          stop(paste("Error! Invalid data for `store_id`. Must be a string:", `store_id`))
        }
        self$`store_id` <- `store_id`
      }
      if (!is.null(`document_type`)) {
        if (!(is.character(`document_type`) && length(`document_type`) == 1)) {
          stop(paste("Error! Invalid data for `document_type`. Must be a string:", `document_type`))
        }
        self$`document_type` <- `document_type`
      }
      if (!is.null(`transaction_id`)) {
        if (!(is.character(`transaction_id`) && length(`transaction_id`) == 1)) {
          stop(paste("Error! Invalid data for `transaction_id`. Must be a string:", `transaction_id`))
        }
        self$`transaction_id` <- `transaction_id`
      }
      if (!is.null(`total_price`)) {
        self$`total_price` <- `total_price`
      }
      if (!is.null(`tax_price`)) {
        self$`tax_price` <- `tax_price`
      }
      if (!is.null(`url`)) {
        if (!(is.character(`url`) && length(`url`) == 1)) {
          stop(paste("Error! Invalid data for `url`. Must be a string:", `url`))
        }
        self$`url` <- `url`
      }
      if (!is.null(`content`)) {
        if (!(is.character(`content`) && length(`content`) == 1)) {
          stop(paste("Error! Invalid data for `content`. Must be a string:", `content`))
        }
        self$`content` <- `content`
      }
      if (!is.null(`idempotency_key`)) {
        if (!(is.character(`idempotency_key`) && length(`idempotency_key`) == 1)) {
          stop(paste("Error! Invalid data for `idempotency_key`. Must be a string:", `idempotency_key`))
        }
        self$`idempotency_key` <- `idempotency_key`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return OrderInvoiceAdd as a base R list.
    #' @examples
    #' # convert array of OrderInvoiceAdd (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert OrderInvoiceAdd to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      OrderInvoiceAddObject <- list()
      if (!is.null(self$`order_id`)) {
        OrderInvoiceAddObject[["order_id"]] <-
          self$`order_id`
      }
      if (!is.null(self$`shipment_id`)) {
        OrderInvoiceAddObject[["shipment_id"]] <-
          self$`shipment_id`
      }
      if (!is.null(self$`store_id`)) {
        OrderInvoiceAddObject[["store_id"]] <-
          self$`store_id`
      }
      if (!is.null(self$`number`)) {
        OrderInvoiceAddObject[["number"]] <-
          self$`number`
      }
      if (!is.null(self$`document_type`)) {
        OrderInvoiceAddObject[["document_type"]] <-
          self$`document_type`
      }
      if (!is.null(self$`transaction_id`)) {
        OrderInvoiceAddObject[["transaction_id"]] <-
          self$`transaction_id`
      }
      if (!is.null(self$`total_price`)) {
        OrderInvoiceAddObject[["total_price"]] <-
          self$`total_price`
      }
      if (!is.null(self$`tax_price`)) {
        OrderInvoiceAddObject[["tax_price"]] <-
          self$`tax_price`
      }
      if (!is.null(self$`url`)) {
        OrderInvoiceAddObject[["url"]] <-
          self$`url`
      }
      if (!is.null(self$`content`)) {
        OrderInvoiceAddObject[["content"]] <-
          self$`content`
      }
      if (!is.null(self$`idempotency_key`)) {
        OrderInvoiceAddObject[["idempotency_key"]] <-
          self$`idempotency_key`
      }
      return(OrderInvoiceAddObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderInvoiceAdd
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderInvoiceAdd
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`order_id`)) {
        self$`order_id` <- this_object$`order_id`
      }
      if (!is.null(this_object$`shipment_id`)) {
        self$`shipment_id` <- this_object$`shipment_id`
      }
      if (!is.null(this_object$`store_id`)) {
        self$`store_id` <- this_object$`store_id`
      }
      if (!is.null(this_object$`number`)) {
        self$`number` <- this_object$`number`
      }
      if (!is.null(this_object$`document_type`)) {
        self$`document_type` <- this_object$`document_type`
      }
      if (!is.null(this_object$`transaction_id`)) {
        self$`transaction_id` <- this_object$`transaction_id`
      }
      if (!is.null(this_object$`total_price`)) {
        self$`total_price` <- this_object$`total_price`
      }
      if (!is.null(this_object$`tax_price`)) {
        self$`tax_price` <- this_object$`tax_price`
      }
      if (!is.null(this_object$`url`)) {
        self$`url` <- this_object$`url`
      }
      if (!is.null(this_object$`content`)) {
        self$`content` <- this_object$`content`
      }
      if (!is.null(this_object$`idempotency_key`)) {
        self$`idempotency_key` <- this_object$`idempotency_key`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return OrderInvoiceAdd in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderInvoiceAdd
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderInvoiceAdd
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`order_id` <- this_object$`order_id`
      self$`shipment_id` <- this_object$`shipment_id`
      self$`store_id` <- this_object$`store_id`
      self$`number` <- this_object$`number`
      self$`document_type` <- this_object$`document_type`
      self$`transaction_id` <- this_object$`transaction_id`
      self$`total_price` <- this_object$`total_price`
      self$`tax_price` <- this_object$`tax_price`
      self$`url` <- this_object$`url`
      self$`content` <- this_object$`content`
      self$`idempotency_key` <- this_object$`idempotency_key`
      self
    },

    #' @description
    #' Validate JSON input with respect to OrderInvoiceAdd and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
      # check the required field `number`
      if (!is.null(input_json$`number`)) {
        if (!(is.character(input_json$`number`) && length(input_json$`number`) == 1)) {
          stop(paste("Error! Invalid data for `number`. Must be a string:", input_json$`number`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for OrderInvoiceAdd: the required field `number` is missing."))
      }
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of OrderInvoiceAdd
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      # check if the required `number` is null
      if (is.null(self$`number`)) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      # check if the required `number` is null
      if (is.null(self$`number`)) {
        invalid_fields["number"] <- "Non-nullable required field `number` cannot be null."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# OrderInvoiceAdd$unlock()
#
## Below is an example to define the print function
# OrderInvoiceAdd$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# OrderInvoiceAdd$lock()

