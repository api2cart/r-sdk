#' Create a new ProductAddSpecificsInnerFoodDetails
#'
#' @description
#' ProductAddSpecificsInnerFoodDetails Class
#'
#' @docType class
#' @title ProductAddSpecificsInnerFoodDetails
#' @description ProductAddSpecificsInnerFoodDetails Class
#' @format An \code{R6Class} generator object
#' @field calories  numeric
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductAddSpecificsInnerFoodDetails <- R6::R6Class(
  "ProductAddSpecificsInnerFoodDetails",
  public = list(
    `calories` = NULL,

    #' @description
    #' Initialize a new ProductAddSpecificsInnerFoodDetails class.
    #'
    #' @param calories calories
    #' @param ... Other optional arguments.
    initialize = function(`calories`, ...) {
      if (!missing(`calories`)) {
        self$`calories` <- `calories`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductAddSpecificsInnerFoodDetails as a base R list.
    #' @examples
    #' # convert array of ProductAddSpecificsInnerFoodDetails (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductAddSpecificsInnerFoodDetails to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductAddSpecificsInnerFoodDetailsObject <- list()
      if (!is.null(self$`calories`)) {
        ProductAddSpecificsInnerFoodDetailsObject[["calories"]] <-
          self$`calories`
      }
      return(ProductAddSpecificsInnerFoodDetailsObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductAddSpecificsInnerFoodDetails
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductAddSpecificsInnerFoodDetails
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`calories`)) {
        self$`calories` <- this_object$`calories`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductAddSpecificsInnerFoodDetails in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductAddSpecificsInnerFoodDetails
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductAddSpecificsInnerFoodDetails
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`calories` <- this_object$`calories`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductAddSpecificsInnerFoodDetails and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
      # check the required field `calories`
      if (!is.null(input_json$`calories`)) {
      } else {
        stop(paste("The JSON input `", input, "` is invalid for ProductAddSpecificsInnerFoodDetails: the required field `calories` is missing."))
      }
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductAddSpecificsInnerFoodDetails
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      # check if the required `calories` is null
      if (is.null(self$`calories`)) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      # check if the required `calories` is null
      if (is.null(self$`calories`)) {
        invalid_fields["calories"] <- "Non-nullable required field `calories` cannot be null."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductAddSpecificsInnerFoodDetails$unlock()
#
## Below is an example to define the print function
# ProductAddSpecificsInnerFoodDetails$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductAddSpecificsInnerFoodDetails$lock()

