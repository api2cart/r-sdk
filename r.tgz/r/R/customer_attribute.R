#' Create a new CustomerAttribute
#'
#' @description
#' CustomerAttribute Class
#'
#' @docType class
#' @title CustomerAttribute
#' @description CustomerAttribute Class
#' @format An \code{R6Class} generator object
#' @field attribute_id  character [optional]
#' @field code  character [optional]
#' @field name  character [optional]
#' @field type  character [optional]
#' @field values  list(\link{CustomerAttributeValue}) [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
CustomerAttribute <- R6::R6Class(
  "CustomerAttribute",
  public = list(
    `attribute_id` = NULL,
    `code` = NULL,
    `name` = NULL,
    `type` = NULL,
    `values` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new CustomerAttribute class.
    #'
    #' @param attribute_id attribute_id
    #' @param code code
    #' @param name name
    #' @param type type
    #' @param values values
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`attribute_id` = NULL, `code` = NULL, `name` = NULL, `type` = NULL, `values` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`attribute_id`)) {
        if (!(is.character(`attribute_id`) && length(`attribute_id`) == 1)) {
          stop(paste("Error! Invalid data for `attribute_id`. Must be a string:", `attribute_id`))
        }
        self$`attribute_id` <- `attribute_id`
      }
      if (!is.null(`code`)) {
        if (!(is.character(`code`) && length(`code`) == 1)) {
          stop(paste("Error! Invalid data for `code`. Must be a string:", `code`))
        }
        self$`code` <- `code`
      }
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`type`)) {
        if (!(is.character(`type`) && length(`type`) == 1)) {
          stop(paste("Error! Invalid data for `type`. Must be a string:", `type`))
        }
        self$`type` <- `type`
      }
      if (!is.null(`values`)) {
        stopifnot(is.vector(`values`), length(`values`) != 0)
        sapply(`values`, function(x) stopifnot(R6::is.R6(x)))
        self$`values` <- `values`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return CustomerAttribute as a base R list.
    #' @examples
    #' # convert array of CustomerAttribute (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert CustomerAttribute to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      CustomerAttributeObject <- list()
      if (!is.null(self$`attribute_id`)) {
        CustomerAttributeObject[["attribute_id"]] <-
          self$`attribute_id`
      }
      if (!is.null(self$`code`)) {
        CustomerAttributeObject[["code"]] <-
          self$`code`
      }
      if (!is.null(self$`name`)) {
        CustomerAttributeObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`type`)) {
        CustomerAttributeObject[["type"]] <-
          self$`type`
      }
      if (!is.null(self$`values`)) {
        CustomerAttributeObject[["values"]] <-
          lapply(self$`values`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`additional_fields`)) {
        CustomerAttributeObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        CustomerAttributeObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(CustomerAttributeObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of CustomerAttribute
    #'
    #' @param input_json the JSON input
    #' @return the instance of CustomerAttribute
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`attribute_id`)) {
        self$`attribute_id` <- this_object$`attribute_id`
      }
      if (!is.null(this_object$`code`)) {
        self$`code` <- this_object$`code`
      }
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`type`)) {
        self$`type` <- this_object$`type`
      }
      if (!is.null(this_object$`values`)) {
        self$`values` <- ApiClient$new()$deserializeObj(this_object$`values`, "array[CustomerAttributeValue]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return CustomerAttribute in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of CustomerAttribute
    #'
    #' @param input_json the JSON input
    #' @return the instance of CustomerAttribute
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`attribute_id` <- this_object$`attribute_id`
      self$`code` <- this_object$`code`
      self$`name` <- this_object$`name`
      self$`type` <- this_object$`type`
      self$`values` <- ApiClient$new()$deserializeObj(this_object$`values`, "array[CustomerAttributeValue]", loadNamespace("openapi"))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to CustomerAttribute and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of CustomerAttribute
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# CustomerAttribute$unlock()
#
## Below is an example to define the print function
# CustomerAttribute$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# CustomerAttribute$lock()

