#' Create a new Currency
#'
#' @description
#' Currency Class
#'
#' @docType class
#' @title Currency
#' @description Currency Class
#' @format An \code{R6Class} generator object
#' @field id  character [optional]
#' @field name  character [optional]
#' @field iso3  character [optional]
#' @field symbol_left  character [optional]
#' @field symbol_right  character [optional]
#' @field rate  numeric [optional]
#' @field avail  character [optional]
#' @field default  character [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
Currency <- R6::R6Class(
  "Currency",
  public = list(
    `id` = NULL,
    `name` = NULL,
    `iso3` = NULL,
    `symbol_left` = NULL,
    `symbol_right` = NULL,
    `rate` = NULL,
    `avail` = NULL,
    `default` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new Currency class.
    #'
    #' @param id id
    #' @param name name
    #' @param iso3 iso3
    #' @param symbol_left symbol_left
    #' @param symbol_right symbol_right
    #' @param rate rate
    #' @param avail avail
    #' @param default default
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `name` = NULL, `iso3` = NULL, `symbol_left` = NULL, `symbol_right` = NULL, `rate` = NULL, `avail` = NULL, `default` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`iso3`)) {
        if (!(is.character(`iso3`) && length(`iso3`) == 1)) {
          stop(paste("Error! Invalid data for `iso3`. Must be a string:", `iso3`))
        }
        self$`iso3` <- `iso3`
      }
      if (!is.null(`symbol_left`)) {
        if (!(is.character(`symbol_left`) && length(`symbol_left`) == 1)) {
          stop(paste("Error! Invalid data for `symbol_left`. Must be a string:", `symbol_left`))
        }
        self$`symbol_left` <- `symbol_left`
      }
      if (!is.null(`symbol_right`)) {
        if (!(is.character(`symbol_right`) && length(`symbol_right`) == 1)) {
          stop(paste("Error! Invalid data for `symbol_right`. Must be a string:", `symbol_right`))
        }
        self$`symbol_right` <- `symbol_right`
      }
      if (!is.null(`rate`)) {
        self$`rate` <- `rate`
      }
      if (!is.null(`avail`)) {
        if (!(is.logical(`avail`) && length(`avail`) == 1)) {
          stop(paste("Error! Invalid data for `avail`. Must be a boolean:", `avail`))
        }
        self$`avail` <- `avail`
      }
      if (!is.null(`default`)) {
        if (!(is.logical(`default`) && length(`default`) == 1)) {
          stop(paste("Error! Invalid data for `default`. Must be a boolean:", `default`))
        }
        self$`default` <- `default`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return Currency as a base R list.
    #' @examples
    #' # convert array of Currency (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert Currency to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      CurrencyObject <- list()
      if (!is.null(self$`id`)) {
        CurrencyObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`name`)) {
        CurrencyObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`iso3`)) {
        CurrencyObject[["iso3"]] <-
          self$`iso3`
      }
      if (!is.null(self$`symbol_left`)) {
        CurrencyObject[["symbol_left"]] <-
          self$`symbol_left`
      }
      if (!is.null(self$`symbol_right`)) {
        CurrencyObject[["symbol_right"]] <-
          self$`symbol_right`
      }
      if (!is.null(self$`rate`)) {
        CurrencyObject[["rate"]] <-
          self$`rate`
      }
      if (!is.null(self$`avail`)) {
        CurrencyObject[["avail"]] <-
          self$`avail`
      }
      if (!is.null(self$`default`)) {
        CurrencyObject[["default"]] <-
          self$`default`
      }
      if (!is.null(self$`additional_fields`)) {
        CurrencyObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        CurrencyObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(CurrencyObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of Currency
    #'
    #' @param input_json the JSON input
    #' @return the instance of Currency
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`iso3`)) {
        self$`iso3` <- this_object$`iso3`
      }
      if (!is.null(this_object$`symbol_left`)) {
        self$`symbol_left` <- this_object$`symbol_left`
      }
      if (!is.null(this_object$`symbol_right`)) {
        self$`symbol_right` <- this_object$`symbol_right`
      }
      if (!is.null(this_object$`rate`)) {
        self$`rate` <- this_object$`rate`
      }
      if (!is.null(this_object$`avail`)) {
        self$`avail` <- this_object$`avail`
      }
      if (!is.null(this_object$`default`)) {
        self$`default` <- this_object$`default`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return Currency in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of Currency
    #'
    #' @param input_json the JSON input
    #' @return the instance of Currency
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`name` <- this_object$`name`
      self$`iso3` <- this_object$`iso3`
      self$`symbol_left` <- this_object$`symbol_left`
      self$`symbol_right` <- this_object$`symbol_right`
      self$`rate` <- this_object$`rate`
      self$`avail` <- this_object$`avail`
      self$`default` <- this_object$`default`
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to Currency and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of Currency
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# Currency$unlock()
#
## Below is an example to define the print function
# Currency$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# Currency$lock()

