#' Create a new ProductAdd
#'
#' @description
#' ProductAdd Class
#'
#' @docType class
#' @title ProductAdd
#' @description ProductAdd Class
#' @format An \code{R6Class} generator object
#' @field name Defines product's name that has to be added character
#' @field model Defines product's model that has to be added character
#' @field description Defines product's description that has to be added character
#' @field price Defines product's price that has to be added numeric
#' @field sku Defines product's sku that has to be added character [optional]
#' @field short_description Defines short description character [optional]
#' @field type Defines product's type character [optional]
#' @field status Defines product's status character [optional]
#' @field visible Set visibility status character [optional]
#' @field category_id Defines product add that is specified by category id character [optional]
#' @field categories_ids Defines product add that is specified by comma-separated categories id character [optional]
#' @field product_class A categorization for the product character [optional]
#' @field product_type A categorization for the product character [optional]
#' @field is_virtual Defines whether the product is virtual character [optional]
#' @field downloadable Defines whether the product is downloadable character [optional]
#' @field is_supply If true, it indicates the product as a supply, otherwise it indicates that it is a finished product. character [optional]
#' @field available_for_view Specifies the set of visible/invisible products for users character [optional]
#' @field available_for_sale Specifies the set of visible/invisible products for sale character [optional]
#' @field store_id Store Id character [optional]
#' @field stores_ids Assign product to the stores that is specified by comma-separated stores' id character [optional]
#' @field lang_id Language id character [optional]
#' @field old_price Defines product's old price numeric [optional]
#' @field special_price Defines product's model that has to be added numeric [optional]
#' @field wholesale_price This parameter is deprecated. Please use the <strong>old_price</strong> parameter instead. numeric [optional]
#' @field cost_price Defines new product's cost price numeric [optional]
#' @field fixed_cost_shipping_price Specifies product's fixed cost shipping price numeric [optional]
#' @field tier_prices Defines product's tier prices list(\link{ProductAddTierPricesInner}) [optional]
#' @field group_prices Defines product's group prices list(\link{ProductAddGroupPricesInner}) [optional]
#' @field buyitnow_price Defines buy it now value numeric [optional]
#' @field reserve_price Defines reserve price value numeric [optional]
#' @field measure_unit Unit for the price per unit. Must be in allowed list character [optional]
#' @field unit_price Defines new product's unit price numeric [optional]
#' @field prices_inc_tax Indicates whether prices include tax. character [optional]
#' @field quantity Defines product's quantity that has to be added numeric [optional]
#' @field in_stock Set stock status character [optional]
#' @field manage_stock Defines inventory tracking for product character [optional]
#' @field warehouse_id This parameter is used for selecting a warehouse where you need to set/modify a product quantity. character [optional]
#' @field backorder_status Set backorder status character [optional]
#' @field min_order_quantity The minimum quantity an order must contain, to be eligible to purchase this product. numeric [optional]
#' @field max_order_quantity The maximum quantity an order can contain when purchasing the product. numeric [optional]
#' @field low_stock_threshold Specify the quantity threshold below which the product is considered low in stock numeric [optional]
#' @field weight Weight numeric [optional]
#' @field weight_unit Weight Unit character [optional]
#' @field width Defines product's width numeric [optional]
#' @field height Defines product's height numeric [optional]
#' @field length Defines product's length numeric [optional]
#' @field dimensions_unit Weight Unit character [optional]
#' @field barcode A barcode is a unique code composed of numbers used as a product identifier. character [optional]
#' @field upc Universal Product Code. A UPC (UPC-A) is a commonly used identifer for many different products. character [optional]
#' @field ean European Article Number. An EAN is a unique 8 or 13-digit identifier that many industries (such as book publishers) use to identify products. character [optional]
#' @field isbn International Standard Book Number. An ISBN is a unique identifier for books. character [optional]
#' @field gtin Global Trade Item Number. An GTIN is an identifier for trade items. character [optional]
#' @field mpn Manufacturer Part Number. A MPN is an identifier of a particular part design or material used. character [optional]
#' @field asin Amazon Standard Identification Number. character [optional]
#' @field product_reference Groups all variations, that you want to combine into one product. character [optional]
#' @field external_product_link External product link character [optional]
#' @field harmonized_system_code Harmonized System Code. An HSC is a 6-digit identifier that allows participating countries to classify traded goods on a common basis for customs purposes character [optional]
#' @field country_of_origin The country where the inventory item was made character [optional]
#' @field manufacturer Defines product's manufacturer character [optional]
#' @field manufacturer_id Defines product's manufacturer by manufacturer_id character [optional]
#' @field manufacturer_info  \link{ProductAddManufacturerInfo} [optional]
#' @field brand_name Defines product brand name character [optional]
#' @field image_url Image Url character [optional]
#' @field image_name Defines image's name character [optional]
#' @field additional_image_urls Image Url list(character) [optional]
#' @field files File Url list(\link{ProductAddFilesInner}) [optional]
#' @field size_chart  \link{ProductAddSizeChart} [optional]
#' @field related_products_ids Defines product's related products ids that has to be added character [optional]
#' @field up_sell_products_ids Defines product's up-sell products ids that has to be added character [optional]
#' @field cross_sell_products_ids Defines product's cross-sell products ids that has to be added character [optional]
#' @field attribute_set_name Defines product’s attribute set name in Magento character [optional]
#' @field attribute_name Defines product’s attribute name separated with a comma in Magento character [optional]
#' @field search_keywords Defines unique search keywords character [optional]
#' @field tags Product tags character [optional]
#' @field materials A list of material strings for materials used in the product. list(character) [optional]
#' @field certifications An array of product certifications. The list of possible certifications can be obtained using the \"<i>category.info</i>\" method (<i>additional_fields->rules->product_certifications</i>). list(\link{ProductAddCertificationsInner}) [optional]
#' @field specifics An array of Item Specific Name/Value pairs used by the seller to provide descriptive details of an item in a structured manner.         The list of possible specifications can be obtained using the category.info method (additional_fields->product_specifics).         <b>The structure of the parameter is different for specific platforms.</b> list(\link{ProductAddSpecificsInner}) [optional]
#' @field avail_from Allows to schedule a time in the future that the item becomes available. The value should be greater than the current date and time. character [optional]
#' @field sprice_create Defines the date of special price creation character [optional]
#' @field sprice_modified Defines the date of special price modification character [optional]
#' @field sprice_expire Defines the term of special price offer duration character [optional]
#' @field created_at Defines the date of entity creation character [optional]
#' @field auto_renew When true, automatically renews a listing upon its expiration. character [optional]
#' @field when_made An enumerated string for the era in which the maker made the product. character [optional]
#' @field meta_title Defines unique meta title for each entity character [optional]
#' @field meta_keywords Defines unique meta keywords for each entity character [optional]
#' @field meta_description Defines unique meta description of a entity character [optional]
#' @field url Defines unique product's URL character [optional]
#' @field seo_url Defines unique URL for SEO character [optional]
#' @field tax_class_id Defines tax classes where entity has to be added character [optional]
#' @field taxable Specifies whether a tax is charged character [optional]
#' @field sales_tax  \link{ProductAddSalesTax} [optional]
#' @field condition The human-readable label for the condition (e.g., \"New\"). character [optional]
#' @field condition_description Detailed description of the product condition. character [optional]
#' @field allow_display_condition Flag used to determine whether the product condition is shown to the customer on the product page. character [optional]
#' @field payment_methods Identifies the payment method (such as PayPal) that the seller will accept when the buyer pays for the item. Look at cart.info method response for allowed values.<hr><div style=\"font-style:normal\">Param structure:<div style=\"margin-left: 2\%;\"><code style=\"padding:0; background-color:#ffffff;font-size:85\%;font-family:monospace;\">payment_methods[0] = string</br>payment_methods[1] = string</br></code></div></div> list(character) [optional]
#' @field paypal_email Valid PayPal email address for the PayPal account that the seller will use if they offer PayPal as a payment method for the listing. character [optional]
#' @field shipping_template_id The numeric ID of the shipping template associated with the products in Etsy. You can find possible values in the \"cart.info\" API method response, in the field shipping_zones[]->id. integer [optional]
#' @field processing_profile_id The numeric ID of the processing profile (readiness state) for physical products in Etsy. You can find possible values in the \"cart.info\" API method response, in the field processing_profiles[]->readiness_state_id. integer [optional]
#' @field shipping_details The shipping details, including flat and calculated shipping costs and shipping insurance costs. Look at cart.info method response for allowed values.<hr><div style=\"font-style:normal\">Param structure:<div style=\"margin-left: 2\%;\"><code style=\"padding:0; background-color:#ffffff;font-size:85\%;font-family:monospace;\">shipping_details[0][<b>shipping_type</b>] = string </br>shipping_details[0][<b>shipping_service</b>] = string</br>shipping_details[0][<b>shipping_cost</b>] = decimal</br>shipping_details[1][<b>shipping_type</b>] = string </br>shipping_details[1][<b>shipping_service</b>] = string</br>shipping_details[1][<b>shipping_cost</b>] = decimal</br></code></div></div> list(\link{ProductAddShippingDetailsInner}) [optional]
#' @field is_free_shipping Specifies product's free shipping flag that has to be added character [optional]
#' @field delivery_code The delivery promise that applies to offer character [optional]
#' @field delivery_type Defines the type of the delivery. character [optional]
#' @field delivery_time Defines delivery time in days. integer [optional]
#' @field delivery_option_ids Defines delivery options for product by ids. character [optional]
#' @field package_details  \link{ProductAddPackageDetails} [optional]
#' @field logistic_info Defines product's logistic channel settings list(\link{ProductAddLogisticInfoInner}) [optional]
#' @field listing_duration Describes the number of days the seller wants the listing to be active. Look at cart.info method response for allowed values. character [optional]
#' @field listing_type Indicates the selling format of the marketplace listing. character [optional]
#' @field category_type Specifies the type of category (e.g., apparel or other) for the product being added. character [optional]
#' @field return_accepted Indicates whether the seller allows the buyer to return the item. character [optional]
#' @field seller_profiles  \link{ProductAddSellerProfiles} [optional]
#' @field auction_confidentiality_level This allows buyers to remain anonymous when the bid or buy an item. character [optional]
#' @field best_offer  \link{ProductAddBestOffer} [optional]
#' @field production_partner_ids Defines product's production partner ids that has to be added character [optional]
#' @field marketplace_item_properties String containing the JSON representation of the supplied data character [optional]
#' @field clear_cache Is cache clear required character [optional]
#' @field viewed_count Specifies the number of product's reviews integer [optional]
#' @field ordered_count Defines how many times the product was ordered integer [optional]
#' @field shop_section_id Add Shop Section Id integer [optional]
#' @field return_policy_id Add Return Policy Id integer [optional]
#' @field personalization_details  \link{ProductAddPersonalizationDetails} [optional]
#' @field personalization_questions Defines personalization questions for the listing as an array of question objects. Each question object supports the following fields: question_id (integer, nullable), question_text (string, 1-45 chars), instructions (string, nullable), question_type (string), required (boolean), max_allowed_characters (integer, nullable), max_allowed_files (integer, nullable), options (array, nullable). Cannot be used together with <strong>personalization_details</strong>. list(\link{ProductAddPersonalizationQuestionsInner}) [optional]
#' @field manufacturer_ids A comma-separated list of manufacturer IDs. Retrieve the IDs from the cart.info method. character [optional]
#' @field responsible_person_ids A comma-separated list of responsible person IDs. Retrieve the IDs from the cart.info method. character [optional]
#' @field idempotency_key A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong> character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductAdd <- R6::R6Class(
  "ProductAdd",
  public = list(
    `name` = NULL,
    `model` = NULL,
    `description` = NULL,
    `price` = NULL,
    `sku` = NULL,
    `short_description` = NULL,
    `type` = NULL,
    `status` = NULL,
    `visible` = NULL,
    `category_id` = NULL,
    `categories_ids` = NULL,
    `product_class` = NULL,
    `product_type` = NULL,
    `is_virtual` = NULL,
    `downloadable` = NULL,
    `is_supply` = NULL,
    `available_for_view` = NULL,
    `available_for_sale` = NULL,
    `store_id` = NULL,
    `stores_ids` = NULL,
    `lang_id` = NULL,
    `old_price` = NULL,
    `special_price` = NULL,
    `wholesale_price` = NULL,
    `cost_price` = NULL,
    `fixed_cost_shipping_price` = NULL,
    `tier_prices` = NULL,
    `group_prices` = NULL,
    `buyitnow_price` = NULL,
    `reserve_price` = NULL,
    `measure_unit` = NULL,
    `unit_price` = NULL,
    `prices_inc_tax` = NULL,
    `quantity` = NULL,
    `in_stock` = NULL,
    `manage_stock` = NULL,
    `warehouse_id` = NULL,
    `backorder_status` = NULL,
    `min_order_quantity` = NULL,
    `max_order_quantity` = NULL,
    `low_stock_threshold` = NULL,
    `weight` = NULL,
    `weight_unit` = NULL,
    `width` = NULL,
    `height` = NULL,
    `length` = NULL,
    `dimensions_unit` = NULL,
    `barcode` = NULL,
    `upc` = NULL,
    `ean` = NULL,
    `isbn` = NULL,
    `gtin` = NULL,
    `mpn` = NULL,
    `asin` = NULL,
    `product_reference` = NULL,
    `external_product_link` = NULL,
    `harmonized_system_code` = NULL,
    `country_of_origin` = NULL,
    `manufacturer` = NULL,
    `manufacturer_id` = NULL,
    `manufacturer_info` = NULL,
    `brand_name` = NULL,
    `image_url` = NULL,
    `image_name` = NULL,
    `additional_image_urls` = NULL,
    `files` = NULL,
    `size_chart` = NULL,
    `related_products_ids` = NULL,
    `up_sell_products_ids` = NULL,
    `cross_sell_products_ids` = NULL,
    `attribute_set_name` = NULL,
    `attribute_name` = NULL,
    `search_keywords` = NULL,
    `tags` = NULL,
    `materials` = NULL,
    `certifications` = NULL,
    `specifics` = NULL,
    `avail_from` = NULL,
    `sprice_create` = NULL,
    `sprice_modified` = NULL,
    `sprice_expire` = NULL,
    `created_at` = NULL,
    `auto_renew` = NULL,
    `when_made` = NULL,
    `meta_title` = NULL,
    `meta_keywords` = NULL,
    `meta_description` = NULL,
    `url` = NULL,
    `seo_url` = NULL,
    `tax_class_id` = NULL,
    `taxable` = NULL,
    `sales_tax` = NULL,
    `condition` = NULL,
    `condition_description` = NULL,
    `allow_display_condition` = NULL,
    `payment_methods` = NULL,
    `paypal_email` = NULL,
    `shipping_template_id` = NULL,
    `processing_profile_id` = NULL,
    `shipping_details` = NULL,
    `is_free_shipping` = NULL,
    `delivery_code` = NULL,
    `delivery_type` = NULL,
    `delivery_time` = NULL,
    `delivery_option_ids` = NULL,
    `package_details` = NULL,
    `logistic_info` = NULL,
    `listing_duration` = NULL,
    `listing_type` = NULL,
    `category_type` = NULL,
    `return_accepted` = NULL,
    `seller_profiles` = NULL,
    `auction_confidentiality_level` = NULL,
    `best_offer` = NULL,
    `production_partner_ids` = NULL,
    `marketplace_item_properties` = NULL,
    `clear_cache` = NULL,
    `viewed_count` = NULL,
    `ordered_count` = NULL,
    `shop_section_id` = NULL,
    `return_policy_id` = NULL,
    `personalization_details` = NULL,
    `personalization_questions` = NULL,
    `manufacturer_ids` = NULL,
    `responsible_person_ids` = NULL,
    `idempotency_key` = NULL,

    #' @description
    #' Initialize a new ProductAdd class.
    #'
    #' @param name Defines product's name that has to be added
    #' @param model Defines product's model that has to be added
    #' @param description Defines product's description that has to be added
    #' @param price Defines product's price that has to be added
    #' @param sku Defines product's sku that has to be added
    #' @param short_description Defines short description
    #' @param type Defines product's type. Default to "simple".
    #' @param status Defines product's status
    #' @param visible Set visibility status
    #' @param category_id Defines product add that is specified by category id
    #' @param categories_ids Defines product add that is specified by comma-separated categories id
    #' @param product_class A categorization for the product
    #' @param product_type A categorization for the product
    #' @param is_virtual Defines whether the product is virtual. Default to FALSE.
    #' @param downloadable Defines whether the product is downloadable. Default to FALSE.
    #' @param is_supply If true, it indicates the product as a supply, otherwise it indicates that it is a finished product.. Default to TRUE.
    #' @param available_for_view Specifies the set of visible/invisible products for users. Default to TRUE.
    #' @param available_for_sale Specifies the set of visible/invisible products for sale. Default to TRUE.
    #' @param store_id Store Id
    #' @param stores_ids Assign product to the stores that is specified by comma-separated stores' id
    #' @param lang_id Language id
    #' @param old_price Defines product's old price
    #' @param special_price Defines product's model that has to be added
    #' @param wholesale_price This parameter is deprecated. Please use the <strong>old_price</strong> parameter instead.
    #' @param cost_price Defines new product's cost price
    #' @param fixed_cost_shipping_price Specifies product's fixed cost shipping price
    #' @param tier_prices Defines product's tier prices
    #' @param group_prices Defines product's group prices
    #' @param buyitnow_price Defines buy it now value
    #' @param reserve_price Defines reserve price value
    #' @param measure_unit Unit for the price per unit. Must be in allowed list
    #' @param unit_price Defines new product's unit price
    #' @param prices_inc_tax Indicates whether prices include tax.. Default to FALSE.
    #' @param quantity Defines product's quantity that has to be added. Default to 0.
    #' @param in_stock Set stock status
    #' @param manage_stock Defines inventory tracking for product
    #' @param warehouse_id This parameter is used for selecting a warehouse where you need to set/modify a product quantity.
    #' @param backorder_status Set backorder status
    #' @param min_order_quantity The minimum quantity an order must contain, to be eligible to purchase this product.
    #' @param max_order_quantity The maximum quantity an order can contain when purchasing the product.
    #' @param low_stock_threshold Specify the quantity threshold below which the product is considered low in stock
    #' @param weight Weight. Default to 0.
    #' @param weight_unit Weight Unit
    #' @param width Defines product's width
    #' @param height Defines product's height
    #' @param length Defines product's length
    #' @param dimensions_unit Weight Unit
    #' @param barcode A barcode is a unique code composed of numbers used as a product identifier.
    #' @param upc Universal Product Code. A UPC (UPC-A) is a commonly used identifer for many different products.
    #' @param ean European Article Number. An EAN is a unique 8 or 13-digit identifier that many industries (such as book publishers) use to identify products.
    #' @param isbn International Standard Book Number. An ISBN is a unique identifier for books.
    #' @param gtin Global Trade Item Number. An GTIN is an identifier for trade items.
    #' @param mpn Manufacturer Part Number. A MPN is an identifier of a particular part design or material used.
    #' @param asin Amazon Standard Identification Number.
    #' @param product_reference Groups all variations, that you want to combine into one product.
    #' @param external_product_link External product link
    #' @param harmonized_system_code Harmonized System Code. An HSC is a 6-digit identifier that allows participating countries to classify traded goods on a common basis for customs purposes
    #' @param country_of_origin The country where the inventory item was made
    #' @param manufacturer Defines product's manufacturer
    #' @param manufacturer_id Defines product's manufacturer by manufacturer_id
    #' @param manufacturer_info manufacturer_info
    #' @param brand_name Defines product brand name
    #' @param image_url Image Url
    #' @param image_name Defines image's name
    #' @param additional_image_urls Image Url
    #' @param files File Url
    #' @param size_chart size_chart
    #' @param related_products_ids Defines product's related products ids that has to be added
    #' @param up_sell_products_ids Defines product's up-sell products ids that has to be added
    #' @param cross_sell_products_ids Defines product's cross-sell products ids that has to be added
    #' @param attribute_set_name Defines product’s attribute set name in Magento. Default to "Default".
    #' @param attribute_name Defines product’s attribute name separated with a comma in Magento
    #' @param search_keywords Defines unique search keywords
    #' @param tags Product tags
    #' @param materials A list of material strings for materials used in the product.
    #' @param certifications An array of product certifications. The list of possible certifications can be obtained using the \"<i>category.info</i>\" method (<i>additional_fields->rules->product_certifications</i>).
    #' @param specifics An array of Item Specific Name/Value pairs used by the seller to provide descriptive details of an item in a structured manner.         The list of possible specifications can be obtained using the category.info method (additional_fields->product_specifics).         <b>The structure of the parameter is different for specific platforms.</b>
    #' @param avail_from Allows to schedule a time in the future that the item becomes available. The value should be greater than the current date and time.
    #' @param sprice_create Defines the date of special price creation
    #' @param sprice_modified Defines the date of special price modification
    #' @param sprice_expire Defines the term of special price offer duration
    #' @param created_at Defines the date of entity creation
    #' @param auto_renew When true, automatically renews a listing upon its expiration.. Default to FALSE.
    #' @param when_made An enumerated string for the era in which the maker made the product.. Default to "made_to_order".
    #' @param meta_title Defines unique meta title for each entity
    #' @param meta_keywords Defines unique meta keywords for each entity
    #' @param meta_description Defines unique meta description of a entity
    #' @param url Defines unique product's URL
    #' @param seo_url Defines unique URL for SEO
    #' @param tax_class_id Defines tax classes where entity has to be added
    #' @param taxable Specifies whether a tax is charged. Default to TRUE.
    #' @param sales_tax sales_tax
    #' @param condition The human-readable label for the condition (e.g., \"New\").
    #' @param condition_description Detailed description of the product condition.
    #' @param allow_display_condition Flag used to determine whether the product condition is shown to the customer on the product page.
    #' @param payment_methods Identifies the payment method (such as PayPal) that the seller will accept when the buyer pays for the item. Look at cart.info method response for allowed values.<hr><div style=\"font-style:normal\">Param structure:<div style=\"margin-left: 2\%;\"><code style=\"padding:0; background-color:#ffffff;font-size:85\%;font-family:monospace;\">payment_methods[0] = string</br>payment_methods[1] = string</br></code></div></div>
    #' @param paypal_email Valid PayPal email address for the PayPal account that the seller will use if they offer PayPal as a payment method for the listing.
    #' @param shipping_template_id The numeric ID of the shipping template associated with the products in Etsy. You can find possible values in the \"cart.info\" API method response, in the field shipping_zones[]->id.. Default to 0.
    #' @param processing_profile_id The numeric ID of the processing profile (readiness state) for physical products in Etsy. You can find possible values in the \"cart.info\" API method response, in the field processing_profiles[]->readiness_state_id.
    #' @param shipping_details The shipping details, including flat and calculated shipping costs and shipping insurance costs. Look at cart.info method response for allowed values.<hr><div style=\"font-style:normal\">Param structure:<div style=\"margin-left: 2\%;\"><code style=\"padding:0; background-color:#ffffff;font-size:85\%;font-family:monospace;\">shipping_details[0][<b>shipping_type</b>] = string </br>shipping_details[0][<b>shipping_service</b>] = string</br>shipping_details[0][<b>shipping_cost</b>] = decimal</br>shipping_details[1][<b>shipping_type</b>] = string </br>shipping_details[1][<b>shipping_service</b>] = string</br>shipping_details[1][<b>shipping_cost</b>] = decimal</br></code></div></div>
    #' @param is_free_shipping Specifies product's free shipping flag that has to be added
    #' @param delivery_code The delivery promise that applies to offer
    #' @param delivery_type Defines the type of the delivery.
    #' @param delivery_time Defines delivery time in days.
    #' @param delivery_option_ids Defines delivery options for product by ids.
    #' @param package_details package_details
    #' @param logistic_info Defines product's logistic channel settings
    #' @param listing_duration Describes the number of days the seller wants the listing to be active. Look at cart.info method response for allowed values.
    #' @param listing_type Indicates the selling format of the marketplace listing.. Default to "FixedPrice".
    #' @param category_type Specifies the type of category (e.g., apparel or other) for the product being added.
    #' @param return_accepted Indicates whether the seller allows the buyer to return the item.
    #' @param seller_profiles seller_profiles
    #' @param auction_confidentiality_level This allows buyers to remain anonymous when the bid or buy an item.
    #' @param best_offer best_offer
    #' @param production_partner_ids Defines product's production partner ids that has to be added
    #' @param marketplace_item_properties String containing the JSON representation of the supplied data
    #' @param clear_cache Is cache clear required. Default to TRUE.
    #' @param viewed_count Specifies the number of product's reviews. Default to 0.
    #' @param ordered_count Defines how many times the product was ordered. Default to 0.
    #' @param shop_section_id Add Shop Section Id
    #' @param return_policy_id Add Return Policy Id
    #' @param personalization_details personalization_details
    #' @param personalization_questions Defines personalization questions for the listing as an array of question objects. Each question object supports the following fields: question_id (integer, nullable), question_text (string, 1-45 chars), instructions (string, nullable), question_type (string), required (boolean), max_allowed_characters (integer, nullable), max_allowed_files (integer, nullable), options (array, nullable). Cannot be used together with <strong>personalization_details</strong>.
    #' @param manufacturer_ids A comma-separated list of manufacturer IDs. Retrieve the IDs from the cart.info method.
    #' @param responsible_person_ids A comma-separated list of responsible person IDs. Retrieve the IDs from the cart.info method.
    #' @param idempotency_key A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong>
    #' @param ... Other optional arguments.
    initialize = function(`name`, `model`, `description`, `price`, `sku` = NULL, `short_description` = NULL, `type` = "simple", `status` = NULL, `visible` = NULL, `category_id` = NULL, `categories_ids` = NULL, `product_class` = NULL, `product_type` = NULL, `is_virtual` = FALSE, `downloadable` = FALSE, `is_supply` = TRUE, `available_for_view` = TRUE, `available_for_sale` = TRUE, `store_id` = NULL, `stores_ids` = NULL, `lang_id` = NULL, `old_price` = NULL, `special_price` = NULL, `wholesale_price` = NULL, `cost_price` = NULL, `fixed_cost_shipping_price` = NULL, `tier_prices` = NULL, `group_prices` = NULL, `buyitnow_price` = NULL, `reserve_price` = NULL, `measure_unit` = NULL, `unit_price` = NULL, `prices_inc_tax` = FALSE, `quantity` = 0, `in_stock` = NULL, `manage_stock` = NULL, `warehouse_id` = NULL, `backorder_status` = NULL, `min_order_quantity` = NULL, `max_order_quantity` = NULL, `low_stock_threshold` = NULL, `weight` = 0, `weight_unit` = NULL, `width` = NULL, `height` = NULL, `length` = NULL, `dimensions_unit` = NULL, `barcode` = NULL, `upc` = NULL, `ean` = NULL, `isbn` = NULL, `gtin` = NULL, `mpn` = NULL, `asin` = NULL, `product_reference` = NULL, `external_product_link` = NULL, `harmonized_system_code` = NULL, `country_of_origin` = NULL, `manufacturer` = NULL, `manufacturer_id` = NULL, `manufacturer_info` = NULL, `brand_name` = NULL, `image_url` = NULL, `image_name` = NULL, `additional_image_urls` = NULL, `files` = NULL, `size_chart` = NULL, `related_products_ids` = NULL, `up_sell_products_ids` = NULL, `cross_sell_products_ids` = NULL, `attribute_set_name` = "Default", `attribute_name` = NULL, `search_keywords` = NULL, `tags` = NULL, `materials` = NULL, `certifications` = NULL, `specifics` = NULL, `avail_from` = NULL, `sprice_create` = NULL, `sprice_modified` = NULL, `sprice_expire` = NULL, `created_at` = NULL, `auto_renew` = FALSE, `when_made` = "made_to_order", `meta_title` = NULL, `meta_keywords` = NULL, `meta_description` = NULL, `url` = NULL, `seo_url` = NULL, `tax_class_id` = NULL, `taxable` = TRUE, `sales_tax` = NULL, `condition` = NULL, `condition_description` = NULL, `allow_display_condition` = NULL, `payment_methods` = NULL, `paypal_email` = NULL, `shipping_template_id` = 0, `processing_profile_id` = NULL, `shipping_details` = NULL, `is_free_shipping` = NULL, `delivery_code` = NULL, `delivery_type` = NULL, `delivery_time` = NULL, `delivery_option_ids` = NULL, `package_details` = NULL, `logistic_info` = NULL, `listing_duration` = NULL, `listing_type` = "FixedPrice", `category_type` = NULL, `return_accepted` = NULL, `seller_profiles` = NULL, `auction_confidentiality_level` = NULL, `best_offer` = NULL, `production_partner_ids` = NULL, `marketplace_item_properties` = NULL, `clear_cache` = TRUE, `viewed_count` = 0, `ordered_count` = 0, `shop_section_id` = NULL, `return_policy_id` = NULL, `personalization_details` = NULL, `personalization_questions` = NULL, `manufacturer_ids` = NULL, `responsible_person_ids` = NULL, `idempotency_key` = NULL, ...) {
      if (!missing(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!missing(`model`)) {
        if (!(is.character(`model`) && length(`model`) == 1)) {
          stop(paste("Error! Invalid data for `model`. Must be a string:", `model`))
        }
        self$`model` <- `model`
      }
      if (!missing(`description`)) {
        if (!(is.character(`description`) && length(`description`) == 1)) {
          stop(paste("Error! Invalid data for `description`. Must be a string:", `description`))
        }
        self$`description` <- `description`
      }
      if (!missing(`price`)) {
        self$`price` <- `price`
      }
      if (!is.null(`sku`)) {
        if (!(is.character(`sku`) && length(`sku`) == 1)) {
          stop(paste("Error! Invalid data for `sku`. Must be a string:", `sku`))
        }
        self$`sku` <- `sku`
      }
      if (!is.null(`short_description`)) {
        if (!(is.character(`short_description`) && length(`short_description`) == 1)) {
          stop(paste("Error! Invalid data for `short_description`. Must be a string:", `short_description`))
        }
        self$`short_description` <- `short_description`
      }
      if (!is.null(`type`)) {
        if (!(is.character(`type`) && length(`type`) == 1)) {
          stop(paste("Error! Invalid data for `type`. Must be a string:", `type`))
        }
        self$`type` <- `type`
      }
      if (!is.null(`status`)) {
        if (!(is.character(`status`) && length(`status`) == 1)) {
          stop(paste("Error! Invalid data for `status`. Must be a string:", `status`))
        }
        self$`status` <- `status`
      }
      if (!is.null(`visible`)) {
        if (!(is.character(`visible`) && length(`visible`) == 1)) {
          stop(paste("Error! Invalid data for `visible`. Must be a string:", `visible`))
        }
        self$`visible` <- `visible`
      }
      if (!is.null(`category_id`)) {
        if (!(is.character(`category_id`) && length(`category_id`) == 1)) {
          stop(paste("Error! Invalid data for `category_id`. Must be a string:", `category_id`))
        }
        self$`category_id` <- `category_id`
      }
      if (!is.null(`categories_ids`)) {
        if (!(is.character(`categories_ids`) && length(`categories_ids`) == 1)) {
          stop(paste("Error! Invalid data for `categories_ids`. Must be a string:", `categories_ids`))
        }
        self$`categories_ids` <- `categories_ids`
      }
      if (!is.null(`product_class`)) {
        if (!(is.character(`product_class`) && length(`product_class`) == 1)) {
          stop(paste("Error! Invalid data for `product_class`. Must be a string:", `product_class`))
        }
        self$`product_class` <- `product_class`
      }
      if (!is.null(`product_type`)) {
        if (!(is.character(`product_type`) && length(`product_type`) == 1)) {
          stop(paste("Error! Invalid data for `product_type`. Must be a string:", `product_type`))
        }
        self$`product_type` <- `product_type`
      }
      if (!is.null(`is_virtual`)) {
        if (!(is.logical(`is_virtual`) && length(`is_virtual`) == 1)) {
          stop(paste("Error! Invalid data for `is_virtual`. Must be a boolean:", `is_virtual`))
        }
        self$`is_virtual` <- `is_virtual`
      }
      if (!is.null(`downloadable`)) {
        if (!(is.logical(`downloadable`) && length(`downloadable`) == 1)) {
          stop(paste("Error! Invalid data for `downloadable`. Must be a boolean:", `downloadable`))
        }
        self$`downloadable` <- `downloadable`
      }
      if (!is.null(`is_supply`)) {
        if (!(is.logical(`is_supply`) && length(`is_supply`) == 1)) {
          stop(paste("Error! Invalid data for `is_supply`. Must be a boolean:", `is_supply`))
        }
        self$`is_supply` <- `is_supply`
      }
      if (!is.null(`available_for_view`)) {
        if (!(is.logical(`available_for_view`) && length(`available_for_view`) == 1)) {
          stop(paste("Error! Invalid data for `available_for_view`. Must be a boolean:", `available_for_view`))
        }
        self$`available_for_view` <- `available_for_view`
      }
      if (!is.null(`available_for_sale`)) {
        if (!(is.logical(`available_for_sale`) && length(`available_for_sale`) == 1)) {
          stop(paste("Error! Invalid data for `available_for_sale`. Must be a boolean:", `available_for_sale`))
        }
        self$`available_for_sale` <- `available_for_sale`
      }
      if (!is.null(`store_id`)) {
        if (!(is.character(`store_id`) && length(`store_id`) == 1)) {
          stop(paste("Error! Invalid data for `store_id`. Must be a string:", `store_id`))
        }
        self$`store_id` <- `store_id`
      }
      if (!is.null(`stores_ids`)) {
        if (!(is.character(`stores_ids`) && length(`stores_ids`) == 1)) {
          stop(paste("Error! Invalid data for `stores_ids`. Must be a string:", `stores_ids`))
        }
        self$`stores_ids` <- `stores_ids`
      }
      if (!is.null(`lang_id`)) {
        if (!(is.character(`lang_id`) && length(`lang_id`) == 1)) {
          stop(paste("Error! Invalid data for `lang_id`. Must be a string:", `lang_id`))
        }
        self$`lang_id` <- `lang_id`
      }
      if (!is.null(`old_price`)) {
        self$`old_price` <- `old_price`
      }
      if (!is.null(`special_price`)) {
        self$`special_price` <- `special_price`
      }
      if (!is.null(`wholesale_price`)) {
        self$`wholesale_price` <- `wholesale_price`
      }
      if (!is.null(`cost_price`)) {
        self$`cost_price` <- `cost_price`
      }
      if (!is.null(`fixed_cost_shipping_price`)) {
        self$`fixed_cost_shipping_price` <- `fixed_cost_shipping_price`
      }
      if (!is.null(`tier_prices`)) {
        stopifnot(is.vector(`tier_prices`), length(`tier_prices`) != 0)
        sapply(`tier_prices`, function(x) stopifnot(R6::is.R6(x)))
        self$`tier_prices` <- `tier_prices`
      }
      if (!is.null(`group_prices`)) {
        stopifnot(is.vector(`group_prices`), length(`group_prices`) != 0)
        sapply(`group_prices`, function(x) stopifnot(R6::is.R6(x)))
        self$`group_prices` <- `group_prices`
      }
      if (!is.null(`buyitnow_price`)) {
        self$`buyitnow_price` <- `buyitnow_price`
      }
      if (!is.null(`reserve_price`)) {
        self$`reserve_price` <- `reserve_price`
      }
      if (!is.null(`measure_unit`)) {
        if (!(is.character(`measure_unit`) && length(`measure_unit`) == 1)) {
          stop(paste("Error! Invalid data for `measure_unit`. Must be a string:", `measure_unit`))
        }
        self$`measure_unit` <- `measure_unit`
      }
      if (!is.null(`unit_price`)) {
        self$`unit_price` <- `unit_price`
      }
      if (!is.null(`prices_inc_tax`)) {
        if (!(is.logical(`prices_inc_tax`) && length(`prices_inc_tax`) == 1)) {
          stop(paste("Error! Invalid data for `prices_inc_tax`. Must be a boolean:", `prices_inc_tax`))
        }
        self$`prices_inc_tax` <- `prices_inc_tax`
      }
      if (!is.null(`quantity`)) {
        self$`quantity` <- `quantity`
      }
      if (!is.null(`in_stock`)) {
        if (!(is.logical(`in_stock`) && length(`in_stock`) == 1)) {
          stop(paste("Error! Invalid data for `in_stock`. Must be a boolean:", `in_stock`))
        }
        self$`in_stock` <- `in_stock`
      }
      if (!is.null(`manage_stock`)) {
        if (!(is.logical(`manage_stock`) && length(`manage_stock`) == 1)) {
          stop(paste("Error! Invalid data for `manage_stock`. Must be a boolean:", `manage_stock`))
        }
        self$`manage_stock` <- `manage_stock`
      }
      if (!is.null(`warehouse_id`)) {
        if (!(is.character(`warehouse_id`) && length(`warehouse_id`) == 1)) {
          stop(paste("Error! Invalid data for `warehouse_id`. Must be a string:", `warehouse_id`))
        }
        self$`warehouse_id` <- `warehouse_id`
      }
      if (!is.null(`backorder_status`)) {
        if (!(is.character(`backorder_status`) && length(`backorder_status`) == 1)) {
          stop(paste("Error! Invalid data for `backorder_status`. Must be a string:", `backorder_status`))
        }
        self$`backorder_status` <- `backorder_status`
      }
      if (!is.null(`min_order_quantity`)) {
        self$`min_order_quantity` <- `min_order_quantity`
      }
      if (!is.null(`max_order_quantity`)) {
        self$`max_order_quantity` <- `max_order_quantity`
      }
      if (!is.null(`low_stock_threshold`)) {
        self$`low_stock_threshold` <- `low_stock_threshold`
      }
      if (!is.null(`weight`)) {
        self$`weight` <- `weight`
      }
      if (!is.null(`weight_unit`)) {
        if (!(is.character(`weight_unit`) && length(`weight_unit`) == 1)) {
          stop(paste("Error! Invalid data for `weight_unit`. Must be a string:", `weight_unit`))
        }
        self$`weight_unit` <- `weight_unit`
      }
      if (!is.null(`width`)) {
        self$`width` <- `width`
      }
      if (!is.null(`height`)) {
        self$`height` <- `height`
      }
      if (!is.null(`length`)) {
        self$`length` <- `length`
      }
      if (!is.null(`dimensions_unit`)) {
        if (!(is.character(`dimensions_unit`) && length(`dimensions_unit`) == 1)) {
          stop(paste("Error! Invalid data for `dimensions_unit`. Must be a string:", `dimensions_unit`))
        }
        self$`dimensions_unit` <- `dimensions_unit`
      }
      if (!is.null(`barcode`)) {
        if (!(is.character(`barcode`) && length(`barcode`) == 1)) {
          stop(paste("Error! Invalid data for `barcode`. Must be a string:", `barcode`))
        }
        self$`barcode` <- `barcode`
      }
      if (!is.null(`upc`)) {
        if (!(is.character(`upc`) && length(`upc`) == 1)) {
          stop(paste("Error! Invalid data for `upc`. Must be a string:", `upc`))
        }
        self$`upc` <- `upc`
      }
      if (!is.null(`ean`)) {
        if (!(is.character(`ean`) && length(`ean`) == 1)) {
          stop(paste("Error! Invalid data for `ean`. Must be a string:", `ean`))
        }
        self$`ean` <- `ean`
      }
      if (!is.null(`isbn`)) {
        if (!(is.character(`isbn`) && length(`isbn`) == 1)) {
          stop(paste("Error! Invalid data for `isbn`. Must be a string:", `isbn`))
        }
        self$`isbn` <- `isbn`
      }
      if (!is.null(`gtin`)) {
        if (!(is.character(`gtin`) && length(`gtin`) == 1)) {
          stop(paste("Error! Invalid data for `gtin`. Must be a string:", `gtin`))
        }
        self$`gtin` <- `gtin`
      }
      if (!is.null(`mpn`)) {
        if (!(is.character(`mpn`) && length(`mpn`) == 1)) {
          stop(paste("Error! Invalid data for `mpn`. Must be a string:", `mpn`))
        }
        self$`mpn` <- `mpn`
      }
      if (!is.null(`asin`)) {
        if (!(is.character(`asin`) && length(`asin`) == 1)) {
          stop(paste("Error! Invalid data for `asin`. Must be a string:", `asin`))
        }
        self$`asin` <- `asin`
      }
      if (!is.null(`product_reference`)) {
        if (!(is.character(`product_reference`) && length(`product_reference`) == 1)) {
          stop(paste("Error! Invalid data for `product_reference`. Must be a string:", `product_reference`))
        }
        self$`product_reference` <- `product_reference`
      }
      if (!is.null(`external_product_link`)) {
        if (!(is.character(`external_product_link`) && length(`external_product_link`) == 1)) {
          stop(paste("Error! Invalid data for `external_product_link`. Must be a string:", `external_product_link`))
        }
        self$`external_product_link` <- `external_product_link`
      }
      if (!is.null(`harmonized_system_code`)) {
        if (!(is.character(`harmonized_system_code`) && length(`harmonized_system_code`) == 1)) {
          stop(paste("Error! Invalid data for `harmonized_system_code`. Must be a string:", `harmonized_system_code`))
        }
        self$`harmonized_system_code` <- `harmonized_system_code`
      }
      if (!is.null(`country_of_origin`)) {
        if (!(is.character(`country_of_origin`) && length(`country_of_origin`) == 1)) {
          stop(paste("Error! Invalid data for `country_of_origin`. Must be a string:", `country_of_origin`))
        }
        self$`country_of_origin` <- `country_of_origin`
      }
      if (!is.null(`manufacturer`)) {
        if (!(is.character(`manufacturer`) && length(`manufacturer`) == 1)) {
          stop(paste("Error! Invalid data for `manufacturer`. Must be a string:", `manufacturer`))
        }
        self$`manufacturer` <- `manufacturer`
      }
      if (!is.null(`manufacturer_id`)) {
        if (!(is.character(`manufacturer_id`) && length(`manufacturer_id`) == 1)) {
          stop(paste("Error! Invalid data for `manufacturer_id`. Must be a string:", `manufacturer_id`))
        }
        self$`manufacturer_id` <- `manufacturer_id`
      }
      if (!is.null(`manufacturer_info`)) {
        stopifnot(R6::is.R6(`manufacturer_info`))
        self$`manufacturer_info` <- `manufacturer_info`
      }
      if (!is.null(`brand_name`)) {
        if (!(is.character(`brand_name`) && length(`brand_name`) == 1)) {
          stop(paste("Error! Invalid data for `brand_name`. Must be a string:", `brand_name`))
        }
        self$`brand_name` <- `brand_name`
      }
      if (!is.null(`image_url`)) {
        if (!(is.character(`image_url`) && length(`image_url`) == 1)) {
          stop(paste("Error! Invalid data for `image_url`. Must be a string:", `image_url`))
        }
        self$`image_url` <- `image_url`
      }
      if (!is.null(`image_name`)) {
        if (!(is.character(`image_name`) && length(`image_name`) == 1)) {
          stop(paste("Error! Invalid data for `image_name`. Must be a string:", `image_name`))
        }
        self$`image_name` <- `image_name`
      }
      if (!is.null(`additional_image_urls`)) {
        stopifnot(is.vector(`additional_image_urls`), length(`additional_image_urls`) != 0)
        sapply(`additional_image_urls`, function(x) stopifnot(is.character(x)))
        self$`additional_image_urls` <- `additional_image_urls`
      }
      if (!is.null(`files`)) {
        stopifnot(is.vector(`files`), length(`files`) != 0)
        sapply(`files`, function(x) stopifnot(R6::is.R6(x)))
        self$`files` <- `files`
      }
      if (!is.null(`size_chart`)) {
        stopifnot(R6::is.R6(`size_chart`))
        self$`size_chart` <- `size_chart`
      }
      if (!is.null(`related_products_ids`)) {
        if (!(is.character(`related_products_ids`) && length(`related_products_ids`) == 1)) {
          stop(paste("Error! Invalid data for `related_products_ids`. Must be a string:", `related_products_ids`))
        }
        self$`related_products_ids` <- `related_products_ids`
      }
      if (!is.null(`up_sell_products_ids`)) {
        if (!(is.character(`up_sell_products_ids`) && length(`up_sell_products_ids`) == 1)) {
          stop(paste("Error! Invalid data for `up_sell_products_ids`. Must be a string:", `up_sell_products_ids`))
        }
        self$`up_sell_products_ids` <- `up_sell_products_ids`
      }
      if (!is.null(`cross_sell_products_ids`)) {
        if (!(is.character(`cross_sell_products_ids`) && length(`cross_sell_products_ids`) == 1)) {
          stop(paste("Error! Invalid data for `cross_sell_products_ids`. Must be a string:", `cross_sell_products_ids`))
        }
        self$`cross_sell_products_ids` <- `cross_sell_products_ids`
      }
      if (!is.null(`attribute_set_name`)) {
        if (!(is.character(`attribute_set_name`) && length(`attribute_set_name`) == 1)) {
          stop(paste("Error! Invalid data for `attribute_set_name`. Must be a string:", `attribute_set_name`))
        }
        self$`attribute_set_name` <- `attribute_set_name`
      }
      if (!is.null(`attribute_name`)) {
        if (!(is.character(`attribute_name`) && length(`attribute_name`) == 1)) {
          stop(paste("Error! Invalid data for `attribute_name`. Must be a string:", `attribute_name`))
        }
        self$`attribute_name` <- `attribute_name`
      }
      if (!is.null(`search_keywords`)) {
        if (!(is.character(`search_keywords`) && length(`search_keywords`) == 1)) {
          stop(paste("Error! Invalid data for `search_keywords`. Must be a string:", `search_keywords`))
        }
        self$`search_keywords` <- `search_keywords`
      }
      if (!is.null(`tags`)) {
        if (!(is.character(`tags`) && length(`tags`) == 1)) {
          stop(paste("Error! Invalid data for `tags`. Must be a string:", `tags`))
        }
        self$`tags` <- `tags`
      }
      if (!is.null(`materials`)) {
        stopifnot(is.vector(`materials`), length(`materials`) != 0)
        sapply(`materials`, function(x) stopifnot(is.character(x)))
        self$`materials` <- `materials`
      }
      if (!is.null(`certifications`)) {
        stopifnot(is.vector(`certifications`), length(`certifications`) != 0)
        sapply(`certifications`, function(x) stopifnot(R6::is.R6(x)))
        self$`certifications` <- `certifications`
      }
      if (!is.null(`specifics`)) {
        stopifnot(is.vector(`specifics`), length(`specifics`) != 0)
        sapply(`specifics`, function(x) stopifnot(R6::is.R6(x)))
        self$`specifics` <- `specifics`
      }
      if (!is.null(`avail_from`)) {
        if (!(is.character(`avail_from`) && length(`avail_from`) == 1)) {
          stop(paste("Error! Invalid data for `avail_from`. Must be a string:", `avail_from`))
        }
        self$`avail_from` <- `avail_from`
      }
      if (!is.null(`sprice_create`)) {
        if (!(is.character(`sprice_create`) && length(`sprice_create`) == 1)) {
          stop(paste("Error! Invalid data for `sprice_create`. Must be a string:", `sprice_create`))
        }
        self$`sprice_create` <- `sprice_create`
      }
      if (!is.null(`sprice_modified`)) {
        if (!(is.character(`sprice_modified`) && length(`sprice_modified`) == 1)) {
          stop(paste("Error! Invalid data for `sprice_modified`. Must be a string:", `sprice_modified`))
        }
        self$`sprice_modified` <- `sprice_modified`
      }
      if (!is.null(`sprice_expire`)) {
        if (!(is.character(`sprice_expire`) && length(`sprice_expire`) == 1)) {
          stop(paste("Error! Invalid data for `sprice_expire`. Must be a string:", `sprice_expire`))
        }
        self$`sprice_expire` <- `sprice_expire`
      }
      if (!is.null(`created_at`)) {
        if (!(is.character(`created_at`) && length(`created_at`) == 1)) {
          stop(paste("Error! Invalid data for `created_at`. Must be a string:", `created_at`))
        }
        self$`created_at` <- `created_at`
      }
      if (!is.null(`auto_renew`)) {
        if (!(is.logical(`auto_renew`) && length(`auto_renew`) == 1)) {
          stop(paste("Error! Invalid data for `auto_renew`. Must be a boolean:", `auto_renew`))
        }
        self$`auto_renew` <- `auto_renew`
      }
      if (!is.null(`when_made`)) {
        if (!(is.character(`when_made`) && length(`when_made`) == 1)) {
          stop(paste("Error! Invalid data for `when_made`. Must be a string:", `when_made`))
        }
        self$`when_made` <- `when_made`
      }
      if (!is.null(`meta_title`)) {
        if (!(is.character(`meta_title`) && length(`meta_title`) == 1)) {
          stop(paste("Error! Invalid data for `meta_title`. Must be a string:", `meta_title`))
        }
        self$`meta_title` <- `meta_title`
      }
      if (!is.null(`meta_keywords`)) {
        if (!(is.character(`meta_keywords`) && length(`meta_keywords`) == 1)) {
          stop(paste("Error! Invalid data for `meta_keywords`. Must be a string:", `meta_keywords`))
        }
        self$`meta_keywords` <- `meta_keywords`
      }
      if (!is.null(`meta_description`)) {
        if (!(is.character(`meta_description`) && length(`meta_description`) == 1)) {
          stop(paste("Error! Invalid data for `meta_description`. Must be a string:", `meta_description`))
        }
        self$`meta_description` <- `meta_description`
      }
      if (!is.null(`url`)) {
        if (!(is.character(`url`) && length(`url`) == 1)) {
          stop(paste("Error! Invalid data for `url`. Must be a string:", `url`))
        }
        self$`url` <- `url`
      }
      if (!is.null(`seo_url`)) {
        if (!(is.character(`seo_url`) && length(`seo_url`) == 1)) {
          stop(paste("Error! Invalid data for `seo_url`. Must be a string:", `seo_url`))
        }
        self$`seo_url` <- `seo_url`
      }
      if (!is.null(`tax_class_id`)) {
        if (!(is.character(`tax_class_id`) && length(`tax_class_id`) == 1)) {
          stop(paste("Error! Invalid data for `tax_class_id`. Must be a string:", `tax_class_id`))
        }
        self$`tax_class_id` <- `tax_class_id`
      }
      if (!is.null(`taxable`)) {
        if (!(is.logical(`taxable`) && length(`taxable`) == 1)) {
          stop(paste("Error! Invalid data for `taxable`. Must be a boolean:", `taxable`))
        }
        self$`taxable` <- `taxable`
      }
      if (!is.null(`sales_tax`)) {
        stopifnot(R6::is.R6(`sales_tax`))
        self$`sales_tax` <- `sales_tax`
      }
      if (!is.null(`condition`)) {
        if (!(is.character(`condition`) && length(`condition`) == 1)) {
          stop(paste("Error! Invalid data for `condition`. Must be a string:", `condition`))
        }
        self$`condition` <- `condition`
      }
      if (!is.null(`condition_description`)) {
        if (!(is.character(`condition_description`) && length(`condition_description`) == 1)) {
          stop(paste("Error! Invalid data for `condition_description`. Must be a string:", `condition_description`))
        }
        self$`condition_description` <- `condition_description`
      }
      if (!is.null(`allow_display_condition`)) {
        if (!(is.logical(`allow_display_condition`) && length(`allow_display_condition`) == 1)) {
          stop(paste("Error! Invalid data for `allow_display_condition`. Must be a boolean:", `allow_display_condition`))
        }
        self$`allow_display_condition` <- `allow_display_condition`
      }
      if (!is.null(`payment_methods`)) {
        stopifnot(is.vector(`payment_methods`), length(`payment_methods`) != 0)
        sapply(`payment_methods`, function(x) stopifnot(is.character(x)))
        self$`payment_methods` <- `payment_methods`
      }
      if (!is.null(`paypal_email`)) {
        if (!(is.character(`paypal_email`) && length(`paypal_email`) == 1)) {
          stop(paste("Error! Invalid data for `paypal_email`. Must be a string:", `paypal_email`))
        }
        self$`paypal_email` <- `paypal_email`
      }
      if (!is.null(`shipping_template_id`)) {
        if (!(is.numeric(`shipping_template_id`) && length(`shipping_template_id`) == 1)) {
          stop(paste("Error! Invalid data for `shipping_template_id`. Must be an integer:", `shipping_template_id`))
        }
        self$`shipping_template_id` <- `shipping_template_id`
      }
      if (!is.null(`processing_profile_id`)) {
        if (!(is.numeric(`processing_profile_id`) && length(`processing_profile_id`) == 1)) {
          stop(paste("Error! Invalid data for `processing_profile_id`. Must be an integer:", `processing_profile_id`))
        }
        self$`processing_profile_id` <- `processing_profile_id`
      }
      if (!is.null(`shipping_details`)) {
        stopifnot(is.vector(`shipping_details`), length(`shipping_details`) != 0)
        sapply(`shipping_details`, function(x) stopifnot(R6::is.R6(x)))
        self$`shipping_details` <- `shipping_details`
      }
      if (!is.null(`is_free_shipping`)) {
        if (!(is.logical(`is_free_shipping`) && length(`is_free_shipping`) == 1)) {
          stop(paste("Error! Invalid data for `is_free_shipping`. Must be a boolean:", `is_free_shipping`))
        }
        self$`is_free_shipping` <- `is_free_shipping`
      }
      if (!is.null(`delivery_code`)) {
        if (!(is.character(`delivery_code`) && length(`delivery_code`) == 1)) {
          stop(paste("Error! Invalid data for `delivery_code`. Must be a string:", `delivery_code`))
        }
        self$`delivery_code` <- `delivery_code`
      }
      if (!is.null(`delivery_type`)) {
        if (!(is.character(`delivery_type`) && length(`delivery_type`) == 1)) {
          stop(paste("Error! Invalid data for `delivery_type`. Must be a string:", `delivery_type`))
        }
        self$`delivery_type` <- `delivery_type`
      }
      if (!is.null(`delivery_time`)) {
        if (!(is.numeric(`delivery_time`) && length(`delivery_time`) == 1)) {
          stop(paste("Error! Invalid data for `delivery_time`. Must be an integer:", `delivery_time`))
        }
        self$`delivery_time` <- `delivery_time`
      }
      if (!is.null(`delivery_option_ids`)) {
        if (!(is.character(`delivery_option_ids`) && length(`delivery_option_ids`) == 1)) {
          stop(paste("Error! Invalid data for `delivery_option_ids`. Must be a string:", `delivery_option_ids`))
        }
        self$`delivery_option_ids` <- `delivery_option_ids`
      }
      if (!is.null(`package_details`)) {
        stopifnot(R6::is.R6(`package_details`))
        self$`package_details` <- `package_details`
      }
      if (!is.null(`logistic_info`)) {
        stopifnot(is.vector(`logistic_info`), length(`logistic_info`) != 0)
        sapply(`logistic_info`, function(x) stopifnot(R6::is.R6(x)))
        self$`logistic_info` <- `logistic_info`
      }
      if (!is.null(`listing_duration`)) {
        if (!(is.character(`listing_duration`) && length(`listing_duration`) == 1)) {
          stop(paste("Error! Invalid data for `listing_duration`. Must be a string:", `listing_duration`))
        }
        self$`listing_duration` <- `listing_duration`
      }
      if (!is.null(`listing_type`)) {
        if (!(is.character(`listing_type`) && length(`listing_type`) == 1)) {
          stop(paste("Error! Invalid data for `listing_type`. Must be a string:", `listing_type`))
        }
        self$`listing_type` <- `listing_type`
      }
      if (!is.null(`category_type`)) {
        if (!(is.character(`category_type`) && length(`category_type`) == 1)) {
          stop(paste("Error! Invalid data for `category_type`. Must be a string:", `category_type`))
        }
        self$`category_type` <- `category_type`
      }
      if (!is.null(`return_accepted`)) {
        if (!(is.logical(`return_accepted`) && length(`return_accepted`) == 1)) {
          stop(paste("Error! Invalid data for `return_accepted`. Must be a boolean:", `return_accepted`))
        }
        self$`return_accepted` <- `return_accepted`
      }
      if (!is.null(`seller_profiles`)) {
        stopifnot(R6::is.R6(`seller_profiles`))
        self$`seller_profiles` <- `seller_profiles`
      }
      if (!is.null(`auction_confidentiality_level`)) {
        if (!(is.character(`auction_confidentiality_level`) && length(`auction_confidentiality_level`) == 1)) {
          stop(paste("Error! Invalid data for `auction_confidentiality_level`. Must be a string:", `auction_confidentiality_level`))
        }
        self$`auction_confidentiality_level` <- `auction_confidentiality_level`
      }
      if (!is.null(`best_offer`)) {
        stopifnot(R6::is.R6(`best_offer`))
        self$`best_offer` <- `best_offer`
      }
      if (!is.null(`production_partner_ids`)) {
        if (!(is.character(`production_partner_ids`) && length(`production_partner_ids`) == 1)) {
          stop(paste("Error! Invalid data for `production_partner_ids`. Must be a string:", `production_partner_ids`))
        }
        self$`production_partner_ids` <- `production_partner_ids`
      }
      if (!is.null(`marketplace_item_properties`)) {
        if (!(is.character(`marketplace_item_properties`) && length(`marketplace_item_properties`) == 1)) {
          stop(paste("Error! Invalid data for `marketplace_item_properties`. Must be a string:", `marketplace_item_properties`))
        }
        self$`marketplace_item_properties` <- `marketplace_item_properties`
      }
      if (!is.null(`clear_cache`)) {
        if (!(is.logical(`clear_cache`) && length(`clear_cache`) == 1)) {
          stop(paste("Error! Invalid data for `clear_cache`. Must be a boolean:", `clear_cache`))
        }
        self$`clear_cache` <- `clear_cache`
      }
      if (!is.null(`viewed_count`)) {
        if (!(is.numeric(`viewed_count`) && length(`viewed_count`) == 1)) {
          stop(paste("Error! Invalid data for `viewed_count`. Must be an integer:", `viewed_count`))
        }
        self$`viewed_count` <- `viewed_count`
      }
      if (!is.null(`ordered_count`)) {
        if (!(is.numeric(`ordered_count`) && length(`ordered_count`) == 1)) {
          stop(paste("Error! Invalid data for `ordered_count`. Must be an integer:", `ordered_count`))
        }
        self$`ordered_count` <- `ordered_count`
      }
      if (!is.null(`shop_section_id`)) {
        if (!(is.numeric(`shop_section_id`) && length(`shop_section_id`) == 1)) {
          stop(paste("Error! Invalid data for `shop_section_id`. Must be an integer:", `shop_section_id`))
        }
        self$`shop_section_id` <- `shop_section_id`
      }
      if (!is.null(`return_policy_id`)) {
        if (!(is.numeric(`return_policy_id`) && length(`return_policy_id`) == 1)) {
          stop(paste("Error! Invalid data for `return_policy_id`. Must be an integer:", `return_policy_id`))
        }
        self$`return_policy_id` <- `return_policy_id`
      }
      if (!is.null(`personalization_details`)) {
        stopifnot(R6::is.R6(`personalization_details`))
        self$`personalization_details` <- `personalization_details`
      }
      if (!is.null(`personalization_questions`)) {
        stopifnot(is.vector(`personalization_questions`), length(`personalization_questions`) != 0)
        sapply(`personalization_questions`, function(x) stopifnot(R6::is.R6(x)))
        self$`personalization_questions` <- `personalization_questions`
      }
      if (!is.null(`manufacturer_ids`)) {
        if (!(is.character(`manufacturer_ids`) && length(`manufacturer_ids`) == 1)) {
          stop(paste("Error! Invalid data for `manufacturer_ids`. Must be a string:", `manufacturer_ids`))
        }
        self$`manufacturer_ids` <- `manufacturer_ids`
      }
      if (!is.null(`responsible_person_ids`)) {
        if (!(is.character(`responsible_person_ids`) && length(`responsible_person_ids`) == 1)) {
          stop(paste("Error! Invalid data for `responsible_person_ids`. Must be a string:", `responsible_person_ids`))
        }
        self$`responsible_person_ids` <- `responsible_person_ids`
      }
      if (!is.null(`idempotency_key`)) {
        if (!(is.character(`idempotency_key`) && length(`idempotency_key`) == 1)) {
          stop(paste("Error! Invalid data for `idempotency_key`. Must be a string:", `idempotency_key`))
        }
        self$`idempotency_key` <- `idempotency_key`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductAdd as a base R list.
    #' @examples
    #' # convert array of ProductAdd (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductAdd to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductAddObject <- list()
      if (!is.null(self$`name`)) {
        ProductAddObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`model`)) {
        ProductAddObject[["model"]] <-
          self$`model`
      }
      if (!is.null(self$`description`)) {
        ProductAddObject[["description"]] <-
          self$`description`
      }
      if (!is.null(self$`price`)) {
        ProductAddObject[["price"]] <-
          self$`price`
      }
      if (!is.null(self$`sku`)) {
        ProductAddObject[["sku"]] <-
          self$`sku`
      }
      if (!is.null(self$`short_description`)) {
        ProductAddObject[["short_description"]] <-
          self$`short_description`
      }
      if (!is.null(self$`type`)) {
        ProductAddObject[["type"]] <-
          self$`type`
      }
      if (!is.null(self$`status`)) {
        ProductAddObject[["status"]] <-
          self$`status`
      }
      if (!is.null(self$`visible`)) {
        ProductAddObject[["visible"]] <-
          self$`visible`
      }
      if (!is.null(self$`category_id`)) {
        ProductAddObject[["category_id"]] <-
          self$`category_id`
      }
      if (!is.null(self$`categories_ids`)) {
        ProductAddObject[["categories_ids"]] <-
          self$`categories_ids`
      }
      if (!is.null(self$`product_class`)) {
        ProductAddObject[["product_class"]] <-
          self$`product_class`
      }
      if (!is.null(self$`product_type`)) {
        ProductAddObject[["product_type"]] <-
          self$`product_type`
      }
      if (!is.null(self$`is_virtual`)) {
        ProductAddObject[["is_virtual"]] <-
          self$`is_virtual`
      }
      if (!is.null(self$`downloadable`)) {
        ProductAddObject[["downloadable"]] <-
          self$`downloadable`
      }
      if (!is.null(self$`is_supply`)) {
        ProductAddObject[["is_supply"]] <-
          self$`is_supply`
      }
      if (!is.null(self$`available_for_view`)) {
        ProductAddObject[["available_for_view"]] <-
          self$`available_for_view`
      }
      if (!is.null(self$`available_for_sale`)) {
        ProductAddObject[["available_for_sale"]] <-
          self$`available_for_sale`
      }
      if (!is.null(self$`store_id`)) {
        ProductAddObject[["store_id"]] <-
          self$`store_id`
      }
      if (!is.null(self$`stores_ids`)) {
        ProductAddObject[["stores_ids"]] <-
          self$`stores_ids`
      }
      if (!is.null(self$`lang_id`)) {
        ProductAddObject[["lang_id"]] <-
          self$`lang_id`
      }
      if (!is.null(self$`old_price`)) {
        ProductAddObject[["old_price"]] <-
          self$`old_price`
      }
      if (!is.null(self$`special_price`)) {
        ProductAddObject[["special_price"]] <-
          self$`special_price`
      }
      if (!is.null(self$`wholesale_price`)) {
        ProductAddObject[["wholesale_price"]] <-
          self$`wholesale_price`
      }
      if (!is.null(self$`cost_price`)) {
        ProductAddObject[["cost_price"]] <-
          self$`cost_price`
      }
      if (!is.null(self$`fixed_cost_shipping_price`)) {
        ProductAddObject[["fixed_cost_shipping_price"]] <-
          self$`fixed_cost_shipping_price`
      }
      if (!is.null(self$`tier_prices`)) {
        ProductAddObject[["tier_prices"]] <-
          lapply(self$`tier_prices`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`group_prices`)) {
        ProductAddObject[["group_prices"]] <-
          lapply(self$`group_prices`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`buyitnow_price`)) {
        ProductAddObject[["buyitnow_price"]] <-
          self$`buyitnow_price`
      }
      if (!is.null(self$`reserve_price`)) {
        ProductAddObject[["reserve_price"]] <-
          self$`reserve_price`
      }
      if (!is.null(self$`measure_unit`)) {
        ProductAddObject[["measure_unit"]] <-
          self$`measure_unit`
      }
      if (!is.null(self$`unit_price`)) {
        ProductAddObject[["unit_price"]] <-
          self$`unit_price`
      }
      if (!is.null(self$`prices_inc_tax`)) {
        ProductAddObject[["prices_inc_tax"]] <-
          self$`prices_inc_tax`
      }
      if (!is.null(self$`quantity`)) {
        ProductAddObject[["quantity"]] <-
          self$`quantity`
      }
      if (!is.null(self$`in_stock`)) {
        ProductAddObject[["in_stock"]] <-
          self$`in_stock`
      }
      if (!is.null(self$`manage_stock`)) {
        ProductAddObject[["manage_stock"]] <-
          self$`manage_stock`
      }
      if (!is.null(self$`warehouse_id`)) {
        ProductAddObject[["warehouse_id"]] <-
          self$`warehouse_id`
      }
      if (!is.null(self$`backorder_status`)) {
        ProductAddObject[["backorder_status"]] <-
          self$`backorder_status`
      }
      if (!is.null(self$`min_order_quantity`)) {
        ProductAddObject[["min_order_quantity"]] <-
          self$`min_order_quantity`
      }
      if (!is.null(self$`max_order_quantity`)) {
        ProductAddObject[["max_order_quantity"]] <-
          self$`max_order_quantity`
      }
      if (!is.null(self$`low_stock_threshold`)) {
        ProductAddObject[["low_stock_threshold"]] <-
          self$`low_stock_threshold`
      }
      if (!is.null(self$`weight`)) {
        ProductAddObject[["weight"]] <-
          self$`weight`
      }
      if (!is.null(self$`weight_unit`)) {
        ProductAddObject[["weight_unit"]] <-
          self$`weight_unit`
      }
      if (!is.null(self$`width`)) {
        ProductAddObject[["width"]] <-
          self$`width`
      }
      if (!is.null(self$`height`)) {
        ProductAddObject[["height"]] <-
          self$`height`
      }
      if (!is.null(self$`length`)) {
        ProductAddObject[["length"]] <-
          self$`length`
      }
      if (!is.null(self$`dimensions_unit`)) {
        ProductAddObject[["dimensions_unit"]] <-
          self$`dimensions_unit`
      }
      if (!is.null(self$`barcode`)) {
        ProductAddObject[["barcode"]] <-
          self$`barcode`
      }
      if (!is.null(self$`upc`)) {
        ProductAddObject[["upc"]] <-
          self$`upc`
      }
      if (!is.null(self$`ean`)) {
        ProductAddObject[["ean"]] <-
          self$`ean`
      }
      if (!is.null(self$`isbn`)) {
        ProductAddObject[["isbn"]] <-
          self$`isbn`
      }
      if (!is.null(self$`gtin`)) {
        ProductAddObject[["gtin"]] <-
          self$`gtin`
      }
      if (!is.null(self$`mpn`)) {
        ProductAddObject[["mpn"]] <-
          self$`mpn`
      }
      if (!is.null(self$`asin`)) {
        ProductAddObject[["asin"]] <-
          self$`asin`
      }
      if (!is.null(self$`product_reference`)) {
        ProductAddObject[["product_reference"]] <-
          self$`product_reference`
      }
      if (!is.null(self$`external_product_link`)) {
        ProductAddObject[["external_product_link"]] <-
          self$`external_product_link`
      }
      if (!is.null(self$`harmonized_system_code`)) {
        ProductAddObject[["harmonized_system_code"]] <-
          self$`harmonized_system_code`
      }
      if (!is.null(self$`country_of_origin`)) {
        ProductAddObject[["country_of_origin"]] <-
          self$`country_of_origin`
      }
      if (!is.null(self$`manufacturer`)) {
        ProductAddObject[["manufacturer"]] <-
          self$`manufacturer`
      }
      if (!is.null(self$`manufacturer_id`)) {
        ProductAddObject[["manufacturer_id"]] <-
          self$`manufacturer_id`
      }
      if (!is.null(self$`manufacturer_info`)) {
        ProductAddObject[["manufacturer_info"]] <-
          self$`manufacturer_info`$toSimpleType()
      }
      if (!is.null(self$`brand_name`)) {
        ProductAddObject[["brand_name"]] <-
          self$`brand_name`
      }
      if (!is.null(self$`image_url`)) {
        ProductAddObject[["image_url"]] <-
          self$`image_url`
      }
      if (!is.null(self$`image_name`)) {
        ProductAddObject[["image_name"]] <-
          self$`image_name`
      }
      if (!is.null(self$`additional_image_urls`)) {
        ProductAddObject[["additional_image_urls"]] <-
          self$`additional_image_urls`
      }
      if (!is.null(self$`files`)) {
        ProductAddObject[["files"]] <-
          lapply(self$`files`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`size_chart`)) {
        ProductAddObject[["size_chart"]] <-
          self$`size_chart`$toSimpleType()
      }
      if (!is.null(self$`related_products_ids`)) {
        ProductAddObject[["related_products_ids"]] <-
          self$`related_products_ids`
      }
      if (!is.null(self$`up_sell_products_ids`)) {
        ProductAddObject[["up_sell_products_ids"]] <-
          self$`up_sell_products_ids`
      }
      if (!is.null(self$`cross_sell_products_ids`)) {
        ProductAddObject[["cross_sell_products_ids"]] <-
          self$`cross_sell_products_ids`
      }
      if (!is.null(self$`attribute_set_name`)) {
        ProductAddObject[["attribute_set_name"]] <-
          self$`attribute_set_name`
      }
      if (!is.null(self$`attribute_name`)) {
        ProductAddObject[["attribute_name"]] <-
          self$`attribute_name`
      }
      if (!is.null(self$`search_keywords`)) {
        ProductAddObject[["search_keywords"]] <-
          self$`search_keywords`
      }
      if (!is.null(self$`tags`)) {
        ProductAddObject[["tags"]] <-
          self$`tags`
      }
      if (!is.null(self$`materials`)) {
        ProductAddObject[["materials"]] <-
          self$`materials`
      }
      if (!is.null(self$`certifications`)) {
        ProductAddObject[["certifications"]] <-
          lapply(self$`certifications`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`specifics`)) {
        ProductAddObject[["specifics"]] <-
          lapply(self$`specifics`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`avail_from`)) {
        ProductAddObject[["avail_from"]] <-
          self$`avail_from`
      }
      if (!is.null(self$`sprice_create`)) {
        ProductAddObject[["sprice_create"]] <-
          self$`sprice_create`
      }
      if (!is.null(self$`sprice_modified`)) {
        ProductAddObject[["sprice_modified"]] <-
          self$`sprice_modified`
      }
      if (!is.null(self$`sprice_expire`)) {
        ProductAddObject[["sprice_expire"]] <-
          self$`sprice_expire`
      }
      if (!is.null(self$`created_at`)) {
        ProductAddObject[["created_at"]] <-
          self$`created_at`
      }
      if (!is.null(self$`auto_renew`)) {
        ProductAddObject[["auto_renew"]] <-
          self$`auto_renew`
      }
      if (!is.null(self$`when_made`)) {
        ProductAddObject[["when_made"]] <-
          self$`when_made`
      }
      if (!is.null(self$`meta_title`)) {
        ProductAddObject[["meta_title"]] <-
          self$`meta_title`
      }
      if (!is.null(self$`meta_keywords`)) {
        ProductAddObject[["meta_keywords"]] <-
          self$`meta_keywords`
      }
      if (!is.null(self$`meta_description`)) {
        ProductAddObject[["meta_description"]] <-
          self$`meta_description`
      }
      if (!is.null(self$`url`)) {
        ProductAddObject[["url"]] <-
          self$`url`
      }
      if (!is.null(self$`seo_url`)) {
        ProductAddObject[["seo_url"]] <-
          self$`seo_url`
      }
      if (!is.null(self$`tax_class_id`)) {
        ProductAddObject[["tax_class_id"]] <-
          self$`tax_class_id`
      }
      if (!is.null(self$`taxable`)) {
        ProductAddObject[["taxable"]] <-
          self$`taxable`
      }
      if (!is.null(self$`sales_tax`)) {
        ProductAddObject[["sales_tax"]] <-
          self$`sales_tax`$toSimpleType()
      }
      if (!is.null(self$`condition`)) {
        ProductAddObject[["condition"]] <-
          self$`condition`
      }
      if (!is.null(self$`condition_description`)) {
        ProductAddObject[["condition_description"]] <-
          self$`condition_description`
      }
      if (!is.null(self$`allow_display_condition`)) {
        ProductAddObject[["allow_display_condition"]] <-
          self$`allow_display_condition`
      }
      if (!is.null(self$`payment_methods`)) {
        ProductAddObject[["payment_methods"]] <-
          self$`payment_methods`
      }
      if (!is.null(self$`paypal_email`)) {
        ProductAddObject[["paypal_email"]] <-
          self$`paypal_email`
      }
      if (!is.null(self$`shipping_template_id`)) {
        ProductAddObject[["shipping_template_id"]] <-
          self$`shipping_template_id`
      }
      if (!is.null(self$`processing_profile_id`)) {
        ProductAddObject[["processing_profile_id"]] <-
          self$`processing_profile_id`
      }
      if (!is.null(self$`shipping_details`)) {
        ProductAddObject[["shipping_details"]] <-
          lapply(self$`shipping_details`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`is_free_shipping`)) {
        ProductAddObject[["is_free_shipping"]] <-
          self$`is_free_shipping`
      }
      if (!is.null(self$`delivery_code`)) {
        ProductAddObject[["delivery_code"]] <-
          self$`delivery_code`
      }
      if (!is.null(self$`delivery_type`)) {
        ProductAddObject[["delivery_type"]] <-
          self$`delivery_type`
      }
      if (!is.null(self$`delivery_time`)) {
        ProductAddObject[["delivery_time"]] <-
          self$`delivery_time`
      }
      if (!is.null(self$`delivery_option_ids`)) {
        ProductAddObject[["delivery_option_ids"]] <-
          self$`delivery_option_ids`
      }
      if (!is.null(self$`package_details`)) {
        ProductAddObject[["package_details"]] <-
          self$`package_details`$toSimpleType()
      }
      if (!is.null(self$`logistic_info`)) {
        ProductAddObject[["logistic_info"]] <-
          lapply(self$`logistic_info`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`listing_duration`)) {
        ProductAddObject[["listing_duration"]] <-
          self$`listing_duration`
      }
      if (!is.null(self$`listing_type`)) {
        ProductAddObject[["listing_type"]] <-
          self$`listing_type`
      }
      if (!is.null(self$`category_type`)) {
        ProductAddObject[["category_type"]] <-
          self$`category_type`
      }
      if (!is.null(self$`return_accepted`)) {
        ProductAddObject[["return_accepted"]] <-
          self$`return_accepted`
      }
      if (!is.null(self$`seller_profiles`)) {
        ProductAddObject[["seller_profiles"]] <-
          self$`seller_profiles`$toSimpleType()
      }
      if (!is.null(self$`auction_confidentiality_level`)) {
        ProductAddObject[["auction_confidentiality_level"]] <-
          self$`auction_confidentiality_level`
      }
      if (!is.null(self$`best_offer`)) {
        ProductAddObject[["best_offer"]] <-
          self$`best_offer`$toSimpleType()
      }
      if (!is.null(self$`production_partner_ids`)) {
        ProductAddObject[["production_partner_ids"]] <-
          self$`production_partner_ids`
      }
      if (!is.null(self$`marketplace_item_properties`)) {
        ProductAddObject[["marketplace_item_properties"]] <-
          self$`marketplace_item_properties`
      }
      if (!is.null(self$`clear_cache`)) {
        ProductAddObject[["clear_cache"]] <-
          self$`clear_cache`
      }
      if (!is.null(self$`viewed_count`)) {
        ProductAddObject[["viewed_count"]] <-
          self$`viewed_count`
      }
      if (!is.null(self$`ordered_count`)) {
        ProductAddObject[["ordered_count"]] <-
          self$`ordered_count`
      }
      if (!is.null(self$`shop_section_id`)) {
        ProductAddObject[["shop_section_id"]] <-
          self$`shop_section_id`
      }
      if (!is.null(self$`return_policy_id`)) {
        ProductAddObject[["return_policy_id"]] <-
          self$`return_policy_id`
      }
      if (!is.null(self$`personalization_details`)) {
        ProductAddObject[["personalization_details"]] <-
          self$`personalization_details`$toSimpleType()
      }
      if (!is.null(self$`personalization_questions`)) {
        ProductAddObject[["personalization_questions"]] <-
          lapply(self$`personalization_questions`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`manufacturer_ids`)) {
        ProductAddObject[["manufacturer_ids"]] <-
          self$`manufacturer_ids`
      }
      if (!is.null(self$`responsible_person_ids`)) {
        ProductAddObject[["responsible_person_ids"]] <-
          self$`responsible_person_ids`
      }
      if (!is.null(self$`idempotency_key`)) {
        ProductAddObject[["idempotency_key"]] <-
          self$`idempotency_key`
      }
      return(ProductAddObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductAdd
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductAdd
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`model`)) {
        self$`model` <- this_object$`model`
      }
      if (!is.null(this_object$`description`)) {
        self$`description` <- this_object$`description`
      }
      if (!is.null(this_object$`price`)) {
        self$`price` <- this_object$`price`
      }
      if (!is.null(this_object$`sku`)) {
        self$`sku` <- this_object$`sku`
      }
      if (!is.null(this_object$`short_description`)) {
        self$`short_description` <- this_object$`short_description`
      }
      if (!is.null(this_object$`type`)) {
        self$`type` <- this_object$`type`
      }
      if (!is.null(this_object$`status`)) {
        self$`status` <- this_object$`status`
      }
      if (!is.null(this_object$`visible`)) {
        self$`visible` <- this_object$`visible`
      }
      if (!is.null(this_object$`category_id`)) {
        self$`category_id` <- this_object$`category_id`
      }
      if (!is.null(this_object$`categories_ids`)) {
        self$`categories_ids` <- this_object$`categories_ids`
      }
      if (!is.null(this_object$`product_class`)) {
        self$`product_class` <- this_object$`product_class`
      }
      if (!is.null(this_object$`product_type`)) {
        self$`product_type` <- this_object$`product_type`
      }
      if (!is.null(this_object$`is_virtual`)) {
        self$`is_virtual` <- this_object$`is_virtual`
      }
      if (!is.null(this_object$`downloadable`)) {
        self$`downloadable` <- this_object$`downloadable`
      }
      if (!is.null(this_object$`is_supply`)) {
        self$`is_supply` <- this_object$`is_supply`
      }
      if (!is.null(this_object$`available_for_view`)) {
        self$`available_for_view` <- this_object$`available_for_view`
      }
      if (!is.null(this_object$`available_for_sale`)) {
        self$`available_for_sale` <- this_object$`available_for_sale`
      }
      if (!is.null(this_object$`store_id`)) {
        self$`store_id` <- this_object$`store_id`
      }
      if (!is.null(this_object$`stores_ids`)) {
        self$`stores_ids` <- this_object$`stores_ids`
      }
      if (!is.null(this_object$`lang_id`)) {
        self$`lang_id` <- this_object$`lang_id`
      }
      if (!is.null(this_object$`old_price`)) {
        self$`old_price` <- this_object$`old_price`
      }
      if (!is.null(this_object$`special_price`)) {
        self$`special_price` <- this_object$`special_price`
      }
      if (!is.null(this_object$`wholesale_price`)) {
        self$`wholesale_price` <- this_object$`wholesale_price`
      }
      if (!is.null(this_object$`cost_price`)) {
        self$`cost_price` <- this_object$`cost_price`
      }
      if (!is.null(this_object$`fixed_cost_shipping_price`)) {
        self$`fixed_cost_shipping_price` <- this_object$`fixed_cost_shipping_price`
      }
      if (!is.null(this_object$`tier_prices`)) {
        self$`tier_prices` <- ApiClient$new()$deserializeObj(this_object$`tier_prices`, "array[ProductAddTierPricesInner]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`group_prices`)) {
        self$`group_prices` <- ApiClient$new()$deserializeObj(this_object$`group_prices`, "array[ProductAddGroupPricesInner]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`buyitnow_price`)) {
        self$`buyitnow_price` <- this_object$`buyitnow_price`
      }
      if (!is.null(this_object$`reserve_price`)) {
        self$`reserve_price` <- this_object$`reserve_price`
      }
      if (!is.null(this_object$`measure_unit`)) {
        self$`measure_unit` <- this_object$`measure_unit`
      }
      if (!is.null(this_object$`unit_price`)) {
        self$`unit_price` <- this_object$`unit_price`
      }
      if (!is.null(this_object$`prices_inc_tax`)) {
        self$`prices_inc_tax` <- this_object$`prices_inc_tax`
      }
      if (!is.null(this_object$`quantity`)) {
        self$`quantity` <- this_object$`quantity`
      }
      if (!is.null(this_object$`in_stock`)) {
        self$`in_stock` <- this_object$`in_stock`
      }
      if (!is.null(this_object$`manage_stock`)) {
        self$`manage_stock` <- this_object$`manage_stock`
      }
      if (!is.null(this_object$`warehouse_id`)) {
        self$`warehouse_id` <- this_object$`warehouse_id`
      }
      if (!is.null(this_object$`backorder_status`)) {
        self$`backorder_status` <- this_object$`backorder_status`
      }
      if (!is.null(this_object$`min_order_quantity`)) {
        self$`min_order_quantity` <- this_object$`min_order_quantity`
      }
      if (!is.null(this_object$`max_order_quantity`)) {
        self$`max_order_quantity` <- this_object$`max_order_quantity`
      }
      if (!is.null(this_object$`low_stock_threshold`)) {
        self$`low_stock_threshold` <- this_object$`low_stock_threshold`
      }
      if (!is.null(this_object$`weight`)) {
        self$`weight` <- this_object$`weight`
      }
      if (!is.null(this_object$`weight_unit`)) {
        self$`weight_unit` <- this_object$`weight_unit`
      }
      if (!is.null(this_object$`width`)) {
        self$`width` <- this_object$`width`
      }
      if (!is.null(this_object$`height`)) {
        self$`height` <- this_object$`height`
      }
      if (!is.null(this_object$`length`)) {
        self$`length` <- this_object$`length`
      }
      if (!is.null(this_object$`dimensions_unit`)) {
        self$`dimensions_unit` <- this_object$`dimensions_unit`
      }
      if (!is.null(this_object$`barcode`)) {
        self$`barcode` <- this_object$`barcode`
      }
      if (!is.null(this_object$`upc`)) {
        self$`upc` <- this_object$`upc`
      }
      if (!is.null(this_object$`ean`)) {
        self$`ean` <- this_object$`ean`
      }
      if (!is.null(this_object$`isbn`)) {
        self$`isbn` <- this_object$`isbn`
      }
      if (!is.null(this_object$`gtin`)) {
        self$`gtin` <- this_object$`gtin`
      }
      if (!is.null(this_object$`mpn`)) {
        self$`mpn` <- this_object$`mpn`
      }
      if (!is.null(this_object$`asin`)) {
        self$`asin` <- this_object$`asin`
      }
      if (!is.null(this_object$`product_reference`)) {
        self$`product_reference` <- this_object$`product_reference`
      }
      if (!is.null(this_object$`external_product_link`)) {
        self$`external_product_link` <- this_object$`external_product_link`
      }
      if (!is.null(this_object$`harmonized_system_code`)) {
        self$`harmonized_system_code` <- this_object$`harmonized_system_code`
      }
      if (!is.null(this_object$`country_of_origin`)) {
        self$`country_of_origin` <- this_object$`country_of_origin`
      }
      if (!is.null(this_object$`manufacturer`)) {
        self$`manufacturer` <- this_object$`manufacturer`
      }
      if (!is.null(this_object$`manufacturer_id`)) {
        self$`manufacturer_id` <- this_object$`manufacturer_id`
      }
      if (!is.null(this_object$`manufacturer_info`)) {
        `manufacturer_info_object` <- ProductAddManufacturerInfo$new()
        `manufacturer_info_object`$fromJSON(jsonlite::toJSON(this_object$`manufacturer_info`, auto_unbox = TRUE, digits = NA))
        self$`manufacturer_info` <- `manufacturer_info_object`
      }
      if (!is.null(this_object$`brand_name`)) {
        self$`brand_name` <- this_object$`brand_name`
      }
      if (!is.null(this_object$`image_url`)) {
        self$`image_url` <- this_object$`image_url`
      }
      if (!is.null(this_object$`image_name`)) {
        self$`image_name` <- this_object$`image_name`
      }
      if (!is.null(this_object$`additional_image_urls`)) {
        self$`additional_image_urls` <- ApiClient$new()$deserializeObj(this_object$`additional_image_urls`, "array[character]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`files`)) {
        self$`files` <- ApiClient$new()$deserializeObj(this_object$`files`, "array[ProductAddFilesInner]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`size_chart`)) {
        `size_chart_object` <- ProductAddSizeChart$new()
        `size_chart_object`$fromJSON(jsonlite::toJSON(this_object$`size_chart`, auto_unbox = TRUE, digits = NA))
        self$`size_chart` <- `size_chart_object`
      }
      if (!is.null(this_object$`related_products_ids`)) {
        self$`related_products_ids` <- this_object$`related_products_ids`
      }
      if (!is.null(this_object$`up_sell_products_ids`)) {
        self$`up_sell_products_ids` <- this_object$`up_sell_products_ids`
      }
      if (!is.null(this_object$`cross_sell_products_ids`)) {
        self$`cross_sell_products_ids` <- this_object$`cross_sell_products_ids`
      }
      if (!is.null(this_object$`attribute_set_name`)) {
        self$`attribute_set_name` <- this_object$`attribute_set_name`
      }
      if (!is.null(this_object$`attribute_name`)) {
        self$`attribute_name` <- this_object$`attribute_name`
      }
      if (!is.null(this_object$`search_keywords`)) {
        self$`search_keywords` <- this_object$`search_keywords`
      }
      if (!is.null(this_object$`tags`)) {
        self$`tags` <- this_object$`tags`
      }
      if (!is.null(this_object$`materials`)) {
        self$`materials` <- ApiClient$new()$deserializeObj(this_object$`materials`, "array[character]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`certifications`)) {
        self$`certifications` <- ApiClient$new()$deserializeObj(this_object$`certifications`, "array[ProductAddCertificationsInner]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`specifics`)) {
        self$`specifics` <- ApiClient$new()$deserializeObj(this_object$`specifics`, "array[ProductAddSpecificsInner]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`avail_from`)) {
        self$`avail_from` <- this_object$`avail_from`
      }
      if (!is.null(this_object$`sprice_create`)) {
        self$`sprice_create` <- this_object$`sprice_create`
      }
      if (!is.null(this_object$`sprice_modified`)) {
        self$`sprice_modified` <- this_object$`sprice_modified`
      }
      if (!is.null(this_object$`sprice_expire`)) {
        self$`sprice_expire` <- this_object$`sprice_expire`
      }
      if (!is.null(this_object$`created_at`)) {
        self$`created_at` <- this_object$`created_at`
      }
      if (!is.null(this_object$`auto_renew`)) {
        self$`auto_renew` <- this_object$`auto_renew`
      }
      if (!is.null(this_object$`when_made`)) {
        self$`when_made` <- this_object$`when_made`
      }
      if (!is.null(this_object$`meta_title`)) {
        self$`meta_title` <- this_object$`meta_title`
      }
      if (!is.null(this_object$`meta_keywords`)) {
        self$`meta_keywords` <- this_object$`meta_keywords`
      }
      if (!is.null(this_object$`meta_description`)) {
        self$`meta_description` <- this_object$`meta_description`
      }
      if (!is.null(this_object$`url`)) {
        self$`url` <- this_object$`url`
      }
      if (!is.null(this_object$`seo_url`)) {
        self$`seo_url` <- this_object$`seo_url`
      }
      if (!is.null(this_object$`tax_class_id`)) {
        self$`tax_class_id` <- this_object$`tax_class_id`
      }
      if (!is.null(this_object$`taxable`)) {
        self$`taxable` <- this_object$`taxable`
      }
      if (!is.null(this_object$`sales_tax`)) {
        `sales_tax_object` <- ProductAddSalesTax$new()
        `sales_tax_object`$fromJSON(jsonlite::toJSON(this_object$`sales_tax`, auto_unbox = TRUE, digits = NA))
        self$`sales_tax` <- `sales_tax_object`
      }
      if (!is.null(this_object$`condition`)) {
        self$`condition` <- this_object$`condition`
      }
      if (!is.null(this_object$`condition_description`)) {
        self$`condition_description` <- this_object$`condition_description`
      }
      if (!is.null(this_object$`allow_display_condition`)) {
        self$`allow_display_condition` <- this_object$`allow_display_condition`
      }
      if (!is.null(this_object$`payment_methods`)) {
        self$`payment_methods` <- ApiClient$new()$deserializeObj(this_object$`payment_methods`, "array[character]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`paypal_email`)) {
        self$`paypal_email` <- this_object$`paypal_email`
      }
      if (!is.null(this_object$`shipping_template_id`)) {
        self$`shipping_template_id` <- this_object$`shipping_template_id`
      }
      if (!is.null(this_object$`processing_profile_id`)) {
        self$`processing_profile_id` <- this_object$`processing_profile_id`
      }
      if (!is.null(this_object$`shipping_details`)) {
        self$`shipping_details` <- ApiClient$new()$deserializeObj(this_object$`shipping_details`, "array[ProductAddShippingDetailsInner]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`is_free_shipping`)) {
        self$`is_free_shipping` <- this_object$`is_free_shipping`
      }
      if (!is.null(this_object$`delivery_code`)) {
        self$`delivery_code` <- this_object$`delivery_code`
      }
      if (!is.null(this_object$`delivery_type`)) {
        self$`delivery_type` <- this_object$`delivery_type`
      }
      if (!is.null(this_object$`delivery_time`)) {
        self$`delivery_time` <- this_object$`delivery_time`
      }
      if (!is.null(this_object$`delivery_option_ids`)) {
        self$`delivery_option_ids` <- this_object$`delivery_option_ids`
      }
      if (!is.null(this_object$`package_details`)) {
        `package_details_object` <- ProductAddPackageDetails$new()
        `package_details_object`$fromJSON(jsonlite::toJSON(this_object$`package_details`, auto_unbox = TRUE, digits = NA))
        self$`package_details` <- `package_details_object`
      }
      if (!is.null(this_object$`logistic_info`)) {
        self$`logistic_info` <- ApiClient$new()$deserializeObj(this_object$`logistic_info`, "array[ProductAddLogisticInfoInner]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`listing_duration`)) {
        self$`listing_duration` <- this_object$`listing_duration`
      }
      if (!is.null(this_object$`listing_type`)) {
        self$`listing_type` <- this_object$`listing_type`
      }
      if (!is.null(this_object$`category_type`)) {
        self$`category_type` <- this_object$`category_type`
      }
      if (!is.null(this_object$`return_accepted`)) {
        self$`return_accepted` <- this_object$`return_accepted`
      }
      if (!is.null(this_object$`seller_profiles`)) {
        `seller_profiles_object` <- ProductAddSellerProfiles$new()
        `seller_profiles_object`$fromJSON(jsonlite::toJSON(this_object$`seller_profiles`, auto_unbox = TRUE, digits = NA))
        self$`seller_profiles` <- `seller_profiles_object`
      }
      if (!is.null(this_object$`auction_confidentiality_level`)) {
        self$`auction_confidentiality_level` <- this_object$`auction_confidentiality_level`
      }
      if (!is.null(this_object$`best_offer`)) {
        `best_offer_object` <- ProductAddBestOffer$new()
        `best_offer_object`$fromJSON(jsonlite::toJSON(this_object$`best_offer`, auto_unbox = TRUE, digits = NA))
        self$`best_offer` <- `best_offer_object`
      }
      if (!is.null(this_object$`production_partner_ids`)) {
        self$`production_partner_ids` <- this_object$`production_partner_ids`
      }
      if (!is.null(this_object$`marketplace_item_properties`)) {
        self$`marketplace_item_properties` <- this_object$`marketplace_item_properties`
      }
      if (!is.null(this_object$`clear_cache`)) {
        self$`clear_cache` <- this_object$`clear_cache`
      }
      if (!is.null(this_object$`viewed_count`)) {
        self$`viewed_count` <- this_object$`viewed_count`
      }
      if (!is.null(this_object$`ordered_count`)) {
        self$`ordered_count` <- this_object$`ordered_count`
      }
      if (!is.null(this_object$`shop_section_id`)) {
        self$`shop_section_id` <- this_object$`shop_section_id`
      }
      if (!is.null(this_object$`return_policy_id`)) {
        self$`return_policy_id` <- this_object$`return_policy_id`
      }
      if (!is.null(this_object$`personalization_details`)) {
        `personalization_details_object` <- ProductAddPersonalizationDetails$new()
        `personalization_details_object`$fromJSON(jsonlite::toJSON(this_object$`personalization_details`, auto_unbox = TRUE, digits = NA))
        self$`personalization_details` <- `personalization_details_object`
      }
      if (!is.null(this_object$`personalization_questions`)) {
        self$`personalization_questions` <- ApiClient$new()$deserializeObj(this_object$`personalization_questions`, "array[ProductAddPersonalizationQuestionsInner]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`manufacturer_ids`)) {
        self$`manufacturer_ids` <- this_object$`manufacturer_ids`
      }
      if (!is.null(this_object$`responsible_person_ids`)) {
        self$`responsible_person_ids` <- this_object$`responsible_person_ids`
      }
      if (!is.null(this_object$`idempotency_key`)) {
        self$`idempotency_key` <- this_object$`idempotency_key`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductAdd in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductAdd
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductAdd
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`name` <- this_object$`name`
      self$`model` <- this_object$`model`
      self$`description` <- this_object$`description`
      self$`price` <- this_object$`price`
      self$`sku` <- this_object$`sku`
      self$`short_description` <- this_object$`short_description`
      self$`type` <- this_object$`type`
      self$`status` <- this_object$`status`
      self$`visible` <- this_object$`visible`
      self$`category_id` <- this_object$`category_id`
      self$`categories_ids` <- this_object$`categories_ids`
      self$`product_class` <- this_object$`product_class`
      self$`product_type` <- this_object$`product_type`
      self$`is_virtual` <- this_object$`is_virtual`
      self$`downloadable` <- this_object$`downloadable`
      self$`is_supply` <- this_object$`is_supply`
      self$`available_for_view` <- this_object$`available_for_view`
      self$`available_for_sale` <- this_object$`available_for_sale`
      self$`store_id` <- this_object$`store_id`
      self$`stores_ids` <- this_object$`stores_ids`
      self$`lang_id` <- this_object$`lang_id`
      self$`old_price` <- this_object$`old_price`
      self$`special_price` <- this_object$`special_price`
      self$`wholesale_price` <- this_object$`wholesale_price`
      self$`cost_price` <- this_object$`cost_price`
      self$`fixed_cost_shipping_price` <- this_object$`fixed_cost_shipping_price`
      self$`tier_prices` <- ApiClient$new()$deserializeObj(this_object$`tier_prices`, "array[ProductAddTierPricesInner]", loadNamespace("openapi"))
      self$`group_prices` <- ApiClient$new()$deserializeObj(this_object$`group_prices`, "array[ProductAddGroupPricesInner]", loadNamespace("openapi"))
      self$`buyitnow_price` <- this_object$`buyitnow_price`
      self$`reserve_price` <- this_object$`reserve_price`
      self$`measure_unit` <- this_object$`measure_unit`
      self$`unit_price` <- this_object$`unit_price`
      self$`prices_inc_tax` <- this_object$`prices_inc_tax`
      self$`quantity` <- this_object$`quantity`
      self$`in_stock` <- this_object$`in_stock`
      self$`manage_stock` <- this_object$`manage_stock`
      self$`warehouse_id` <- this_object$`warehouse_id`
      self$`backorder_status` <- this_object$`backorder_status`
      self$`min_order_quantity` <- this_object$`min_order_quantity`
      self$`max_order_quantity` <- this_object$`max_order_quantity`
      self$`low_stock_threshold` <- this_object$`low_stock_threshold`
      self$`weight` <- this_object$`weight`
      self$`weight_unit` <- this_object$`weight_unit`
      self$`width` <- this_object$`width`
      self$`height` <- this_object$`height`
      self$`length` <- this_object$`length`
      self$`dimensions_unit` <- this_object$`dimensions_unit`
      self$`barcode` <- this_object$`barcode`
      self$`upc` <- this_object$`upc`
      self$`ean` <- this_object$`ean`
      self$`isbn` <- this_object$`isbn`
      self$`gtin` <- this_object$`gtin`
      self$`mpn` <- this_object$`mpn`
      self$`asin` <- this_object$`asin`
      self$`product_reference` <- this_object$`product_reference`
      self$`external_product_link` <- this_object$`external_product_link`
      self$`harmonized_system_code` <- this_object$`harmonized_system_code`
      self$`country_of_origin` <- this_object$`country_of_origin`
      self$`manufacturer` <- this_object$`manufacturer`
      self$`manufacturer_id` <- this_object$`manufacturer_id`
      self$`manufacturer_info` <- ProductAddManufacturerInfo$new()$fromJSON(jsonlite::toJSON(this_object$`manufacturer_info`, auto_unbox = TRUE, digits = NA))
      self$`brand_name` <- this_object$`brand_name`
      self$`image_url` <- this_object$`image_url`
      self$`image_name` <- this_object$`image_name`
      self$`additional_image_urls` <- ApiClient$new()$deserializeObj(this_object$`additional_image_urls`, "array[character]", loadNamespace("openapi"))
      self$`files` <- ApiClient$new()$deserializeObj(this_object$`files`, "array[ProductAddFilesInner]", loadNamespace("openapi"))
      self$`size_chart` <- ProductAddSizeChart$new()$fromJSON(jsonlite::toJSON(this_object$`size_chart`, auto_unbox = TRUE, digits = NA))
      self$`related_products_ids` <- this_object$`related_products_ids`
      self$`up_sell_products_ids` <- this_object$`up_sell_products_ids`
      self$`cross_sell_products_ids` <- this_object$`cross_sell_products_ids`
      self$`attribute_set_name` <- this_object$`attribute_set_name`
      self$`attribute_name` <- this_object$`attribute_name`
      self$`search_keywords` <- this_object$`search_keywords`
      self$`tags` <- this_object$`tags`
      self$`materials` <- ApiClient$new()$deserializeObj(this_object$`materials`, "array[character]", loadNamespace("openapi"))
      self$`certifications` <- ApiClient$new()$deserializeObj(this_object$`certifications`, "array[ProductAddCertificationsInner]", loadNamespace("openapi"))
      self$`specifics` <- ApiClient$new()$deserializeObj(this_object$`specifics`, "array[ProductAddSpecificsInner]", loadNamespace("openapi"))
      self$`avail_from` <- this_object$`avail_from`
      self$`sprice_create` <- this_object$`sprice_create`
      self$`sprice_modified` <- this_object$`sprice_modified`
      self$`sprice_expire` <- this_object$`sprice_expire`
      self$`created_at` <- this_object$`created_at`
      self$`auto_renew` <- this_object$`auto_renew`
      self$`when_made` <- this_object$`when_made`
      self$`meta_title` <- this_object$`meta_title`
      self$`meta_keywords` <- this_object$`meta_keywords`
      self$`meta_description` <- this_object$`meta_description`
      self$`url` <- this_object$`url`
      self$`seo_url` <- this_object$`seo_url`
      self$`tax_class_id` <- this_object$`tax_class_id`
      self$`taxable` <- this_object$`taxable`
      self$`sales_tax` <- ProductAddSalesTax$new()$fromJSON(jsonlite::toJSON(this_object$`sales_tax`, auto_unbox = TRUE, digits = NA))
      self$`condition` <- this_object$`condition`
      self$`condition_description` <- this_object$`condition_description`
      self$`allow_display_condition` <- this_object$`allow_display_condition`
      self$`payment_methods` <- ApiClient$new()$deserializeObj(this_object$`payment_methods`, "array[character]", loadNamespace("openapi"))
      self$`paypal_email` <- this_object$`paypal_email`
      self$`shipping_template_id` <- this_object$`shipping_template_id`
      self$`processing_profile_id` <- this_object$`processing_profile_id`
      self$`shipping_details` <- ApiClient$new()$deserializeObj(this_object$`shipping_details`, "array[ProductAddShippingDetailsInner]", loadNamespace("openapi"))
      self$`is_free_shipping` <- this_object$`is_free_shipping`
      self$`delivery_code` <- this_object$`delivery_code`
      self$`delivery_type` <- this_object$`delivery_type`
      self$`delivery_time` <- this_object$`delivery_time`
      self$`delivery_option_ids` <- this_object$`delivery_option_ids`
      self$`package_details` <- ProductAddPackageDetails$new()$fromJSON(jsonlite::toJSON(this_object$`package_details`, auto_unbox = TRUE, digits = NA))
      self$`logistic_info` <- ApiClient$new()$deserializeObj(this_object$`logistic_info`, "array[ProductAddLogisticInfoInner]", loadNamespace("openapi"))
      self$`listing_duration` <- this_object$`listing_duration`
      self$`listing_type` <- this_object$`listing_type`
      self$`category_type` <- this_object$`category_type`
      self$`return_accepted` <- this_object$`return_accepted`
      self$`seller_profiles` <- ProductAddSellerProfiles$new()$fromJSON(jsonlite::toJSON(this_object$`seller_profiles`, auto_unbox = TRUE, digits = NA))
      self$`auction_confidentiality_level` <- this_object$`auction_confidentiality_level`
      self$`best_offer` <- ProductAddBestOffer$new()$fromJSON(jsonlite::toJSON(this_object$`best_offer`, auto_unbox = TRUE, digits = NA))
      self$`production_partner_ids` <- this_object$`production_partner_ids`
      self$`marketplace_item_properties` <- this_object$`marketplace_item_properties`
      self$`clear_cache` <- this_object$`clear_cache`
      self$`viewed_count` <- this_object$`viewed_count`
      self$`ordered_count` <- this_object$`ordered_count`
      self$`shop_section_id` <- this_object$`shop_section_id`
      self$`return_policy_id` <- this_object$`return_policy_id`
      self$`personalization_details` <- ProductAddPersonalizationDetails$new()$fromJSON(jsonlite::toJSON(this_object$`personalization_details`, auto_unbox = TRUE, digits = NA))
      self$`personalization_questions` <- ApiClient$new()$deserializeObj(this_object$`personalization_questions`, "array[ProductAddPersonalizationQuestionsInner]", loadNamespace("openapi"))
      self$`manufacturer_ids` <- this_object$`manufacturer_ids`
      self$`responsible_person_ids` <- this_object$`responsible_person_ids`
      self$`idempotency_key` <- this_object$`idempotency_key`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductAdd and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
      # check the required field `name`
      if (!is.null(input_json$`name`)) {
        if (!(is.character(input_json$`name`) && length(input_json$`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", input_json$`name`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for ProductAdd: the required field `name` is missing."))
      }
      # check the required field `model`
      if (!is.null(input_json$`model`)) {
        if (!(is.character(input_json$`model`) && length(input_json$`model`) == 1)) {
          stop(paste("Error! Invalid data for `model`. Must be a string:", input_json$`model`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for ProductAdd: the required field `model` is missing."))
      }
      # check the required field `description`
      if (!is.null(input_json$`description`)) {
        if (!(is.character(input_json$`description`) && length(input_json$`description`) == 1)) {
          stop(paste("Error! Invalid data for `description`. Must be a string:", input_json$`description`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for ProductAdd: the required field `description` is missing."))
      }
      # check the required field `price`
      if (!is.null(input_json$`price`)) {
      } else {
        stop(paste("The JSON input `", input, "` is invalid for ProductAdd: the required field `price` is missing."))
      }
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductAdd
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      # check if the required `name` is null
      if (is.null(self$`name`)) {
        return(FALSE)
      }

      # check if the required `model` is null
      if (is.null(self$`model`)) {
        return(FALSE)
      }

      # check if the required `description` is null
      if (is.null(self$`description`)) {
        return(FALSE)
      }

      # check if the required `price` is null
      if (is.null(self$`price`)) {
        return(FALSE)
      }

      if (length(self$`personalization_questions`) > 5) {
        return(FALSE)
      }
      if (length(self$`personalization_questions`) < 1) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      # check if the required `name` is null
      if (is.null(self$`name`)) {
        invalid_fields["name"] <- "Non-nullable required field `name` cannot be null."
      }

      # check if the required `model` is null
      if (is.null(self$`model`)) {
        invalid_fields["model"] <- "Non-nullable required field `model` cannot be null."
      }

      # check if the required `description` is null
      if (is.null(self$`description`)) {
        invalid_fields["description"] <- "Non-nullable required field `description` cannot be null."
      }

      # check if the required `price` is null
      if (is.null(self$`price`)) {
        invalid_fields["price"] <- "Non-nullable required field `price` cannot be null."
      }

      if (length(self$`personalization_questions`) > 5) {
        invalid_fields["personalization_questions"] <- "Invalid length for `personalization_questions`, number of items must be less than or equal to 5."
      }
      if (length(self$`personalization_questions`) < 1) {
        invalid_fields["personalization_questions"] <- "Invalid length for ``, number of items must be greater than or equal to 1."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductAdd$unlock()
#
## Below is an example to define the print function
# ProductAdd$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductAdd$lock()

