#' Create a new CatalogPriceRule
#'
#' @description
#' CatalogPriceRule Class
#'
#' @docType class
#' @title CatalogPriceRule
#' @description CatalogPriceRule Class
#' @format An \code{R6Class} generator object
#' @field id  character [optional]
#' @field gid  character [optional]
#' @field type  character [optional]
#' @field name  character [optional]
#' @field description  character [optional]
#' @field short_description  character [optional]
#' @field avail  character [optional]
#' @field actions  list(\link{CatalogPriceRuleAction}) [optional]
#' @field created_time  \link{A2CDateTime} [optional]
#' @field date_start  \link{A2CDateTime} [optional]
#' @field date_end  \link{A2CDateTime} [optional]
#' @field usage_count  numeric [optional]
#' @field conditions  list(\link{CouponCondition}) [optional]
#' @field uses_per_order_limit  integer [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
CatalogPriceRule <- R6::R6Class(
  "CatalogPriceRule",
  public = list(
    `id` = NULL,
    `gid` = NULL,
    `type` = NULL,
    `name` = NULL,
    `description` = NULL,
    `short_description` = NULL,
    `avail` = NULL,
    `actions` = NULL,
    `created_time` = NULL,
    `date_start` = NULL,
    `date_end` = NULL,
    `usage_count` = NULL,
    `conditions` = NULL,
    `uses_per_order_limit` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new CatalogPriceRule class.
    #'
    #' @param id id
    #' @param gid gid
    #' @param type type
    #' @param name name
    #' @param description description
    #' @param short_description short_description
    #' @param avail avail
    #' @param actions actions
    #' @param created_time created_time
    #' @param date_start date_start
    #' @param date_end date_end
    #' @param usage_count usage_count
    #' @param conditions conditions
    #' @param uses_per_order_limit uses_per_order_limit
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `gid` = NULL, `type` = NULL, `name` = NULL, `description` = NULL, `short_description` = NULL, `avail` = NULL, `actions` = NULL, `created_time` = NULL, `date_start` = NULL, `date_end` = NULL, `usage_count` = NULL, `conditions` = NULL, `uses_per_order_limit` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`gid`)) {
        if (!(is.character(`gid`) && length(`gid`) == 1)) {
          stop(paste("Error! Invalid data for `gid`. Must be a string:", `gid`))
        }
        self$`gid` <- `gid`
      }
      if (!is.null(`type`)) {
        if (!(is.character(`type`) && length(`type`) == 1)) {
          stop(paste("Error! Invalid data for `type`. Must be a string:", `type`))
        }
        self$`type` <- `type`
      }
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`description`)) {
        if (!(is.character(`description`) && length(`description`) == 1)) {
          stop(paste("Error! Invalid data for `description`. Must be a string:", `description`))
        }
        self$`description` <- `description`
      }
      if (!is.null(`short_description`)) {
        if (!(is.character(`short_description`) && length(`short_description`) == 1)) {
          stop(paste("Error! Invalid data for `short_description`. Must be a string:", `short_description`))
        }
        self$`short_description` <- `short_description`
      }
      if (!is.null(`avail`)) {
        if (!(is.logical(`avail`) && length(`avail`) == 1)) {
          stop(paste("Error! Invalid data for `avail`. Must be a boolean:", `avail`))
        }
        self$`avail` <- `avail`
      }
      if (!is.null(`actions`)) {
        stopifnot(is.vector(`actions`), length(`actions`) != 0)
        sapply(`actions`, function(x) stopifnot(R6::is.R6(x)))
        self$`actions` <- `actions`
      }
      if (!is.null(`created_time`)) {
        stopifnot(R6::is.R6(`created_time`))
        self$`created_time` <- `created_time`
      }
      if (!is.null(`date_start`)) {
        stopifnot(R6::is.R6(`date_start`))
        self$`date_start` <- `date_start`
      }
      if (!is.null(`date_end`)) {
        stopifnot(R6::is.R6(`date_end`))
        self$`date_end` <- `date_end`
      }
      if (!is.null(`usage_count`)) {
        self$`usage_count` <- `usage_count`
      }
      if (!is.null(`conditions`)) {
        stopifnot(is.vector(`conditions`), length(`conditions`) != 0)
        sapply(`conditions`, function(x) stopifnot(R6::is.R6(x)))
        self$`conditions` <- `conditions`
      }
      if (!is.null(`uses_per_order_limit`)) {
        if (!(is.numeric(`uses_per_order_limit`) && length(`uses_per_order_limit`) == 1)) {
          stop(paste("Error! Invalid data for `uses_per_order_limit`. Must be an integer:", `uses_per_order_limit`))
        }
        self$`uses_per_order_limit` <- `uses_per_order_limit`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return CatalogPriceRule as a base R list.
    #' @examples
    #' # convert array of CatalogPriceRule (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert CatalogPriceRule to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      CatalogPriceRuleObject <- list()
      if (!is.null(self$`id`)) {
        CatalogPriceRuleObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`gid`)) {
        CatalogPriceRuleObject[["gid"]] <-
          self$`gid`
      }
      if (!is.null(self$`type`)) {
        CatalogPriceRuleObject[["type"]] <-
          self$`type`
      }
      if (!is.null(self$`name`)) {
        CatalogPriceRuleObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`description`)) {
        CatalogPriceRuleObject[["description"]] <-
          self$`description`
      }
      if (!is.null(self$`short_description`)) {
        CatalogPriceRuleObject[["short_description"]] <-
          self$`short_description`
      }
      if (!is.null(self$`avail`)) {
        CatalogPriceRuleObject[["avail"]] <-
          self$`avail`
      }
      if (!is.null(self$`actions`)) {
        CatalogPriceRuleObject[["actions"]] <-
          lapply(self$`actions`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`created_time`)) {
        CatalogPriceRuleObject[["created_time"]] <-
          self$`created_time`$toSimpleType()
      }
      if (!is.null(self$`date_start`)) {
        CatalogPriceRuleObject[["date_start"]] <-
          self$`date_start`$toSimpleType()
      }
      if (!is.null(self$`date_end`)) {
        CatalogPriceRuleObject[["date_end"]] <-
          self$`date_end`$toSimpleType()
      }
      if (!is.null(self$`usage_count`)) {
        CatalogPriceRuleObject[["usage_count"]] <-
          self$`usage_count`
      }
      if (!is.null(self$`conditions`)) {
        CatalogPriceRuleObject[["conditions"]] <-
          lapply(self$`conditions`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`uses_per_order_limit`)) {
        CatalogPriceRuleObject[["uses_per_order_limit"]] <-
          self$`uses_per_order_limit`
      }
      if (!is.null(self$`additional_fields`)) {
        CatalogPriceRuleObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        CatalogPriceRuleObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(CatalogPriceRuleObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of CatalogPriceRule
    #'
    #' @param input_json the JSON input
    #' @return the instance of CatalogPriceRule
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`gid`)) {
        self$`gid` <- this_object$`gid`
      }
      if (!is.null(this_object$`type`)) {
        self$`type` <- this_object$`type`
      }
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`description`)) {
        self$`description` <- this_object$`description`
      }
      if (!is.null(this_object$`short_description`)) {
        self$`short_description` <- this_object$`short_description`
      }
      if (!is.null(this_object$`avail`)) {
        self$`avail` <- this_object$`avail`
      }
      if (!is.null(this_object$`actions`)) {
        self$`actions` <- ApiClient$new()$deserializeObj(this_object$`actions`, "array[CatalogPriceRuleAction]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`created_time`)) {
        `created_time_object` <- A2CDateTime$new()
        `created_time_object`$fromJSON(jsonlite::toJSON(this_object$`created_time`, auto_unbox = TRUE, digits = NA))
        self$`created_time` <- `created_time_object`
      }
      if (!is.null(this_object$`date_start`)) {
        `date_start_object` <- A2CDateTime$new()
        `date_start_object`$fromJSON(jsonlite::toJSON(this_object$`date_start`, auto_unbox = TRUE, digits = NA))
        self$`date_start` <- `date_start_object`
      }
      if (!is.null(this_object$`date_end`)) {
        `date_end_object` <- A2CDateTime$new()
        `date_end_object`$fromJSON(jsonlite::toJSON(this_object$`date_end`, auto_unbox = TRUE, digits = NA))
        self$`date_end` <- `date_end_object`
      }
      if (!is.null(this_object$`usage_count`)) {
        self$`usage_count` <- this_object$`usage_count`
      }
      if (!is.null(this_object$`conditions`)) {
        self$`conditions` <- ApiClient$new()$deserializeObj(this_object$`conditions`, "array[CouponCondition]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`uses_per_order_limit`)) {
        self$`uses_per_order_limit` <- this_object$`uses_per_order_limit`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return CatalogPriceRule in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of CatalogPriceRule
    #'
    #' @param input_json the JSON input
    #' @return the instance of CatalogPriceRule
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`gid` <- this_object$`gid`
      self$`type` <- this_object$`type`
      self$`name` <- this_object$`name`
      self$`description` <- this_object$`description`
      self$`short_description` <- this_object$`short_description`
      self$`avail` <- this_object$`avail`
      self$`actions` <- ApiClient$new()$deserializeObj(this_object$`actions`, "array[CatalogPriceRuleAction]", loadNamespace("openapi"))
      self$`created_time` <- A2CDateTime$new()$fromJSON(jsonlite::toJSON(this_object$`created_time`, auto_unbox = TRUE, digits = NA))
      self$`date_start` <- A2CDateTime$new()$fromJSON(jsonlite::toJSON(this_object$`date_start`, auto_unbox = TRUE, digits = NA))
      self$`date_end` <- A2CDateTime$new()$fromJSON(jsonlite::toJSON(this_object$`date_end`, auto_unbox = TRUE, digits = NA))
      self$`usage_count` <- this_object$`usage_count`
      self$`conditions` <- ApiClient$new()$deserializeObj(this_object$`conditions`, "array[CouponCondition]", loadNamespace("openapi"))
      self$`uses_per_order_limit` <- this_object$`uses_per_order_limit`
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to CatalogPriceRule and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of CatalogPriceRule
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# CatalogPriceRule$unlock()
#
## Below is an example to define the print function
# CatalogPriceRule$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# CatalogPriceRule$lock()

