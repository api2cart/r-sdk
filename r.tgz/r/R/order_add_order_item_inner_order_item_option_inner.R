#' Create a new OrderAddOrderItemInnerOrderItemOptionInner
#'
#' @description
#' OrderAddOrderItemInnerOrderItemOptionInner Class
#'
#' @docType class
#' @title OrderAddOrderItemInnerOrderItemOptionInner
#' @description OrderAddOrderItemInnerOrderItemOptionInner Class
#' @format An \code{R6Class} generator object
#' @field order_item_option_name Ordered Product Option Name. Where x is order item ID, y is order item option ID character [optional]
#' @field order_item_option_value Ordered product option value Where x is order item ID, y - order item option ID character [optional]
#' @field order_item_option_price Ordered product option price Where x is order item ID, y - order item option ID numeric [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
OrderAddOrderItemInnerOrderItemOptionInner <- R6::R6Class(
  "OrderAddOrderItemInnerOrderItemOptionInner",
  public = list(
    `order_item_option_name` = NULL,
    `order_item_option_value` = NULL,
    `order_item_option_price` = NULL,

    #' @description
    #' Initialize a new OrderAddOrderItemInnerOrderItemOptionInner class.
    #'
    #' @param order_item_option_name Ordered Product Option Name. Where x is order item ID, y is order item option ID
    #' @param order_item_option_value Ordered product option value Where x is order item ID, y - order item option ID
    #' @param order_item_option_price Ordered product option price Where x is order item ID, y - order item option ID
    #' @param ... Other optional arguments.
    initialize = function(`order_item_option_name` = NULL, `order_item_option_value` = NULL, `order_item_option_price` = NULL, ...) {
      if (!is.null(`order_item_option_name`)) {
        if (!(is.character(`order_item_option_name`) && length(`order_item_option_name`) == 1)) {
          stop(paste("Error! Invalid data for `order_item_option_name`. Must be a string:", `order_item_option_name`))
        }
        self$`order_item_option_name` <- `order_item_option_name`
      }
      if (!is.null(`order_item_option_value`)) {
        if (!(is.character(`order_item_option_value`) && length(`order_item_option_value`) == 1)) {
          stop(paste("Error! Invalid data for `order_item_option_value`. Must be a string:", `order_item_option_value`))
        }
        self$`order_item_option_value` <- `order_item_option_value`
      }
      if (!is.null(`order_item_option_price`)) {
        self$`order_item_option_price` <- `order_item_option_price`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return OrderAddOrderItemInnerOrderItemOptionInner as a base R list.
    #' @examples
    #' # convert array of OrderAddOrderItemInnerOrderItemOptionInner (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert OrderAddOrderItemInnerOrderItemOptionInner to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      OrderAddOrderItemInnerOrderItemOptionInnerObject <- list()
      if (!is.null(self$`order_item_option_name`)) {
        OrderAddOrderItemInnerOrderItemOptionInnerObject[["order_item_option_name"]] <-
          self$`order_item_option_name`
      }
      if (!is.null(self$`order_item_option_value`)) {
        OrderAddOrderItemInnerOrderItemOptionInnerObject[["order_item_option_value"]] <-
          self$`order_item_option_value`
      }
      if (!is.null(self$`order_item_option_price`)) {
        OrderAddOrderItemInnerOrderItemOptionInnerObject[["order_item_option_price"]] <-
          self$`order_item_option_price`
      }
      return(OrderAddOrderItemInnerOrderItemOptionInnerObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderAddOrderItemInnerOrderItemOptionInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderAddOrderItemInnerOrderItemOptionInner
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`order_item_option_name`)) {
        self$`order_item_option_name` <- this_object$`order_item_option_name`
      }
      if (!is.null(this_object$`order_item_option_value`)) {
        self$`order_item_option_value` <- this_object$`order_item_option_value`
      }
      if (!is.null(this_object$`order_item_option_price`)) {
        self$`order_item_option_price` <- this_object$`order_item_option_price`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return OrderAddOrderItemInnerOrderItemOptionInner in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderAddOrderItemInnerOrderItemOptionInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderAddOrderItemInnerOrderItemOptionInner
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`order_item_option_name` <- this_object$`order_item_option_name`
      self$`order_item_option_value` <- this_object$`order_item_option_value`
      self$`order_item_option_price` <- this_object$`order_item_option_price`
      self
    },

    #' @description
    #' Validate JSON input with respect to OrderAddOrderItemInnerOrderItemOptionInner and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of OrderAddOrderItemInnerOrderItemOptionInner
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# OrderAddOrderItemInnerOrderItemOptionInner$unlock()
#
## Below is an example to define the print function
# OrderAddOrderItemInnerOrderItemOptionInner$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# OrderAddOrderItemInnerOrderItemOptionInner$lock()

