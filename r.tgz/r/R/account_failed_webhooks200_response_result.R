#' Create a new AccountFailedWebhooks200ResponseResult
#'
#' @description
#' AccountFailedWebhooks200ResponseResult Class
#'
#' @docType class
#' @title AccountFailedWebhooks200ResponseResult
#' @description AccountFailedWebhooks200ResponseResult Class
#' @format An \code{R6Class} generator object
#' @field all_failed_webhook  character [optional]
#' @field webhook  list(\link{AccountFailedWebhooks200ResponseResultWebhookInner}) [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
AccountFailedWebhooks200ResponseResult <- R6::R6Class(
  "AccountFailedWebhooks200ResponseResult",
  public = list(
    `all_failed_webhook` = NULL,
    `webhook` = NULL,

    #' @description
    #' Initialize a new AccountFailedWebhooks200ResponseResult class.
    #'
    #' @param all_failed_webhook all_failed_webhook
    #' @param webhook webhook
    #' @param ... Other optional arguments.
    initialize = function(`all_failed_webhook` = NULL, `webhook` = NULL, ...) {
      if (!is.null(`all_failed_webhook`)) {
        if (!(is.character(`all_failed_webhook`) && length(`all_failed_webhook`) == 1)) {
          stop(paste("Error! Invalid data for `all_failed_webhook`. Must be a string:", `all_failed_webhook`))
        }
        self$`all_failed_webhook` <- `all_failed_webhook`
      }
      if (!is.null(`webhook`)) {
        stopifnot(is.vector(`webhook`), length(`webhook`) != 0)
        sapply(`webhook`, function(x) stopifnot(R6::is.R6(x)))
        self$`webhook` <- `webhook`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return AccountFailedWebhooks200ResponseResult as a base R list.
    #' @examples
    #' # convert array of AccountFailedWebhooks200ResponseResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert AccountFailedWebhooks200ResponseResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      AccountFailedWebhooks200ResponseResultObject <- list()
      if (!is.null(self$`all_failed_webhook`)) {
        AccountFailedWebhooks200ResponseResultObject[["all_failed_webhook"]] <-
          self$`all_failed_webhook`
      }
      if (!is.null(self$`webhook`)) {
        AccountFailedWebhooks200ResponseResultObject[["webhook"]] <-
          lapply(self$`webhook`, function(x) x$toSimpleType())
      }
      return(AccountFailedWebhooks200ResponseResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of AccountFailedWebhooks200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of AccountFailedWebhooks200ResponseResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`all_failed_webhook`)) {
        self$`all_failed_webhook` <- this_object$`all_failed_webhook`
      }
      if (!is.null(this_object$`webhook`)) {
        self$`webhook` <- ApiClient$new()$deserializeObj(this_object$`webhook`, "array[AccountFailedWebhooks200ResponseResultWebhookInner]", loadNamespace("openapi"))
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return AccountFailedWebhooks200ResponseResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of AccountFailedWebhooks200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of AccountFailedWebhooks200ResponseResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`all_failed_webhook` <- this_object$`all_failed_webhook`
      self$`webhook` <- ApiClient$new()$deserializeObj(this_object$`webhook`, "array[AccountFailedWebhooks200ResponseResultWebhookInner]", loadNamespace("openapi"))
      self
    },

    #' @description
    #' Validate JSON input with respect to AccountFailedWebhooks200ResponseResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of AccountFailedWebhooks200ResponseResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# AccountFailedWebhooks200ResponseResult$unlock()
#
## Below is an example to define the print function
# AccountFailedWebhooks200ResponseResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# AccountFailedWebhooks200ResponseResult$lock()

