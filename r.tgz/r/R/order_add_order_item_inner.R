#' Create a new OrderAddOrderItemInner
#'
#' @description
#' OrderAddOrderItemInner Class
#'
#' @docType class
#' @title OrderAddOrderItemInner
#' @description OrderAddOrderItemInner Class
#' @format An \code{R6Class} generator object
#' @field order_item_id Defines orders specified by order item id character
#' @field order_item_name Defines orders specified by order item name character
#' @field order_item_model Defines orders specified by order item model character [optional]
#' @field order_item_price Defines orders specified by order item price numeric
#' @field order_item_quantity Defines orders specified by order item quantity integer
#' @field order_item_weight Defines orders specified by order item weight numeric [optional]
#' @field order_item_variant_id Ordered product variant. Where x is order item ID character [optional]
#' @field order_item_tax Percentage of tax for product order numeric [optional]
#' @field order_item_tax_class Id of the tax class of product. character [optional]
#' @field order_item_price_includes_tax Defines if item price includes tax character [optional]
#' @field order_item_parent Index of the parent grouped/bundle product integer [optional]
#' @field order_item_parent_option_name Option name of the parent grouped/bundle product character [optional]
#' @field order_item_allow_refund_items_separately Indicates whether subitems of the grouped/bundle product can be refunded separately character [optional]
#' @field order_item_allow_ship_items_separately Indicates whether subitems of the grouped/bundle product can be shipped separately character [optional]
#' @field order_item_option  list(\link{OrderAddOrderItemInnerOrderItemOptionInner}) [optional]
#' @field order_item_property  list(\link{OrderAddOrderItemInnerOrderItemPropertyInner}) [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
OrderAddOrderItemInner <- R6::R6Class(
  "OrderAddOrderItemInner",
  public = list(
    `order_item_id` = NULL,
    `order_item_name` = NULL,
    `order_item_model` = NULL,
    `order_item_price` = NULL,
    `order_item_quantity` = NULL,
    `order_item_weight` = NULL,
    `order_item_variant_id` = NULL,
    `order_item_tax` = NULL,
    `order_item_tax_class` = NULL,
    `order_item_price_includes_tax` = NULL,
    `order_item_parent` = NULL,
    `order_item_parent_option_name` = NULL,
    `order_item_allow_refund_items_separately` = NULL,
    `order_item_allow_ship_items_separately` = NULL,
    `order_item_option` = NULL,
    `order_item_property` = NULL,

    #' @description
    #' Initialize a new OrderAddOrderItemInner class.
    #'
    #' @param order_item_id Defines orders specified by order item id
    #' @param order_item_name Defines orders specified by order item name
    #' @param order_item_price Defines orders specified by order item price
    #' @param order_item_quantity Defines orders specified by order item quantity
    #' @param order_item_model Defines orders specified by order item model
    #' @param order_item_weight Defines orders specified by order item weight
    #' @param order_item_variant_id Ordered product variant. Where x is order item ID
    #' @param order_item_tax Percentage of tax for product order. Default to 0.
    #' @param order_item_tax_class Id of the tax class of product.
    #' @param order_item_price_includes_tax Defines if item price includes tax. Default to FALSE.
    #' @param order_item_parent Index of the parent grouped/bundle product
    #' @param order_item_parent_option_name Option name of the parent grouped/bundle product
    #' @param order_item_allow_refund_items_separately Indicates whether subitems of the grouped/bundle product can be refunded separately
    #' @param order_item_allow_ship_items_separately Indicates whether subitems of the grouped/bundle product can be shipped separately
    #' @param order_item_option order_item_option
    #' @param order_item_property order_item_property
    #' @param ... Other optional arguments.
    initialize = function(`order_item_id`, `order_item_name`, `order_item_price`, `order_item_quantity`, `order_item_model` = NULL, `order_item_weight` = NULL, `order_item_variant_id` = NULL, `order_item_tax` = 0, `order_item_tax_class` = NULL, `order_item_price_includes_tax` = FALSE, `order_item_parent` = NULL, `order_item_parent_option_name` = NULL, `order_item_allow_refund_items_separately` = NULL, `order_item_allow_ship_items_separately` = NULL, `order_item_option` = NULL, `order_item_property` = NULL, ...) {
      if (!missing(`order_item_id`)) {
        if (!(is.character(`order_item_id`) && length(`order_item_id`) == 1)) {
          stop(paste("Error! Invalid data for `order_item_id`. Must be a string:", `order_item_id`))
        }
        self$`order_item_id` <- `order_item_id`
      }
      if (!missing(`order_item_name`)) {
        if (!(is.character(`order_item_name`) && length(`order_item_name`) == 1)) {
          stop(paste("Error! Invalid data for `order_item_name`. Must be a string:", `order_item_name`))
        }
        self$`order_item_name` <- `order_item_name`
      }
      if (!missing(`order_item_price`)) {
        self$`order_item_price` <- `order_item_price`
      }
      if (!missing(`order_item_quantity`)) {
        if (!(is.numeric(`order_item_quantity`) && length(`order_item_quantity`) == 1)) {
          stop(paste("Error! Invalid data for `order_item_quantity`. Must be an integer:", `order_item_quantity`))
        }
        self$`order_item_quantity` <- `order_item_quantity`
      }
      if (!is.null(`order_item_model`)) {
        if (!(is.character(`order_item_model`) && length(`order_item_model`) == 1)) {
          stop(paste("Error! Invalid data for `order_item_model`. Must be a string:", `order_item_model`))
        }
        self$`order_item_model` <- `order_item_model`
      }
      if (!is.null(`order_item_weight`)) {
        self$`order_item_weight` <- `order_item_weight`
      }
      if (!is.null(`order_item_variant_id`)) {
        if (!(is.character(`order_item_variant_id`) && length(`order_item_variant_id`) == 1)) {
          stop(paste("Error! Invalid data for `order_item_variant_id`. Must be a string:", `order_item_variant_id`))
        }
        self$`order_item_variant_id` <- `order_item_variant_id`
      }
      if (!is.null(`order_item_tax`)) {
        self$`order_item_tax` <- `order_item_tax`
      }
      if (!is.null(`order_item_tax_class`)) {
        if (!(is.character(`order_item_tax_class`) && length(`order_item_tax_class`) == 1)) {
          stop(paste("Error! Invalid data for `order_item_tax_class`. Must be a string:", `order_item_tax_class`))
        }
        self$`order_item_tax_class` <- `order_item_tax_class`
      }
      if (!is.null(`order_item_price_includes_tax`)) {
        if (!(is.logical(`order_item_price_includes_tax`) && length(`order_item_price_includes_tax`) == 1)) {
          stop(paste("Error! Invalid data for `order_item_price_includes_tax`. Must be a boolean:", `order_item_price_includes_tax`))
        }
        self$`order_item_price_includes_tax` <- `order_item_price_includes_tax`
      }
      if (!is.null(`order_item_parent`)) {
        if (!(is.numeric(`order_item_parent`) && length(`order_item_parent`) == 1)) {
          stop(paste("Error! Invalid data for `order_item_parent`. Must be an integer:", `order_item_parent`))
        }
        self$`order_item_parent` <- `order_item_parent`
      }
      if (!is.null(`order_item_parent_option_name`)) {
        if (!(is.character(`order_item_parent_option_name`) && length(`order_item_parent_option_name`) == 1)) {
          stop(paste("Error! Invalid data for `order_item_parent_option_name`. Must be a string:", `order_item_parent_option_name`))
        }
        self$`order_item_parent_option_name` <- `order_item_parent_option_name`
      }
      if (!is.null(`order_item_allow_refund_items_separately`)) {
        if (!(is.logical(`order_item_allow_refund_items_separately`) && length(`order_item_allow_refund_items_separately`) == 1)) {
          stop(paste("Error! Invalid data for `order_item_allow_refund_items_separately`. Must be a boolean:", `order_item_allow_refund_items_separately`))
        }
        self$`order_item_allow_refund_items_separately` <- `order_item_allow_refund_items_separately`
      }
      if (!is.null(`order_item_allow_ship_items_separately`)) {
        if (!(is.logical(`order_item_allow_ship_items_separately`) && length(`order_item_allow_ship_items_separately`) == 1)) {
          stop(paste("Error! Invalid data for `order_item_allow_ship_items_separately`. Must be a boolean:", `order_item_allow_ship_items_separately`))
        }
        self$`order_item_allow_ship_items_separately` <- `order_item_allow_ship_items_separately`
      }
      if (!is.null(`order_item_option`)) {
        stopifnot(is.vector(`order_item_option`), length(`order_item_option`) != 0)
        sapply(`order_item_option`, function(x) stopifnot(R6::is.R6(x)))
        self$`order_item_option` <- `order_item_option`
      }
      if (!is.null(`order_item_property`)) {
        stopifnot(is.vector(`order_item_property`), length(`order_item_property`) != 0)
        sapply(`order_item_property`, function(x) stopifnot(R6::is.R6(x)))
        self$`order_item_property` <- `order_item_property`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return OrderAddOrderItemInner as a base R list.
    #' @examples
    #' # convert array of OrderAddOrderItemInner (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert OrderAddOrderItemInner to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      OrderAddOrderItemInnerObject <- list()
      if (!is.null(self$`order_item_id`)) {
        OrderAddOrderItemInnerObject[["order_item_id"]] <-
          self$`order_item_id`
      }
      if (!is.null(self$`order_item_name`)) {
        OrderAddOrderItemInnerObject[["order_item_name"]] <-
          self$`order_item_name`
      }
      if (!is.null(self$`order_item_model`)) {
        OrderAddOrderItemInnerObject[["order_item_model"]] <-
          self$`order_item_model`
      }
      if (!is.null(self$`order_item_price`)) {
        OrderAddOrderItemInnerObject[["order_item_price"]] <-
          self$`order_item_price`
      }
      if (!is.null(self$`order_item_quantity`)) {
        OrderAddOrderItemInnerObject[["order_item_quantity"]] <-
          self$`order_item_quantity`
      }
      if (!is.null(self$`order_item_weight`)) {
        OrderAddOrderItemInnerObject[["order_item_weight"]] <-
          self$`order_item_weight`
      }
      if (!is.null(self$`order_item_variant_id`)) {
        OrderAddOrderItemInnerObject[["order_item_variant_id"]] <-
          self$`order_item_variant_id`
      }
      if (!is.null(self$`order_item_tax`)) {
        OrderAddOrderItemInnerObject[["order_item_tax"]] <-
          self$`order_item_tax`
      }
      if (!is.null(self$`order_item_tax_class`)) {
        OrderAddOrderItemInnerObject[["order_item_tax_class"]] <-
          self$`order_item_tax_class`
      }
      if (!is.null(self$`order_item_price_includes_tax`)) {
        OrderAddOrderItemInnerObject[["order_item_price_includes_tax"]] <-
          self$`order_item_price_includes_tax`
      }
      if (!is.null(self$`order_item_parent`)) {
        OrderAddOrderItemInnerObject[["order_item_parent"]] <-
          self$`order_item_parent`
      }
      if (!is.null(self$`order_item_parent_option_name`)) {
        OrderAddOrderItemInnerObject[["order_item_parent_option_name"]] <-
          self$`order_item_parent_option_name`
      }
      if (!is.null(self$`order_item_allow_refund_items_separately`)) {
        OrderAddOrderItemInnerObject[["order_item_allow_refund_items_separately"]] <-
          self$`order_item_allow_refund_items_separately`
      }
      if (!is.null(self$`order_item_allow_ship_items_separately`)) {
        OrderAddOrderItemInnerObject[["order_item_allow_ship_items_separately"]] <-
          self$`order_item_allow_ship_items_separately`
      }
      if (!is.null(self$`order_item_option`)) {
        OrderAddOrderItemInnerObject[["order_item_option"]] <-
          lapply(self$`order_item_option`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`order_item_property`)) {
        OrderAddOrderItemInnerObject[["order_item_property"]] <-
          lapply(self$`order_item_property`, function(x) x$toSimpleType())
      }
      return(OrderAddOrderItemInnerObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderAddOrderItemInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderAddOrderItemInner
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`order_item_id`)) {
        self$`order_item_id` <- this_object$`order_item_id`
      }
      if (!is.null(this_object$`order_item_name`)) {
        self$`order_item_name` <- this_object$`order_item_name`
      }
      if (!is.null(this_object$`order_item_model`)) {
        self$`order_item_model` <- this_object$`order_item_model`
      }
      if (!is.null(this_object$`order_item_price`)) {
        self$`order_item_price` <- this_object$`order_item_price`
      }
      if (!is.null(this_object$`order_item_quantity`)) {
        self$`order_item_quantity` <- this_object$`order_item_quantity`
      }
      if (!is.null(this_object$`order_item_weight`)) {
        self$`order_item_weight` <- this_object$`order_item_weight`
      }
      if (!is.null(this_object$`order_item_variant_id`)) {
        self$`order_item_variant_id` <- this_object$`order_item_variant_id`
      }
      if (!is.null(this_object$`order_item_tax`)) {
        self$`order_item_tax` <- this_object$`order_item_tax`
      }
      if (!is.null(this_object$`order_item_tax_class`)) {
        self$`order_item_tax_class` <- this_object$`order_item_tax_class`
      }
      if (!is.null(this_object$`order_item_price_includes_tax`)) {
        self$`order_item_price_includes_tax` <- this_object$`order_item_price_includes_tax`
      }
      if (!is.null(this_object$`order_item_parent`)) {
        self$`order_item_parent` <- this_object$`order_item_parent`
      }
      if (!is.null(this_object$`order_item_parent_option_name`)) {
        self$`order_item_parent_option_name` <- this_object$`order_item_parent_option_name`
      }
      if (!is.null(this_object$`order_item_allow_refund_items_separately`)) {
        self$`order_item_allow_refund_items_separately` <- this_object$`order_item_allow_refund_items_separately`
      }
      if (!is.null(this_object$`order_item_allow_ship_items_separately`)) {
        self$`order_item_allow_ship_items_separately` <- this_object$`order_item_allow_ship_items_separately`
      }
      if (!is.null(this_object$`order_item_option`)) {
        self$`order_item_option` <- ApiClient$new()$deserializeObj(this_object$`order_item_option`, "array[OrderAddOrderItemInnerOrderItemOptionInner]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`order_item_property`)) {
        self$`order_item_property` <- ApiClient$new()$deserializeObj(this_object$`order_item_property`, "array[OrderAddOrderItemInnerOrderItemPropertyInner]", loadNamespace("openapi"))
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return OrderAddOrderItemInner in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderAddOrderItemInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderAddOrderItemInner
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`order_item_id` <- this_object$`order_item_id`
      self$`order_item_name` <- this_object$`order_item_name`
      self$`order_item_model` <- this_object$`order_item_model`
      self$`order_item_price` <- this_object$`order_item_price`
      self$`order_item_quantity` <- this_object$`order_item_quantity`
      self$`order_item_weight` <- this_object$`order_item_weight`
      self$`order_item_variant_id` <- this_object$`order_item_variant_id`
      self$`order_item_tax` <- this_object$`order_item_tax`
      self$`order_item_tax_class` <- this_object$`order_item_tax_class`
      self$`order_item_price_includes_tax` <- this_object$`order_item_price_includes_tax`
      self$`order_item_parent` <- this_object$`order_item_parent`
      self$`order_item_parent_option_name` <- this_object$`order_item_parent_option_name`
      self$`order_item_allow_refund_items_separately` <- this_object$`order_item_allow_refund_items_separately`
      self$`order_item_allow_ship_items_separately` <- this_object$`order_item_allow_ship_items_separately`
      self$`order_item_option` <- ApiClient$new()$deserializeObj(this_object$`order_item_option`, "array[OrderAddOrderItemInnerOrderItemOptionInner]", loadNamespace("openapi"))
      self$`order_item_property` <- ApiClient$new()$deserializeObj(this_object$`order_item_property`, "array[OrderAddOrderItemInnerOrderItemPropertyInner]", loadNamespace("openapi"))
      self
    },

    #' @description
    #' Validate JSON input with respect to OrderAddOrderItemInner and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
      # check the required field `order_item_id`
      if (!is.null(input_json$`order_item_id`)) {
        if (!(is.character(input_json$`order_item_id`) && length(input_json$`order_item_id`) == 1)) {
          stop(paste("Error! Invalid data for `order_item_id`. Must be a string:", input_json$`order_item_id`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for OrderAddOrderItemInner: the required field `order_item_id` is missing."))
      }
      # check the required field `order_item_name`
      if (!is.null(input_json$`order_item_name`)) {
        if (!(is.character(input_json$`order_item_name`) && length(input_json$`order_item_name`) == 1)) {
          stop(paste("Error! Invalid data for `order_item_name`. Must be a string:", input_json$`order_item_name`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for OrderAddOrderItemInner: the required field `order_item_name` is missing."))
      }
      # check the required field `order_item_price`
      if (!is.null(input_json$`order_item_price`)) {
      } else {
        stop(paste("The JSON input `", input, "` is invalid for OrderAddOrderItemInner: the required field `order_item_price` is missing."))
      }
      # check the required field `order_item_quantity`
      if (!is.null(input_json$`order_item_quantity`)) {
        if (!(is.numeric(input_json$`order_item_quantity`) && length(input_json$`order_item_quantity`) == 1)) {
          stop(paste("Error! Invalid data for `order_item_quantity`. Must be an integer:", input_json$`order_item_quantity`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for OrderAddOrderItemInner: the required field `order_item_quantity` is missing."))
      }
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of OrderAddOrderItemInner
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      # check if the required `order_item_id` is null
      if (is.null(self$`order_item_id`)) {
        return(FALSE)
      }

      # check if the required `order_item_name` is null
      if (is.null(self$`order_item_name`)) {
        return(FALSE)
      }

      # check if the required `order_item_price` is null
      if (is.null(self$`order_item_price`)) {
        return(FALSE)
      }

      # check if the required `order_item_quantity` is null
      if (is.null(self$`order_item_quantity`)) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      # check if the required `order_item_id` is null
      if (is.null(self$`order_item_id`)) {
        invalid_fields["order_item_id"] <- "Non-nullable required field `order_item_id` cannot be null."
      }

      # check if the required `order_item_name` is null
      if (is.null(self$`order_item_name`)) {
        invalid_fields["order_item_name"] <- "Non-nullable required field `order_item_name` cannot be null."
      }

      # check if the required `order_item_price` is null
      if (is.null(self$`order_item_price`)) {
        invalid_fields["order_item_price"] <- "Non-nullable required field `order_item_price` cannot be null."
      }

      # check if the required `order_item_quantity` is null
      if (is.null(self$`order_item_quantity`)) {
        invalid_fields["order_item_quantity"] <- "Non-nullable required field `order_item_quantity` cannot be null."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# OrderAddOrderItemInner$unlock()
#
## Below is an example to define the print function
# OrderAddOrderItemInner$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# OrderAddOrderItemInner$lock()

