#' Create a new OrderShipmentTrackingAdd200ResponseResult
#'
#' @description
#' OrderShipmentTrackingAdd200ResponseResult Class
#'
#' @docType class
#' @title OrderShipmentTrackingAdd200ResponseResult
#' @description OrderShipmentTrackingAdd200ResponseResult Class
#' @format An \code{R6Class} generator object
#' @field shipment_tracking_id  character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
OrderShipmentTrackingAdd200ResponseResult <- R6::R6Class(
  "OrderShipmentTrackingAdd200ResponseResult",
  public = list(
    `shipment_tracking_id` = NULL,

    #' @description
    #' Initialize a new OrderShipmentTrackingAdd200ResponseResult class.
    #'
    #' @param shipment_tracking_id shipment_tracking_id
    #' @param ... Other optional arguments.
    initialize = function(`shipment_tracking_id` = NULL, ...) {
      if (!is.null(`shipment_tracking_id`)) {
        if (!(is.character(`shipment_tracking_id`) && length(`shipment_tracking_id`) == 1)) {
          stop(paste("Error! Invalid data for `shipment_tracking_id`. Must be a string:", `shipment_tracking_id`))
        }
        self$`shipment_tracking_id` <- `shipment_tracking_id`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return OrderShipmentTrackingAdd200ResponseResult as a base R list.
    #' @examples
    #' # convert array of OrderShipmentTrackingAdd200ResponseResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert OrderShipmentTrackingAdd200ResponseResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      OrderShipmentTrackingAdd200ResponseResultObject <- list()
      if (!is.null(self$`shipment_tracking_id`)) {
        OrderShipmentTrackingAdd200ResponseResultObject[["shipment_tracking_id"]] <-
          self$`shipment_tracking_id`
      }
      return(OrderShipmentTrackingAdd200ResponseResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderShipmentTrackingAdd200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderShipmentTrackingAdd200ResponseResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`shipment_tracking_id`)) {
        self$`shipment_tracking_id` <- this_object$`shipment_tracking_id`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return OrderShipmentTrackingAdd200ResponseResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderShipmentTrackingAdd200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderShipmentTrackingAdd200ResponseResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`shipment_tracking_id` <- this_object$`shipment_tracking_id`
      self
    },

    #' @description
    #' Validate JSON input with respect to OrderShipmentTrackingAdd200ResponseResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of OrderShipmentTrackingAdd200ResponseResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# OrderShipmentTrackingAdd200ResponseResult$unlock()
#
## Below is an example to define the print function
# OrderShipmentTrackingAdd200ResponseResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# OrderShipmentTrackingAdd200ResponseResult$lock()

