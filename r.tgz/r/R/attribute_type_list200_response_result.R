#' Create a new AttributeTypeList200ResponseResult
#'
#' @description
#' AttributeTypeList200ResponseResult Class
#'
#' @docType class
#' @title AttributeTypeList200ResponseResult
#' @description AttributeTypeList200ResponseResult Class
#' @format An \code{R6Class} generator object
#' @field attribute_type  list(character) [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
AttributeTypeList200ResponseResult <- R6::R6Class(
  "AttributeTypeList200ResponseResult",
  public = list(
    `attribute_type` = NULL,

    #' @description
    #' Initialize a new AttributeTypeList200ResponseResult class.
    #'
    #' @param attribute_type attribute_type
    #' @param ... Other optional arguments.
    initialize = function(`attribute_type` = NULL, ...) {
      if (!is.null(`attribute_type`)) {
        stopifnot(is.vector(`attribute_type`), length(`attribute_type`) != 0)
        sapply(`attribute_type`, function(x) stopifnot(is.character(x)))
        self$`attribute_type` <- `attribute_type`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return AttributeTypeList200ResponseResult as a base R list.
    #' @examples
    #' # convert array of AttributeTypeList200ResponseResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert AttributeTypeList200ResponseResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      AttributeTypeList200ResponseResultObject <- list()
      if (!is.null(self$`attribute_type`)) {
        AttributeTypeList200ResponseResultObject[["attribute_type"]] <-
          self$`attribute_type`
      }
      return(AttributeTypeList200ResponseResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of AttributeTypeList200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of AttributeTypeList200ResponseResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`attribute_type`)) {
        self$`attribute_type` <- ApiClient$new()$deserializeObj(this_object$`attribute_type`, "array[character]", loadNamespace("openapi"))
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return AttributeTypeList200ResponseResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of AttributeTypeList200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of AttributeTypeList200ResponseResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`attribute_type` <- ApiClient$new()$deserializeObj(this_object$`attribute_type`, "array[character]", loadNamespace("openapi"))
      self
    },

    #' @description
    #' Validate JSON input with respect to AttributeTypeList200ResponseResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of AttributeTypeList200ResponseResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# AttributeTypeList200ResponseResult$unlock()
#
## Below is an example to define the print function
# AttributeTypeList200ResponseResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# AttributeTypeList200ResponseResult$lock()

