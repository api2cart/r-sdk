#' Create a new ResponseAnalyticsProductReportResult
#'
#' @description
#' ResponseAnalyticsProductReportResult Class
#'
#' @docType class
#' @title ResponseAnalyticsProductReportResult
#' @description ResponseAnalyticsProductReportResult Class
#' @format An \code{R6Class} generator object
#' @field period  \link{AnalyticsPeriod} [optional]
#' @field items  list(\link{AnalyticsProduct}) [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ResponseAnalyticsProductReportResult <- R6::R6Class(
  "ResponseAnalyticsProductReportResult",
  public = list(
    `period` = NULL,
    `items` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new ResponseAnalyticsProductReportResult class.
    #'
    #' @param period period
    #' @param items items
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`period` = NULL, `items` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`period`)) {
        stopifnot(R6::is.R6(`period`))
        self$`period` <- `period`
      }
      if (!is.null(`items`)) {
        stopifnot(is.vector(`items`), length(`items`) != 0)
        sapply(`items`, function(x) stopifnot(R6::is.R6(x)))
        self$`items` <- `items`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ResponseAnalyticsProductReportResult as a base R list.
    #' @examples
    #' # convert array of ResponseAnalyticsProductReportResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ResponseAnalyticsProductReportResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ResponseAnalyticsProductReportResultObject <- list()
      if (!is.null(self$`period`)) {
        ResponseAnalyticsProductReportResultObject[["period"]] <-
          self$`period`$toSimpleType()
      }
      if (!is.null(self$`items`)) {
        ResponseAnalyticsProductReportResultObject[["items"]] <-
          lapply(self$`items`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`additional_fields`)) {
        ResponseAnalyticsProductReportResultObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        ResponseAnalyticsProductReportResultObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(ResponseAnalyticsProductReportResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ResponseAnalyticsProductReportResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ResponseAnalyticsProductReportResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`period`)) {
        `period_object` <- AnalyticsPeriod$new()
        `period_object`$fromJSON(jsonlite::toJSON(this_object$`period`, auto_unbox = TRUE, digits = NA))
        self$`period` <- `period_object`
      }
      if (!is.null(this_object$`items`)) {
        self$`items` <- ApiClient$new()$deserializeObj(this_object$`items`, "array[AnalyticsProduct]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ResponseAnalyticsProductReportResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ResponseAnalyticsProductReportResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ResponseAnalyticsProductReportResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`period` <- AnalyticsPeriod$new()$fromJSON(jsonlite::toJSON(this_object$`period`, auto_unbox = TRUE, digits = NA))
      self$`items` <- ApiClient$new()$deserializeObj(this_object$`items`, "array[AnalyticsProduct]", loadNamespace("openapi"))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to ResponseAnalyticsProductReportResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ResponseAnalyticsProductReportResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ResponseAnalyticsProductReportResult$unlock()
#
## Below is an example to define the print function
# ResponseAnalyticsProductReportResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ResponseAnalyticsProductReportResult$lock()

