#' Create a new ProductTaxAdd200ResponseResult
#'
#' @description
#' ProductTaxAdd200ResponseResult Class
#'
#' @docType class
#' @title ProductTaxAdd200ResponseResult
#' @description ProductTaxAdd200ResponseResult Class
#' @format An \code{R6Class} generator object
#' @field tax_class_id  character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductTaxAdd200ResponseResult <- R6::R6Class(
  "ProductTaxAdd200ResponseResult",
  public = list(
    `tax_class_id` = NULL,

    #' @description
    #' Initialize a new ProductTaxAdd200ResponseResult class.
    #'
    #' @param tax_class_id tax_class_id
    #' @param ... Other optional arguments.
    initialize = function(`tax_class_id` = NULL, ...) {
      if (!is.null(`tax_class_id`)) {
        if (!(is.character(`tax_class_id`) && length(`tax_class_id`) == 1)) {
          stop(paste("Error! Invalid data for `tax_class_id`. Must be a string:", `tax_class_id`))
        }
        self$`tax_class_id` <- `tax_class_id`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductTaxAdd200ResponseResult as a base R list.
    #' @examples
    #' # convert array of ProductTaxAdd200ResponseResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductTaxAdd200ResponseResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductTaxAdd200ResponseResultObject <- list()
      if (!is.null(self$`tax_class_id`)) {
        ProductTaxAdd200ResponseResultObject[["tax_class_id"]] <-
          self$`tax_class_id`
      }
      return(ProductTaxAdd200ResponseResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductTaxAdd200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductTaxAdd200ResponseResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`tax_class_id`)) {
        self$`tax_class_id` <- this_object$`tax_class_id`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductTaxAdd200ResponseResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductTaxAdd200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductTaxAdd200ResponseResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`tax_class_id` <- this_object$`tax_class_id`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductTaxAdd200ResponseResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductTaxAdd200ResponseResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductTaxAdd200ResponseResult$unlock()
#
## Below is an example to define the print function
# ProductTaxAdd200ResponseResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductTaxAdd200ResponseResult$lock()

