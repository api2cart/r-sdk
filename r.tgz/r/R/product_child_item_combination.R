#' Create a new ProductChildItemCombination
#'
#' @description
#' ProductChildItemCombination Class
#'
#' @docType class
#' @title ProductChildItemCombination
#' @description ProductChildItemCombination Class
#' @format An \code{R6Class} generator object
#' @field option_id  character [optional]
#' @field option_value_id  character [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductChildItemCombination <- R6::R6Class(
  "ProductChildItemCombination",
  public = list(
    `option_id` = NULL,
    `option_value_id` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new ProductChildItemCombination class.
    #'
    #' @param option_id option_id
    #' @param option_value_id option_value_id
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`option_id` = NULL, `option_value_id` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`option_id`)) {
        if (!(is.character(`option_id`) && length(`option_id`) == 1)) {
          stop(paste("Error! Invalid data for `option_id`. Must be a string:", `option_id`))
        }
        self$`option_id` <- `option_id`
      }
      if (!is.null(`option_value_id`)) {
        if (!(is.character(`option_value_id`) && length(`option_value_id`) == 1)) {
          stop(paste("Error! Invalid data for `option_value_id`. Must be a string:", `option_value_id`))
        }
        self$`option_value_id` <- `option_value_id`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductChildItemCombination as a base R list.
    #' @examples
    #' # convert array of ProductChildItemCombination (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductChildItemCombination to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductChildItemCombinationObject <- list()
      if (!is.null(self$`option_id`)) {
        ProductChildItemCombinationObject[["option_id"]] <-
          self$`option_id`
      }
      if (!is.null(self$`option_value_id`)) {
        ProductChildItemCombinationObject[["option_value_id"]] <-
          self$`option_value_id`
      }
      if (!is.null(self$`additional_fields`)) {
        ProductChildItemCombinationObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        ProductChildItemCombinationObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(ProductChildItemCombinationObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductChildItemCombination
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductChildItemCombination
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`option_id`)) {
        self$`option_id` <- this_object$`option_id`
      }
      if (!is.null(this_object$`option_value_id`)) {
        self$`option_value_id` <- this_object$`option_value_id`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductChildItemCombination in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductChildItemCombination
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductChildItemCombination
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`option_id` <- this_object$`option_id`
      self$`option_value_id` <- this_object$`option_value_id`
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductChildItemCombination and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductChildItemCombination
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductChildItemCombination$unlock()
#
## Below is an example to define the print function
# ProductChildItemCombination$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductChildItemCombination$lock()

