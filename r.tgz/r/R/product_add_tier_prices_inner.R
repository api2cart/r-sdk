#' Create a new ProductAddTierPricesInner
#'
#' @description
#' ProductAddTierPricesInner Class
#'
#' @docType class
#' @title ProductAddTierPricesInner
#' @description ProductAddTierPricesInner Class
#' @format An \code{R6Class} generator object
#' @field quantity  numeric [optional]
#' @field price  numeric [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductAddTierPricesInner <- R6::R6Class(
  "ProductAddTierPricesInner",
  public = list(
    `quantity` = NULL,
    `price` = NULL,

    #' @description
    #' Initialize a new ProductAddTierPricesInner class.
    #'
    #' @param quantity quantity
    #' @param price price
    #' @param ... Other optional arguments.
    initialize = function(`quantity` = NULL, `price` = NULL, ...) {
      if (!is.null(`quantity`)) {
        self$`quantity` <- `quantity`
      }
      if (!is.null(`price`)) {
        self$`price` <- `price`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductAddTierPricesInner as a base R list.
    #' @examples
    #' # convert array of ProductAddTierPricesInner (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductAddTierPricesInner to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductAddTierPricesInnerObject <- list()
      if (!is.null(self$`quantity`)) {
        ProductAddTierPricesInnerObject[["quantity"]] <-
          self$`quantity`
      }
      if (!is.null(self$`price`)) {
        ProductAddTierPricesInnerObject[["price"]] <-
          self$`price`
      }
      return(ProductAddTierPricesInnerObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductAddTierPricesInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductAddTierPricesInner
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`quantity`)) {
        self$`quantity` <- this_object$`quantity`
      }
      if (!is.null(this_object$`price`)) {
        self$`price` <- this_object$`price`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductAddTierPricesInner in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductAddTierPricesInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductAddTierPricesInner
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`quantity` <- this_object$`quantity`
      self$`price` <- this_object$`price`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductAddTierPricesInner and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductAddTierPricesInner
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductAddTierPricesInner$unlock()
#
## Below is an example to define the print function
# ProductAddTierPricesInner$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductAddTierPricesInner$lock()

