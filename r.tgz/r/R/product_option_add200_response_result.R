#' Create a new ProductOptionAdd200ResponseResult
#'
#' @description
#' ProductOptionAdd200ResponseResult Class
#'
#' @docType class
#' @title ProductOptionAdd200ResponseResult
#' @description ProductOptionAdd200ResponseResult Class
#' @format An \code{R6Class} generator object
#' @field option_id  character [optional]
#' @field product_option_id  character [optional]
#' @field product_value_ids  character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductOptionAdd200ResponseResult <- R6::R6Class(
  "ProductOptionAdd200ResponseResult",
  public = list(
    `option_id` = NULL,
    `product_option_id` = NULL,
    `product_value_ids` = NULL,

    #' @description
    #' Initialize a new ProductOptionAdd200ResponseResult class.
    #'
    #' @param option_id option_id
    #' @param product_option_id product_option_id
    #' @param product_value_ids product_value_ids
    #' @param ... Other optional arguments.
    initialize = function(`option_id` = NULL, `product_option_id` = NULL, `product_value_ids` = NULL, ...) {
      if (!is.null(`option_id`)) {
        if (!(is.character(`option_id`) && length(`option_id`) == 1)) {
          stop(paste("Error! Invalid data for `option_id`. Must be a string:", `option_id`))
        }
        self$`option_id` <- `option_id`
      }
      if (!is.null(`product_option_id`)) {
        if (!(is.character(`product_option_id`) && length(`product_option_id`) == 1)) {
          stop(paste("Error! Invalid data for `product_option_id`. Must be a string:", `product_option_id`))
        }
        self$`product_option_id` <- `product_option_id`
      }
      if (!is.null(`product_value_ids`)) {
        if (!(is.character(`product_value_ids`) && length(`product_value_ids`) == 1)) {
          stop(paste("Error! Invalid data for `product_value_ids`. Must be a string:", `product_value_ids`))
        }
        self$`product_value_ids` <- `product_value_ids`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductOptionAdd200ResponseResult as a base R list.
    #' @examples
    #' # convert array of ProductOptionAdd200ResponseResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductOptionAdd200ResponseResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductOptionAdd200ResponseResultObject <- list()
      if (!is.null(self$`option_id`)) {
        ProductOptionAdd200ResponseResultObject[["option_id"]] <-
          self$`option_id`
      }
      if (!is.null(self$`product_option_id`)) {
        ProductOptionAdd200ResponseResultObject[["product_option_id"]] <-
          self$`product_option_id`
      }
      if (!is.null(self$`product_value_ids`)) {
        ProductOptionAdd200ResponseResultObject[["product_value_ids"]] <-
          self$`product_value_ids`
      }
      return(ProductOptionAdd200ResponseResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductOptionAdd200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductOptionAdd200ResponseResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`option_id`)) {
        self$`option_id` <- this_object$`option_id`
      }
      if (!is.null(this_object$`product_option_id`)) {
        self$`product_option_id` <- this_object$`product_option_id`
      }
      if (!is.null(this_object$`product_value_ids`)) {
        self$`product_value_ids` <- this_object$`product_value_ids`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductOptionAdd200ResponseResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductOptionAdd200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductOptionAdd200ResponseResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`option_id` <- this_object$`option_id`
      self$`product_option_id` <- this_object$`product_option_id`
      self$`product_value_ids` <- this_object$`product_value_ids`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductOptionAdd200ResponseResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductOptionAdd200ResponseResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductOptionAdd200ResponseResult$unlock()
#
## Below is an example to define the print function
# ProductOptionAdd200ResponseResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductOptionAdd200ResponseResult$lock()

