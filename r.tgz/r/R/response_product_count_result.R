#' Create a new ResponseProductCountResult
#'
#' @description
#' ResponseProductCountResult Class
#'
#' @docType class
#' @title ResponseProductCountResult
#' @description ResponseProductCountResult Class
#' @format An \code{R6Class} generator object
#' @field products_count  integer [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ResponseProductCountResult <- R6::R6Class(
  "ResponseProductCountResult",
  public = list(
    `products_count` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new ResponseProductCountResult class.
    #'
    #' @param products_count products_count
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`products_count` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`products_count`)) {
        if (!(is.numeric(`products_count`) && length(`products_count`) == 1)) {
          stop(paste("Error! Invalid data for `products_count`. Must be an integer:", `products_count`))
        }
        self$`products_count` <- `products_count`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ResponseProductCountResult as a base R list.
    #' @examples
    #' # convert array of ResponseProductCountResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ResponseProductCountResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ResponseProductCountResultObject <- list()
      if (!is.null(self$`products_count`)) {
        ResponseProductCountResultObject[["products_count"]] <-
          self$`products_count`
      }
      if (!is.null(self$`additional_fields`)) {
        ResponseProductCountResultObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        ResponseProductCountResultObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(ResponseProductCountResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ResponseProductCountResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ResponseProductCountResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`products_count`)) {
        self$`products_count` <- this_object$`products_count`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ResponseProductCountResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ResponseProductCountResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ResponseProductCountResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`products_count` <- this_object$`products_count`
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to ResponseProductCountResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ResponseProductCountResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ResponseProductCountResult$unlock()
#
## Below is an example to define the print function
# ResponseProductCountResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ResponseProductCountResult$lock()

