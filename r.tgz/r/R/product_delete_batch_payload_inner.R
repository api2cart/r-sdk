#' Create a new ProductDeleteBatchPayloadInner
#'
#' @description
#' ProductDeleteBatchPayloadInner Class
#'
#' @docType class
#' @title ProductDeleteBatchPayloadInner
#' @description ProductDeleteBatchPayloadInner Class
#' @format An \code{R6Class} generator object
#' @field id  character [optional]
#' @field store_id  character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductDeleteBatchPayloadInner <- R6::R6Class(
  "ProductDeleteBatchPayloadInner",
  public = list(
    `id` = NULL,
    `store_id` = NULL,

    #' @description
    #' Initialize a new ProductDeleteBatchPayloadInner class.
    #'
    #' @param id id
    #' @param store_id store_id
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `store_id` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`store_id`)) {
        if (!(is.character(`store_id`) && length(`store_id`) == 1)) {
          stop(paste("Error! Invalid data for `store_id`. Must be a string:", `store_id`))
        }
        self$`store_id` <- `store_id`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductDeleteBatchPayloadInner as a base R list.
    #' @examples
    #' # convert array of ProductDeleteBatchPayloadInner (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductDeleteBatchPayloadInner to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductDeleteBatchPayloadInnerObject <- list()
      if (!is.null(self$`id`)) {
        ProductDeleteBatchPayloadInnerObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`store_id`)) {
        ProductDeleteBatchPayloadInnerObject[["store_id"]] <-
          self$`store_id`
      }
      return(ProductDeleteBatchPayloadInnerObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductDeleteBatchPayloadInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductDeleteBatchPayloadInner
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`store_id`)) {
        self$`store_id` <- this_object$`store_id`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductDeleteBatchPayloadInner in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductDeleteBatchPayloadInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductDeleteBatchPayloadInner
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`store_id` <- this_object$`store_id`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductDeleteBatchPayloadInner and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductDeleteBatchPayloadInner
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductDeleteBatchPayloadInner$unlock()
#
## Below is an example to define the print function
# ProductDeleteBatchPayloadInner$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductDeleteBatchPayloadInner$lock()

