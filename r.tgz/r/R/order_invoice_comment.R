#' Create a new OrderInvoiceComment
#'
#' @description
#' OrderInvoiceComment Class
#'
#' @docType class
#' @title OrderInvoiceComment
#' @description OrderInvoiceComment Class
#' @format An \code{R6Class} generator object
#' @field id  character [optional]
#' @field comment  character [optional]
#' @field created_at  \link{A2CDateTime} [optional]
#' @field notify  character [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
OrderInvoiceComment <- R6::R6Class(
  "OrderInvoiceComment",
  public = list(
    `id` = NULL,
    `comment` = NULL,
    `created_at` = NULL,
    `notify` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new OrderInvoiceComment class.
    #'
    #' @param id id
    #' @param comment comment
    #' @param created_at created_at
    #' @param notify notify
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `comment` = NULL, `created_at` = NULL, `notify` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`comment`)) {
        if (!(is.character(`comment`) && length(`comment`) == 1)) {
          stop(paste("Error! Invalid data for `comment`. Must be a string:", `comment`))
        }
        self$`comment` <- `comment`
      }
      if (!is.null(`created_at`)) {
        stopifnot(R6::is.R6(`created_at`))
        self$`created_at` <- `created_at`
      }
      if (!is.null(`notify`)) {
        if (!(is.logical(`notify`) && length(`notify`) == 1)) {
          stop(paste("Error! Invalid data for `notify`. Must be a boolean:", `notify`))
        }
        self$`notify` <- `notify`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return OrderInvoiceComment as a base R list.
    #' @examples
    #' # convert array of OrderInvoiceComment (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert OrderInvoiceComment to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      OrderInvoiceCommentObject <- list()
      if (!is.null(self$`id`)) {
        OrderInvoiceCommentObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`comment`)) {
        OrderInvoiceCommentObject[["comment"]] <-
          self$`comment`
      }
      if (!is.null(self$`created_at`)) {
        OrderInvoiceCommentObject[["created_at"]] <-
          self$`created_at`$toSimpleType()
      }
      if (!is.null(self$`notify`)) {
        OrderInvoiceCommentObject[["notify"]] <-
          self$`notify`
      }
      if (!is.null(self$`additional_fields`)) {
        OrderInvoiceCommentObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        OrderInvoiceCommentObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(OrderInvoiceCommentObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderInvoiceComment
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderInvoiceComment
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`comment`)) {
        self$`comment` <- this_object$`comment`
      }
      if (!is.null(this_object$`created_at`)) {
        `created_at_object` <- A2CDateTime$new()
        `created_at_object`$fromJSON(jsonlite::toJSON(this_object$`created_at`, auto_unbox = TRUE, digits = NA))
        self$`created_at` <- `created_at_object`
      }
      if (!is.null(this_object$`notify`)) {
        self$`notify` <- this_object$`notify`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return OrderInvoiceComment in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderInvoiceComment
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderInvoiceComment
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`comment` <- this_object$`comment`
      self$`created_at` <- A2CDateTime$new()$fromJSON(jsonlite::toJSON(this_object$`created_at`, auto_unbox = TRUE, digits = NA))
      self$`notify` <- this_object$`notify`
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to OrderInvoiceComment and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of OrderInvoiceComment
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# OrderInvoiceComment$unlock()
#
## Below is an example to define the print function
# OrderInvoiceComment$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# OrderInvoiceComment$lock()

