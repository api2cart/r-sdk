#' Create a new OrderItemOption
#'
#' @description
#' OrderItemOption Class
#'
#' @docType class
#' @title OrderItemOption
#' @description OrderItemOption Class
#' @format An \code{R6Class} generator object
#' @field option_id  character [optional]
#' @field name  character [optional]
#' @field value  character [optional]
#' @field price  numeric [optional]
#' @field weight  numeric [optional]
#' @field type  character [optional]
#' @field product_option_value_id  character [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
OrderItemOption <- R6::R6Class(
  "OrderItemOption",
  public = list(
    `option_id` = NULL,
    `name` = NULL,
    `value` = NULL,
    `price` = NULL,
    `weight` = NULL,
    `type` = NULL,
    `product_option_value_id` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new OrderItemOption class.
    #'
    #' @param option_id option_id
    #' @param name name
    #' @param value value
    #' @param price price
    #' @param weight weight
    #' @param type type
    #' @param product_option_value_id product_option_value_id
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`option_id` = NULL, `name` = NULL, `value` = NULL, `price` = NULL, `weight` = NULL, `type` = NULL, `product_option_value_id` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`option_id`)) {
        if (!(is.character(`option_id`) && length(`option_id`) == 1)) {
          stop(paste("Error! Invalid data for `option_id`. Must be a string:", `option_id`))
        }
        self$`option_id` <- `option_id`
      }
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`value`)) {
        if (!(is.character(`value`) && length(`value`) == 1)) {
          stop(paste("Error! Invalid data for `value`. Must be a string:", `value`))
        }
        self$`value` <- `value`
      }
      if (!is.null(`price`)) {
        self$`price` <- `price`
      }
      if (!is.null(`weight`)) {
        self$`weight` <- `weight`
      }
      if (!is.null(`type`)) {
        if (!(is.character(`type`) && length(`type`) == 1)) {
          stop(paste("Error! Invalid data for `type`. Must be a string:", `type`))
        }
        self$`type` <- `type`
      }
      if (!is.null(`product_option_value_id`)) {
        if (!(is.character(`product_option_value_id`) && length(`product_option_value_id`) == 1)) {
          stop(paste("Error! Invalid data for `product_option_value_id`. Must be a string:", `product_option_value_id`))
        }
        self$`product_option_value_id` <- `product_option_value_id`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return OrderItemOption as a base R list.
    #' @examples
    #' # convert array of OrderItemOption (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert OrderItemOption to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      OrderItemOptionObject <- list()
      if (!is.null(self$`option_id`)) {
        OrderItemOptionObject[["option_id"]] <-
          self$`option_id`
      }
      if (!is.null(self$`name`)) {
        OrderItemOptionObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`value`)) {
        OrderItemOptionObject[["value"]] <-
          self$`value`
      }
      if (!is.null(self$`price`)) {
        OrderItemOptionObject[["price"]] <-
          self$`price`
      }
      if (!is.null(self$`weight`)) {
        OrderItemOptionObject[["weight"]] <-
          self$`weight`
      }
      if (!is.null(self$`type`)) {
        OrderItemOptionObject[["type"]] <-
          self$`type`
      }
      if (!is.null(self$`product_option_value_id`)) {
        OrderItemOptionObject[["product_option_value_id"]] <-
          self$`product_option_value_id`
      }
      if (!is.null(self$`additional_fields`)) {
        OrderItemOptionObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        OrderItemOptionObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(OrderItemOptionObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderItemOption
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderItemOption
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`option_id`)) {
        self$`option_id` <- this_object$`option_id`
      }
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`value`)) {
        self$`value` <- this_object$`value`
      }
      if (!is.null(this_object$`price`)) {
        self$`price` <- this_object$`price`
      }
      if (!is.null(this_object$`weight`)) {
        self$`weight` <- this_object$`weight`
      }
      if (!is.null(this_object$`type`)) {
        self$`type` <- this_object$`type`
      }
      if (!is.null(this_object$`product_option_value_id`)) {
        self$`product_option_value_id` <- this_object$`product_option_value_id`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return OrderItemOption in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderItemOption
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderItemOption
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`option_id` <- this_object$`option_id`
      self$`name` <- this_object$`name`
      self$`value` <- this_object$`value`
      self$`price` <- this_object$`price`
      self$`weight` <- this_object$`weight`
      self$`type` <- this_object$`type`
      self$`product_option_value_id` <- this_object$`product_option_value_id`
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to OrderItemOption and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of OrderItemOption
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# OrderItemOption$unlock()
#
## Below is an example to define the print function
# OrderItemOption$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# OrderItemOption$lock()

