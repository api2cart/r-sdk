#' Create a new ResponseAttributeTypeListResult
#'
#' @description
#' ResponseAttributeTypeListResult Class
#'
#' @docType class
#' @title ResponseAttributeTypeListResult
#' @description ResponseAttributeTypeListResult Class
#' @format An \code{R6Class} generator object
#' @field items_count  integer [optional]
#' @field attribute_type  list(character) [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ResponseAttributeTypeListResult <- R6::R6Class(
  "ResponseAttributeTypeListResult",
  public = list(
    `items_count` = NULL,
    `attribute_type` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new ResponseAttributeTypeListResult class.
    #'
    #' @param items_count items_count
    #' @param attribute_type attribute_type
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`items_count` = NULL, `attribute_type` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`items_count`)) {
        if (!(is.numeric(`items_count`) && length(`items_count`) == 1)) {
          stop(paste("Error! Invalid data for `items_count`. Must be an integer:", `items_count`))
        }
        self$`items_count` <- `items_count`
      }
      if (!is.null(`attribute_type`)) {
        stopifnot(is.vector(`attribute_type`), length(`attribute_type`) != 0)
        sapply(`attribute_type`, function(x) stopifnot(is.character(x)))
        self$`attribute_type` <- `attribute_type`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ResponseAttributeTypeListResult as a base R list.
    #' @examples
    #' # convert array of ResponseAttributeTypeListResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ResponseAttributeTypeListResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ResponseAttributeTypeListResultObject <- list()
      if (!is.null(self$`items_count`)) {
        ResponseAttributeTypeListResultObject[["items_count"]] <-
          self$`items_count`
      }
      if (!is.null(self$`attribute_type`)) {
        ResponseAttributeTypeListResultObject[["attribute_type"]] <-
          self$`attribute_type`
      }
      if (!is.null(self$`additional_fields`)) {
        ResponseAttributeTypeListResultObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        ResponseAttributeTypeListResultObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(ResponseAttributeTypeListResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ResponseAttributeTypeListResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ResponseAttributeTypeListResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`items_count`)) {
        self$`items_count` <- this_object$`items_count`
      }
      if (!is.null(this_object$`attribute_type`)) {
        self$`attribute_type` <- ApiClient$new()$deserializeObj(this_object$`attribute_type`, "array[character]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ResponseAttributeTypeListResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ResponseAttributeTypeListResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ResponseAttributeTypeListResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`items_count` <- this_object$`items_count`
      self$`attribute_type` <- ApiClient$new()$deserializeObj(this_object$`attribute_type`, "array[character]", loadNamespace("openapi"))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to ResponseAttributeTypeListResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ResponseAttributeTypeListResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ResponseAttributeTypeListResult$unlock()
#
## Below is an example to define the print function
# ResponseAttributeTypeListResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ResponseAttributeTypeListResult$lock()

