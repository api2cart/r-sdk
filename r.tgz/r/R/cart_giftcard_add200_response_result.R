#' Create a new CartGiftcardAdd200ResponseResult
#'
#' @description
#' CartGiftcardAdd200ResponseResult Class
#'
#' @docType class
#' @title CartGiftcardAdd200ResponseResult
#' @description CartGiftcardAdd200ResponseResult Class
#' @format An \code{R6Class} generator object
#' @field id  character [optional]
#' @field code  character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
CartGiftcardAdd200ResponseResult <- R6::R6Class(
  "CartGiftcardAdd200ResponseResult",
  public = list(
    `id` = NULL,
    `code` = NULL,

    #' @description
    #' Initialize a new CartGiftcardAdd200ResponseResult class.
    #'
    #' @param id id
    #' @param code code
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `code` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`code`)) {
        if (!(is.character(`code`) && length(`code`) == 1)) {
          stop(paste("Error! Invalid data for `code`. Must be a string:", `code`))
        }
        self$`code` <- `code`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return CartGiftcardAdd200ResponseResult as a base R list.
    #' @examples
    #' # convert array of CartGiftcardAdd200ResponseResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert CartGiftcardAdd200ResponseResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      CartGiftcardAdd200ResponseResultObject <- list()
      if (!is.null(self$`id`)) {
        CartGiftcardAdd200ResponseResultObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`code`)) {
        CartGiftcardAdd200ResponseResultObject[["code"]] <-
          self$`code`
      }
      return(CartGiftcardAdd200ResponseResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of CartGiftcardAdd200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of CartGiftcardAdd200ResponseResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`code`)) {
        self$`code` <- this_object$`code`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return CartGiftcardAdd200ResponseResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of CartGiftcardAdd200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of CartGiftcardAdd200ResponseResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`code` <- this_object$`code`
      self
    },

    #' @description
    #' Validate JSON input with respect to CartGiftcardAdd200ResponseResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of CartGiftcardAdd200ResponseResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# CartGiftcardAdd200ResponseResult$unlock()
#
## Below is an example to define the print function
# CartGiftcardAdd200ResponseResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# CartGiftcardAdd200ResponseResult$lock()

