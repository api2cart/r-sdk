#' Create a new ProductVariantImageAdd200ResponseResult
#'
#' @description
#' ProductVariantImageAdd200ResponseResult Class
#'
#' @docType class
#' @title ProductVariantImageAdd200ResponseResult
#' @description ProductVariantImageAdd200ResponseResult Class
#' @format An \code{R6Class} generator object
#' @field id  character [optional]
#' @field image_path  character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductVariantImageAdd200ResponseResult <- R6::R6Class(
  "ProductVariantImageAdd200ResponseResult",
  public = list(
    `id` = NULL,
    `image_path` = NULL,

    #' @description
    #' Initialize a new ProductVariantImageAdd200ResponseResult class.
    #'
    #' @param id id
    #' @param image_path image_path
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `image_path` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`image_path`)) {
        if (!(is.character(`image_path`) && length(`image_path`) == 1)) {
          stop(paste("Error! Invalid data for `image_path`. Must be a string:", `image_path`))
        }
        self$`image_path` <- `image_path`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductVariantImageAdd200ResponseResult as a base R list.
    #' @examples
    #' # convert array of ProductVariantImageAdd200ResponseResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductVariantImageAdd200ResponseResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductVariantImageAdd200ResponseResultObject <- list()
      if (!is.null(self$`id`)) {
        ProductVariantImageAdd200ResponseResultObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`image_path`)) {
        ProductVariantImageAdd200ResponseResultObject[["image_path"]] <-
          self$`image_path`
      }
      return(ProductVariantImageAdd200ResponseResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductVariantImageAdd200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductVariantImageAdd200ResponseResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`image_path`)) {
        self$`image_path` <- this_object$`image_path`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductVariantImageAdd200ResponseResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductVariantImageAdd200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductVariantImageAdd200ResponseResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`image_path` <- this_object$`image_path`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductVariantImageAdd200ResponseResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductVariantImageAdd200ResponseResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductVariantImageAdd200ResponseResult$unlock()
#
## Below is an example to define the print function
# ProductVariantImageAdd200ResponseResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductVariantImageAdd200ResponseResult$lock()

