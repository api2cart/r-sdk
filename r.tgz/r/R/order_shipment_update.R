#' Create a new OrderShipmentUpdate
#'
#' @description
#' OrderShipmentUpdate Class
#'
#' @docType class
#' @title OrderShipmentUpdate
#' @description OrderShipmentUpdate Class
#' @format An \code{R6Class} generator object
#' @field shipment_id Shipment id indicates the number of delivery character
#' @field order_id Defines the order that will be updated character [optional]
#' @field store_id Store Id character [optional]
#' @field shipment_provider Defines company name that provide tracking of shipment character [optional]
#' @field tracking_numbers Defines shipment's tracking numbers that have to be added</br> How set tracking numbers to appropriate carrier:<ul><li>tracking_numbers[]=a2c.demo1,a2c.demo2 - set default carrier</li><li>tracking_numbers[<b>carrier_id</b>]=a2c.demo - set appropriate carrier</li></ul>To get the list of carriers IDs that are available in your store, use the <a href = \"https://api2cart.com/docs/#/cart/CartInfo\">cart.info</a > method list(\link{OrderShipmentAddTrackingNumbersInner}) [optional]
#' @field tracking_link Defines custom tracking link character [optional]
#' @field is_shipped Defines shipment's status character [optional]
#' @field delivered_at Defines the date of delivery character [optional]
#' @field replace Allows rewrite tracking numbers character [optional]
#' @field send_notifications Send notifications to customer after order was created character [optional]
#' @field tracking_provider Defines name of the company which provides shipment tracking character [optional]
#' @field items Defines items in the order that will be shipped list(\link{OrderShipmentAddItemsInner}) [optional]
#' @field admin_comment Specifies admin's order comment character [optional]
#' @field idempotency_key A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong> character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
OrderShipmentUpdate <- R6::R6Class(
  "OrderShipmentUpdate",
  public = list(
    `shipment_id` = NULL,
    `order_id` = NULL,
    `store_id` = NULL,
    `shipment_provider` = NULL,
    `tracking_numbers` = NULL,
    `tracking_link` = NULL,
    `is_shipped` = NULL,
    `delivered_at` = NULL,
    `replace` = NULL,
    `send_notifications` = NULL,
    `tracking_provider` = NULL,
    `items` = NULL,
    `admin_comment` = NULL,
    `idempotency_key` = NULL,

    #' @description
    #' Initialize a new OrderShipmentUpdate class.
    #'
    #' @param shipment_id Shipment id indicates the number of delivery
    #' @param order_id Defines the order that will be updated
    #' @param store_id Store Id
    #' @param shipment_provider Defines company name that provide tracking of shipment
    #' @param tracking_numbers Defines shipment's tracking numbers that have to be added</br> How set tracking numbers to appropriate carrier:<ul><li>tracking_numbers[]=a2c.demo1,a2c.demo2 - set default carrier</li><li>tracking_numbers[<b>carrier_id</b>]=a2c.demo - set appropriate carrier</li></ul>To get the list of carriers IDs that are available in your store, use the <a href = \"https://api2cart.com/docs/#/cart/CartInfo\">cart.info</a > method
    #' @param tracking_link Defines custom tracking link
    #' @param is_shipped Defines shipment's status. Default to TRUE.
    #' @param delivered_at Defines the date of delivery
    #' @param replace Allows rewrite tracking numbers. Default to TRUE.
    #' @param send_notifications Send notifications to customer after order was created. Default to FALSE.
    #' @param tracking_provider Defines name of the company which provides shipment tracking
    #' @param items Defines items in the order that will be shipped
    #' @param admin_comment Specifies admin's order comment
    #' @param idempotency_key A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong>
    #' @param ... Other optional arguments.
    initialize = function(`shipment_id`, `order_id` = NULL, `store_id` = NULL, `shipment_provider` = NULL, `tracking_numbers` = NULL, `tracking_link` = NULL, `is_shipped` = TRUE, `delivered_at` = NULL, `replace` = TRUE, `send_notifications` = FALSE, `tracking_provider` = NULL, `items` = NULL, `admin_comment` = NULL, `idempotency_key` = NULL, ...) {
      if (!missing(`shipment_id`)) {
        if (!(is.character(`shipment_id`) && length(`shipment_id`) == 1)) {
          stop(paste("Error! Invalid data for `shipment_id`. Must be a string:", `shipment_id`))
        }
        self$`shipment_id` <- `shipment_id`
      }
      if (!is.null(`order_id`)) {
        if (!(is.character(`order_id`) && length(`order_id`) == 1)) {
          stop(paste("Error! Invalid data for `order_id`. Must be a string:", `order_id`))
        }
        self$`order_id` <- `order_id`
      }
      if (!is.null(`store_id`)) {
        if (!(is.character(`store_id`) && length(`store_id`) == 1)) {
          stop(paste("Error! Invalid data for `store_id`. Must be a string:", `store_id`))
        }
        self$`store_id` <- `store_id`
      }
      if (!is.null(`shipment_provider`)) {
        if (!(is.character(`shipment_provider`) && length(`shipment_provider`) == 1)) {
          stop(paste("Error! Invalid data for `shipment_provider`. Must be a string:", `shipment_provider`))
        }
        self$`shipment_provider` <- `shipment_provider`
      }
      if (!is.null(`tracking_numbers`)) {
        stopifnot(is.vector(`tracking_numbers`), length(`tracking_numbers`) != 0)
        sapply(`tracking_numbers`, function(x) stopifnot(R6::is.R6(x)))
        self$`tracking_numbers` <- `tracking_numbers`
      }
      if (!is.null(`tracking_link`)) {
        if (!(is.character(`tracking_link`) && length(`tracking_link`) == 1)) {
          stop(paste("Error! Invalid data for `tracking_link`. Must be a string:", `tracking_link`))
        }
        self$`tracking_link` <- `tracking_link`
      }
      if (!is.null(`is_shipped`)) {
        if (!(is.logical(`is_shipped`) && length(`is_shipped`) == 1)) {
          stop(paste("Error! Invalid data for `is_shipped`. Must be a boolean:", `is_shipped`))
        }
        self$`is_shipped` <- `is_shipped`
      }
      if (!is.null(`delivered_at`)) {
        if (!(is.character(`delivered_at`) && length(`delivered_at`) == 1)) {
          stop(paste("Error! Invalid data for `delivered_at`. Must be a string:", `delivered_at`))
        }
        self$`delivered_at` <- `delivered_at`
      }
      if (!is.null(`replace`)) {
        if (!(is.logical(`replace`) && length(`replace`) == 1)) {
          stop(paste("Error! Invalid data for `replace`. Must be a boolean:", `replace`))
        }
        self$`replace` <- `replace`
      }
      if (!is.null(`send_notifications`)) {
        if (!(is.logical(`send_notifications`) && length(`send_notifications`) == 1)) {
          stop(paste("Error! Invalid data for `send_notifications`. Must be a boolean:", `send_notifications`))
        }
        self$`send_notifications` <- `send_notifications`
      }
      if (!is.null(`tracking_provider`)) {
        if (!(is.character(`tracking_provider`) && length(`tracking_provider`) == 1)) {
          stop(paste("Error! Invalid data for `tracking_provider`. Must be a string:", `tracking_provider`))
        }
        self$`tracking_provider` <- `tracking_provider`
      }
      if (!is.null(`items`)) {
        stopifnot(is.vector(`items`), length(`items`) != 0)
        sapply(`items`, function(x) stopifnot(R6::is.R6(x)))
        self$`items` <- `items`
      }
      if (!is.null(`admin_comment`)) {
        if (!(is.character(`admin_comment`) && length(`admin_comment`) == 1)) {
          stop(paste("Error! Invalid data for `admin_comment`. Must be a string:", `admin_comment`))
        }
        self$`admin_comment` <- `admin_comment`
      }
      if (!is.null(`idempotency_key`)) {
        if (!(is.character(`idempotency_key`) && length(`idempotency_key`) == 1)) {
          stop(paste("Error! Invalid data for `idempotency_key`. Must be a string:", `idempotency_key`))
        }
        self$`idempotency_key` <- `idempotency_key`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return OrderShipmentUpdate as a base R list.
    #' @examples
    #' # convert array of OrderShipmentUpdate (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert OrderShipmentUpdate to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      OrderShipmentUpdateObject <- list()
      if (!is.null(self$`shipment_id`)) {
        OrderShipmentUpdateObject[["shipment_id"]] <-
          self$`shipment_id`
      }
      if (!is.null(self$`order_id`)) {
        OrderShipmentUpdateObject[["order_id"]] <-
          self$`order_id`
      }
      if (!is.null(self$`store_id`)) {
        OrderShipmentUpdateObject[["store_id"]] <-
          self$`store_id`
      }
      if (!is.null(self$`shipment_provider`)) {
        OrderShipmentUpdateObject[["shipment_provider"]] <-
          self$`shipment_provider`
      }
      if (!is.null(self$`tracking_numbers`)) {
        OrderShipmentUpdateObject[["tracking_numbers"]] <-
          lapply(self$`tracking_numbers`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`tracking_link`)) {
        OrderShipmentUpdateObject[["tracking_link"]] <-
          self$`tracking_link`
      }
      if (!is.null(self$`is_shipped`)) {
        OrderShipmentUpdateObject[["is_shipped"]] <-
          self$`is_shipped`
      }
      if (!is.null(self$`delivered_at`)) {
        OrderShipmentUpdateObject[["delivered_at"]] <-
          self$`delivered_at`
      }
      if (!is.null(self$`replace`)) {
        OrderShipmentUpdateObject[["replace"]] <-
          self$`replace`
      }
      if (!is.null(self$`send_notifications`)) {
        OrderShipmentUpdateObject[["send_notifications"]] <-
          self$`send_notifications`
      }
      if (!is.null(self$`tracking_provider`)) {
        OrderShipmentUpdateObject[["tracking_provider"]] <-
          self$`tracking_provider`
      }
      if (!is.null(self$`items`)) {
        OrderShipmentUpdateObject[["items"]] <-
          lapply(self$`items`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`admin_comment`)) {
        OrderShipmentUpdateObject[["admin_comment"]] <-
          self$`admin_comment`
      }
      if (!is.null(self$`idempotency_key`)) {
        OrderShipmentUpdateObject[["idempotency_key"]] <-
          self$`idempotency_key`
      }
      return(OrderShipmentUpdateObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderShipmentUpdate
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderShipmentUpdate
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`shipment_id`)) {
        self$`shipment_id` <- this_object$`shipment_id`
      }
      if (!is.null(this_object$`order_id`)) {
        self$`order_id` <- this_object$`order_id`
      }
      if (!is.null(this_object$`store_id`)) {
        self$`store_id` <- this_object$`store_id`
      }
      if (!is.null(this_object$`shipment_provider`)) {
        self$`shipment_provider` <- this_object$`shipment_provider`
      }
      if (!is.null(this_object$`tracking_numbers`)) {
        self$`tracking_numbers` <- ApiClient$new()$deserializeObj(this_object$`tracking_numbers`, "array[OrderShipmentAddTrackingNumbersInner]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`tracking_link`)) {
        self$`tracking_link` <- this_object$`tracking_link`
      }
      if (!is.null(this_object$`is_shipped`)) {
        self$`is_shipped` <- this_object$`is_shipped`
      }
      if (!is.null(this_object$`delivered_at`)) {
        self$`delivered_at` <- this_object$`delivered_at`
      }
      if (!is.null(this_object$`replace`)) {
        self$`replace` <- this_object$`replace`
      }
      if (!is.null(this_object$`send_notifications`)) {
        self$`send_notifications` <- this_object$`send_notifications`
      }
      if (!is.null(this_object$`tracking_provider`)) {
        self$`tracking_provider` <- this_object$`tracking_provider`
      }
      if (!is.null(this_object$`items`)) {
        self$`items` <- ApiClient$new()$deserializeObj(this_object$`items`, "array[OrderShipmentAddItemsInner]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`admin_comment`)) {
        self$`admin_comment` <- this_object$`admin_comment`
      }
      if (!is.null(this_object$`idempotency_key`)) {
        self$`idempotency_key` <- this_object$`idempotency_key`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return OrderShipmentUpdate in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderShipmentUpdate
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderShipmentUpdate
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`shipment_id` <- this_object$`shipment_id`
      self$`order_id` <- this_object$`order_id`
      self$`store_id` <- this_object$`store_id`
      self$`shipment_provider` <- this_object$`shipment_provider`
      self$`tracking_numbers` <- ApiClient$new()$deserializeObj(this_object$`tracking_numbers`, "array[OrderShipmentAddTrackingNumbersInner]", loadNamespace("openapi"))
      self$`tracking_link` <- this_object$`tracking_link`
      self$`is_shipped` <- this_object$`is_shipped`
      self$`delivered_at` <- this_object$`delivered_at`
      self$`replace` <- this_object$`replace`
      self$`send_notifications` <- this_object$`send_notifications`
      self$`tracking_provider` <- this_object$`tracking_provider`
      self$`items` <- ApiClient$new()$deserializeObj(this_object$`items`, "array[OrderShipmentAddItemsInner]", loadNamespace("openapi"))
      self$`admin_comment` <- this_object$`admin_comment`
      self$`idempotency_key` <- this_object$`idempotency_key`
      self
    },

    #' @description
    #' Validate JSON input with respect to OrderShipmentUpdate and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
      # check the required field `shipment_id`
      if (!is.null(input_json$`shipment_id`)) {
        if (!(is.character(input_json$`shipment_id`) && length(input_json$`shipment_id`) == 1)) {
          stop(paste("Error! Invalid data for `shipment_id`. Must be a string:", input_json$`shipment_id`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for OrderShipmentUpdate: the required field `shipment_id` is missing."))
      }
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of OrderShipmentUpdate
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      # check if the required `shipment_id` is null
      if (is.null(self$`shipment_id`)) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      # check if the required `shipment_id` is null
      if (is.null(self$`shipment_id`)) {
        invalid_fields["shipment_id"] <- "Non-nullable required field `shipment_id` cannot be null."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# OrderShipmentUpdate$unlock()
#
## Below is an example to define the print function
# OrderShipmentUpdate$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# OrderShipmentUpdate$lock()

