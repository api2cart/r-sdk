#' Create a new ResponseCartShippingZonesListResult
#'
#' @description
#' ResponseCartShippingZonesListResult Class
#'
#' @docType class
#' @title ResponseCartShippingZonesListResult
#' @description ResponseCartShippingZonesListResult Class
#' @format An \code{R6Class} generator object
#' @field shipping_zone  list(\link{CartShippingZone2}) [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ResponseCartShippingZonesListResult <- R6::R6Class(
  "ResponseCartShippingZonesListResult",
  public = list(
    `shipping_zone` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new ResponseCartShippingZonesListResult class.
    #'
    #' @param shipping_zone shipping_zone
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`shipping_zone` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`shipping_zone`)) {
        stopifnot(is.vector(`shipping_zone`), length(`shipping_zone`) != 0)
        sapply(`shipping_zone`, function(x) stopifnot(R6::is.R6(x)))
        self$`shipping_zone` <- `shipping_zone`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ResponseCartShippingZonesListResult as a base R list.
    #' @examples
    #' # convert array of ResponseCartShippingZonesListResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ResponseCartShippingZonesListResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ResponseCartShippingZonesListResultObject <- list()
      if (!is.null(self$`shipping_zone`)) {
        ResponseCartShippingZonesListResultObject[["shipping_zone"]] <-
          lapply(self$`shipping_zone`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`additional_fields`)) {
        ResponseCartShippingZonesListResultObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        ResponseCartShippingZonesListResultObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(ResponseCartShippingZonesListResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ResponseCartShippingZonesListResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ResponseCartShippingZonesListResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`shipping_zone`)) {
        self$`shipping_zone` <- ApiClient$new()$deserializeObj(this_object$`shipping_zone`, "array[CartShippingZone2]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ResponseCartShippingZonesListResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ResponseCartShippingZonesListResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ResponseCartShippingZonesListResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`shipping_zone` <- ApiClient$new()$deserializeObj(this_object$`shipping_zone`, "array[CartShippingZone2]", loadNamespace("openapi"))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to ResponseCartShippingZonesListResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ResponseCartShippingZonesListResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ResponseCartShippingZonesListResult$unlock()
#
## Below is an example to define the print function
# ResponseCartShippingZonesListResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ResponseCartShippingZonesListResult$lock()

