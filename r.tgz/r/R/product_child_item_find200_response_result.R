#' Create a new ProductChildItemFind200ResponseResult
#'
#' @description
#' ProductChildItemFind200ResponseResult Class
#'
#' @docType class
#' @title ProductChildItemFind200ResponseResult
#' @description ProductChildItemFind200ResponseResult Class
#' @format An \code{R6Class} generator object
#' @field children  \link{AnyType} [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductChildItemFind200ResponseResult <- R6::R6Class(
  "ProductChildItemFind200ResponseResult",
  public = list(
    `children` = NULL,

    #' @description
    #' Initialize a new ProductChildItemFind200ResponseResult class.
    #'
    #' @param children children
    #' @param ... Other optional arguments.
    initialize = function(`children` = NULL, ...) {
      if (!is.null(`children`)) {
        stopifnot(R6::is.R6(`children`))
        self$`children` <- `children`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductChildItemFind200ResponseResult as a base R list.
    #' @examples
    #' # convert array of ProductChildItemFind200ResponseResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductChildItemFind200ResponseResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductChildItemFind200ResponseResultObject <- list()
      if (!is.null(self$`children`)) {
        ProductChildItemFind200ResponseResultObject[["children"]] <-
          self$`children`$toSimpleType()
      }
      return(ProductChildItemFind200ResponseResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductChildItemFind200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductChildItemFind200ResponseResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`children`)) {
        `children_object` <- AnyType$new()
        `children_object`$fromJSON(jsonlite::toJSON(this_object$`children`, auto_unbox = TRUE, digits = NA))
        self$`children` <- `children_object`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductChildItemFind200ResponseResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductChildItemFind200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductChildItemFind200ResponseResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`children` <- AnyType$new()$fromJSON(jsonlite::toJSON(this_object$`children`, auto_unbox = TRUE, digits = NA))
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductChildItemFind200ResponseResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductChildItemFind200ResponseResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductChildItemFind200ResponseResult$unlock()
#
## Below is an example to define the print function
# ProductChildItemFind200ResponseResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductChildItemFind200ResponseResult$lock()

