#' Create a new ProductImageAdd
#'
#' @description
#' ProductImageAdd Class
#'
#' @docType class
#' @title ProductImageAdd
#' @description ProductImageAdd Class
#' @format An \code{R6Class} generator object
#' @field type Defines image's types that are specified by comma-separated list character
#' @field image_name Defines image's name character
#' @field product_id Defines product id where the image should be added character [optional]
#' @field product_variant_id Defines product's variants specified by variant id character [optional]
#' @field variant_ids Defines product's variants ids character [optional]
#' @field option_value_ids Defines product's option values ids character [optional]
#' @field store_id Store Id character [optional]
#' @field lang_id Add product image on specified language id character [optional]
#' @field url Defines URL of the image that has to be added character [optional]
#' @field content Content(body) encoded in base64 of image file character [optional]
#' @field label Defines alternative text that has to be attached to the picture character [optional]
#' @field mime Mime type of image http://en.wikipedia.org/wiki/Internet_media_type. character [optional]
#' @field position Defines image’s position in the list integer [optional]
#' @field use_latest_api_version Use the latest platform API version character [optional]
#' @field idempotency_key A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong> character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductImageAdd <- R6::R6Class(
  "ProductImageAdd",
  public = list(
    `type` = NULL,
    `image_name` = NULL,
    `product_id` = NULL,
    `product_variant_id` = NULL,
    `variant_ids` = NULL,
    `option_value_ids` = NULL,
    `store_id` = NULL,
    `lang_id` = NULL,
    `url` = NULL,
    `content` = NULL,
    `label` = NULL,
    `mime` = NULL,
    `position` = NULL,
    `use_latest_api_version` = NULL,
    `idempotency_key` = NULL,

    #' @description
    #' Initialize a new ProductImageAdd class.
    #'
    #' @param type Defines image's types that are specified by comma-separated list
    #' @param image_name Defines image's name
    #' @param product_id Defines product id where the image should be added
    #' @param product_variant_id Defines product's variants specified by variant id
    #' @param variant_ids Defines product's variants ids
    #' @param option_value_ids Defines product's option values ids
    #' @param store_id Store Id
    #' @param lang_id Add product image on specified language id
    #' @param url Defines URL of the image that has to be added
    #' @param content Content(body) encoded in base64 of image file
    #' @param label Defines alternative text that has to be attached to the picture
    #' @param mime Mime type of image http://en.wikipedia.org/wiki/Internet_media_type.
    #' @param position Defines image’s position in the list. Default to 0.
    #' @param use_latest_api_version Use the latest platform API version. Default to FALSE.
    #' @param idempotency_key A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong>
    #' @param ... Other optional arguments.
    initialize = function(`type`, `image_name`, `product_id` = NULL, `product_variant_id` = NULL, `variant_ids` = NULL, `option_value_ids` = NULL, `store_id` = NULL, `lang_id` = NULL, `url` = NULL, `content` = NULL, `label` = NULL, `mime` = NULL, `position` = 0, `use_latest_api_version` = FALSE, `idempotency_key` = NULL, ...) {
      if (!missing(`type`)) {
        if (!(`type` %in% c("small", "base", "additional", "thumbnail"))) {
          stop(paste("Error! \"", `type`, "\" cannot be assigned to `type`. Must be \"small\", \"base\", \"additional\", \"thumbnail\".", sep = ""))
        }
        if (!(is.character(`type`) && length(`type`) == 1)) {
          stop(paste("Error! Invalid data for `type`. Must be a string:", `type`))
        }
        self$`type` <- `type`
      }
      if (!missing(`image_name`)) {
        if (!(is.character(`image_name`) && length(`image_name`) == 1)) {
          stop(paste("Error! Invalid data for `image_name`. Must be a string:", `image_name`))
        }
        self$`image_name` <- `image_name`
      }
      if (!is.null(`product_id`)) {
        if (!(is.character(`product_id`) && length(`product_id`) == 1)) {
          stop(paste("Error! Invalid data for `product_id`. Must be a string:", `product_id`))
        }
        self$`product_id` <- `product_id`
      }
      if (!is.null(`product_variant_id`)) {
        if (!(is.character(`product_variant_id`) && length(`product_variant_id`) == 1)) {
          stop(paste("Error! Invalid data for `product_variant_id`. Must be a string:", `product_variant_id`))
        }
        self$`product_variant_id` <- `product_variant_id`
      }
      if (!is.null(`variant_ids`)) {
        if (!(is.character(`variant_ids`) && length(`variant_ids`) == 1)) {
          stop(paste("Error! Invalid data for `variant_ids`. Must be a string:", `variant_ids`))
        }
        self$`variant_ids` <- `variant_ids`
      }
      if (!is.null(`option_value_ids`)) {
        if (!(is.character(`option_value_ids`) && length(`option_value_ids`) == 1)) {
          stop(paste("Error! Invalid data for `option_value_ids`. Must be a string:", `option_value_ids`))
        }
        self$`option_value_ids` <- `option_value_ids`
      }
      if (!is.null(`store_id`)) {
        if (!(is.character(`store_id`) && length(`store_id`) == 1)) {
          stop(paste("Error! Invalid data for `store_id`. Must be a string:", `store_id`))
        }
        self$`store_id` <- `store_id`
      }
      if (!is.null(`lang_id`)) {
        if (!(is.character(`lang_id`) && length(`lang_id`) == 1)) {
          stop(paste("Error! Invalid data for `lang_id`. Must be a string:", `lang_id`))
        }
        self$`lang_id` <- `lang_id`
      }
      if (!is.null(`url`)) {
        if (!(is.character(`url`) && length(`url`) == 1)) {
          stop(paste("Error! Invalid data for `url`. Must be a string:", `url`))
        }
        self$`url` <- `url`
      }
      if (!is.null(`content`)) {
        if (!(is.character(`content`) && length(`content`) == 1)) {
          stop(paste("Error! Invalid data for `content`. Must be a string:", `content`))
        }
        self$`content` <- `content`
      }
      if (!is.null(`label`)) {
        if (!(is.character(`label`) && length(`label`) == 1)) {
          stop(paste("Error! Invalid data for `label`. Must be a string:", `label`))
        }
        self$`label` <- `label`
      }
      if (!is.null(`mime`)) {
        if (!(is.character(`mime`) && length(`mime`) == 1)) {
          stop(paste("Error! Invalid data for `mime`. Must be a string:", `mime`))
        }
        self$`mime` <- `mime`
      }
      if (!is.null(`position`)) {
        if (!(is.numeric(`position`) && length(`position`) == 1)) {
          stop(paste("Error! Invalid data for `position`. Must be an integer:", `position`))
        }
        self$`position` <- `position`
      }
      if (!is.null(`use_latest_api_version`)) {
        if (!(is.logical(`use_latest_api_version`) && length(`use_latest_api_version`) == 1)) {
          stop(paste("Error! Invalid data for `use_latest_api_version`. Must be a boolean:", `use_latest_api_version`))
        }
        self$`use_latest_api_version` <- `use_latest_api_version`
      }
      if (!is.null(`idempotency_key`)) {
        if (!(is.character(`idempotency_key`) && length(`idempotency_key`) == 1)) {
          stop(paste("Error! Invalid data for `idempotency_key`. Must be a string:", `idempotency_key`))
        }
        self$`idempotency_key` <- `idempotency_key`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductImageAdd as a base R list.
    #' @examples
    #' # convert array of ProductImageAdd (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductImageAdd to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductImageAddObject <- list()
      if (!is.null(self$`type`)) {
        ProductImageAddObject[["type"]] <-
          self$`type`
      }
      if (!is.null(self$`image_name`)) {
        ProductImageAddObject[["image_name"]] <-
          self$`image_name`
      }
      if (!is.null(self$`product_id`)) {
        ProductImageAddObject[["product_id"]] <-
          self$`product_id`
      }
      if (!is.null(self$`product_variant_id`)) {
        ProductImageAddObject[["product_variant_id"]] <-
          self$`product_variant_id`
      }
      if (!is.null(self$`variant_ids`)) {
        ProductImageAddObject[["variant_ids"]] <-
          self$`variant_ids`
      }
      if (!is.null(self$`option_value_ids`)) {
        ProductImageAddObject[["option_value_ids"]] <-
          self$`option_value_ids`
      }
      if (!is.null(self$`store_id`)) {
        ProductImageAddObject[["store_id"]] <-
          self$`store_id`
      }
      if (!is.null(self$`lang_id`)) {
        ProductImageAddObject[["lang_id"]] <-
          self$`lang_id`
      }
      if (!is.null(self$`url`)) {
        ProductImageAddObject[["url"]] <-
          self$`url`
      }
      if (!is.null(self$`content`)) {
        ProductImageAddObject[["content"]] <-
          self$`content`
      }
      if (!is.null(self$`label`)) {
        ProductImageAddObject[["label"]] <-
          self$`label`
      }
      if (!is.null(self$`mime`)) {
        ProductImageAddObject[["mime"]] <-
          self$`mime`
      }
      if (!is.null(self$`position`)) {
        ProductImageAddObject[["position"]] <-
          self$`position`
      }
      if (!is.null(self$`use_latest_api_version`)) {
        ProductImageAddObject[["use_latest_api_version"]] <-
          self$`use_latest_api_version`
      }
      if (!is.null(self$`idempotency_key`)) {
        ProductImageAddObject[["idempotency_key"]] <-
          self$`idempotency_key`
      }
      return(ProductImageAddObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductImageAdd
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductImageAdd
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`type`)) {
        if (!is.null(this_object$`type`) && !(this_object$`type` %in% c("small", "base", "additional", "thumbnail"))) {
          stop(paste("Error! \"", this_object$`type`, "\" cannot be assigned to `type`. Must be \"small\", \"base\", \"additional\", \"thumbnail\".", sep = ""))
        }
        self$`type` <- this_object$`type`
      }
      if (!is.null(this_object$`image_name`)) {
        self$`image_name` <- this_object$`image_name`
      }
      if (!is.null(this_object$`product_id`)) {
        self$`product_id` <- this_object$`product_id`
      }
      if (!is.null(this_object$`product_variant_id`)) {
        self$`product_variant_id` <- this_object$`product_variant_id`
      }
      if (!is.null(this_object$`variant_ids`)) {
        self$`variant_ids` <- this_object$`variant_ids`
      }
      if (!is.null(this_object$`option_value_ids`)) {
        self$`option_value_ids` <- this_object$`option_value_ids`
      }
      if (!is.null(this_object$`store_id`)) {
        self$`store_id` <- this_object$`store_id`
      }
      if (!is.null(this_object$`lang_id`)) {
        self$`lang_id` <- this_object$`lang_id`
      }
      if (!is.null(this_object$`url`)) {
        self$`url` <- this_object$`url`
      }
      if (!is.null(this_object$`content`)) {
        self$`content` <- this_object$`content`
      }
      if (!is.null(this_object$`label`)) {
        self$`label` <- this_object$`label`
      }
      if (!is.null(this_object$`mime`)) {
        self$`mime` <- this_object$`mime`
      }
      if (!is.null(this_object$`position`)) {
        self$`position` <- this_object$`position`
      }
      if (!is.null(this_object$`use_latest_api_version`)) {
        self$`use_latest_api_version` <- this_object$`use_latest_api_version`
      }
      if (!is.null(this_object$`idempotency_key`)) {
        self$`idempotency_key` <- this_object$`idempotency_key`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductImageAdd in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductImageAdd
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductImageAdd
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`type`) && !(this_object$`type` %in% c("small", "base", "additional", "thumbnail"))) {
        stop(paste("Error! \"", this_object$`type`, "\" cannot be assigned to `type`. Must be \"small\", \"base\", \"additional\", \"thumbnail\".", sep = ""))
      }
      self$`type` <- this_object$`type`
      self$`image_name` <- this_object$`image_name`
      self$`product_id` <- this_object$`product_id`
      self$`product_variant_id` <- this_object$`product_variant_id`
      self$`variant_ids` <- this_object$`variant_ids`
      self$`option_value_ids` <- this_object$`option_value_ids`
      self$`store_id` <- this_object$`store_id`
      self$`lang_id` <- this_object$`lang_id`
      self$`url` <- this_object$`url`
      self$`content` <- this_object$`content`
      self$`label` <- this_object$`label`
      self$`mime` <- this_object$`mime`
      self$`position` <- this_object$`position`
      self$`use_latest_api_version` <- this_object$`use_latest_api_version`
      self$`idempotency_key` <- this_object$`idempotency_key`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductImageAdd and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
      # check the required field `type`
      if (!is.null(input_json$`type`)) {
        if (!(is.character(input_json$`type`) && length(input_json$`type`) == 1)) {
          stop(paste("Error! Invalid data for `type`. Must be a string:", input_json$`type`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for ProductImageAdd: the required field `type` is missing."))
      }
      # check the required field `image_name`
      if (!is.null(input_json$`image_name`)) {
        if (!(is.character(input_json$`image_name`) && length(input_json$`image_name`) == 1)) {
          stop(paste("Error! Invalid data for `image_name`. Must be a string:", input_json$`image_name`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for ProductImageAdd: the required field `image_name` is missing."))
      }
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductImageAdd
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      # check if the required `type` is null
      if (is.null(self$`type`)) {
        return(FALSE)
      }

      # check if the required `image_name` is null
      if (is.null(self$`image_name`)) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      # check if the required `type` is null
      if (is.null(self$`type`)) {
        invalid_fields["type"] <- "Non-nullable required field `type` cannot be null."
      }

      # check if the required `image_name` is null
      if (is.null(self$`image_name`)) {
        invalid_fields["image_name"] <- "Non-nullable required field `image_name` cannot be null."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductImageAdd$unlock()
#
## Below is an example to define the print function
# ProductImageAdd$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductImageAdd$lock()

