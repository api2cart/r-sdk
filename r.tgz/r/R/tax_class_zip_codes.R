#' Create a new TaxClassZipCodes
#'
#' @description
#' TaxClassZipCodes Class
#'
#' @docType class
#' @title TaxClassZipCodes
#' @description TaxClassZipCodes Class
#' @format An \code{R6Class} generator object
#' @field is_range  character [optional]
#' @field range  list(character) [optional]
#' @field fields  list(\link{TaxClassZipCodesRange}) [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
TaxClassZipCodes <- R6::R6Class(
  "TaxClassZipCodes",
  public = list(
    `is_range` = NULL,
    `range` = NULL,
    `fields` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new TaxClassZipCodes class.
    #'
    #' @param is_range is_range
    #' @param range range
    #' @param fields fields
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`is_range` = NULL, `range` = NULL, `fields` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`is_range`)) {
        if (!(is.logical(`is_range`) && length(`is_range`) == 1)) {
          stop(paste("Error! Invalid data for `is_range`. Must be a boolean:", `is_range`))
        }
        self$`is_range` <- `is_range`
      }
      if (!is.null(`range`)) {
        stopifnot(is.vector(`range`), length(`range`) != 0)
        sapply(`range`, function(x) stopifnot(is.character(x)))
        self$`range` <- `range`
      }
      if (!is.null(`fields`)) {
        stopifnot(is.vector(`fields`), length(`fields`) != 0)
        sapply(`fields`, function(x) stopifnot(R6::is.R6(x)))
        self$`fields` <- `fields`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return TaxClassZipCodes as a base R list.
    #' @examples
    #' # convert array of TaxClassZipCodes (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert TaxClassZipCodes to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      TaxClassZipCodesObject <- list()
      if (!is.null(self$`is_range`)) {
        TaxClassZipCodesObject[["is_range"]] <-
          self$`is_range`
      }
      if (!is.null(self$`range`)) {
        TaxClassZipCodesObject[["range"]] <-
          self$`range`
      }
      if (!is.null(self$`fields`)) {
        TaxClassZipCodesObject[["fields"]] <-
          lapply(self$`fields`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`additional_fields`)) {
        TaxClassZipCodesObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        TaxClassZipCodesObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(TaxClassZipCodesObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of TaxClassZipCodes
    #'
    #' @param input_json the JSON input
    #' @return the instance of TaxClassZipCodes
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`is_range`)) {
        self$`is_range` <- this_object$`is_range`
      }
      if (!is.null(this_object$`range`)) {
        self$`range` <- ApiClient$new()$deserializeObj(this_object$`range`, "array[character]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`fields`)) {
        self$`fields` <- ApiClient$new()$deserializeObj(this_object$`fields`, "array[TaxClassZipCodesRange]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return TaxClassZipCodes in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of TaxClassZipCodes
    #'
    #' @param input_json the JSON input
    #' @return the instance of TaxClassZipCodes
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`is_range` <- this_object$`is_range`
      self$`range` <- ApiClient$new()$deserializeObj(this_object$`range`, "array[character]", loadNamespace("openapi"))
      self$`fields` <- ApiClient$new()$deserializeObj(this_object$`fields`, "array[TaxClassZipCodesRange]", loadNamespace("openapi"))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to TaxClassZipCodes and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of TaxClassZipCodes
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# TaxClassZipCodes$unlock()
#
## Below is an example to define the print function
# TaxClassZipCodes$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# TaxClassZipCodes$lock()

