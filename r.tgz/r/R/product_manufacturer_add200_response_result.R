#' Create a new ProductManufacturerAdd200ResponseResult
#'
#' @description
#' ProductManufacturerAdd200ResponseResult Class
#'
#' @docType class
#' @title ProductManufacturerAdd200ResponseResult
#' @description ProductManufacturerAdd200ResponseResult Class
#' @format An \code{R6Class} generator object
#' @field manufacturer_id  character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductManufacturerAdd200ResponseResult <- R6::R6Class(
  "ProductManufacturerAdd200ResponseResult",
  public = list(
    `manufacturer_id` = NULL,

    #' @description
    #' Initialize a new ProductManufacturerAdd200ResponseResult class.
    #'
    #' @param manufacturer_id manufacturer_id
    #' @param ... Other optional arguments.
    initialize = function(`manufacturer_id` = NULL, ...) {
      if (!is.null(`manufacturer_id`)) {
        if (!(is.character(`manufacturer_id`) && length(`manufacturer_id`) == 1)) {
          stop(paste("Error! Invalid data for `manufacturer_id`. Must be a string:", `manufacturer_id`))
        }
        self$`manufacturer_id` <- `manufacturer_id`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductManufacturerAdd200ResponseResult as a base R list.
    #' @examples
    #' # convert array of ProductManufacturerAdd200ResponseResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductManufacturerAdd200ResponseResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductManufacturerAdd200ResponseResultObject <- list()
      if (!is.null(self$`manufacturer_id`)) {
        ProductManufacturerAdd200ResponseResultObject[["manufacturer_id"]] <-
          self$`manufacturer_id`
      }
      return(ProductManufacturerAdd200ResponseResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductManufacturerAdd200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductManufacturerAdd200ResponseResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`manufacturer_id`)) {
        self$`manufacturer_id` <- this_object$`manufacturer_id`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductManufacturerAdd200ResponseResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductManufacturerAdd200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductManufacturerAdd200ResponseResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`manufacturer_id` <- this_object$`manufacturer_id`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductManufacturerAdd200ResponseResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductManufacturerAdd200ResponseResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductManufacturerAdd200ResponseResult$unlock()
#
## Below is an example to define the print function
# ProductManufacturerAdd200ResponseResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductManufacturerAdd200ResponseResult$lock()

