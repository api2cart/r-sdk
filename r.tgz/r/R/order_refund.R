#' Create a new OrderRefund
#'
#' @description
#' OrderRefund Class
#'
#' @docType class
#' @title OrderRefund
#' @description OrderRefund Class
#' @format An \code{R6Class} generator object
#' @field id  character [optional]
#' @field shipping  numeric [optional]
#' @field fee  numeric [optional]
#' @field tax  numeric [optional]
#' @field total  numeric [optional]
#' @field modified_time  \link{A2CDateTime} [optional]
#' @field comment  character [optional]
#' @field items  list(\link{OrderStatusRefundItem}) [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
OrderRefund <- R6::R6Class(
  "OrderRefund",
  public = list(
    `id` = NULL,
    `shipping` = NULL,
    `fee` = NULL,
    `tax` = NULL,
    `total` = NULL,
    `modified_time` = NULL,
    `comment` = NULL,
    `items` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new OrderRefund class.
    #'
    #' @param id id
    #' @param shipping shipping
    #' @param fee fee
    #' @param tax tax
    #' @param total total
    #' @param modified_time modified_time
    #' @param comment comment
    #' @param items items
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `shipping` = NULL, `fee` = NULL, `tax` = NULL, `total` = NULL, `modified_time` = NULL, `comment` = NULL, `items` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`shipping`)) {
        self$`shipping` <- `shipping`
      }
      if (!is.null(`fee`)) {
        self$`fee` <- `fee`
      }
      if (!is.null(`tax`)) {
        self$`tax` <- `tax`
      }
      if (!is.null(`total`)) {
        self$`total` <- `total`
      }
      if (!is.null(`modified_time`)) {
        stopifnot(R6::is.R6(`modified_time`))
        self$`modified_time` <- `modified_time`
      }
      if (!is.null(`comment`)) {
        if (!(is.character(`comment`) && length(`comment`) == 1)) {
          stop(paste("Error! Invalid data for `comment`. Must be a string:", `comment`))
        }
        self$`comment` <- `comment`
      }
      if (!is.null(`items`)) {
        stopifnot(is.vector(`items`), length(`items`) != 0)
        sapply(`items`, function(x) stopifnot(R6::is.R6(x)))
        self$`items` <- `items`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return OrderRefund as a base R list.
    #' @examples
    #' # convert array of OrderRefund (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert OrderRefund to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      OrderRefundObject <- list()
      if (!is.null(self$`id`)) {
        OrderRefundObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`shipping`)) {
        OrderRefundObject[["shipping"]] <-
          self$`shipping`
      }
      if (!is.null(self$`fee`)) {
        OrderRefundObject[["fee"]] <-
          self$`fee`
      }
      if (!is.null(self$`tax`)) {
        OrderRefundObject[["tax"]] <-
          self$`tax`
      }
      if (!is.null(self$`total`)) {
        OrderRefundObject[["total"]] <-
          self$`total`
      }
      if (!is.null(self$`modified_time`)) {
        OrderRefundObject[["modified_time"]] <-
          self$`modified_time`$toSimpleType()
      }
      if (!is.null(self$`comment`)) {
        OrderRefundObject[["comment"]] <-
          self$`comment`
      }
      if (!is.null(self$`items`)) {
        OrderRefundObject[["items"]] <-
          lapply(self$`items`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`additional_fields`)) {
        OrderRefundObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        OrderRefundObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(OrderRefundObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderRefund
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderRefund
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`shipping`)) {
        self$`shipping` <- this_object$`shipping`
      }
      if (!is.null(this_object$`fee`)) {
        self$`fee` <- this_object$`fee`
      }
      if (!is.null(this_object$`tax`)) {
        self$`tax` <- this_object$`tax`
      }
      if (!is.null(this_object$`total`)) {
        self$`total` <- this_object$`total`
      }
      if (!is.null(this_object$`modified_time`)) {
        `modified_time_object` <- A2CDateTime$new()
        `modified_time_object`$fromJSON(jsonlite::toJSON(this_object$`modified_time`, auto_unbox = TRUE, digits = NA))
        self$`modified_time` <- `modified_time_object`
      }
      if (!is.null(this_object$`comment`)) {
        self$`comment` <- this_object$`comment`
      }
      if (!is.null(this_object$`items`)) {
        self$`items` <- ApiClient$new()$deserializeObj(this_object$`items`, "array[OrderStatusRefundItem]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return OrderRefund in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderRefund
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderRefund
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`shipping` <- this_object$`shipping`
      self$`fee` <- this_object$`fee`
      self$`tax` <- this_object$`tax`
      self$`total` <- this_object$`total`
      self$`modified_time` <- A2CDateTime$new()$fromJSON(jsonlite::toJSON(this_object$`modified_time`, auto_unbox = TRUE, digits = NA))
      self$`comment` <- this_object$`comment`
      self$`items` <- ApiClient$new()$deserializeObj(this_object$`items`, "array[OrderStatusRefundItem]", loadNamespace("openapi"))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to OrderRefund and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of OrderRefund
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# OrderRefund$unlock()
#
## Below is an example to define the print function
# OrderRefund$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# OrderRefund$lock()

