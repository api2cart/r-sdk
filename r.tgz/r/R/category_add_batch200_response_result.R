#' Create a new CategoryAddBatch200ResponseResult
#'
#' @description
#' CategoryAddBatch200ResponseResult Class
#'
#' @docType class
#' @title CategoryAddBatch200ResponseResult
#' @description CategoryAddBatch200ResponseResult Class
#' @format An \code{R6Class} generator object
#' @field job_id  character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
CategoryAddBatch200ResponseResult <- R6::R6Class(
  "CategoryAddBatch200ResponseResult",
  public = list(
    `job_id` = NULL,

    #' @description
    #' Initialize a new CategoryAddBatch200ResponseResult class.
    #'
    #' @param job_id job_id
    #' @param ... Other optional arguments.
    initialize = function(`job_id` = NULL, ...) {
      if (!is.null(`job_id`)) {
        if (!(is.character(`job_id`) && length(`job_id`) == 1)) {
          stop(paste("Error! Invalid data for `job_id`. Must be a string:", `job_id`))
        }
        self$`job_id` <- `job_id`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return CategoryAddBatch200ResponseResult as a base R list.
    #' @examples
    #' # convert array of CategoryAddBatch200ResponseResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert CategoryAddBatch200ResponseResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      CategoryAddBatch200ResponseResultObject <- list()
      if (!is.null(self$`job_id`)) {
        CategoryAddBatch200ResponseResultObject[["job_id"]] <-
          self$`job_id`
      }
      return(CategoryAddBatch200ResponseResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of CategoryAddBatch200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of CategoryAddBatch200ResponseResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`job_id`)) {
        self$`job_id` <- this_object$`job_id`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return CategoryAddBatch200ResponseResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of CategoryAddBatch200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of CategoryAddBatch200ResponseResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`job_id` <- this_object$`job_id`
      self
    },

    #' @description
    #' Validate JSON input with respect to CategoryAddBatch200ResponseResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of CategoryAddBatch200ResponseResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# CategoryAddBatch200ResponseResult$unlock()
#
## Below is an example to define the print function
# CategoryAddBatch200ResponseResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# CategoryAddBatch200ResponseResult$lock()

