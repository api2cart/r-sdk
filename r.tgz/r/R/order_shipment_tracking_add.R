#' Create a new OrderShipmentTrackingAdd
#'
#' @description
#' OrderShipmentTrackingAdd Class
#'
#' @docType class
#' @title OrderShipmentTrackingAdd
#' @description OrderShipmentTrackingAdd Class
#' @format An \code{R6Class} generator object
#' @field order_id Defines the order id character [optional]
#' @field shipment_id Shipment id indicates the number of delivery character
#' @field carrier_id Defines tracking carrier id character [optional]
#' @field store_id Store Id character [optional]
#' @field tracking_provider Defines name of the company which provides shipment tracking character [optional]
#' @field tracking_number Defines tracking number character
#' @field tracking_link Defines custom tracking link character [optional]
#' @field send_notifications Send notifications to customer after tracking was created character [optional]
#' @field idempotency_key A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong> character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
OrderShipmentTrackingAdd <- R6::R6Class(
  "OrderShipmentTrackingAdd",
  public = list(
    `order_id` = NULL,
    `shipment_id` = NULL,
    `carrier_id` = NULL,
    `store_id` = NULL,
    `tracking_provider` = NULL,
    `tracking_number` = NULL,
    `tracking_link` = NULL,
    `send_notifications` = NULL,
    `idempotency_key` = NULL,

    #' @description
    #' Initialize a new OrderShipmentTrackingAdd class.
    #'
    #' @param shipment_id Shipment id indicates the number of delivery
    #' @param tracking_number Defines tracking number
    #' @param order_id Defines the order id
    #' @param carrier_id Defines tracking carrier id
    #' @param store_id Store Id
    #' @param tracking_provider Defines name of the company which provides shipment tracking
    #' @param tracking_link Defines custom tracking link
    #' @param send_notifications Send notifications to customer after tracking was created. Default to FALSE.
    #' @param idempotency_key A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong>
    #' @param ... Other optional arguments.
    initialize = function(`shipment_id`, `tracking_number`, `order_id` = NULL, `carrier_id` = NULL, `store_id` = NULL, `tracking_provider` = NULL, `tracking_link` = NULL, `send_notifications` = FALSE, `idempotency_key` = NULL, ...) {
      if (!missing(`shipment_id`)) {
        if (!(is.character(`shipment_id`) && length(`shipment_id`) == 1)) {
          stop(paste("Error! Invalid data for `shipment_id`. Must be a string:", `shipment_id`))
        }
        self$`shipment_id` <- `shipment_id`
      }
      if (!missing(`tracking_number`)) {
        if (!(is.character(`tracking_number`) && length(`tracking_number`) == 1)) {
          stop(paste("Error! Invalid data for `tracking_number`. Must be a string:", `tracking_number`))
        }
        self$`tracking_number` <- `tracking_number`
      }
      if (!is.null(`order_id`)) {
        if (!(is.character(`order_id`) && length(`order_id`) == 1)) {
          stop(paste("Error! Invalid data for `order_id`. Must be a string:", `order_id`))
        }
        self$`order_id` <- `order_id`
      }
      if (!is.null(`carrier_id`)) {
        if (!(is.character(`carrier_id`) && length(`carrier_id`) == 1)) {
          stop(paste("Error! Invalid data for `carrier_id`. Must be a string:", `carrier_id`))
        }
        self$`carrier_id` <- `carrier_id`
      }
      if (!is.null(`store_id`)) {
        if (!(is.character(`store_id`) && length(`store_id`) == 1)) {
          stop(paste("Error! Invalid data for `store_id`. Must be a string:", `store_id`))
        }
        self$`store_id` <- `store_id`
      }
      if (!is.null(`tracking_provider`)) {
        if (!(is.character(`tracking_provider`) && length(`tracking_provider`) == 1)) {
          stop(paste("Error! Invalid data for `tracking_provider`. Must be a string:", `tracking_provider`))
        }
        self$`tracking_provider` <- `tracking_provider`
      }
      if (!is.null(`tracking_link`)) {
        if (!(is.character(`tracking_link`) && length(`tracking_link`) == 1)) {
          stop(paste("Error! Invalid data for `tracking_link`. Must be a string:", `tracking_link`))
        }
        self$`tracking_link` <- `tracking_link`
      }
      if (!is.null(`send_notifications`)) {
        if (!(is.logical(`send_notifications`) && length(`send_notifications`) == 1)) {
          stop(paste("Error! Invalid data for `send_notifications`. Must be a boolean:", `send_notifications`))
        }
        self$`send_notifications` <- `send_notifications`
      }
      if (!is.null(`idempotency_key`)) {
        if (!(is.character(`idempotency_key`) && length(`idempotency_key`) == 1)) {
          stop(paste("Error! Invalid data for `idempotency_key`. Must be a string:", `idempotency_key`))
        }
        self$`idempotency_key` <- `idempotency_key`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return OrderShipmentTrackingAdd as a base R list.
    #' @examples
    #' # convert array of OrderShipmentTrackingAdd (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert OrderShipmentTrackingAdd to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      OrderShipmentTrackingAddObject <- list()
      if (!is.null(self$`order_id`)) {
        OrderShipmentTrackingAddObject[["order_id"]] <-
          self$`order_id`
      }
      if (!is.null(self$`shipment_id`)) {
        OrderShipmentTrackingAddObject[["shipment_id"]] <-
          self$`shipment_id`
      }
      if (!is.null(self$`carrier_id`)) {
        OrderShipmentTrackingAddObject[["carrier_id"]] <-
          self$`carrier_id`
      }
      if (!is.null(self$`store_id`)) {
        OrderShipmentTrackingAddObject[["store_id"]] <-
          self$`store_id`
      }
      if (!is.null(self$`tracking_provider`)) {
        OrderShipmentTrackingAddObject[["tracking_provider"]] <-
          self$`tracking_provider`
      }
      if (!is.null(self$`tracking_number`)) {
        OrderShipmentTrackingAddObject[["tracking_number"]] <-
          self$`tracking_number`
      }
      if (!is.null(self$`tracking_link`)) {
        OrderShipmentTrackingAddObject[["tracking_link"]] <-
          self$`tracking_link`
      }
      if (!is.null(self$`send_notifications`)) {
        OrderShipmentTrackingAddObject[["send_notifications"]] <-
          self$`send_notifications`
      }
      if (!is.null(self$`idempotency_key`)) {
        OrderShipmentTrackingAddObject[["idempotency_key"]] <-
          self$`idempotency_key`
      }
      return(OrderShipmentTrackingAddObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderShipmentTrackingAdd
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderShipmentTrackingAdd
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`order_id`)) {
        self$`order_id` <- this_object$`order_id`
      }
      if (!is.null(this_object$`shipment_id`)) {
        self$`shipment_id` <- this_object$`shipment_id`
      }
      if (!is.null(this_object$`carrier_id`)) {
        self$`carrier_id` <- this_object$`carrier_id`
      }
      if (!is.null(this_object$`store_id`)) {
        self$`store_id` <- this_object$`store_id`
      }
      if (!is.null(this_object$`tracking_provider`)) {
        self$`tracking_provider` <- this_object$`tracking_provider`
      }
      if (!is.null(this_object$`tracking_number`)) {
        self$`tracking_number` <- this_object$`tracking_number`
      }
      if (!is.null(this_object$`tracking_link`)) {
        self$`tracking_link` <- this_object$`tracking_link`
      }
      if (!is.null(this_object$`send_notifications`)) {
        self$`send_notifications` <- this_object$`send_notifications`
      }
      if (!is.null(this_object$`idempotency_key`)) {
        self$`idempotency_key` <- this_object$`idempotency_key`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return OrderShipmentTrackingAdd in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderShipmentTrackingAdd
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderShipmentTrackingAdd
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`order_id` <- this_object$`order_id`
      self$`shipment_id` <- this_object$`shipment_id`
      self$`carrier_id` <- this_object$`carrier_id`
      self$`store_id` <- this_object$`store_id`
      self$`tracking_provider` <- this_object$`tracking_provider`
      self$`tracking_number` <- this_object$`tracking_number`
      self$`tracking_link` <- this_object$`tracking_link`
      self$`send_notifications` <- this_object$`send_notifications`
      self$`idempotency_key` <- this_object$`idempotency_key`
      self
    },

    #' @description
    #' Validate JSON input with respect to OrderShipmentTrackingAdd and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
      # check the required field `shipment_id`
      if (!is.null(input_json$`shipment_id`)) {
        if (!(is.character(input_json$`shipment_id`) && length(input_json$`shipment_id`) == 1)) {
          stop(paste("Error! Invalid data for `shipment_id`. Must be a string:", input_json$`shipment_id`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for OrderShipmentTrackingAdd: the required field `shipment_id` is missing."))
      }
      # check the required field `tracking_number`
      if (!is.null(input_json$`tracking_number`)) {
        if (!(is.character(input_json$`tracking_number`) && length(input_json$`tracking_number`) == 1)) {
          stop(paste("Error! Invalid data for `tracking_number`. Must be a string:", input_json$`tracking_number`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for OrderShipmentTrackingAdd: the required field `tracking_number` is missing."))
      }
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of OrderShipmentTrackingAdd
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      # check if the required `shipment_id` is null
      if (is.null(self$`shipment_id`)) {
        return(FALSE)
      }

      # check if the required `tracking_number` is null
      if (is.null(self$`tracking_number`)) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      # check if the required `shipment_id` is null
      if (is.null(self$`shipment_id`)) {
        invalid_fields["shipment_id"] <- "Non-nullable required field `shipment_id` cannot be null."
      }

      # check if the required `tracking_number` is null
      if (is.null(self$`tracking_number`)) {
        invalid_fields["tracking_number"] <- "Non-nullable required field `tracking_number` cannot be null."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# OrderShipmentTrackingAdd$unlock()
#
## Below is an example to define the print function
# OrderShipmentTrackingAdd$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# OrderShipmentTrackingAdd$lock()

