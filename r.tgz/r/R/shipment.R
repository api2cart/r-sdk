#' Create a new Shipment
#'
#' @description
#' Shipment Class
#'
#' @docType class
#' @title Shipment
#' @description Shipment Class
#' @format An \code{R6Class} generator object
#' @field id  character [optional]
#' @field order_id  character [optional]
#' @field name  character [optional]
#' @field warehouse_id  character [optional]
#' @field shipment_provider  character [optional]
#' @field tracking_numbers  list(\link{ShipmentTrackingNumber}) [optional]
#' @field created_at  \link{A2CDateTime} [optional]
#' @field modified_time  \link{A2CDateTime} [optional]
#' @field items  list(\link{ShipmentItem}) [optional]
#' @field is_shipped  character [optional]
#' @field delivered_at  \link{A2CDateTime} [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
Shipment <- R6::R6Class(
  "Shipment",
  public = list(
    `id` = NULL,
    `order_id` = NULL,
    `name` = NULL,
    `warehouse_id` = NULL,
    `shipment_provider` = NULL,
    `tracking_numbers` = NULL,
    `created_at` = NULL,
    `modified_time` = NULL,
    `items` = NULL,
    `is_shipped` = NULL,
    `delivered_at` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new Shipment class.
    #'
    #' @param id id
    #' @param order_id order_id
    #' @param name name
    #' @param warehouse_id warehouse_id
    #' @param shipment_provider shipment_provider
    #' @param tracking_numbers tracking_numbers
    #' @param created_at created_at
    #' @param modified_time modified_time
    #' @param items items
    #' @param is_shipped is_shipped
    #' @param delivered_at delivered_at
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `order_id` = NULL, `name` = NULL, `warehouse_id` = NULL, `shipment_provider` = NULL, `tracking_numbers` = NULL, `created_at` = NULL, `modified_time` = NULL, `items` = NULL, `is_shipped` = NULL, `delivered_at` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`order_id`)) {
        if (!(is.character(`order_id`) && length(`order_id`) == 1)) {
          stop(paste("Error! Invalid data for `order_id`. Must be a string:", `order_id`))
        }
        self$`order_id` <- `order_id`
      }
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`warehouse_id`)) {
        if (!(is.character(`warehouse_id`) && length(`warehouse_id`) == 1)) {
          stop(paste("Error! Invalid data for `warehouse_id`. Must be a string:", `warehouse_id`))
        }
        self$`warehouse_id` <- `warehouse_id`
      }
      if (!is.null(`shipment_provider`)) {
        if (!(is.character(`shipment_provider`) && length(`shipment_provider`) == 1)) {
          stop(paste("Error! Invalid data for `shipment_provider`. Must be a string:", `shipment_provider`))
        }
        self$`shipment_provider` <- `shipment_provider`
      }
      if (!is.null(`tracking_numbers`)) {
        stopifnot(is.vector(`tracking_numbers`), length(`tracking_numbers`) != 0)
        sapply(`tracking_numbers`, function(x) stopifnot(R6::is.R6(x)))
        self$`tracking_numbers` <- `tracking_numbers`
      }
      if (!is.null(`created_at`)) {
        stopifnot(R6::is.R6(`created_at`))
        self$`created_at` <- `created_at`
      }
      if (!is.null(`modified_time`)) {
        stopifnot(R6::is.R6(`modified_time`))
        self$`modified_time` <- `modified_time`
      }
      if (!is.null(`items`)) {
        stopifnot(is.vector(`items`), length(`items`) != 0)
        sapply(`items`, function(x) stopifnot(R6::is.R6(x)))
        self$`items` <- `items`
      }
      if (!is.null(`is_shipped`)) {
        if (!(is.logical(`is_shipped`) && length(`is_shipped`) == 1)) {
          stop(paste("Error! Invalid data for `is_shipped`. Must be a boolean:", `is_shipped`))
        }
        self$`is_shipped` <- `is_shipped`
      }
      if (!is.null(`delivered_at`)) {
        stopifnot(R6::is.R6(`delivered_at`))
        self$`delivered_at` <- `delivered_at`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return Shipment as a base R list.
    #' @examples
    #' # convert array of Shipment (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert Shipment to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ShipmentObject <- list()
      if (!is.null(self$`id`)) {
        ShipmentObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`order_id`)) {
        ShipmentObject[["order_id"]] <-
          self$`order_id`
      }
      if (!is.null(self$`name`)) {
        ShipmentObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`warehouse_id`)) {
        ShipmentObject[["warehouse_id"]] <-
          self$`warehouse_id`
      }
      if (!is.null(self$`shipment_provider`)) {
        ShipmentObject[["shipment_provider"]] <-
          self$`shipment_provider`
      }
      if (!is.null(self$`tracking_numbers`)) {
        ShipmentObject[["tracking_numbers"]] <-
          lapply(self$`tracking_numbers`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`created_at`)) {
        ShipmentObject[["created_at"]] <-
          self$`created_at`$toSimpleType()
      }
      if (!is.null(self$`modified_time`)) {
        ShipmentObject[["modified_time"]] <-
          self$`modified_time`$toSimpleType()
      }
      if (!is.null(self$`items`)) {
        ShipmentObject[["items"]] <-
          lapply(self$`items`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`is_shipped`)) {
        ShipmentObject[["is_shipped"]] <-
          self$`is_shipped`
      }
      if (!is.null(self$`delivered_at`)) {
        ShipmentObject[["delivered_at"]] <-
          self$`delivered_at`$toSimpleType()
      }
      if (!is.null(self$`additional_fields`)) {
        ShipmentObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        ShipmentObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(ShipmentObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of Shipment
    #'
    #' @param input_json the JSON input
    #' @return the instance of Shipment
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`order_id`)) {
        self$`order_id` <- this_object$`order_id`
      }
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`warehouse_id`)) {
        self$`warehouse_id` <- this_object$`warehouse_id`
      }
      if (!is.null(this_object$`shipment_provider`)) {
        self$`shipment_provider` <- this_object$`shipment_provider`
      }
      if (!is.null(this_object$`tracking_numbers`)) {
        self$`tracking_numbers` <- ApiClient$new()$deserializeObj(this_object$`tracking_numbers`, "array[ShipmentTrackingNumber]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`created_at`)) {
        `created_at_object` <- A2CDateTime$new()
        `created_at_object`$fromJSON(jsonlite::toJSON(this_object$`created_at`, auto_unbox = TRUE, digits = NA))
        self$`created_at` <- `created_at_object`
      }
      if (!is.null(this_object$`modified_time`)) {
        `modified_time_object` <- A2CDateTime$new()
        `modified_time_object`$fromJSON(jsonlite::toJSON(this_object$`modified_time`, auto_unbox = TRUE, digits = NA))
        self$`modified_time` <- `modified_time_object`
      }
      if (!is.null(this_object$`items`)) {
        self$`items` <- ApiClient$new()$deserializeObj(this_object$`items`, "array[ShipmentItem]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`is_shipped`)) {
        self$`is_shipped` <- this_object$`is_shipped`
      }
      if (!is.null(this_object$`delivered_at`)) {
        `delivered_at_object` <- A2CDateTime$new()
        `delivered_at_object`$fromJSON(jsonlite::toJSON(this_object$`delivered_at`, auto_unbox = TRUE, digits = NA))
        self$`delivered_at` <- `delivered_at_object`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return Shipment in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of Shipment
    #'
    #' @param input_json the JSON input
    #' @return the instance of Shipment
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`order_id` <- this_object$`order_id`
      self$`name` <- this_object$`name`
      self$`warehouse_id` <- this_object$`warehouse_id`
      self$`shipment_provider` <- this_object$`shipment_provider`
      self$`tracking_numbers` <- ApiClient$new()$deserializeObj(this_object$`tracking_numbers`, "array[ShipmentTrackingNumber]", loadNamespace("openapi"))
      self$`created_at` <- A2CDateTime$new()$fromJSON(jsonlite::toJSON(this_object$`created_at`, auto_unbox = TRUE, digits = NA))
      self$`modified_time` <- A2CDateTime$new()$fromJSON(jsonlite::toJSON(this_object$`modified_time`, auto_unbox = TRUE, digits = NA))
      self$`items` <- ApiClient$new()$deserializeObj(this_object$`items`, "array[ShipmentItem]", loadNamespace("openapi"))
      self$`is_shipped` <- this_object$`is_shipped`
      self$`delivered_at` <- A2CDateTime$new()$fromJSON(jsonlite::toJSON(this_object$`delivered_at`, auto_unbox = TRUE, digits = NA))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to Shipment and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of Shipment
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# Shipment$unlock()
#
## Below is an example to define the print function
# Shipment$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# Shipment$lock()

