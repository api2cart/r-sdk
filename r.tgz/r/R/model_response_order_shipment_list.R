#' Create a new ModelResponseOrderShipmentList
#'
#' @description
#' ModelResponseOrderShipmentList Class
#'
#' @docType class
#' @title ModelResponseOrderShipmentList
#' @description ModelResponseOrderShipmentList Class
#' @format An \code{R6Class} generator object
#' @field return_code  integer [optional]
#' @field return_message  character [optional]
#' @field pagination  \link{Pagination} [optional]
#' @field result  \link{ResponseOrderShipmentListResult} [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ModelResponseOrderShipmentList <- R6::R6Class(
  "ModelResponseOrderShipmentList",
  public = list(
    `return_code` = NULL,
    `return_message` = NULL,
    `pagination` = NULL,
    `result` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new ModelResponseOrderShipmentList class.
    #'
    #' @param return_code return_code
    #' @param return_message return_message
    #' @param pagination pagination
    #' @param result result
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`return_code` = NULL, `return_message` = NULL, `pagination` = NULL, `result` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`return_code`)) {
        if (!(is.numeric(`return_code`) && length(`return_code`) == 1)) {
          stop(paste("Error! Invalid data for `return_code`. Must be an integer:", `return_code`))
        }
        self$`return_code` <- `return_code`
      }
      if (!is.null(`return_message`)) {
        if (!(is.character(`return_message`) && length(`return_message`) == 1)) {
          stop(paste("Error! Invalid data for `return_message`. Must be a string:", `return_message`))
        }
        self$`return_message` <- `return_message`
      }
      if (!is.null(`pagination`)) {
        stopifnot(R6::is.R6(`pagination`))
        self$`pagination` <- `pagination`
      }
      if (!is.null(`result`)) {
        stopifnot(R6::is.R6(`result`))
        self$`result` <- `result`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ModelResponseOrderShipmentList as a base R list.
    #' @examples
    #' # convert array of ModelResponseOrderShipmentList (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ModelResponseOrderShipmentList to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ModelResponseOrderShipmentListObject <- list()
      if (!is.null(self$`return_code`)) {
        ModelResponseOrderShipmentListObject[["return_code"]] <-
          self$`return_code`
      }
      if (!is.null(self$`return_message`)) {
        ModelResponseOrderShipmentListObject[["return_message"]] <-
          self$`return_message`
      }
      if (!is.null(self$`pagination`)) {
        ModelResponseOrderShipmentListObject[["pagination"]] <-
          self$`pagination`$toSimpleType()
      }
      if (!is.null(self$`result`)) {
        ModelResponseOrderShipmentListObject[["result"]] <-
          self$`result`$toSimpleType()
      }
      if (!is.null(self$`additional_fields`)) {
        ModelResponseOrderShipmentListObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        ModelResponseOrderShipmentListObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(ModelResponseOrderShipmentListObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ModelResponseOrderShipmentList
    #'
    #' @param input_json the JSON input
    #' @return the instance of ModelResponseOrderShipmentList
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`return_code`)) {
        self$`return_code` <- this_object$`return_code`
      }
      if (!is.null(this_object$`return_message`)) {
        self$`return_message` <- this_object$`return_message`
      }
      if (!is.null(this_object$`pagination`)) {
        `pagination_object` <- Pagination$new()
        `pagination_object`$fromJSON(jsonlite::toJSON(this_object$`pagination`, auto_unbox = TRUE, digits = NA))
        self$`pagination` <- `pagination_object`
      }
      if (!is.null(this_object$`result`)) {
        `result_object` <- ResponseOrderShipmentListResult$new()
        `result_object`$fromJSON(jsonlite::toJSON(this_object$`result`, auto_unbox = TRUE, digits = NA))
        self$`result` <- `result_object`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ModelResponseOrderShipmentList in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ModelResponseOrderShipmentList
    #'
    #' @param input_json the JSON input
    #' @return the instance of ModelResponseOrderShipmentList
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`return_code` <- this_object$`return_code`
      self$`return_message` <- this_object$`return_message`
      self$`pagination` <- Pagination$new()$fromJSON(jsonlite::toJSON(this_object$`pagination`, auto_unbox = TRUE, digits = NA))
      self$`result` <- ResponseOrderShipmentListResult$new()$fromJSON(jsonlite::toJSON(this_object$`result`, auto_unbox = TRUE, digits = NA))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to ModelResponseOrderShipmentList and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ModelResponseOrderShipmentList
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ModelResponseOrderShipmentList$unlock()
#
## Below is an example to define the print function
# ModelResponseOrderShipmentList$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ModelResponseOrderShipmentList$lock()

