#' Create a new ProductAdvancedPrice
#'
#' @description
#' ProductAdvancedPrice Class
#'
#' @docType class
#' @title ProductAdvancedPrice
#' @description ProductAdvancedPrice Class
#' @format An \code{R6Class} generator object
#' @field id  character [optional]
#' @field value  numeric [optional]
#' @field avail  character [optional]
#' @field group_id  character [optional]
#' @field quantity_from  numeric [optional]
#' @field start_time  \link{A2CDateTime} [optional]
#' @field expire_time  \link{A2CDateTime} [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductAdvancedPrice <- R6::R6Class(
  "ProductAdvancedPrice",
  public = list(
    `id` = NULL,
    `value` = NULL,
    `avail` = NULL,
    `group_id` = NULL,
    `quantity_from` = NULL,
    `start_time` = NULL,
    `expire_time` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new ProductAdvancedPrice class.
    #'
    #' @param id id
    #' @param value value
    #' @param avail avail
    #' @param group_id group_id
    #' @param quantity_from quantity_from
    #' @param start_time start_time
    #' @param expire_time expire_time
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `value` = NULL, `avail` = NULL, `group_id` = NULL, `quantity_from` = NULL, `start_time` = NULL, `expire_time` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`value`)) {
        self$`value` <- `value`
      }
      if (!is.null(`avail`)) {
        if (!(is.logical(`avail`) && length(`avail`) == 1)) {
          stop(paste("Error! Invalid data for `avail`. Must be a boolean:", `avail`))
        }
        self$`avail` <- `avail`
      }
      if (!is.null(`group_id`)) {
        if (!(is.character(`group_id`) && length(`group_id`) == 1)) {
          stop(paste("Error! Invalid data for `group_id`. Must be a string:", `group_id`))
        }
        self$`group_id` <- `group_id`
      }
      if (!is.null(`quantity_from`)) {
        self$`quantity_from` <- `quantity_from`
      }
      if (!is.null(`start_time`)) {
        stopifnot(R6::is.R6(`start_time`))
        self$`start_time` <- `start_time`
      }
      if (!is.null(`expire_time`)) {
        stopifnot(R6::is.R6(`expire_time`))
        self$`expire_time` <- `expire_time`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductAdvancedPrice as a base R list.
    #' @examples
    #' # convert array of ProductAdvancedPrice (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductAdvancedPrice to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductAdvancedPriceObject <- list()
      if (!is.null(self$`id`)) {
        ProductAdvancedPriceObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`value`)) {
        ProductAdvancedPriceObject[["value"]] <-
          self$`value`
      }
      if (!is.null(self$`avail`)) {
        ProductAdvancedPriceObject[["avail"]] <-
          self$`avail`
      }
      if (!is.null(self$`group_id`)) {
        ProductAdvancedPriceObject[["group_id"]] <-
          self$`group_id`
      }
      if (!is.null(self$`quantity_from`)) {
        ProductAdvancedPriceObject[["quantity_from"]] <-
          self$`quantity_from`
      }
      if (!is.null(self$`start_time`)) {
        ProductAdvancedPriceObject[["start_time"]] <-
          self$`start_time`$toSimpleType()
      }
      if (!is.null(self$`expire_time`)) {
        ProductAdvancedPriceObject[["expire_time"]] <-
          self$`expire_time`$toSimpleType()
      }
      if (!is.null(self$`additional_fields`)) {
        ProductAdvancedPriceObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        ProductAdvancedPriceObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(ProductAdvancedPriceObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductAdvancedPrice
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductAdvancedPrice
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`value`)) {
        self$`value` <- this_object$`value`
      }
      if (!is.null(this_object$`avail`)) {
        self$`avail` <- this_object$`avail`
      }
      if (!is.null(this_object$`group_id`)) {
        self$`group_id` <- this_object$`group_id`
      }
      if (!is.null(this_object$`quantity_from`)) {
        self$`quantity_from` <- this_object$`quantity_from`
      }
      if (!is.null(this_object$`start_time`)) {
        `start_time_object` <- A2CDateTime$new()
        `start_time_object`$fromJSON(jsonlite::toJSON(this_object$`start_time`, auto_unbox = TRUE, digits = NA))
        self$`start_time` <- `start_time_object`
      }
      if (!is.null(this_object$`expire_time`)) {
        `expire_time_object` <- A2CDateTime$new()
        `expire_time_object`$fromJSON(jsonlite::toJSON(this_object$`expire_time`, auto_unbox = TRUE, digits = NA))
        self$`expire_time` <- `expire_time_object`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductAdvancedPrice in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductAdvancedPrice
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductAdvancedPrice
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`value` <- this_object$`value`
      self$`avail` <- this_object$`avail`
      self$`group_id` <- this_object$`group_id`
      self$`quantity_from` <- this_object$`quantity_from`
      self$`start_time` <- A2CDateTime$new()$fromJSON(jsonlite::toJSON(this_object$`start_time`, auto_unbox = TRUE, digits = NA))
      self$`expire_time` <- A2CDateTime$new()$fromJSON(jsonlite::toJSON(this_object$`expire_time`, auto_unbox = TRUE, digits = NA))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductAdvancedPrice and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductAdvancedPrice
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductAdvancedPrice$unlock()
#
## Below is an example to define the print function
# ProductAdvancedPrice$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductAdvancedPrice$lock()

