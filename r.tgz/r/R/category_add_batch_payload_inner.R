#' Create a new CategoryAddBatchPayloadInner
#'
#' @description
#' CategoryAddBatchPayloadInner Class
#'
#' @docType class
#' @title CategoryAddBatchPayloadInner
#' @description CategoryAddBatchPayloadInner Class
#' @format An \code{R6Class} generator object
#' @field name  character
#' @field avail  character [optional]
#' @field description  character [optional]
#' @field meta_title  character [optional]
#' @field meta_description  character [optional]
#' @field meta_keywords  list(character) [optional]
#' @field parent_id  character [optional]
#' @field sort_order  integer [optional]
#' @field seo_url  character [optional]
#' @field store_id  character [optional]
#' @field images  list(\link{CategoryAddBatchPayloadInnerImagesInner}) [optional]
#' @field stores_ids  list(character) [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
CategoryAddBatchPayloadInner <- R6::R6Class(
  "CategoryAddBatchPayloadInner",
  public = list(
    `name` = NULL,
    `avail` = NULL,
    `description` = NULL,
    `meta_title` = NULL,
    `meta_description` = NULL,
    `meta_keywords` = NULL,
    `parent_id` = NULL,
    `sort_order` = NULL,
    `seo_url` = NULL,
    `store_id` = NULL,
    `images` = NULL,
    `stores_ids` = NULL,

    #' @description
    #' Initialize a new CategoryAddBatchPayloadInner class.
    #'
    #' @param name name
    #' @param avail avail
    #' @param description description
    #' @param meta_title meta_title
    #' @param meta_description meta_description
    #' @param meta_keywords meta_keywords
    #' @param parent_id parent_id
    #' @param sort_order sort_order
    #' @param seo_url seo_url
    #' @param store_id store_id
    #' @param images images
    #' @param stores_ids stores_ids
    #' @param ... Other optional arguments.
    initialize = function(`name`, `avail` = NULL, `description` = NULL, `meta_title` = NULL, `meta_description` = NULL, `meta_keywords` = NULL, `parent_id` = NULL, `sort_order` = NULL, `seo_url` = NULL, `store_id` = NULL, `images` = NULL, `stores_ids` = NULL, ...) {
      if (!missing(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`avail`)) {
        if (!(is.logical(`avail`) && length(`avail`) == 1)) {
          stop(paste("Error! Invalid data for `avail`. Must be a boolean:", `avail`))
        }
        self$`avail` <- `avail`
      }
      if (!is.null(`description`)) {
        if (!(is.character(`description`) && length(`description`) == 1)) {
          stop(paste("Error! Invalid data for `description`. Must be a string:", `description`))
        }
        self$`description` <- `description`
      }
      if (!is.null(`meta_title`)) {
        if (!(is.character(`meta_title`) && length(`meta_title`) == 1)) {
          stop(paste("Error! Invalid data for `meta_title`. Must be a string:", `meta_title`))
        }
        self$`meta_title` <- `meta_title`
      }
      if (!is.null(`meta_description`)) {
        if (!(is.character(`meta_description`) && length(`meta_description`) == 1)) {
          stop(paste("Error! Invalid data for `meta_description`. Must be a string:", `meta_description`))
        }
        self$`meta_description` <- `meta_description`
      }
      if (!is.null(`meta_keywords`)) {
        stopifnot(is.vector(`meta_keywords`), length(`meta_keywords`) != 0)
        sapply(`meta_keywords`, function(x) stopifnot(is.character(x)))
        self$`meta_keywords` <- `meta_keywords`
      }
      if (!is.null(`parent_id`)) {
        if (!(is.character(`parent_id`) && length(`parent_id`) == 1)) {
          stop(paste("Error! Invalid data for `parent_id`. Must be a string:", `parent_id`))
        }
        self$`parent_id` <- `parent_id`
      }
      if (!is.null(`sort_order`)) {
        if (!(is.numeric(`sort_order`) && length(`sort_order`) == 1)) {
          stop(paste("Error! Invalid data for `sort_order`. Must be an integer:", `sort_order`))
        }
        self$`sort_order` <- `sort_order`
      }
      if (!is.null(`seo_url`)) {
        if (!(is.character(`seo_url`) && length(`seo_url`) == 1)) {
          stop(paste("Error! Invalid data for `seo_url`. Must be a string:", `seo_url`))
        }
        self$`seo_url` <- `seo_url`
      }
      if (!is.null(`store_id`)) {
        if (!(is.character(`store_id`) && length(`store_id`) == 1)) {
          stop(paste("Error! Invalid data for `store_id`. Must be a string:", `store_id`))
        }
        self$`store_id` <- `store_id`
      }
      if (!is.null(`images`)) {
        stopifnot(is.vector(`images`), length(`images`) != 0)
        sapply(`images`, function(x) stopifnot(R6::is.R6(x)))
        self$`images` <- `images`
      }
      if (!is.null(`stores_ids`)) {
        stopifnot(is.vector(`stores_ids`), length(`stores_ids`) != 0)
        sapply(`stores_ids`, function(x) stopifnot(is.character(x)))
        self$`stores_ids` <- `stores_ids`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return CategoryAddBatchPayloadInner as a base R list.
    #' @examples
    #' # convert array of CategoryAddBatchPayloadInner (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert CategoryAddBatchPayloadInner to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      CategoryAddBatchPayloadInnerObject <- list()
      if (!is.null(self$`name`)) {
        CategoryAddBatchPayloadInnerObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`avail`)) {
        CategoryAddBatchPayloadInnerObject[["avail"]] <-
          self$`avail`
      }
      if (!is.null(self$`description`)) {
        CategoryAddBatchPayloadInnerObject[["description"]] <-
          self$`description`
      }
      if (!is.null(self$`meta_title`)) {
        CategoryAddBatchPayloadInnerObject[["meta_title"]] <-
          self$`meta_title`
      }
      if (!is.null(self$`meta_description`)) {
        CategoryAddBatchPayloadInnerObject[["meta_description"]] <-
          self$`meta_description`
      }
      if (!is.null(self$`meta_keywords`)) {
        CategoryAddBatchPayloadInnerObject[["meta_keywords"]] <-
          self$`meta_keywords`
      }
      if (!is.null(self$`parent_id`)) {
        CategoryAddBatchPayloadInnerObject[["parent_id"]] <-
          self$`parent_id`
      }
      if (!is.null(self$`sort_order`)) {
        CategoryAddBatchPayloadInnerObject[["sort_order"]] <-
          self$`sort_order`
      }
      if (!is.null(self$`seo_url`)) {
        CategoryAddBatchPayloadInnerObject[["seo_url"]] <-
          self$`seo_url`
      }
      if (!is.null(self$`store_id`)) {
        CategoryAddBatchPayloadInnerObject[["store_id"]] <-
          self$`store_id`
      }
      if (!is.null(self$`images`)) {
        CategoryAddBatchPayloadInnerObject[["images"]] <-
          lapply(self$`images`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`stores_ids`)) {
        CategoryAddBatchPayloadInnerObject[["stores_ids"]] <-
          self$`stores_ids`
      }
      return(CategoryAddBatchPayloadInnerObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of CategoryAddBatchPayloadInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of CategoryAddBatchPayloadInner
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`avail`)) {
        self$`avail` <- this_object$`avail`
      }
      if (!is.null(this_object$`description`)) {
        self$`description` <- this_object$`description`
      }
      if (!is.null(this_object$`meta_title`)) {
        self$`meta_title` <- this_object$`meta_title`
      }
      if (!is.null(this_object$`meta_description`)) {
        self$`meta_description` <- this_object$`meta_description`
      }
      if (!is.null(this_object$`meta_keywords`)) {
        self$`meta_keywords` <- ApiClient$new()$deserializeObj(this_object$`meta_keywords`, "array[character]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`parent_id`)) {
        self$`parent_id` <- this_object$`parent_id`
      }
      if (!is.null(this_object$`sort_order`)) {
        self$`sort_order` <- this_object$`sort_order`
      }
      if (!is.null(this_object$`seo_url`)) {
        self$`seo_url` <- this_object$`seo_url`
      }
      if (!is.null(this_object$`store_id`)) {
        self$`store_id` <- this_object$`store_id`
      }
      if (!is.null(this_object$`images`)) {
        self$`images` <- ApiClient$new()$deserializeObj(this_object$`images`, "array[CategoryAddBatchPayloadInnerImagesInner]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`stores_ids`)) {
        self$`stores_ids` <- ApiClient$new()$deserializeObj(this_object$`stores_ids`, "array[character]", loadNamespace("openapi"))
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return CategoryAddBatchPayloadInner in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of CategoryAddBatchPayloadInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of CategoryAddBatchPayloadInner
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`name` <- this_object$`name`
      self$`avail` <- this_object$`avail`
      self$`description` <- this_object$`description`
      self$`meta_title` <- this_object$`meta_title`
      self$`meta_description` <- this_object$`meta_description`
      self$`meta_keywords` <- ApiClient$new()$deserializeObj(this_object$`meta_keywords`, "array[character]", loadNamespace("openapi"))
      self$`parent_id` <- this_object$`parent_id`
      self$`sort_order` <- this_object$`sort_order`
      self$`seo_url` <- this_object$`seo_url`
      self$`store_id` <- this_object$`store_id`
      self$`images` <- ApiClient$new()$deserializeObj(this_object$`images`, "array[CategoryAddBatchPayloadInnerImagesInner]", loadNamespace("openapi"))
      self$`stores_ids` <- ApiClient$new()$deserializeObj(this_object$`stores_ids`, "array[character]", loadNamespace("openapi"))
      self
    },

    #' @description
    #' Validate JSON input with respect to CategoryAddBatchPayloadInner and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
      # check the required field `name`
      if (!is.null(input_json$`name`)) {
        if (!(is.character(input_json$`name`) && length(input_json$`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", input_json$`name`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for CategoryAddBatchPayloadInner: the required field `name` is missing."))
      }
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of CategoryAddBatchPayloadInner
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      # check if the required `name` is null
      if (is.null(self$`name`)) {
        return(FALSE)
      }

      if (length(self$`meta_keywords`) < 1) {
        return(FALSE)
      }

      if (length(self$`images`) > 1) {
        return(FALSE)
      }

      if (length(self$`stores_ids`) < 1) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      # check if the required `name` is null
      if (is.null(self$`name`)) {
        invalid_fields["name"] <- "Non-nullable required field `name` cannot be null."
      }

      if (length(self$`meta_keywords`) < 1) {
        invalid_fields["meta_keywords"] <- "Invalid length for ``, number of items must be greater than or equal to 1."
      }

      if (length(self$`images`) > 1) {
        invalid_fields["images"] <- "Invalid length for `images`, number of items must be less than or equal to 1."
      }

      if (length(self$`stores_ids`) < 1) {
        invalid_fields["stores_ids"] <- "Invalid length for ``, number of items must be greater than or equal to 1."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# CategoryAddBatchPayloadInner$unlock()
#
## Below is an example to define the print function
# CategoryAddBatchPayloadInner$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# CategoryAddBatchPayloadInner$lock()

