#' Create a new ProductGroupPrice
#'
#' @description
#' ProductGroupPrice Class
#'
#' @docType class
#' @title ProductGroupPrice
#' @description ProductGroupPrice Class
#' @format An \code{R6Class} generator object
#' @field id  character [optional]
#' @field group_id  character [optional]
#' @field price  numeric [optional]
#' @field store_id  character [optional]
#' @field quantity  numeric [optional]
#' @field start_time  character [optional]
#' @field expire_time  character [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductGroupPrice <- R6::R6Class(
  "ProductGroupPrice",
  public = list(
    `id` = NULL,
    `group_id` = NULL,
    `price` = NULL,
    `store_id` = NULL,
    `quantity` = NULL,
    `start_time` = NULL,
    `expire_time` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new ProductGroupPrice class.
    #'
    #' @param id id
    #' @param group_id group_id
    #' @param price price
    #' @param store_id store_id
    #' @param quantity quantity
    #' @param start_time start_time
    #' @param expire_time expire_time
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `group_id` = NULL, `price` = NULL, `store_id` = NULL, `quantity` = NULL, `start_time` = NULL, `expire_time` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`group_id`)) {
        if (!(is.character(`group_id`) && length(`group_id`) == 1)) {
          stop(paste("Error! Invalid data for `group_id`. Must be a string:", `group_id`))
        }
        self$`group_id` <- `group_id`
      }
      if (!is.null(`price`)) {
        self$`price` <- `price`
      }
      if (!is.null(`store_id`)) {
        if (!(is.character(`store_id`) && length(`store_id`) == 1)) {
          stop(paste("Error! Invalid data for `store_id`. Must be a string:", `store_id`))
        }
        self$`store_id` <- `store_id`
      }
      if (!is.null(`quantity`)) {
        self$`quantity` <- `quantity`
      }
      if (!is.null(`start_time`)) {
        if (!(is.character(`start_time`) && length(`start_time`) == 1)) {
          stop(paste("Error! Invalid data for `start_time`. Must be a string:", `start_time`))
        }
        self$`start_time` <- `start_time`
      }
      if (!is.null(`expire_time`)) {
        if (!(is.character(`expire_time`) && length(`expire_time`) == 1)) {
          stop(paste("Error! Invalid data for `expire_time`. Must be a string:", `expire_time`))
        }
        self$`expire_time` <- `expire_time`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductGroupPrice as a base R list.
    #' @examples
    #' # convert array of ProductGroupPrice (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductGroupPrice to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductGroupPriceObject <- list()
      if (!is.null(self$`id`)) {
        ProductGroupPriceObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`group_id`)) {
        ProductGroupPriceObject[["group_id"]] <-
          self$`group_id`
      }
      if (!is.null(self$`price`)) {
        ProductGroupPriceObject[["price"]] <-
          self$`price`
      }
      if (!is.null(self$`store_id`)) {
        ProductGroupPriceObject[["store_id"]] <-
          self$`store_id`
      }
      if (!is.null(self$`quantity`)) {
        ProductGroupPriceObject[["quantity"]] <-
          self$`quantity`
      }
      if (!is.null(self$`start_time`)) {
        ProductGroupPriceObject[["start_time"]] <-
          self$`start_time`
      }
      if (!is.null(self$`expire_time`)) {
        ProductGroupPriceObject[["expire_time"]] <-
          self$`expire_time`
      }
      if (!is.null(self$`additional_fields`)) {
        ProductGroupPriceObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        ProductGroupPriceObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(ProductGroupPriceObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductGroupPrice
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductGroupPrice
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`group_id`)) {
        self$`group_id` <- this_object$`group_id`
      }
      if (!is.null(this_object$`price`)) {
        self$`price` <- this_object$`price`
      }
      if (!is.null(this_object$`store_id`)) {
        self$`store_id` <- this_object$`store_id`
      }
      if (!is.null(this_object$`quantity`)) {
        self$`quantity` <- this_object$`quantity`
      }
      if (!is.null(this_object$`start_time`)) {
        self$`start_time` <- this_object$`start_time`
      }
      if (!is.null(this_object$`expire_time`)) {
        self$`expire_time` <- this_object$`expire_time`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductGroupPrice in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductGroupPrice
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductGroupPrice
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`group_id` <- this_object$`group_id`
      self$`price` <- this_object$`price`
      self$`store_id` <- this_object$`store_id`
      self$`quantity` <- this_object$`quantity`
      self$`start_time` <- this_object$`start_time`
      self$`expire_time` <- this_object$`expire_time`
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductGroupPrice and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductGroupPrice
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductGroupPrice$unlock()
#
## Below is an example to define the print function
# ProductGroupPrice$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductGroupPrice$lock()

