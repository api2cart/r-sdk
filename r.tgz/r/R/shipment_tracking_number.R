#' Create a new ShipmentTrackingNumber
#'
#' @description
#' ShipmentTrackingNumber Class
#'
#' @docType class
#' @title ShipmentTrackingNumber
#' @description ShipmentTrackingNumber Class
#' @format An \code{R6Class} generator object
#' @field carrier_id  character [optional]
#' @field tracking_number  character [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ShipmentTrackingNumber <- R6::R6Class(
  "ShipmentTrackingNumber",
  public = list(
    `carrier_id` = NULL,
    `tracking_number` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new ShipmentTrackingNumber class.
    #'
    #' @param carrier_id carrier_id
    #' @param tracking_number tracking_number
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`carrier_id` = NULL, `tracking_number` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`carrier_id`)) {
        if (!(is.character(`carrier_id`) && length(`carrier_id`) == 1)) {
          stop(paste("Error! Invalid data for `carrier_id`. Must be a string:", `carrier_id`))
        }
        self$`carrier_id` <- `carrier_id`
      }
      if (!is.null(`tracking_number`)) {
        if (!(is.character(`tracking_number`) && length(`tracking_number`) == 1)) {
          stop(paste("Error! Invalid data for `tracking_number`. Must be a string:", `tracking_number`))
        }
        self$`tracking_number` <- `tracking_number`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ShipmentTrackingNumber as a base R list.
    #' @examples
    #' # convert array of ShipmentTrackingNumber (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ShipmentTrackingNumber to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ShipmentTrackingNumberObject <- list()
      if (!is.null(self$`carrier_id`)) {
        ShipmentTrackingNumberObject[["carrier_id"]] <-
          self$`carrier_id`
      }
      if (!is.null(self$`tracking_number`)) {
        ShipmentTrackingNumberObject[["tracking_number"]] <-
          self$`tracking_number`
      }
      if (!is.null(self$`additional_fields`)) {
        ShipmentTrackingNumberObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        ShipmentTrackingNumberObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(ShipmentTrackingNumberObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ShipmentTrackingNumber
    #'
    #' @param input_json the JSON input
    #' @return the instance of ShipmentTrackingNumber
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`carrier_id`)) {
        self$`carrier_id` <- this_object$`carrier_id`
      }
      if (!is.null(this_object$`tracking_number`)) {
        self$`tracking_number` <- this_object$`tracking_number`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ShipmentTrackingNumber in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ShipmentTrackingNumber
    #'
    #' @param input_json the JSON input
    #' @return the instance of ShipmentTrackingNumber
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`carrier_id` <- this_object$`carrier_id`
      self$`tracking_number` <- this_object$`tracking_number`
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to ShipmentTrackingNumber and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ShipmentTrackingNumber
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ShipmentTrackingNumber$unlock()
#
## Below is an example to define the print function
# ShipmentTrackingNumber$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ShipmentTrackingNumber$lock()

