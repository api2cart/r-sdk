#' Create a new OrderTotal
#'
#' @description
#' OrderTotal Class
#'
#' @docType class
#' @title OrderTotal
#' @description OrderTotal Class
#' @format An \code{R6Class} generator object
#' @field subtotal_ex_tax  numeric [optional]
#' @field wrapping_ex_tax  numeric [optional]
#' @field shipping_ex_tax  numeric [optional]
#' @field total_discount  numeric [optional]
#' @field total_tax  numeric [optional]
#' @field total  numeric [optional]
#' @field total_paid  numeric [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
OrderTotal <- R6::R6Class(
  "OrderTotal",
  public = list(
    `subtotal_ex_tax` = NULL,
    `wrapping_ex_tax` = NULL,
    `shipping_ex_tax` = NULL,
    `total_discount` = NULL,
    `total_tax` = NULL,
    `total` = NULL,
    `total_paid` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new OrderTotal class.
    #'
    #' @param subtotal_ex_tax subtotal_ex_tax
    #' @param wrapping_ex_tax wrapping_ex_tax
    #' @param shipping_ex_tax shipping_ex_tax
    #' @param total_discount total_discount
    #' @param total_tax total_tax
    #' @param total total
    #' @param total_paid total_paid
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`subtotal_ex_tax` = NULL, `wrapping_ex_tax` = NULL, `shipping_ex_tax` = NULL, `total_discount` = NULL, `total_tax` = NULL, `total` = NULL, `total_paid` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`subtotal_ex_tax`)) {
        self$`subtotal_ex_tax` <- `subtotal_ex_tax`
      }
      if (!is.null(`wrapping_ex_tax`)) {
        self$`wrapping_ex_tax` <- `wrapping_ex_tax`
      }
      if (!is.null(`shipping_ex_tax`)) {
        self$`shipping_ex_tax` <- `shipping_ex_tax`
      }
      if (!is.null(`total_discount`)) {
        self$`total_discount` <- `total_discount`
      }
      if (!is.null(`total_tax`)) {
        self$`total_tax` <- `total_tax`
      }
      if (!is.null(`total`)) {
        self$`total` <- `total`
      }
      if (!is.null(`total_paid`)) {
        self$`total_paid` <- `total_paid`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return OrderTotal as a base R list.
    #' @examples
    #' # convert array of OrderTotal (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert OrderTotal to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      OrderTotalObject <- list()
      if (!is.null(self$`subtotal_ex_tax`)) {
        OrderTotalObject[["subtotal_ex_tax"]] <-
          self$`subtotal_ex_tax`
      }
      if (!is.null(self$`wrapping_ex_tax`)) {
        OrderTotalObject[["wrapping_ex_tax"]] <-
          self$`wrapping_ex_tax`
      }
      if (!is.null(self$`shipping_ex_tax`)) {
        OrderTotalObject[["shipping_ex_tax"]] <-
          self$`shipping_ex_tax`
      }
      if (!is.null(self$`total_discount`)) {
        OrderTotalObject[["total_discount"]] <-
          self$`total_discount`
      }
      if (!is.null(self$`total_tax`)) {
        OrderTotalObject[["total_tax"]] <-
          self$`total_tax`
      }
      if (!is.null(self$`total`)) {
        OrderTotalObject[["total"]] <-
          self$`total`
      }
      if (!is.null(self$`total_paid`)) {
        OrderTotalObject[["total_paid"]] <-
          self$`total_paid`
      }
      if (!is.null(self$`additional_fields`)) {
        OrderTotalObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        OrderTotalObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(OrderTotalObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderTotal
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderTotal
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`subtotal_ex_tax`)) {
        self$`subtotal_ex_tax` <- this_object$`subtotal_ex_tax`
      }
      if (!is.null(this_object$`wrapping_ex_tax`)) {
        self$`wrapping_ex_tax` <- this_object$`wrapping_ex_tax`
      }
      if (!is.null(this_object$`shipping_ex_tax`)) {
        self$`shipping_ex_tax` <- this_object$`shipping_ex_tax`
      }
      if (!is.null(this_object$`total_discount`)) {
        self$`total_discount` <- this_object$`total_discount`
      }
      if (!is.null(this_object$`total_tax`)) {
        self$`total_tax` <- this_object$`total_tax`
      }
      if (!is.null(this_object$`total`)) {
        self$`total` <- this_object$`total`
      }
      if (!is.null(this_object$`total_paid`)) {
        self$`total_paid` <- this_object$`total_paid`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return OrderTotal in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderTotal
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderTotal
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`subtotal_ex_tax` <- this_object$`subtotal_ex_tax`
      self$`wrapping_ex_tax` <- this_object$`wrapping_ex_tax`
      self$`shipping_ex_tax` <- this_object$`shipping_ex_tax`
      self$`total_discount` <- this_object$`total_discount`
      self$`total_tax` <- this_object$`total_tax`
      self$`total` <- this_object$`total`
      self$`total_paid` <- this_object$`total_paid`
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to OrderTotal and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of OrderTotal
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# OrderTotal$unlock()
#
## Below is an example to define the print function
# OrderTotal$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# OrderTotal$lock()

