#' Create a new ResponseAttributeListResult
#'
#' @description
#' ResponseAttributeListResult Class
#'
#' @docType class
#' @title ResponseAttributeListResult
#' @description ResponseAttributeListResult Class
#' @format An \code{R6Class} generator object
#' @field attributes_count  integer [optional]
#' @field attribute  list(\link{StoreAttribute}) [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ResponseAttributeListResult <- R6::R6Class(
  "ResponseAttributeListResult",
  public = list(
    `attributes_count` = NULL,
    `attribute` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new ResponseAttributeListResult class.
    #'
    #' @param attributes_count attributes_count
    #' @param attribute attribute
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`attributes_count` = NULL, `attribute` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`attributes_count`)) {
        if (!(is.numeric(`attributes_count`) && length(`attributes_count`) == 1)) {
          stop(paste("Error! Invalid data for `attributes_count`. Must be an integer:", `attributes_count`))
        }
        self$`attributes_count` <- `attributes_count`
      }
      if (!is.null(`attribute`)) {
        stopifnot(is.vector(`attribute`), length(`attribute`) != 0)
        sapply(`attribute`, function(x) stopifnot(R6::is.R6(x)))
        self$`attribute` <- `attribute`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ResponseAttributeListResult as a base R list.
    #' @examples
    #' # convert array of ResponseAttributeListResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ResponseAttributeListResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ResponseAttributeListResultObject <- list()
      if (!is.null(self$`attributes_count`)) {
        ResponseAttributeListResultObject[["attributes_count"]] <-
          self$`attributes_count`
      }
      if (!is.null(self$`attribute`)) {
        ResponseAttributeListResultObject[["attribute"]] <-
          lapply(self$`attribute`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`additional_fields`)) {
        ResponseAttributeListResultObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        ResponseAttributeListResultObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(ResponseAttributeListResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ResponseAttributeListResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ResponseAttributeListResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`attributes_count`)) {
        self$`attributes_count` <- this_object$`attributes_count`
      }
      if (!is.null(this_object$`attribute`)) {
        self$`attribute` <- ApiClient$new()$deserializeObj(this_object$`attribute`, "array[StoreAttribute]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ResponseAttributeListResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ResponseAttributeListResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ResponseAttributeListResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`attributes_count` <- this_object$`attributes_count`
      self$`attribute` <- ApiClient$new()$deserializeObj(this_object$`attribute`, "array[StoreAttribute]", loadNamespace("openapi"))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to ResponseAttributeListResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ResponseAttributeListResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ResponseAttributeListResult$unlock()
#
## Below is an example to define the print function
# ResponseAttributeListResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ResponseAttributeListResult$lock()

