#' Create a new CustomerWishListItem
#'
#' @description
#' CustomerWishListItem Class
#'
#' @docType class
#' @title CustomerWishListItem
#' @description CustomerWishListItem Class
#' @format An \code{R6Class} generator object
#' @field id  character [optional]
#' @field product_id  character [optional]
#' @field child_id  character [optional]
#' @field created_time  \link{A2CDateTime} [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
CustomerWishListItem <- R6::R6Class(
  "CustomerWishListItem",
  public = list(
    `id` = NULL,
    `product_id` = NULL,
    `child_id` = NULL,
    `created_time` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new CustomerWishListItem class.
    #'
    #' @param id id
    #' @param product_id product_id
    #' @param child_id child_id
    #' @param created_time created_time
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `product_id` = NULL, `child_id` = NULL, `created_time` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`product_id`)) {
        if (!(is.character(`product_id`) && length(`product_id`) == 1)) {
          stop(paste("Error! Invalid data for `product_id`. Must be a string:", `product_id`))
        }
        self$`product_id` <- `product_id`
      }
      if (!is.null(`child_id`)) {
        if (!(is.character(`child_id`) && length(`child_id`) == 1)) {
          stop(paste("Error! Invalid data for `child_id`. Must be a string:", `child_id`))
        }
        self$`child_id` <- `child_id`
      }
      if (!is.null(`created_time`)) {
        stopifnot(R6::is.R6(`created_time`))
        self$`created_time` <- `created_time`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return CustomerWishListItem as a base R list.
    #' @examples
    #' # convert array of CustomerWishListItem (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert CustomerWishListItem to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      CustomerWishListItemObject <- list()
      if (!is.null(self$`id`)) {
        CustomerWishListItemObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`product_id`)) {
        CustomerWishListItemObject[["product_id"]] <-
          self$`product_id`
      }
      if (!is.null(self$`child_id`)) {
        CustomerWishListItemObject[["child_id"]] <-
          self$`child_id`
      }
      if (!is.null(self$`created_time`)) {
        CustomerWishListItemObject[["created_time"]] <-
          self$`created_time`$toSimpleType()
      }
      if (!is.null(self$`additional_fields`)) {
        CustomerWishListItemObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        CustomerWishListItemObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(CustomerWishListItemObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of CustomerWishListItem
    #'
    #' @param input_json the JSON input
    #' @return the instance of CustomerWishListItem
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`product_id`)) {
        self$`product_id` <- this_object$`product_id`
      }
      if (!is.null(this_object$`child_id`)) {
        self$`child_id` <- this_object$`child_id`
      }
      if (!is.null(this_object$`created_time`)) {
        `created_time_object` <- A2CDateTime$new()
        `created_time_object`$fromJSON(jsonlite::toJSON(this_object$`created_time`, auto_unbox = TRUE, digits = NA))
        self$`created_time` <- `created_time_object`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return CustomerWishListItem in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of CustomerWishListItem
    #'
    #' @param input_json the JSON input
    #' @return the instance of CustomerWishListItem
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`product_id` <- this_object$`product_id`
      self$`child_id` <- this_object$`child_id`
      self$`created_time` <- A2CDateTime$new()$fromJSON(jsonlite::toJSON(this_object$`created_time`, auto_unbox = TRUE, digits = NA))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to CustomerWishListItem and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of CustomerWishListItem
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# CustomerWishListItem$unlock()
#
## Below is an example to define the print function
# CustomerWishListItem$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# CustomerWishListItem$lock()

