#' Create a new AccountFailedWebhooks200ResponseResultWebhookInner
#'
#' @description
#' AccountFailedWebhooks200ResponseResultWebhookInner Class
#'
#' @docType class
#' @title AccountFailedWebhooks200ResponseResultWebhookInner
#' @description AccountFailedWebhooks200ResponseResultWebhookInner Class
#' @format An \code{R6Class} generator object
#' @field webhook_id  integer [optional]
#' @field entity_id  character [optional]
#' @field time  \link{A2CDateTime} [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
AccountFailedWebhooks200ResponseResultWebhookInner <- R6::R6Class(
  "AccountFailedWebhooks200ResponseResultWebhookInner",
  public = list(
    `webhook_id` = NULL,
    `entity_id` = NULL,
    `time` = NULL,

    #' @description
    #' Initialize a new AccountFailedWebhooks200ResponseResultWebhookInner class.
    #'
    #' @param webhook_id webhook_id
    #' @param entity_id entity_id
    #' @param time time
    #' @param ... Other optional arguments.
    initialize = function(`webhook_id` = NULL, `entity_id` = NULL, `time` = NULL, ...) {
      if (!is.null(`webhook_id`)) {
        if (!(is.numeric(`webhook_id`) && length(`webhook_id`) == 1)) {
          stop(paste("Error! Invalid data for `webhook_id`. Must be an integer:", `webhook_id`))
        }
        self$`webhook_id` <- `webhook_id`
      }
      if (!is.null(`entity_id`)) {
        if (!(is.character(`entity_id`) && length(`entity_id`) == 1)) {
          stop(paste("Error! Invalid data for `entity_id`. Must be a string:", `entity_id`))
        }
        self$`entity_id` <- `entity_id`
      }
      if (!is.null(`time`)) {
        stopifnot(R6::is.R6(`time`))
        self$`time` <- `time`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return AccountFailedWebhooks200ResponseResultWebhookInner as a base R list.
    #' @examples
    #' # convert array of AccountFailedWebhooks200ResponseResultWebhookInner (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert AccountFailedWebhooks200ResponseResultWebhookInner to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      AccountFailedWebhooks200ResponseResultWebhookInnerObject <- list()
      if (!is.null(self$`webhook_id`)) {
        AccountFailedWebhooks200ResponseResultWebhookInnerObject[["webhook_id"]] <-
          self$`webhook_id`
      }
      if (!is.null(self$`entity_id`)) {
        AccountFailedWebhooks200ResponseResultWebhookInnerObject[["entity_id"]] <-
          self$`entity_id`
      }
      if (!is.null(self$`time`)) {
        AccountFailedWebhooks200ResponseResultWebhookInnerObject[["time"]] <-
          self$`time`$toSimpleType()
      }
      return(AccountFailedWebhooks200ResponseResultWebhookInnerObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of AccountFailedWebhooks200ResponseResultWebhookInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of AccountFailedWebhooks200ResponseResultWebhookInner
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`webhook_id`)) {
        self$`webhook_id` <- this_object$`webhook_id`
      }
      if (!is.null(this_object$`entity_id`)) {
        self$`entity_id` <- this_object$`entity_id`
      }
      if (!is.null(this_object$`time`)) {
        `time_object` <- A2CDateTime$new()
        `time_object`$fromJSON(jsonlite::toJSON(this_object$`time`, auto_unbox = TRUE, digits = NA))
        self$`time` <- `time_object`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return AccountFailedWebhooks200ResponseResultWebhookInner in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of AccountFailedWebhooks200ResponseResultWebhookInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of AccountFailedWebhooks200ResponseResultWebhookInner
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`webhook_id` <- this_object$`webhook_id`
      self$`entity_id` <- this_object$`entity_id`
      self$`time` <- A2CDateTime$new()$fromJSON(jsonlite::toJSON(this_object$`time`, auto_unbox = TRUE, digits = NA))
      self
    },

    #' @description
    #' Validate JSON input with respect to AccountFailedWebhooks200ResponseResultWebhookInner and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of AccountFailedWebhooks200ResponseResultWebhookInner
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# AccountFailedWebhooks200ResponseResultWebhookInner$unlock()
#
## Below is an example to define the print function
# AccountFailedWebhooks200ResponseResultWebhookInner$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# AccountFailedWebhooks200ResponseResultWebhookInner$lock()

