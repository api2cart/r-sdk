#' Create a new CouponCondition
#'
#' @description
#' CouponCondition Class
#'
#' @docType class
#' @title CouponCondition
#' @description CouponCondition Class
#' @format An \code{R6Class} generator object
#' @field id  character [optional]
#' @field entity  character [optional]
#' @field match_items  character [optional]
#' @field key  character [optional]
#' @field operator  character [optional]
#' @field value  character [optional]
#' @field logic_operator  character [optional]
#' @field sub-conditions  list(\link{CouponCondition}) [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
CouponCondition <- R6::R6Class(
  "CouponCondition",
  public = list(
    `id` = NULL,
    `entity` = NULL,
    `match_items` = NULL,
    `key` = NULL,
    `operator` = NULL,
    `value` = NULL,
    `logic_operator` = NULL,
    `sub-conditions` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new CouponCondition class.
    #'
    #' @param id id
    #' @param entity entity
    #' @param match_items match_items
    #' @param key key
    #' @param operator operator
    #' @param value value
    #' @param logic_operator logic_operator
    #' @param sub-conditions sub-conditions
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `entity` = NULL, `match_items` = NULL, `key` = NULL, `operator` = NULL, `value` = NULL, `logic_operator` = NULL, `sub-conditions` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`entity`)) {
        if (!(is.character(`entity`) && length(`entity`) == 1)) {
          stop(paste("Error! Invalid data for `entity`. Must be a string:", `entity`))
        }
        self$`entity` <- `entity`
      }
      if (!is.null(`match_items`)) {
        if (!(is.character(`match_items`) && length(`match_items`) == 1)) {
          stop(paste("Error! Invalid data for `match_items`. Must be a string:", `match_items`))
        }
        self$`match_items` <- `match_items`
      }
      if (!is.null(`key`)) {
        if (!(is.character(`key`) && length(`key`) == 1)) {
          stop(paste("Error! Invalid data for `key`. Must be a string:", `key`))
        }
        self$`key` <- `key`
      }
      if (!is.null(`operator`)) {
        if (!(is.character(`operator`) && length(`operator`) == 1)) {
          stop(paste("Error! Invalid data for `operator`. Must be a string:", `operator`))
        }
        self$`operator` <- `operator`
      }
      if (!is.null(`value`)) {
        if (!(is.character(`value`) && length(`value`) == 1)) {
          stop(paste("Error! Invalid data for `value`. Must be a string:", `value`))
        }
        self$`value` <- `value`
      }
      if (!is.null(`logic_operator`)) {
        if (!(is.character(`logic_operator`) && length(`logic_operator`) == 1)) {
          stop(paste("Error! Invalid data for `logic_operator`. Must be a string:", `logic_operator`))
        }
        self$`logic_operator` <- `logic_operator`
      }
      if (!is.null(`sub-conditions`)) {
        stopifnot(is.vector(`sub-conditions`), length(`sub-conditions`) != 0)
        sapply(`sub-conditions`, function(x) stopifnot(R6::is.R6(x)))
        self$`sub-conditions` <- `sub-conditions`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return CouponCondition as a base R list.
    #' @examples
    #' # convert array of CouponCondition (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert CouponCondition to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      CouponConditionObject <- list()
      if (!is.null(self$`id`)) {
        CouponConditionObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`entity`)) {
        CouponConditionObject[["entity"]] <-
          self$`entity`
      }
      if (!is.null(self$`match_items`)) {
        CouponConditionObject[["match_items"]] <-
          self$`match_items`
      }
      if (!is.null(self$`key`)) {
        CouponConditionObject[["key"]] <-
          self$`key`
      }
      if (!is.null(self$`operator`)) {
        CouponConditionObject[["operator"]] <-
          self$`operator`
      }
      if (!is.null(self$`value`)) {
        CouponConditionObject[["value"]] <-
          self$`value`
      }
      if (!is.null(self$`logic_operator`)) {
        CouponConditionObject[["logic_operator"]] <-
          self$`logic_operator`
      }
      if (!is.null(self$`sub-conditions`)) {
        CouponConditionObject[["sub-conditions"]] <-
          lapply(self$`sub-conditions`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`additional_fields`)) {
        CouponConditionObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        CouponConditionObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(CouponConditionObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of CouponCondition
    #'
    #' @param input_json the JSON input
    #' @return the instance of CouponCondition
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`entity`)) {
        self$`entity` <- this_object$`entity`
      }
      if (!is.null(this_object$`match_items`)) {
        self$`match_items` <- this_object$`match_items`
      }
      if (!is.null(this_object$`key`)) {
        self$`key` <- this_object$`key`
      }
      if (!is.null(this_object$`operator`)) {
        self$`operator` <- this_object$`operator`
      }
      if (!is.null(this_object$`value`)) {
        self$`value` <- this_object$`value`
      }
      if (!is.null(this_object$`logic_operator`)) {
        self$`logic_operator` <- this_object$`logic_operator`
      }
      if (!is.null(this_object$`sub-conditions`)) {
        self$`sub-conditions` <- ApiClient$new()$deserializeObj(this_object$`sub-conditions`, "array[CouponCondition]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return CouponCondition in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of CouponCondition
    #'
    #' @param input_json the JSON input
    #' @return the instance of CouponCondition
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`entity` <- this_object$`entity`
      self$`match_items` <- this_object$`match_items`
      self$`key` <- this_object$`key`
      self$`operator` <- this_object$`operator`
      self$`value` <- this_object$`value`
      self$`logic_operator` <- this_object$`logic_operator`
      self$`sub-conditions` <- ApiClient$new()$deserializeObj(this_object$`sub-conditions`, "array[CouponCondition]", loadNamespace("openapi"))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to CouponCondition and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of CouponCondition
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# CouponCondition$unlock()
#
## Below is an example to define the print function
# CouponCondition$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# CouponCondition$lock()

