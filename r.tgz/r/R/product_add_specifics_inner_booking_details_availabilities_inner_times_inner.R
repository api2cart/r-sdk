#' Create a new ProductAddSpecificsInnerBookingDetailsAvailabilitiesInnerTimesInner
#'
#' @description
#' ProductAddSpecificsInnerBookingDetailsAvailabilitiesInnerTimesInner Class
#'
#' @docType class
#' @title ProductAddSpecificsInnerBookingDetailsAvailabilitiesInnerTimesInner
#' @description ProductAddSpecificsInnerBookingDetailsAvailabilitiesInnerTimesInner Class
#' @format An \code{R6Class} generator object
#' @field from The starting time of the of available booking slot in 24 hours format. Required if <code>type=date_time</code> character
#' @field to The ending time of the of available booking slot in 24 hours format. Required if <code>type=date_time</code> character
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductAddSpecificsInnerBookingDetailsAvailabilitiesInnerTimesInner <- R6::R6Class(
  "ProductAddSpecificsInnerBookingDetailsAvailabilitiesInnerTimesInner",
  public = list(
    `from` = NULL,
    `to` = NULL,

    #' @description
    #' Initialize a new ProductAddSpecificsInnerBookingDetailsAvailabilitiesInnerTimesInner class.
    #'
    #' @param from The starting time of the of available booking slot in 24 hours format. Required if <code>type=date_time</code>
    #' @param to The ending time of the of available booking slot in 24 hours format. Required if <code>type=date_time</code>
    #' @param ... Other optional arguments.
    initialize = function(`from`, `to`, ...) {
      if (!missing(`from`)) {
        if (!(is.character(`from`) && length(`from`) == 1)) {
          stop(paste("Error! Invalid data for `from`. Must be a string:", `from`))
        }
        self$`from` <- `from`
      }
      if (!missing(`to`)) {
        if (!(is.character(`to`) && length(`to`) == 1)) {
          stop(paste("Error! Invalid data for `to`. Must be a string:", `to`))
        }
        self$`to` <- `to`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductAddSpecificsInnerBookingDetailsAvailabilitiesInnerTimesInner as a base R list.
    #' @examples
    #' # convert array of ProductAddSpecificsInnerBookingDetailsAvailabilitiesInnerTimesInner (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductAddSpecificsInnerBookingDetailsAvailabilitiesInnerTimesInner to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductAddSpecificsInnerBookingDetailsAvailabilitiesInnerTimesInnerObject <- list()
      if (!is.null(self$`from`)) {
        ProductAddSpecificsInnerBookingDetailsAvailabilitiesInnerTimesInnerObject[["from"]] <-
          self$`from`
      }
      if (!is.null(self$`to`)) {
        ProductAddSpecificsInnerBookingDetailsAvailabilitiesInnerTimesInnerObject[["to"]] <-
          self$`to`
      }
      return(ProductAddSpecificsInnerBookingDetailsAvailabilitiesInnerTimesInnerObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductAddSpecificsInnerBookingDetailsAvailabilitiesInnerTimesInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductAddSpecificsInnerBookingDetailsAvailabilitiesInnerTimesInner
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`from`)) {
        self$`from` <- this_object$`from`
      }
      if (!is.null(this_object$`to`)) {
        self$`to` <- this_object$`to`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductAddSpecificsInnerBookingDetailsAvailabilitiesInnerTimesInner in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductAddSpecificsInnerBookingDetailsAvailabilitiesInnerTimesInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductAddSpecificsInnerBookingDetailsAvailabilitiesInnerTimesInner
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`from` <- this_object$`from`
      self$`to` <- this_object$`to`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductAddSpecificsInnerBookingDetailsAvailabilitiesInnerTimesInner and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
      # check the required field `from`
      if (!is.null(input_json$`from`)) {
        if (!(is.character(input_json$`from`) && length(input_json$`from`) == 1)) {
          stop(paste("Error! Invalid data for `from`. Must be a string:", input_json$`from`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for ProductAddSpecificsInnerBookingDetailsAvailabilitiesInnerTimesInner: the required field `from` is missing."))
      }
      # check the required field `to`
      if (!is.null(input_json$`to`)) {
        if (!(is.character(input_json$`to`) && length(input_json$`to`) == 1)) {
          stop(paste("Error! Invalid data for `to`. Must be a string:", input_json$`to`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for ProductAddSpecificsInnerBookingDetailsAvailabilitiesInnerTimesInner: the required field `to` is missing."))
      }
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductAddSpecificsInnerBookingDetailsAvailabilitiesInnerTimesInner
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      # check if the required `from` is null
      if (is.null(self$`from`)) {
        return(FALSE)
      }

      if (!str_detect(self$`from`, "^(?:[01]\\d|2[0-3]):[0-5]\\d$")) {
        return(FALSE)
      }

      # check if the required `to` is null
      if (is.null(self$`to`)) {
        return(FALSE)
      }

      if (!str_detect(self$`to`, "^(?:[01]\\d|2[0-3]):[0-5]\\d$")) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      # check if the required `from` is null
      if (is.null(self$`from`)) {
        invalid_fields["from"] <- "Non-nullable required field `from` cannot be null."
      }

      if (!str_detect(self$`from`, "^(?:[01]\\d|2[0-3]):[0-5]\\d$")) {
        invalid_fields["from"] <- "Invalid value for `from`, must conform to the pattern ^(?:[01]\\d|2[0-3]):[0-5]\\d$."
      }

      # check if the required `to` is null
      if (is.null(self$`to`)) {
        invalid_fields["to"] <- "Non-nullable required field `to` cannot be null."
      }

      if (!str_detect(self$`to`, "^(?:[01]\\d|2[0-3]):[0-5]\\d$")) {
        invalid_fields["to"] <- "Invalid value for `to`, must conform to the pattern ^(?:[01]\\d|2[0-3]):[0-5]\\d$."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductAddSpecificsInnerBookingDetailsAvailabilitiesInnerTimesInner$unlock()
#
## Below is an example to define the print function
# ProductAddSpecificsInnerBookingDetailsAvailabilitiesInnerTimesInner$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductAddSpecificsInnerBookingDetailsAvailabilitiesInnerTimesInner$lock()

