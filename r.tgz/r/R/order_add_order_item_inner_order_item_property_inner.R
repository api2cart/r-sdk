#' Create a new OrderAddOrderItemInnerOrderItemPropertyInner
#'
#' @description
#' OrderAddOrderItemInnerOrderItemPropertyInner Class
#'
#' @docType class
#' @title OrderAddOrderItemInnerOrderItemPropertyInner
#' @description OrderAddOrderItemInnerOrderItemPropertyInner Class
#' @format An \code{R6Class} generator object
#' @field order_item_property_name Ordered product property name. Where x is order item ID, y is order item property ID character [optional]
#' @field order_item_property_value Ordered product property value. Where x is order item ID, y - order item property ID character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
OrderAddOrderItemInnerOrderItemPropertyInner <- R6::R6Class(
  "OrderAddOrderItemInnerOrderItemPropertyInner",
  public = list(
    `order_item_property_name` = NULL,
    `order_item_property_value` = NULL,

    #' @description
    #' Initialize a new OrderAddOrderItemInnerOrderItemPropertyInner class.
    #'
    #' @param order_item_property_name Ordered product property name. Where x is order item ID, y is order item property ID
    #' @param order_item_property_value Ordered product property value. Where x is order item ID, y - order item property ID
    #' @param ... Other optional arguments.
    initialize = function(`order_item_property_name` = NULL, `order_item_property_value` = NULL, ...) {
      if (!is.null(`order_item_property_name`)) {
        if (!(is.character(`order_item_property_name`) && length(`order_item_property_name`) == 1)) {
          stop(paste("Error! Invalid data for `order_item_property_name`. Must be a string:", `order_item_property_name`))
        }
        self$`order_item_property_name` <- `order_item_property_name`
      }
      if (!is.null(`order_item_property_value`)) {
        if (!(is.character(`order_item_property_value`) && length(`order_item_property_value`) == 1)) {
          stop(paste("Error! Invalid data for `order_item_property_value`. Must be a string:", `order_item_property_value`))
        }
        self$`order_item_property_value` <- `order_item_property_value`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return OrderAddOrderItemInnerOrderItemPropertyInner as a base R list.
    #' @examples
    #' # convert array of OrderAddOrderItemInnerOrderItemPropertyInner (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert OrderAddOrderItemInnerOrderItemPropertyInner to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      OrderAddOrderItemInnerOrderItemPropertyInnerObject <- list()
      if (!is.null(self$`order_item_property_name`)) {
        OrderAddOrderItemInnerOrderItemPropertyInnerObject[["order_item_property_name"]] <-
          self$`order_item_property_name`
      }
      if (!is.null(self$`order_item_property_value`)) {
        OrderAddOrderItemInnerOrderItemPropertyInnerObject[["order_item_property_value"]] <-
          self$`order_item_property_value`
      }
      return(OrderAddOrderItemInnerOrderItemPropertyInnerObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderAddOrderItemInnerOrderItemPropertyInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderAddOrderItemInnerOrderItemPropertyInner
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`order_item_property_name`)) {
        self$`order_item_property_name` <- this_object$`order_item_property_name`
      }
      if (!is.null(this_object$`order_item_property_value`)) {
        self$`order_item_property_value` <- this_object$`order_item_property_value`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return OrderAddOrderItemInnerOrderItemPropertyInner in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderAddOrderItemInnerOrderItemPropertyInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderAddOrderItemInnerOrderItemPropertyInner
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`order_item_property_name` <- this_object$`order_item_property_name`
      self$`order_item_property_value` <- this_object$`order_item_property_value`
      self
    },

    #' @description
    #' Validate JSON input with respect to OrderAddOrderItemInnerOrderItemPropertyInner and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of OrderAddOrderItemInnerOrderItemPropertyInner
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# OrderAddOrderItemInnerOrderItemPropertyInner$unlock()
#
## Below is an example to define the print function
# OrderAddOrderItemInnerOrderItemPropertyInner$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# OrderAddOrderItemInnerOrderItemPropertyInner$lock()

