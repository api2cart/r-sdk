#' Create a new CartShippingZone2
#'
#' @description
#' CartShippingZone2 Class
#'
#' @docType class
#' @title CartShippingZone2
#' @description CartShippingZone2 Class
#' @format An \code{R6Class} generator object
#' @field id  character [optional]
#' @field name  character [optional]
#' @field enabled  character [optional]
#' @field countries  list(\link{Country}) [optional]
#' @field shipping_methods  list(\link{CartShippingMethod}) [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
CartShippingZone2 <- R6::R6Class(
  "CartShippingZone2",
  public = list(
    `id` = NULL,
    `name` = NULL,
    `enabled` = NULL,
    `countries` = NULL,
    `shipping_methods` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new CartShippingZone2 class.
    #'
    #' @param id id
    #' @param name name
    #' @param enabled enabled
    #' @param countries countries
    #' @param shipping_methods shipping_methods
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `name` = NULL, `enabled` = NULL, `countries` = NULL, `shipping_methods` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`enabled`)) {
        if (!(is.logical(`enabled`) && length(`enabled`) == 1)) {
          stop(paste("Error! Invalid data for `enabled`. Must be a boolean:", `enabled`))
        }
        self$`enabled` <- `enabled`
      }
      if (!is.null(`countries`)) {
        stopifnot(is.vector(`countries`), length(`countries`) != 0)
        sapply(`countries`, function(x) stopifnot(R6::is.R6(x)))
        self$`countries` <- `countries`
      }
      if (!is.null(`shipping_methods`)) {
        stopifnot(is.vector(`shipping_methods`), length(`shipping_methods`) != 0)
        sapply(`shipping_methods`, function(x) stopifnot(R6::is.R6(x)))
        self$`shipping_methods` <- `shipping_methods`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return CartShippingZone2 as a base R list.
    #' @examples
    #' # convert array of CartShippingZone2 (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert CartShippingZone2 to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      CartShippingZone2Object <- list()
      if (!is.null(self$`id`)) {
        CartShippingZone2Object[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`name`)) {
        CartShippingZone2Object[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`enabled`)) {
        CartShippingZone2Object[["enabled"]] <-
          self$`enabled`
      }
      if (!is.null(self$`countries`)) {
        CartShippingZone2Object[["countries"]] <-
          lapply(self$`countries`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`shipping_methods`)) {
        CartShippingZone2Object[["shipping_methods"]] <-
          lapply(self$`shipping_methods`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`additional_fields`)) {
        CartShippingZone2Object[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        CartShippingZone2Object[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(CartShippingZone2Object)
    },

    #' @description
    #' Deserialize JSON string into an instance of CartShippingZone2
    #'
    #' @param input_json the JSON input
    #' @return the instance of CartShippingZone2
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`enabled`)) {
        self$`enabled` <- this_object$`enabled`
      }
      if (!is.null(this_object$`countries`)) {
        self$`countries` <- ApiClient$new()$deserializeObj(this_object$`countries`, "array[Country]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`shipping_methods`)) {
        self$`shipping_methods` <- ApiClient$new()$deserializeObj(this_object$`shipping_methods`, "array[CartShippingMethod]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return CartShippingZone2 in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of CartShippingZone2
    #'
    #' @param input_json the JSON input
    #' @return the instance of CartShippingZone2
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`name` <- this_object$`name`
      self$`enabled` <- this_object$`enabled`
      self$`countries` <- ApiClient$new()$deserializeObj(this_object$`countries`, "array[Country]", loadNamespace("openapi"))
      self$`shipping_methods` <- ApiClient$new()$deserializeObj(this_object$`shipping_methods`, "array[CartShippingMethod]", loadNamespace("openapi"))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to CartShippingZone2 and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of CartShippingZone2
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# CartShippingZone2$unlock()
#
## Below is an example to define the print function
# CartShippingZone2$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# CartShippingZone2$lock()

