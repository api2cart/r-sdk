#' Create a new ShipmentEvent
#'
#' @description
#' ShipmentEvent Class
#'
#' @docType class
#' @title ShipmentEvent
#' @description ShipmentEvent Class
#' @format An \code{R6Class} generator object
#' @field id  character [optional]
#' @field status  character [optional]
#' @field created_at  \link{A2CDateTime} [optional]
#' @field estimated_delivery_at  \link{A2CDateTime} [optional]
#' @field message  character [optional]
#' @field address  \link{CustomerAddress} [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ShipmentEvent <- R6::R6Class(
  "ShipmentEvent",
  public = list(
    `id` = NULL,
    `status` = NULL,
    `created_at` = NULL,
    `estimated_delivery_at` = NULL,
    `message` = NULL,
    `address` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new ShipmentEvent class.
    #'
    #' @param id id
    #' @param status status
    #' @param created_at created_at
    #' @param estimated_delivery_at estimated_delivery_at
    #' @param message message
    #' @param address address
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `status` = NULL, `created_at` = NULL, `estimated_delivery_at` = NULL, `message` = NULL, `address` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`status`)) {
        if (!(is.character(`status`) && length(`status`) == 1)) {
          stop(paste("Error! Invalid data for `status`. Must be a string:", `status`))
        }
        self$`status` <- `status`
      }
      if (!is.null(`created_at`)) {
        stopifnot(R6::is.R6(`created_at`))
        self$`created_at` <- `created_at`
      }
      if (!is.null(`estimated_delivery_at`)) {
        stopifnot(R6::is.R6(`estimated_delivery_at`))
        self$`estimated_delivery_at` <- `estimated_delivery_at`
      }
      if (!is.null(`message`)) {
        if (!(is.character(`message`) && length(`message`) == 1)) {
          stop(paste("Error! Invalid data for `message`. Must be a string:", `message`))
        }
        self$`message` <- `message`
      }
      if (!is.null(`address`)) {
        stopifnot(R6::is.R6(`address`))
        self$`address` <- `address`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ShipmentEvent as a base R list.
    #' @examples
    #' # convert array of ShipmentEvent (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ShipmentEvent to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ShipmentEventObject <- list()
      if (!is.null(self$`id`)) {
        ShipmentEventObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`status`)) {
        ShipmentEventObject[["status"]] <-
          self$`status`
      }
      if (!is.null(self$`created_at`)) {
        ShipmentEventObject[["created_at"]] <-
          self$`created_at`$toSimpleType()
      }
      if (!is.null(self$`estimated_delivery_at`)) {
        ShipmentEventObject[["estimated_delivery_at"]] <-
          self$`estimated_delivery_at`$toSimpleType()
      }
      if (!is.null(self$`message`)) {
        ShipmentEventObject[["message"]] <-
          self$`message`
      }
      if (!is.null(self$`address`)) {
        ShipmentEventObject[["address"]] <-
          self$`address`$toSimpleType()
      }
      if (!is.null(self$`additional_fields`)) {
        ShipmentEventObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        ShipmentEventObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(ShipmentEventObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ShipmentEvent
    #'
    #' @param input_json the JSON input
    #' @return the instance of ShipmentEvent
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`status`)) {
        self$`status` <- this_object$`status`
      }
      if (!is.null(this_object$`created_at`)) {
        `created_at_object` <- A2CDateTime$new()
        `created_at_object`$fromJSON(jsonlite::toJSON(this_object$`created_at`, auto_unbox = TRUE, digits = NA))
        self$`created_at` <- `created_at_object`
      }
      if (!is.null(this_object$`estimated_delivery_at`)) {
        `estimated_delivery_at_object` <- A2CDateTime$new()
        `estimated_delivery_at_object`$fromJSON(jsonlite::toJSON(this_object$`estimated_delivery_at`, auto_unbox = TRUE, digits = NA))
        self$`estimated_delivery_at` <- `estimated_delivery_at_object`
      }
      if (!is.null(this_object$`message`)) {
        self$`message` <- this_object$`message`
      }
      if (!is.null(this_object$`address`)) {
        `address_object` <- CustomerAddress$new()
        `address_object`$fromJSON(jsonlite::toJSON(this_object$`address`, auto_unbox = TRUE, digits = NA))
        self$`address` <- `address_object`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ShipmentEvent in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ShipmentEvent
    #'
    #' @param input_json the JSON input
    #' @return the instance of ShipmentEvent
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`status` <- this_object$`status`
      self$`created_at` <- A2CDateTime$new()$fromJSON(jsonlite::toJSON(this_object$`created_at`, auto_unbox = TRUE, digits = NA))
      self$`estimated_delivery_at` <- A2CDateTime$new()$fromJSON(jsonlite::toJSON(this_object$`estimated_delivery_at`, auto_unbox = TRUE, digits = NA))
      self$`message` <- this_object$`message`
      self$`address` <- CustomerAddress$new()$fromJSON(jsonlite::toJSON(this_object$`address`, auto_unbox = TRUE, digits = NA))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to ShipmentEvent and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ShipmentEvent
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ShipmentEvent$unlock()
#
## Below is an example to define the print function
# ShipmentEvent$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ShipmentEvent$lock()

