#' Create a new ProductReview
#'
#' @description
#' ProductReview Class
#'
#' @docType class
#' @title ProductReview
#' @description ProductReview Class
#' @format An \code{R6Class} generator object
#' @field id  character [optional]
#' @field product_id  character [optional]
#' @field customer_id  character [optional]
#' @field nick_name  character [optional]
#' @field email  character [optional]
#' @field summary  character [optional]
#' @field message  character [optional]
#' @field rating  numeric [optional]
#' @field ratings  list(\link{ProductReviewRating}) [optional]
#' @field status  character [optional]
#' @field created_time  \link{A2CDateTime} [optional]
#' @field modified_time  \link{A2CDateTime} [optional]
#' @field medias  list(\link{Media}) [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductReview <- R6::R6Class(
  "ProductReview",
  public = list(
    `id` = NULL,
    `product_id` = NULL,
    `customer_id` = NULL,
    `nick_name` = NULL,
    `email` = NULL,
    `summary` = NULL,
    `message` = NULL,
    `rating` = NULL,
    `ratings` = NULL,
    `status` = NULL,
    `created_time` = NULL,
    `modified_time` = NULL,
    `medias` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new ProductReview class.
    #'
    #' @param id id
    #' @param product_id product_id
    #' @param customer_id customer_id
    #' @param nick_name nick_name
    #' @param email email
    #' @param summary summary
    #' @param message message
    #' @param rating rating
    #' @param ratings ratings
    #' @param status status
    #' @param created_time created_time
    #' @param modified_time modified_time
    #' @param medias medias
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `product_id` = NULL, `customer_id` = NULL, `nick_name` = NULL, `email` = NULL, `summary` = NULL, `message` = NULL, `rating` = NULL, `ratings` = NULL, `status` = NULL, `created_time` = NULL, `modified_time` = NULL, `medias` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`product_id`)) {
        if (!(is.character(`product_id`) && length(`product_id`) == 1)) {
          stop(paste("Error! Invalid data for `product_id`. Must be a string:", `product_id`))
        }
        self$`product_id` <- `product_id`
      }
      if (!is.null(`customer_id`)) {
        if (!(is.character(`customer_id`) && length(`customer_id`) == 1)) {
          stop(paste("Error! Invalid data for `customer_id`. Must be a string:", `customer_id`))
        }
        self$`customer_id` <- `customer_id`
      }
      if (!is.null(`nick_name`)) {
        if (!(is.character(`nick_name`) && length(`nick_name`) == 1)) {
          stop(paste("Error! Invalid data for `nick_name`. Must be a string:", `nick_name`))
        }
        self$`nick_name` <- `nick_name`
      }
      if (!is.null(`email`)) {
        if (!(is.character(`email`) && length(`email`) == 1)) {
          stop(paste("Error! Invalid data for `email`. Must be a string:", `email`))
        }
        self$`email` <- `email`
      }
      if (!is.null(`summary`)) {
        if (!(is.character(`summary`) && length(`summary`) == 1)) {
          stop(paste("Error! Invalid data for `summary`. Must be a string:", `summary`))
        }
        self$`summary` <- `summary`
      }
      if (!is.null(`message`)) {
        if (!(is.character(`message`) && length(`message`) == 1)) {
          stop(paste("Error! Invalid data for `message`. Must be a string:", `message`))
        }
        self$`message` <- `message`
      }
      if (!is.null(`rating`)) {
        self$`rating` <- `rating`
      }
      if (!is.null(`ratings`)) {
        stopifnot(is.vector(`ratings`), length(`ratings`) != 0)
        sapply(`ratings`, function(x) stopifnot(R6::is.R6(x)))
        self$`ratings` <- `ratings`
      }
      if (!is.null(`status`)) {
        if (!(is.character(`status`) && length(`status`) == 1)) {
          stop(paste("Error! Invalid data for `status`. Must be a string:", `status`))
        }
        self$`status` <- `status`
      }
      if (!is.null(`created_time`)) {
        stopifnot(R6::is.R6(`created_time`))
        self$`created_time` <- `created_time`
      }
      if (!is.null(`modified_time`)) {
        stopifnot(R6::is.R6(`modified_time`))
        self$`modified_time` <- `modified_time`
      }
      if (!is.null(`medias`)) {
        stopifnot(is.vector(`medias`), length(`medias`) != 0)
        sapply(`medias`, function(x) stopifnot(R6::is.R6(x)))
        self$`medias` <- `medias`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductReview as a base R list.
    #' @examples
    #' # convert array of ProductReview (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductReview to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductReviewObject <- list()
      if (!is.null(self$`id`)) {
        ProductReviewObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`product_id`)) {
        ProductReviewObject[["product_id"]] <-
          self$`product_id`
      }
      if (!is.null(self$`customer_id`)) {
        ProductReviewObject[["customer_id"]] <-
          self$`customer_id`
      }
      if (!is.null(self$`nick_name`)) {
        ProductReviewObject[["nick_name"]] <-
          self$`nick_name`
      }
      if (!is.null(self$`email`)) {
        ProductReviewObject[["email"]] <-
          self$`email`
      }
      if (!is.null(self$`summary`)) {
        ProductReviewObject[["summary"]] <-
          self$`summary`
      }
      if (!is.null(self$`message`)) {
        ProductReviewObject[["message"]] <-
          self$`message`
      }
      if (!is.null(self$`rating`)) {
        ProductReviewObject[["rating"]] <-
          self$`rating`
      }
      if (!is.null(self$`ratings`)) {
        ProductReviewObject[["ratings"]] <-
          lapply(self$`ratings`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`status`)) {
        ProductReviewObject[["status"]] <-
          self$`status`
      }
      if (!is.null(self$`created_time`)) {
        ProductReviewObject[["created_time"]] <-
          self$`created_time`$toSimpleType()
      }
      if (!is.null(self$`modified_time`)) {
        ProductReviewObject[["modified_time"]] <-
          self$`modified_time`$toSimpleType()
      }
      if (!is.null(self$`medias`)) {
        ProductReviewObject[["medias"]] <-
          lapply(self$`medias`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`additional_fields`)) {
        ProductReviewObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        ProductReviewObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(ProductReviewObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductReview
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductReview
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`product_id`)) {
        self$`product_id` <- this_object$`product_id`
      }
      if (!is.null(this_object$`customer_id`)) {
        self$`customer_id` <- this_object$`customer_id`
      }
      if (!is.null(this_object$`nick_name`)) {
        self$`nick_name` <- this_object$`nick_name`
      }
      if (!is.null(this_object$`email`)) {
        self$`email` <- this_object$`email`
      }
      if (!is.null(this_object$`summary`)) {
        self$`summary` <- this_object$`summary`
      }
      if (!is.null(this_object$`message`)) {
        self$`message` <- this_object$`message`
      }
      if (!is.null(this_object$`rating`)) {
        self$`rating` <- this_object$`rating`
      }
      if (!is.null(this_object$`ratings`)) {
        self$`ratings` <- ApiClient$new()$deserializeObj(this_object$`ratings`, "array[ProductReviewRating]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`status`)) {
        self$`status` <- this_object$`status`
      }
      if (!is.null(this_object$`created_time`)) {
        `created_time_object` <- A2CDateTime$new()
        `created_time_object`$fromJSON(jsonlite::toJSON(this_object$`created_time`, auto_unbox = TRUE, digits = NA))
        self$`created_time` <- `created_time_object`
      }
      if (!is.null(this_object$`modified_time`)) {
        `modified_time_object` <- A2CDateTime$new()
        `modified_time_object`$fromJSON(jsonlite::toJSON(this_object$`modified_time`, auto_unbox = TRUE, digits = NA))
        self$`modified_time` <- `modified_time_object`
      }
      if (!is.null(this_object$`medias`)) {
        self$`medias` <- ApiClient$new()$deserializeObj(this_object$`medias`, "array[Media]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductReview in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductReview
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductReview
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`product_id` <- this_object$`product_id`
      self$`customer_id` <- this_object$`customer_id`
      self$`nick_name` <- this_object$`nick_name`
      self$`email` <- this_object$`email`
      self$`summary` <- this_object$`summary`
      self$`message` <- this_object$`message`
      self$`rating` <- this_object$`rating`
      self$`ratings` <- ApiClient$new()$deserializeObj(this_object$`ratings`, "array[ProductReviewRating]", loadNamespace("openapi"))
      self$`status` <- this_object$`status`
      self$`created_time` <- A2CDateTime$new()$fromJSON(jsonlite::toJSON(this_object$`created_time`, auto_unbox = TRUE, digits = NA))
      self$`modified_time` <- A2CDateTime$new()$fromJSON(jsonlite::toJSON(this_object$`modified_time`, auto_unbox = TRUE, digits = NA))
      self$`medias` <- ApiClient$new()$deserializeObj(this_object$`medias`, "array[Media]", loadNamespace("openapi"))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductReview and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductReview
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductReview$unlock()
#
## Below is an example to define the print function
# ProductReview$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductReview$lock()

