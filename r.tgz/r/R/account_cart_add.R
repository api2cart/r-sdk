#' Create a new AccountCartAdd
#'
#' @description
#' AccountCartAdd Class
#'
#' @docType class
#' @title AccountCartAdd
#' @description AccountCartAdd Class
#' @format An \code{R6Class} generator object
#' @field cart_id Store’s identifier which you can get from cart_list method character
#' @field store_url A web address of a store that you would like to connect to API2Cart character [optional]
#' @field bridge_url This parameter allows to set up store with custom bridge url (also you must use store_root parameter if a bridge folder is not in the root folder of the store) character [optional]
#' @field store_root Absolute path to the store root directory (used with \"bridge_url\" parameter) character [optional]
#' @field store_key Set this parameter if bridge is already uploaded to store character [optional]
#' @field label Defines alternative text that has to be attached to the picture character [optional]
#' @field custom_label Defines a custom label for the store in the app character [optional]
#' @field validate_version Specify if api2cart should validate cart version character [optional]
#' @field verify Enables or disables cart's verification character [optional]
#' @field db_tables_prefix DB tables prefix character [optional]
#' @field user_agent This parameter allows you to set your custom user agent, which will be used in requests to the store. Please use it cautiously, as the store's firewall may block specific values. character [optional]
#' @field ftp_host FTP connection host character [optional]
#' @field ftp_user FTP User character [optional]
#' @field ftp_password FTP Password character [optional]
#' @field ftp_port FTP Port integer [optional]
#' @field ftp_store_dir FTP Store dir character [optional]
#' @field 3dcart_private_key 3DCart Private Key character [optional]
#' @field 3dcart_access_token 3DCart Token character [optional]
#' @field 3dcartapi_api_key 3DCart API Key character [optional]
#' @field amazon_sp_client_id Amazon SP API app client id character [optional]
#' @field amazon_sp_client_secret Amazon SP API app client secret character [optional]
#' @field amazon_sp_refresh_token Amazon SP API OAuth refresh token character [optional]
#' @field amazon_sp_aws_region Amazon AWS Region character [optional]
#' @field amazon_sp_api_environment Amazon SP API environment character [optional]
#' @field amazon_seller_id Amazon Seller ID (Merchant token) character [optional]
#' @field aspdotnetstorefront_api_user It's a AspDotNetStorefront account for which API is available character [optional]
#' @field aspdotnetstorefront_api_pass AspDotNetStorefront API Password character [optional]
#' @field americommerce_app_id Americommerce App ID character [optional]
#' @field americommerce_app_secret Americommerce App Secret character [optional]
#' @field americommerce_access_token Americommerce Access Token character [optional]
#' @field americommerce_refresh_token Americommerce Refresh Token character [optional]
#' @field bigcommerceapi_admin_account It's a BigCommerce account for which API is enabled character [optional]
#' @field bigcommerceapi_api_path BigCommerce API URL character [optional]
#' @field bigcommerceapi_api_key Bigcommerce API Key character [optional]
#' @field bigcommerceapi_client_id Client ID of the requesting app character [optional]
#' @field bigcommerceapi_access_token Access token authorizing the app to access resources on behalf of a user character [optional]
#' @field bigcommerceapi_context API Path section unique to the store character [optional]
#' @field bol_api_key Bol API Key character [optional]
#' @field bol_api_secret Bol API Secret character [optional]
#' @field bol_retailer_id Bol Retailer ID integer [optional]
#' @field bigcartel_user_name Subdomain of store character [optional]
#' @field bigcartel_password BigCartel account password character [optional]
#' @field bricklink_consumer_key Bricklink Consumer Key character [optional]
#' @field bricklink_consumer_secret Bricklink Consumer Secret character [optional]
#' @field bricklink_token Bricklink Access Token character [optional]
#' @field bricklink_token_secret Bricklink Access Token Secret character [optional]
#' @field demandware_client_id Demandware client id character [optional]
#' @field demandware_api_password Demandware api password character [optional]
#' @field demandware_user_name Demandware user name character [optional]
#' @field demandware_user_password Demandware user password character [optional]
#' @field ebay_client_id Application ID (AppID). character [optional]
#' @field ebay_client_secret Shared Secret from eBay application character [optional]
#' @field ebay_runame The RuName value that eBay assigns to your application. character [optional]
#' @field ebay_access_token Used to authenticate API requests. character [optional]
#' @field ebay_refresh_token Used to renew the access token. character [optional]
#' @field ebay_environment eBay environment character [optional]
#' @field ebay_site_id eBay global ID integer [optional]
#' @field walmart_client_id Walmart client ID. For the region 'ca' use Consumer ID character [optional]
#' @field walmart_client_secret Walmart client secret. For the region 'ca' use Private Key character [optional]
#' @field walmart_environment Walmart environment character [optional]
#' @field walmart_channel_type Walmart WM_CONSUMER.CHANNEL.TYPE header character [optional]
#' @field walmart_region Walmart region character [optional]
#' @field ecwid_acess_token Access token authorizing the app to access resources on behalf of a user character [optional]
#' @field ecwid_store_id Store Id character [optional]
#' @field lazada_app_id Lazada App ID character [optional]
#' @field lazada_app_secret Lazada App Secret character [optional]
#' @field lazada_refresh_token Lazada Refresh Token character [optional]
#' @field lazada_region Lazada API endpoint Region character [optional]
#' @field lightspeed_api_key LightSpeed api key character [optional]
#' @field lightspeed_api_secret LightSpeed api secret character [optional]
#' @field etsy_keystring Etsy keystring character [optional]
#' @field etsy_shared_secret Etsy shared secret character [optional]
#' @field etsy_access_token Access token authorizing the app to access resources on behalf of a user character [optional]
#' @field etsy_token_secret Secret token authorizing the app to access resources on behalf of a user character [optional]
#' @field etsy_client_id Etsy Client Id character [optional]
#' @field etsy_refresh_token Etsy Refresh token character [optional]
#' @field facebook_app_id Facebook App ID character [optional]
#' @field facebook_app_secret Facebook App Secret character [optional]
#' @field facebook_access_token Facebook Access Token character [optional]
#' @field facebook_business_id Facebook Business ID character [optional]
#' @field neto_api_key Neto API Key character [optional]
#' @field neto_api_username Neto User Name character [optional]
#' @field shopline_access_token Shopline APP Key character [optional]
#' @field shopline_app_key Shopline APP Key character [optional]
#' @field shopline_app_secret Shopline App Secret character [optional]
#' @field shopline_shared_secret Shopline Shared Secret character [optional]
#' @field shopify_access_token Access token authorizing the app to access resources on behalf of a user character [optional]
#' @field shopify_client_id Shopify Client ID character [optional]
#' @field shopify_api_key Shopify API Key character [optional]
#' @field shopify_api_password Shopify API Password character [optional]
#' @field shopify_shared_secret Shared secret character [optional]
#' @field shopee_partner_id Shopee Partner ID character [optional]
#' @field shopee_partner_key Shopee Partner Key character [optional]
#' @field shopee_shop_id Shopee SHOP ID character [optional]
#' @field shopee_refresh_token Shopee Refresh Token character [optional]
#' @field shopee_region Shopee API endpoint Region. Use for Chinese Mainland or Brazil. character [optional]
#' @field shopee_environment Shopee Environment character [optional]
#' @field shoplazza_access_token Access token authorizing the app to access resources on behalf of a user character [optional]
#' @field shoplazza_shared_secret Shared secret character [optional]
#' @field shopware_access_key Shopware access key character [optional]
#' @field unas_api_key UNAS API Key character [optional]
#' @field shopware_api_key Shopware api key character [optional]
#' @field shopware_api_secret Shopware client secret access key character [optional]
#' @field miva_access_token Miva access token character [optional]
#' @field miva_signature Miva signature character [optional]
#' @field tiendanube_user_id Tiendanube User ID integer [optional]
#' @field tiendanube_access_token Tiendanube Access Token character [optional]
#' @field tiendanube_client_secret Tiendanube Client Secret character [optional]
#' @field volusion_login It's a Volusion account for which API is enabled character [optional]
#' @field volusion_password Volusion API Password character [optional]
#' @field hybris_client_id Omni Commerce Connector Client ID character [optional]
#' @field hybris_client_secret Omni Commerce Connector Client Secret character [optional]
#' @field hybris_username User Name character [optional]
#' @field hybris_password User password character [optional]
#' @field hybris_websites Websites to stores mapping data list(\link{AccountCartAddHybrisWebsitesInner}) [optional]
#' @field square_client_id Square (Weebly) Client ID character [optional]
#' @field square_client_secret Square (Weebly) Client Secret character [optional]
#' @field square_refresh_token Square (Weebly) Refresh Token character [optional]
#' @field squarespace_api_key Squarespace API Key character [optional]
#' @field squarespace_client_id Squarespace Connector Client ID character [optional]
#' @field squarespace_client_secret Squarespace Connector Client Secret character [optional]
#' @field squarespace_access_token Squarespace access token character [optional]
#' @field squarespace_refresh_token Squarespace refresh token character [optional]
#' @field commercehq_api_key CommerceHQ api key character [optional]
#' @field commercehq_api_password CommerceHQ api password character [optional]
#' @field wc_consumer_key Woocommerce consumer key character [optional]
#' @field wc_consumer_secret Woocommerce consumer secret character [optional]
#' @field magento_consumer_key Magento Consumer Key character [optional]
#' @field magento_consumer_secret Magento Consumer Secret character [optional]
#' @field magento_access_token Magento Access Token character [optional]
#' @field magento_token_secret Magento Token Secret character [optional]
#' @field prestashop_webservice_key Prestashop webservice key character [optional]
#' @field wix_app_id Wix App ID character [optional]
#' @field wix_app_secret_key Wix App Secret Key character [optional]
#' @field wix_instance_id Wix Instance ID character [optional]
#' @field wix_refresh_token Wix refresh token character [optional]
#' @field mercado_libre_app_id Mercado Libre App ID character [optional]
#' @field mercado_libre_app_secret_key Mercado Libre App Secret Key character [optional]
#' @field mercado_libre_refresh_token Mercado Libre Refresh Token character [optional]
#' @field zid_client_id Zid Client ID integer [optional]
#' @field zid_client_secret Zid Client Secret character [optional]
#' @field zid_access_token Zid Access Token character [optional]
#' @field zid_authorization Zid Authorization character [optional]
#' @field zid_refresh_token Zid refresh token character [optional]
#' @field jumpseller_client_id Jumpseller OAuth2 Client ID character [optional]
#' @field jumpseller_client_secret Jumpseller OAuth2 Client Secret character [optional]
#' @field jumpseller_refresh_token Jumpseller OAuth2 refresh token character [optional]
#' @field jumpseller_login Jumpseller API login character [optional]
#' @field jumpseller_authtoken Jumpseller API auth token character [optional]
#' @field flipkart_client_id Flipkart Client ID character [optional]
#' @field flipkart_client_secret Flipkart Client Secret character [optional]
#' @field allegro_client_id Allegro Client ID character [optional]
#' @field allegro_client_secret Allegro Client Secret character [optional]
#' @field allegro_access_token Allegro Access Token character [optional]
#' @field allegro_refresh_token Allegro Refresh Token character [optional]
#' @field allegro_environment Allegro Environment character [optional]
#' @field zoho_client_id Zoho Client ID character [optional]
#' @field zoho_client_secret Zoho Client Secret character [optional]
#' @field zoho_refresh_token Zoho Refresh Token character [optional]
#' @field zoho_region Zoho API endpoint Region character [optional]
#' @field otto_client_id Otto Client ID character [optional]
#' @field otto_client_secret Otto Client Secret character [optional]
#' @field otto_app_id Otto App ID character [optional]
#' @field otto_refresh_token Otto Refresh Token character [optional]
#' @field otto_environment Otto Environment character [optional]
#' @field otto_access_token Otto Access Token character [optional]
#' @field tiktokshop_app_key TikTok Shop App Key character [optional]
#' @field tiktokshop_app_secret TikTok Shop App Secret character [optional]
#' @field tiktokshop_refresh_token TikTok Shop Refresh Token character [optional]
#' @field tiktokshop_access_token TikTok Shop Access Token character [optional]
#' @field salla_client_id Salla Client ID character [optional]
#' @field salla_client_secret Salla Client Secret character [optional]
#' @field salla_refresh_token Salla Refresh Token character [optional]
#' @field salla_access_token Salla Access Token character [optional]
#' @field temu_app_key Temu App Key character [optional]
#' @field temu_app_secret Temu App Secret character [optional]
#' @field temu_access_token Temu Access Token character [optional]
#' @field temu_region Temu API endpoint Region. character [optional]
#' @field scapi_client_id Salesforce Commerce API Client ID character [optional]
#' @field scapi_client_secret Salesforce Commerce API Client Secret character [optional]
#' @field scapi_organization_id Salesforce Commerce Organization ID character [optional]
#' @field scapi_short_code Salesforce Commerce Short Code character [optional]
#' @field scapi_scopes Salesforce Commerce API Scopes character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
AccountCartAdd <- R6::R6Class(
  "AccountCartAdd",
  public = list(
    `cart_id` = NULL,
    `store_url` = NULL,
    `bridge_url` = NULL,
    `store_root` = NULL,
    `store_key` = NULL,
    `label` = NULL,
    `custom_label` = NULL,
    `validate_version` = NULL,
    `verify` = NULL,
    `db_tables_prefix` = NULL,
    `user_agent` = NULL,
    `ftp_host` = NULL,
    `ftp_user` = NULL,
    `ftp_password` = NULL,
    `ftp_port` = NULL,
    `ftp_store_dir` = NULL,
    `3dcart_private_key` = NULL,
    `3dcart_access_token` = NULL,
    `3dcartapi_api_key` = NULL,
    `amazon_sp_client_id` = NULL,
    `amazon_sp_client_secret` = NULL,
    `amazon_sp_refresh_token` = NULL,
    `amazon_sp_aws_region` = NULL,
    `amazon_sp_api_environment` = NULL,
    `amazon_seller_id` = NULL,
    `aspdotnetstorefront_api_user` = NULL,
    `aspdotnetstorefront_api_pass` = NULL,
    `americommerce_app_id` = NULL,
    `americommerce_app_secret` = NULL,
    `americommerce_access_token` = NULL,
    `americommerce_refresh_token` = NULL,
    `bigcommerceapi_admin_account` = NULL,
    `bigcommerceapi_api_path` = NULL,
    `bigcommerceapi_api_key` = NULL,
    `bigcommerceapi_client_id` = NULL,
    `bigcommerceapi_access_token` = NULL,
    `bigcommerceapi_context` = NULL,
    `bol_api_key` = NULL,
    `bol_api_secret` = NULL,
    `bol_retailer_id` = NULL,
    `bigcartel_user_name` = NULL,
    `bigcartel_password` = NULL,
    `bricklink_consumer_key` = NULL,
    `bricklink_consumer_secret` = NULL,
    `bricklink_token` = NULL,
    `bricklink_token_secret` = NULL,
    `demandware_client_id` = NULL,
    `demandware_api_password` = NULL,
    `demandware_user_name` = NULL,
    `demandware_user_password` = NULL,
    `ebay_client_id` = NULL,
    `ebay_client_secret` = NULL,
    `ebay_runame` = NULL,
    `ebay_access_token` = NULL,
    `ebay_refresh_token` = NULL,
    `ebay_environment` = NULL,
    `ebay_site_id` = NULL,
    `walmart_client_id` = NULL,
    `walmart_client_secret` = NULL,
    `walmart_environment` = NULL,
    `walmart_channel_type` = NULL,
    `walmart_region` = NULL,
    `ecwid_acess_token` = NULL,
    `ecwid_store_id` = NULL,
    `lazada_app_id` = NULL,
    `lazada_app_secret` = NULL,
    `lazada_refresh_token` = NULL,
    `lazada_region` = NULL,
    `lightspeed_api_key` = NULL,
    `lightspeed_api_secret` = NULL,
    `etsy_keystring` = NULL,
    `etsy_shared_secret` = NULL,
    `etsy_access_token` = NULL,
    `etsy_token_secret` = NULL,
    `etsy_client_id` = NULL,
    `etsy_refresh_token` = NULL,
    `facebook_app_id` = NULL,
    `facebook_app_secret` = NULL,
    `facebook_access_token` = NULL,
    `facebook_business_id` = NULL,
    `neto_api_key` = NULL,
    `neto_api_username` = NULL,
    `shopline_access_token` = NULL,
    `shopline_app_key` = NULL,
    `shopline_app_secret` = NULL,
    `shopline_shared_secret` = NULL,
    `shopify_access_token` = NULL,
    `shopify_client_id` = NULL,
    `shopify_api_key` = NULL,
    `shopify_api_password` = NULL,
    `shopify_shared_secret` = NULL,
    `shopee_partner_id` = NULL,
    `shopee_partner_key` = NULL,
    `shopee_shop_id` = NULL,
    `shopee_refresh_token` = NULL,
    `shopee_region` = NULL,
    `shopee_environment` = NULL,
    `shoplazza_access_token` = NULL,
    `shoplazza_shared_secret` = NULL,
    `shopware_access_key` = NULL,
    `unas_api_key` = NULL,
    `shopware_api_key` = NULL,
    `shopware_api_secret` = NULL,
    `miva_access_token` = NULL,
    `miva_signature` = NULL,
    `tiendanube_user_id` = NULL,
    `tiendanube_access_token` = NULL,
    `tiendanube_client_secret` = NULL,
    `volusion_login` = NULL,
    `volusion_password` = NULL,
    `hybris_client_id` = NULL,
    `hybris_client_secret` = NULL,
    `hybris_username` = NULL,
    `hybris_password` = NULL,
    `hybris_websites` = NULL,
    `square_client_id` = NULL,
    `square_client_secret` = NULL,
    `square_refresh_token` = NULL,
    `squarespace_api_key` = NULL,
    `squarespace_client_id` = NULL,
    `squarespace_client_secret` = NULL,
    `squarespace_access_token` = NULL,
    `squarespace_refresh_token` = NULL,
    `commercehq_api_key` = NULL,
    `commercehq_api_password` = NULL,
    `wc_consumer_key` = NULL,
    `wc_consumer_secret` = NULL,
    `magento_consumer_key` = NULL,
    `magento_consumer_secret` = NULL,
    `magento_access_token` = NULL,
    `magento_token_secret` = NULL,
    `prestashop_webservice_key` = NULL,
    `wix_app_id` = NULL,
    `wix_app_secret_key` = NULL,
    `wix_instance_id` = NULL,
    `wix_refresh_token` = NULL,
    `mercado_libre_app_id` = NULL,
    `mercado_libre_app_secret_key` = NULL,
    `mercado_libre_refresh_token` = NULL,
    `zid_client_id` = NULL,
    `zid_client_secret` = NULL,
    `zid_access_token` = NULL,
    `zid_authorization` = NULL,
    `zid_refresh_token` = NULL,
    `jumpseller_client_id` = NULL,
    `jumpseller_client_secret` = NULL,
    `jumpseller_refresh_token` = NULL,
    `jumpseller_login` = NULL,
    `jumpseller_authtoken` = NULL,
    `flipkart_client_id` = NULL,
    `flipkart_client_secret` = NULL,
    `allegro_client_id` = NULL,
    `allegro_client_secret` = NULL,
    `allegro_access_token` = NULL,
    `allegro_refresh_token` = NULL,
    `allegro_environment` = NULL,
    `zoho_client_id` = NULL,
    `zoho_client_secret` = NULL,
    `zoho_refresh_token` = NULL,
    `zoho_region` = NULL,
    `otto_client_id` = NULL,
    `otto_client_secret` = NULL,
    `otto_app_id` = NULL,
    `otto_refresh_token` = NULL,
    `otto_environment` = NULL,
    `otto_access_token` = NULL,
    `tiktokshop_app_key` = NULL,
    `tiktokshop_app_secret` = NULL,
    `tiktokshop_refresh_token` = NULL,
    `tiktokshop_access_token` = NULL,
    `salla_client_id` = NULL,
    `salla_client_secret` = NULL,
    `salla_refresh_token` = NULL,
    `salla_access_token` = NULL,
    `temu_app_key` = NULL,
    `temu_app_secret` = NULL,
    `temu_access_token` = NULL,
    `temu_region` = NULL,
    `scapi_client_id` = NULL,
    `scapi_client_secret` = NULL,
    `scapi_organization_id` = NULL,
    `scapi_short_code` = NULL,
    `scapi_scopes` = NULL,

    #' @description
    #' Initialize a new AccountCartAdd class.
    #'
    #' @param cart_id Store’s identifier which you can get from cart_list method
    #' @param store_url A web address of a store that you would like to connect to API2Cart
    #' @param bridge_url This parameter allows to set up store with custom bridge url (also you must use store_root parameter if a bridge folder is not in the root folder of the store)
    #' @param store_root Absolute path to the store root directory (used with \"bridge_url\" parameter)
    #' @param store_key Set this parameter if bridge is already uploaded to store
    #' @param label Defines alternative text that has to be attached to the picture
    #' @param custom_label Defines a custom label for the store in the app
    #' @param validate_version Specify if api2cart should validate cart version. Default to FALSE.
    #' @param verify Enables or disables cart's verification. Default to TRUE.
    #' @param db_tables_prefix DB tables prefix
    #' @param user_agent This parameter allows you to set your custom user agent, which will be used in requests to the store. Please use it cautiously, as the store's firewall may block specific values.
    #' @param ftp_host FTP connection host
    #' @param ftp_user FTP User
    #' @param ftp_password FTP Password
    #' @param ftp_port FTP Port
    #' @param ftp_store_dir FTP Store dir
    #' @param 3dcart_private_key 3DCart Private Key
    #' @param 3dcart_access_token 3DCart Token
    #' @param 3dcartapi_api_key 3DCart API Key
    #' @param amazon_sp_client_id Amazon SP API app client id
    #' @param amazon_sp_client_secret Amazon SP API app client secret
    #' @param amazon_sp_refresh_token Amazon SP API OAuth refresh token
    #' @param amazon_sp_aws_region Amazon AWS Region
    #' @param amazon_sp_api_environment Amazon SP API environment. Default to "production".
    #' @param amazon_seller_id Amazon Seller ID (Merchant token)
    #' @param aspdotnetstorefront_api_user It's a AspDotNetStorefront account for which API is available
    #' @param aspdotnetstorefront_api_pass AspDotNetStorefront API Password
    #' @param americommerce_app_id Americommerce App ID
    #' @param americommerce_app_secret Americommerce App Secret
    #' @param americommerce_access_token Americommerce Access Token
    #' @param americommerce_refresh_token Americommerce Refresh Token
    #' @param bigcommerceapi_admin_account It's a BigCommerce account for which API is enabled
    #' @param bigcommerceapi_api_path BigCommerce API URL
    #' @param bigcommerceapi_api_key Bigcommerce API Key
    #' @param bigcommerceapi_client_id Client ID of the requesting app
    #' @param bigcommerceapi_access_token Access token authorizing the app to access resources on behalf of a user
    #' @param bigcommerceapi_context API Path section unique to the store
    #' @param bol_api_key Bol API Key
    #' @param bol_api_secret Bol API Secret
    #' @param bol_retailer_id Bol Retailer ID
    #' @param bigcartel_user_name Subdomain of store
    #' @param bigcartel_password BigCartel account password
    #' @param bricklink_consumer_key Bricklink Consumer Key
    #' @param bricklink_consumer_secret Bricklink Consumer Secret
    #' @param bricklink_token Bricklink Access Token
    #' @param bricklink_token_secret Bricklink Access Token Secret
    #' @param demandware_client_id Demandware client id
    #' @param demandware_api_password Demandware api password
    #' @param demandware_user_name Demandware user name
    #' @param demandware_user_password Demandware user password
    #' @param ebay_client_id Application ID (AppID).
    #' @param ebay_client_secret Shared Secret from eBay application
    #' @param ebay_runame The RuName value that eBay assigns to your application.
    #' @param ebay_access_token Used to authenticate API requests.
    #' @param ebay_refresh_token Used to renew the access token.
    #' @param ebay_environment eBay environment. Default to "production".
    #' @param ebay_site_id eBay global ID. Default to 0.
    #' @param walmart_client_id Walmart client ID. For the region 'ca' use Consumer ID
    #' @param walmart_client_secret Walmart client secret. For the region 'ca' use Private Key
    #' @param walmart_environment Walmart environment. Default to "production".
    #' @param walmart_channel_type Walmart WM_CONSUMER.CHANNEL.TYPE header
    #' @param walmart_region Walmart region. Default to "us".
    #' @param ecwid_acess_token Access token authorizing the app to access resources on behalf of a user
    #' @param ecwid_store_id Store Id
    #' @param lazada_app_id Lazada App ID
    #' @param lazada_app_secret Lazada App Secret
    #' @param lazada_refresh_token Lazada Refresh Token
    #' @param lazada_region Lazada API endpoint Region
    #' @param lightspeed_api_key LightSpeed api key
    #' @param lightspeed_api_secret LightSpeed api secret
    #' @param etsy_keystring Etsy keystring
    #' @param etsy_shared_secret Etsy shared secret
    #' @param etsy_access_token Access token authorizing the app to access resources on behalf of a user
    #' @param etsy_token_secret Secret token authorizing the app to access resources on behalf of a user
    #' @param etsy_client_id Etsy Client Id
    #' @param etsy_refresh_token Etsy Refresh token
    #' @param facebook_app_id Facebook App ID
    #' @param facebook_app_secret Facebook App Secret
    #' @param facebook_access_token Facebook Access Token
    #' @param facebook_business_id Facebook Business ID
    #' @param neto_api_key Neto API Key
    #' @param neto_api_username Neto User Name
    #' @param shopline_access_token Shopline APP Key
    #' @param shopline_app_key Shopline APP Key
    #' @param shopline_app_secret Shopline App Secret
    #' @param shopline_shared_secret Shopline Shared Secret
    #' @param shopify_access_token Access token authorizing the app to access resources on behalf of a user
    #' @param shopify_client_id Shopify Client ID
    #' @param shopify_api_key Shopify API Key
    #' @param shopify_api_password Shopify API Password
    #' @param shopify_shared_secret Shared secret
    #' @param shopee_partner_id Shopee Partner ID
    #' @param shopee_partner_key Shopee Partner Key
    #' @param shopee_shop_id Shopee SHOP ID
    #' @param shopee_refresh_token Shopee Refresh Token
    #' @param shopee_region Shopee API endpoint Region. Use for Chinese Mainland or Brazil.
    #' @param shopee_environment Shopee Environment. Default to "production".
    #' @param shoplazza_access_token Access token authorizing the app to access resources on behalf of a user
    #' @param shoplazza_shared_secret Shared secret
    #' @param shopware_access_key Shopware access key
    #' @param unas_api_key UNAS API Key
    #' @param shopware_api_key Shopware api key
    #' @param shopware_api_secret Shopware client secret access key
    #' @param miva_access_token Miva access token
    #' @param miva_signature Miva signature
    #' @param tiendanube_user_id Tiendanube User ID
    #' @param tiendanube_access_token Tiendanube Access Token
    #' @param tiendanube_client_secret Tiendanube Client Secret
    #' @param volusion_login It's a Volusion account for which API is enabled
    #' @param volusion_password Volusion API Password
    #' @param hybris_client_id Omni Commerce Connector Client ID
    #' @param hybris_client_secret Omni Commerce Connector Client Secret
    #' @param hybris_username User Name
    #' @param hybris_password User password
    #' @param hybris_websites Websites to stores mapping data
    #' @param square_client_id Square (Weebly) Client ID
    #' @param square_client_secret Square (Weebly) Client Secret
    #' @param square_refresh_token Square (Weebly) Refresh Token
    #' @param squarespace_api_key Squarespace API Key
    #' @param squarespace_client_id Squarespace Connector Client ID
    #' @param squarespace_client_secret Squarespace Connector Client Secret
    #' @param squarespace_access_token Squarespace access token
    #' @param squarespace_refresh_token Squarespace refresh token
    #' @param commercehq_api_key CommerceHQ api key
    #' @param commercehq_api_password CommerceHQ api password
    #' @param wc_consumer_key Woocommerce consumer key
    #' @param wc_consumer_secret Woocommerce consumer secret
    #' @param magento_consumer_key Magento Consumer Key
    #' @param magento_consumer_secret Magento Consumer Secret
    #' @param magento_access_token Magento Access Token
    #' @param magento_token_secret Magento Token Secret
    #' @param prestashop_webservice_key Prestashop webservice key
    #' @param wix_app_id Wix App ID
    #' @param wix_app_secret_key Wix App Secret Key
    #' @param wix_instance_id Wix Instance ID
    #' @param wix_refresh_token Wix refresh token
    #' @param mercado_libre_app_id Mercado Libre App ID
    #' @param mercado_libre_app_secret_key Mercado Libre App Secret Key
    #' @param mercado_libre_refresh_token Mercado Libre Refresh Token
    #' @param zid_client_id Zid Client ID
    #' @param zid_client_secret Zid Client Secret
    #' @param zid_access_token Zid Access Token
    #' @param zid_authorization Zid Authorization
    #' @param zid_refresh_token Zid refresh token
    #' @param jumpseller_client_id Jumpseller OAuth2 Client ID
    #' @param jumpseller_client_secret Jumpseller OAuth2 Client Secret
    #' @param jumpseller_refresh_token Jumpseller OAuth2 refresh token
    #' @param jumpseller_login Jumpseller API login
    #' @param jumpseller_authtoken Jumpseller API auth token
    #' @param flipkart_client_id Flipkart Client ID
    #' @param flipkart_client_secret Flipkart Client Secret
    #' @param allegro_client_id Allegro Client ID
    #' @param allegro_client_secret Allegro Client Secret
    #' @param allegro_access_token Allegro Access Token
    #' @param allegro_refresh_token Allegro Refresh Token
    #' @param allegro_environment Allegro Environment. Default to "production".
    #' @param zoho_client_id Zoho Client ID
    #' @param zoho_client_secret Zoho Client Secret
    #' @param zoho_refresh_token Zoho Refresh Token
    #' @param zoho_region Zoho API endpoint Region
    #' @param otto_client_id Otto Client ID
    #' @param otto_client_secret Otto Client Secret
    #' @param otto_app_id Otto App ID
    #' @param otto_refresh_token Otto Refresh Token
    #' @param otto_environment Otto Environment. Default to "production".
    #' @param otto_access_token Otto Access Token
    #' @param tiktokshop_app_key TikTok Shop App Key
    #' @param tiktokshop_app_secret TikTok Shop App Secret
    #' @param tiktokshop_refresh_token TikTok Shop Refresh Token
    #' @param tiktokshop_access_token TikTok Shop Access Token
    #' @param salla_client_id Salla Client ID
    #' @param salla_client_secret Salla Client Secret
    #' @param salla_refresh_token Salla Refresh Token
    #' @param salla_access_token Salla Access Token
    #' @param temu_app_key Temu App Key
    #' @param temu_app_secret Temu App Secret
    #' @param temu_access_token Temu Access Token
    #' @param temu_region Temu API endpoint Region.
    #' @param scapi_client_id Salesforce Commerce API Client ID
    #' @param scapi_client_secret Salesforce Commerce API Client Secret
    #' @param scapi_organization_id Salesforce Commerce Organization ID
    #' @param scapi_short_code Salesforce Commerce Short Code
    #' @param scapi_scopes Salesforce Commerce API Scopes
    #' @param ... Other optional arguments.
    initialize = function(`cart_id`, `store_url` = NULL, `bridge_url` = NULL, `store_root` = NULL, `store_key` = NULL, `label` = NULL, `custom_label` = NULL, `validate_version` = FALSE, `verify` = TRUE, `db_tables_prefix` = NULL, `user_agent` = NULL, `ftp_host` = NULL, `ftp_user` = NULL, `ftp_password` = NULL, `ftp_port` = NULL, `ftp_store_dir` = NULL, `3dcart_private_key` = NULL, `3dcart_access_token` = NULL, `3dcartapi_api_key` = NULL, `amazon_sp_client_id` = NULL, `amazon_sp_client_secret` = NULL, `amazon_sp_refresh_token` = NULL, `amazon_sp_aws_region` = NULL, `amazon_sp_api_environment` = "production", `amazon_seller_id` = NULL, `aspdotnetstorefront_api_user` = NULL, `aspdotnetstorefront_api_pass` = NULL, `americommerce_app_id` = NULL, `americommerce_app_secret` = NULL, `americommerce_access_token` = NULL, `americommerce_refresh_token` = NULL, `bigcommerceapi_admin_account` = NULL, `bigcommerceapi_api_path` = NULL, `bigcommerceapi_api_key` = NULL, `bigcommerceapi_client_id` = NULL, `bigcommerceapi_access_token` = NULL, `bigcommerceapi_context` = NULL, `bol_api_key` = NULL, `bol_api_secret` = NULL, `bol_retailer_id` = NULL, `bigcartel_user_name` = NULL, `bigcartel_password` = NULL, `bricklink_consumer_key` = NULL, `bricklink_consumer_secret` = NULL, `bricklink_token` = NULL, `bricklink_token_secret` = NULL, `demandware_client_id` = NULL, `demandware_api_password` = NULL, `demandware_user_name` = NULL, `demandware_user_password` = NULL, `ebay_client_id` = NULL, `ebay_client_secret` = NULL, `ebay_runame` = NULL, `ebay_access_token` = NULL, `ebay_refresh_token` = NULL, `ebay_environment` = "production", `ebay_site_id` = 0, `walmart_client_id` = NULL, `walmart_client_secret` = NULL, `walmart_environment` = "production", `walmart_channel_type` = NULL, `walmart_region` = "us", `ecwid_acess_token` = NULL, `ecwid_store_id` = NULL, `lazada_app_id` = NULL, `lazada_app_secret` = NULL, `lazada_refresh_token` = NULL, `lazada_region` = NULL, `lightspeed_api_key` = NULL, `lightspeed_api_secret` = NULL, `etsy_keystring` = NULL, `etsy_shared_secret` = NULL, `etsy_access_token` = NULL, `etsy_token_secret` = NULL, `etsy_client_id` = NULL, `etsy_refresh_token` = NULL, `facebook_app_id` = NULL, `facebook_app_secret` = NULL, `facebook_access_token` = NULL, `facebook_business_id` = NULL, `neto_api_key` = NULL, `neto_api_username` = NULL, `shopline_access_token` = NULL, `shopline_app_key` = NULL, `shopline_app_secret` = NULL, `shopline_shared_secret` = NULL, `shopify_access_token` = NULL, `shopify_client_id` = NULL, `shopify_api_key` = NULL, `shopify_api_password` = NULL, `shopify_shared_secret` = NULL, `shopee_partner_id` = NULL, `shopee_partner_key` = NULL, `shopee_shop_id` = NULL, `shopee_refresh_token` = NULL, `shopee_region` = NULL, `shopee_environment` = "production", `shoplazza_access_token` = NULL, `shoplazza_shared_secret` = NULL, `shopware_access_key` = NULL, `unas_api_key` = NULL, `shopware_api_key` = NULL, `shopware_api_secret` = NULL, `miva_access_token` = NULL, `miva_signature` = NULL, `tiendanube_user_id` = NULL, `tiendanube_access_token` = NULL, `tiendanube_client_secret` = NULL, `volusion_login` = NULL, `volusion_password` = NULL, `hybris_client_id` = NULL, `hybris_client_secret` = NULL, `hybris_username` = NULL, `hybris_password` = NULL, `hybris_websites` = NULL, `square_client_id` = NULL, `square_client_secret` = NULL, `square_refresh_token` = NULL, `squarespace_api_key` = NULL, `squarespace_client_id` = NULL, `squarespace_client_secret` = NULL, `squarespace_access_token` = NULL, `squarespace_refresh_token` = NULL, `commercehq_api_key` = NULL, `commercehq_api_password` = NULL, `wc_consumer_key` = NULL, `wc_consumer_secret` = NULL, `magento_consumer_key` = NULL, `magento_consumer_secret` = NULL, `magento_access_token` = NULL, `magento_token_secret` = NULL, `prestashop_webservice_key` = NULL, `wix_app_id` = NULL, `wix_app_secret_key` = NULL, `wix_instance_id` = NULL, `wix_refresh_token` = NULL, `mercado_libre_app_id` = NULL, `mercado_libre_app_secret_key` = NULL, `mercado_libre_refresh_token` = NULL, `zid_client_id` = NULL, `zid_client_secret` = NULL, `zid_access_token` = NULL, `zid_authorization` = NULL, `zid_refresh_token` = NULL, `jumpseller_client_id` = NULL, `jumpseller_client_secret` = NULL, `jumpseller_refresh_token` = NULL, `jumpseller_login` = NULL, `jumpseller_authtoken` = NULL, `flipkart_client_id` = NULL, `flipkart_client_secret` = NULL, `allegro_client_id` = NULL, `allegro_client_secret` = NULL, `allegro_access_token` = NULL, `allegro_refresh_token` = NULL, `allegro_environment` = "production", `zoho_client_id` = NULL, `zoho_client_secret` = NULL, `zoho_refresh_token` = NULL, `zoho_region` = NULL, `otto_client_id` = NULL, `otto_client_secret` = NULL, `otto_app_id` = NULL, `otto_refresh_token` = NULL, `otto_environment` = "production", `otto_access_token` = NULL, `tiktokshop_app_key` = NULL, `tiktokshop_app_secret` = NULL, `tiktokshop_refresh_token` = NULL, `tiktokshop_access_token` = NULL, `salla_client_id` = NULL, `salla_client_secret` = NULL, `salla_refresh_token` = NULL, `salla_access_token` = NULL, `temu_app_key` = NULL, `temu_app_secret` = NULL, `temu_access_token` = NULL, `temu_region` = NULL, `scapi_client_id` = NULL, `scapi_client_secret` = NULL, `scapi_organization_id` = NULL, `scapi_short_code` = NULL, `scapi_scopes` = NULL, ...) {
      if (!missing(`cart_id`)) {
        if (!(`cart_id` %in% c("3DCart", "3DCartApi", "AceShop", "AmazonSP", "Americommerce", "AspDotNetStorefront", "BigCartel", "Bricklink", "BigcommerceApi", "Bol", "CommerceHQ", "Creloaded", "Cscart", "Cubecart", "Demandware", "EBay", "Ecwid", "EtsyAPIv3", "Facebook", "Flipkart", "Gambio", "Hybris", "JooCart", "Jumpseller", "Lazada", "LightSpeed", "Magento1212", "Magento2Api", "MercadoLibre", "MijoShop", "Miva", "Neto", "Opencart14", "Oscmax2", "Oscommerce22ms2", "Otto", "Oxid", "Pinnacle", "Prestashop", "PrestashopApi", "SSPremium", "Salla", "SCAPI", "Shopify", "Shopee", "Shoplazza", "Shopline", "Shopware", "ShopwareApi", "Square", "Squarespace", "Temu", "Tiendanube", "TikTokShop", "Tomatocart", "Ubercart", "Unas", "Virtuemart", "Volusion", "WPecommerce", "Walmart", "WebAsyst", "Wix", "Woocommerce", "WoocommerceApi", "Xcart", "Xtcommerce", "XtcommerceVeyton", "Zencart137", "Zid", "Zoey", "Zoho"))) {
          stop(paste("Error! \"", `cart_id`, "\" cannot be assigned to `cart_id`. Must be \"3DCart\", \"3DCartApi\", \"AceShop\", \"AmazonSP\", \"Americommerce\", \"AspDotNetStorefront\", \"BigCartel\", \"Bricklink\", \"BigcommerceApi\", \"Bol\", \"CommerceHQ\", \"Creloaded\", \"Cscart\", \"Cubecart\", \"Demandware\", \"EBay\", \"Ecwid\", \"EtsyAPIv3\", \"Facebook\", \"Flipkart\", \"Gambio\", \"Hybris\", \"JooCart\", \"Jumpseller\", \"Lazada\", \"LightSpeed\", \"Magento1212\", \"Magento2Api\", \"MercadoLibre\", \"MijoShop\", \"Miva\", \"Neto\", \"Opencart14\", \"Oscmax2\", \"Oscommerce22ms2\", \"Otto\", \"Oxid\", \"Pinnacle\", \"Prestashop\", \"PrestashopApi\", \"SSPremium\", \"Salla\", \"SCAPI\", \"Shopify\", \"Shopee\", \"Shoplazza\", \"Shopline\", \"Shopware\", \"ShopwareApi\", \"Square\", \"Squarespace\", \"Temu\", \"Tiendanube\", \"TikTokShop\", \"Tomatocart\", \"Ubercart\", \"Unas\", \"Virtuemart\", \"Volusion\", \"WPecommerce\", \"Walmart\", \"WebAsyst\", \"Wix\", \"Woocommerce\", \"WoocommerceApi\", \"Xcart\", \"Xtcommerce\", \"XtcommerceVeyton\", \"Zencart137\", \"Zid\", \"Zoey\", \"Zoho\".", sep = ""))
        }
        if (!(is.character(`cart_id`) && length(`cart_id`) == 1)) {
          stop(paste("Error! Invalid data for `cart_id`. Must be a string:", `cart_id`))
        }
        self$`cart_id` <- `cart_id`
      }
      if (!is.null(`store_url`)) {
        if (!(is.character(`store_url`) && length(`store_url`) == 1)) {
          stop(paste("Error! Invalid data for `store_url`. Must be a string:", `store_url`))
        }
        self$`store_url` <- `store_url`
      }
      if (!is.null(`bridge_url`)) {
        if (!(is.character(`bridge_url`) && length(`bridge_url`) == 1)) {
          stop(paste("Error! Invalid data for `bridge_url`. Must be a string:", `bridge_url`))
        }
        self$`bridge_url` <- `bridge_url`
      }
      if (!is.null(`store_root`)) {
        if (!(is.character(`store_root`) && length(`store_root`) == 1)) {
          stop(paste("Error! Invalid data for `store_root`. Must be a string:", `store_root`))
        }
        self$`store_root` <- `store_root`
      }
      if (!is.null(`store_key`)) {
        if (!(is.character(`store_key`) && length(`store_key`) == 1)) {
          stop(paste("Error! Invalid data for `store_key`. Must be a string:", `store_key`))
        }
        self$`store_key` <- `store_key`
      }
      if (!is.null(`label`)) {
        if (!(is.character(`label`) && length(`label`) == 1)) {
          stop(paste("Error! Invalid data for `label`. Must be a string:", `label`))
        }
        self$`label` <- `label`
      }
      if (!is.null(`custom_label`)) {
        if (!(is.character(`custom_label`) && length(`custom_label`) == 1)) {
          stop(paste("Error! Invalid data for `custom_label`. Must be a string:", `custom_label`))
        }
        self$`custom_label` <- `custom_label`
      }
      if (!is.null(`validate_version`)) {
        if (!(is.logical(`validate_version`) && length(`validate_version`) == 1)) {
          stop(paste("Error! Invalid data for `validate_version`. Must be a boolean:", `validate_version`))
        }
        self$`validate_version` <- `validate_version`
      }
      if (!is.null(`verify`)) {
        if (!(is.logical(`verify`) && length(`verify`) == 1)) {
          stop(paste("Error! Invalid data for `verify`. Must be a boolean:", `verify`))
        }
        self$`verify` <- `verify`
      }
      if (!is.null(`db_tables_prefix`)) {
        if (!(is.character(`db_tables_prefix`) && length(`db_tables_prefix`) == 1)) {
          stop(paste("Error! Invalid data for `db_tables_prefix`. Must be a string:", `db_tables_prefix`))
        }
        self$`db_tables_prefix` <- `db_tables_prefix`
      }
      if (!is.null(`user_agent`)) {
        if (!(is.character(`user_agent`) && length(`user_agent`) == 1)) {
          stop(paste("Error! Invalid data for `user_agent`. Must be a string:", `user_agent`))
        }
        self$`user_agent` <- `user_agent`
      }
      if (!is.null(`ftp_host`)) {
        if (!(is.character(`ftp_host`) && length(`ftp_host`) == 1)) {
          stop(paste("Error! Invalid data for `ftp_host`. Must be a string:", `ftp_host`))
        }
        self$`ftp_host` <- `ftp_host`
      }
      if (!is.null(`ftp_user`)) {
        if (!(is.character(`ftp_user`) && length(`ftp_user`) == 1)) {
          stop(paste("Error! Invalid data for `ftp_user`. Must be a string:", `ftp_user`))
        }
        self$`ftp_user` <- `ftp_user`
      }
      if (!is.null(`ftp_password`)) {
        if (!(is.character(`ftp_password`) && length(`ftp_password`) == 1)) {
          stop(paste("Error! Invalid data for `ftp_password`. Must be a string:", `ftp_password`))
        }
        self$`ftp_password` <- `ftp_password`
      }
      if (!is.null(`ftp_port`)) {
        if (!(is.numeric(`ftp_port`) && length(`ftp_port`) == 1)) {
          stop(paste("Error! Invalid data for `ftp_port`. Must be an integer:", `ftp_port`))
        }
        self$`ftp_port` <- `ftp_port`
      }
      if (!is.null(`ftp_store_dir`)) {
        if (!(is.character(`ftp_store_dir`) && length(`ftp_store_dir`) == 1)) {
          stop(paste("Error! Invalid data for `ftp_store_dir`. Must be a string:", `ftp_store_dir`))
        }
        self$`ftp_store_dir` <- `ftp_store_dir`
      }
      if (!is.null(`3dcart_private_key`)) {
        if (!(is.character(`3dcart_private_key`) && length(`3dcart_private_key`) == 1)) {
          stop(paste("Error! Invalid data for `3dcart_private_key`. Must be a string:", `3dcart_private_key`))
        }
        self$`3dcart_private_key` <- `3dcart_private_key`
      }
      if (!is.null(`3dcart_access_token`)) {
        if (!(is.character(`3dcart_access_token`) && length(`3dcart_access_token`) == 1)) {
          stop(paste("Error! Invalid data for `3dcart_access_token`. Must be a string:", `3dcart_access_token`))
        }
        self$`3dcart_access_token` <- `3dcart_access_token`
      }
      if (!is.null(`3dcartapi_api_key`)) {
        if (!(is.character(`3dcartapi_api_key`) && length(`3dcartapi_api_key`) == 1)) {
          stop(paste("Error! Invalid data for `3dcartapi_api_key`. Must be a string:", `3dcartapi_api_key`))
        }
        self$`3dcartapi_api_key` <- `3dcartapi_api_key`
      }
      if (!is.null(`amazon_sp_client_id`)) {
        if (!(is.character(`amazon_sp_client_id`) && length(`amazon_sp_client_id`) == 1)) {
          stop(paste("Error! Invalid data for `amazon_sp_client_id`. Must be a string:", `amazon_sp_client_id`))
        }
        self$`amazon_sp_client_id` <- `amazon_sp_client_id`
      }
      if (!is.null(`amazon_sp_client_secret`)) {
        if (!(is.character(`amazon_sp_client_secret`) && length(`amazon_sp_client_secret`) == 1)) {
          stop(paste("Error! Invalid data for `amazon_sp_client_secret`. Must be a string:", `amazon_sp_client_secret`))
        }
        self$`amazon_sp_client_secret` <- `amazon_sp_client_secret`
      }
      if (!is.null(`amazon_sp_refresh_token`)) {
        if (!(is.character(`amazon_sp_refresh_token`) && length(`amazon_sp_refresh_token`) == 1)) {
          stop(paste("Error! Invalid data for `amazon_sp_refresh_token`. Must be a string:", `amazon_sp_refresh_token`))
        }
        self$`amazon_sp_refresh_token` <- `amazon_sp_refresh_token`
      }
      if (!is.null(`amazon_sp_aws_region`)) {
        if (!(is.character(`amazon_sp_aws_region`) && length(`amazon_sp_aws_region`) == 1)) {
          stop(paste("Error! Invalid data for `amazon_sp_aws_region`. Must be a string:", `amazon_sp_aws_region`))
        }
        self$`amazon_sp_aws_region` <- `amazon_sp_aws_region`
      }
      if (!is.null(`amazon_sp_api_environment`)) {
        if (!(is.character(`amazon_sp_api_environment`) && length(`amazon_sp_api_environment`) == 1)) {
          stop(paste("Error! Invalid data for `amazon_sp_api_environment`. Must be a string:", `amazon_sp_api_environment`))
        }
        self$`amazon_sp_api_environment` <- `amazon_sp_api_environment`
      }
      if (!is.null(`amazon_seller_id`)) {
        if (!(is.character(`amazon_seller_id`) && length(`amazon_seller_id`) == 1)) {
          stop(paste("Error! Invalid data for `amazon_seller_id`. Must be a string:", `amazon_seller_id`))
        }
        self$`amazon_seller_id` <- `amazon_seller_id`
      }
      if (!is.null(`aspdotnetstorefront_api_user`)) {
        if (!(is.character(`aspdotnetstorefront_api_user`) && length(`aspdotnetstorefront_api_user`) == 1)) {
          stop(paste("Error! Invalid data for `aspdotnetstorefront_api_user`. Must be a string:", `aspdotnetstorefront_api_user`))
        }
        self$`aspdotnetstorefront_api_user` <- `aspdotnetstorefront_api_user`
      }
      if (!is.null(`aspdotnetstorefront_api_pass`)) {
        if (!(is.character(`aspdotnetstorefront_api_pass`) && length(`aspdotnetstorefront_api_pass`) == 1)) {
          stop(paste("Error! Invalid data for `aspdotnetstorefront_api_pass`. Must be a string:", `aspdotnetstorefront_api_pass`))
        }
        self$`aspdotnetstorefront_api_pass` <- `aspdotnetstorefront_api_pass`
      }
      if (!is.null(`americommerce_app_id`)) {
        if (!(is.character(`americommerce_app_id`) && length(`americommerce_app_id`) == 1)) {
          stop(paste("Error! Invalid data for `americommerce_app_id`. Must be a string:", `americommerce_app_id`))
        }
        self$`americommerce_app_id` <- `americommerce_app_id`
      }
      if (!is.null(`americommerce_app_secret`)) {
        if (!(is.character(`americommerce_app_secret`) && length(`americommerce_app_secret`) == 1)) {
          stop(paste("Error! Invalid data for `americommerce_app_secret`. Must be a string:", `americommerce_app_secret`))
        }
        self$`americommerce_app_secret` <- `americommerce_app_secret`
      }
      if (!is.null(`americommerce_access_token`)) {
        if (!(is.character(`americommerce_access_token`) && length(`americommerce_access_token`) == 1)) {
          stop(paste("Error! Invalid data for `americommerce_access_token`. Must be a string:", `americommerce_access_token`))
        }
        self$`americommerce_access_token` <- `americommerce_access_token`
      }
      if (!is.null(`americommerce_refresh_token`)) {
        if (!(is.character(`americommerce_refresh_token`) && length(`americommerce_refresh_token`) == 1)) {
          stop(paste("Error! Invalid data for `americommerce_refresh_token`. Must be a string:", `americommerce_refresh_token`))
        }
        self$`americommerce_refresh_token` <- `americommerce_refresh_token`
      }
      if (!is.null(`bigcommerceapi_admin_account`)) {
        if (!(is.character(`bigcommerceapi_admin_account`) && length(`bigcommerceapi_admin_account`) == 1)) {
          stop(paste("Error! Invalid data for `bigcommerceapi_admin_account`. Must be a string:", `bigcommerceapi_admin_account`))
        }
        self$`bigcommerceapi_admin_account` <- `bigcommerceapi_admin_account`
      }
      if (!is.null(`bigcommerceapi_api_path`)) {
        if (!(is.character(`bigcommerceapi_api_path`) && length(`bigcommerceapi_api_path`) == 1)) {
          stop(paste("Error! Invalid data for `bigcommerceapi_api_path`. Must be a string:", `bigcommerceapi_api_path`))
        }
        self$`bigcommerceapi_api_path` <- `bigcommerceapi_api_path`
      }
      if (!is.null(`bigcommerceapi_api_key`)) {
        if (!(is.character(`bigcommerceapi_api_key`) && length(`bigcommerceapi_api_key`) == 1)) {
          stop(paste("Error! Invalid data for `bigcommerceapi_api_key`. Must be a string:", `bigcommerceapi_api_key`))
        }
        self$`bigcommerceapi_api_key` <- `bigcommerceapi_api_key`
      }
      if (!is.null(`bigcommerceapi_client_id`)) {
        if (!(is.character(`bigcommerceapi_client_id`) && length(`bigcommerceapi_client_id`) == 1)) {
          stop(paste("Error! Invalid data for `bigcommerceapi_client_id`. Must be a string:", `bigcommerceapi_client_id`))
        }
        self$`bigcommerceapi_client_id` <- `bigcommerceapi_client_id`
      }
      if (!is.null(`bigcommerceapi_access_token`)) {
        if (!(is.character(`bigcommerceapi_access_token`) && length(`bigcommerceapi_access_token`) == 1)) {
          stop(paste("Error! Invalid data for `bigcommerceapi_access_token`. Must be a string:", `bigcommerceapi_access_token`))
        }
        self$`bigcommerceapi_access_token` <- `bigcommerceapi_access_token`
      }
      if (!is.null(`bigcommerceapi_context`)) {
        if (!(is.character(`bigcommerceapi_context`) && length(`bigcommerceapi_context`) == 1)) {
          stop(paste("Error! Invalid data for `bigcommerceapi_context`. Must be a string:", `bigcommerceapi_context`))
        }
        self$`bigcommerceapi_context` <- `bigcommerceapi_context`
      }
      if (!is.null(`bol_api_key`)) {
        if (!(is.character(`bol_api_key`) && length(`bol_api_key`) == 1)) {
          stop(paste("Error! Invalid data for `bol_api_key`. Must be a string:", `bol_api_key`))
        }
        self$`bol_api_key` <- `bol_api_key`
      }
      if (!is.null(`bol_api_secret`)) {
        if (!(is.character(`bol_api_secret`) && length(`bol_api_secret`) == 1)) {
          stop(paste("Error! Invalid data for `bol_api_secret`. Must be a string:", `bol_api_secret`))
        }
        self$`bol_api_secret` <- `bol_api_secret`
      }
      if (!is.null(`bol_retailer_id`)) {
        if (!(is.numeric(`bol_retailer_id`) && length(`bol_retailer_id`) == 1)) {
          stop(paste("Error! Invalid data for `bol_retailer_id`. Must be an integer:", `bol_retailer_id`))
        }
        self$`bol_retailer_id` <- `bol_retailer_id`
      }
      if (!is.null(`bigcartel_user_name`)) {
        if (!(is.character(`bigcartel_user_name`) && length(`bigcartel_user_name`) == 1)) {
          stop(paste("Error! Invalid data for `bigcartel_user_name`. Must be a string:", `bigcartel_user_name`))
        }
        self$`bigcartel_user_name` <- `bigcartel_user_name`
      }
      if (!is.null(`bigcartel_password`)) {
        if (!(is.character(`bigcartel_password`) && length(`bigcartel_password`) == 1)) {
          stop(paste("Error! Invalid data for `bigcartel_password`. Must be a string:", `bigcartel_password`))
        }
        self$`bigcartel_password` <- `bigcartel_password`
      }
      if (!is.null(`bricklink_consumer_key`)) {
        if (!(is.character(`bricklink_consumer_key`) && length(`bricklink_consumer_key`) == 1)) {
          stop(paste("Error! Invalid data for `bricklink_consumer_key`. Must be a string:", `bricklink_consumer_key`))
        }
        self$`bricklink_consumer_key` <- `bricklink_consumer_key`
      }
      if (!is.null(`bricklink_consumer_secret`)) {
        if (!(is.character(`bricklink_consumer_secret`) && length(`bricklink_consumer_secret`) == 1)) {
          stop(paste("Error! Invalid data for `bricklink_consumer_secret`. Must be a string:", `bricklink_consumer_secret`))
        }
        self$`bricklink_consumer_secret` <- `bricklink_consumer_secret`
      }
      if (!is.null(`bricklink_token`)) {
        if (!(is.character(`bricklink_token`) && length(`bricklink_token`) == 1)) {
          stop(paste("Error! Invalid data for `bricklink_token`. Must be a string:", `bricklink_token`))
        }
        self$`bricklink_token` <- `bricklink_token`
      }
      if (!is.null(`bricklink_token_secret`)) {
        if (!(is.character(`bricklink_token_secret`) && length(`bricklink_token_secret`) == 1)) {
          stop(paste("Error! Invalid data for `bricklink_token_secret`. Must be a string:", `bricklink_token_secret`))
        }
        self$`bricklink_token_secret` <- `bricklink_token_secret`
      }
      if (!is.null(`demandware_client_id`)) {
        if (!(is.character(`demandware_client_id`) && length(`demandware_client_id`) == 1)) {
          stop(paste("Error! Invalid data for `demandware_client_id`. Must be a string:", `demandware_client_id`))
        }
        self$`demandware_client_id` <- `demandware_client_id`
      }
      if (!is.null(`demandware_api_password`)) {
        if (!(is.character(`demandware_api_password`) && length(`demandware_api_password`) == 1)) {
          stop(paste("Error! Invalid data for `demandware_api_password`. Must be a string:", `demandware_api_password`))
        }
        self$`demandware_api_password` <- `demandware_api_password`
      }
      if (!is.null(`demandware_user_name`)) {
        if (!(is.character(`demandware_user_name`) && length(`demandware_user_name`) == 1)) {
          stop(paste("Error! Invalid data for `demandware_user_name`. Must be a string:", `demandware_user_name`))
        }
        self$`demandware_user_name` <- `demandware_user_name`
      }
      if (!is.null(`demandware_user_password`)) {
        if (!(is.character(`demandware_user_password`) && length(`demandware_user_password`) == 1)) {
          stop(paste("Error! Invalid data for `demandware_user_password`. Must be a string:", `demandware_user_password`))
        }
        self$`demandware_user_password` <- `demandware_user_password`
      }
      if (!is.null(`ebay_client_id`)) {
        if (!(is.character(`ebay_client_id`) && length(`ebay_client_id`) == 1)) {
          stop(paste("Error! Invalid data for `ebay_client_id`. Must be a string:", `ebay_client_id`))
        }
        self$`ebay_client_id` <- `ebay_client_id`
      }
      if (!is.null(`ebay_client_secret`)) {
        if (!(is.character(`ebay_client_secret`) && length(`ebay_client_secret`) == 1)) {
          stop(paste("Error! Invalid data for `ebay_client_secret`. Must be a string:", `ebay_client_secret`))
        }
        self$`ebay_client_secret` <- `ebay_client_secret`
      }
      if (!is.null(`ebay_runame`)) {
        if (!(is.character(`ebay_runame`) && length(`ebay_runame`) == 1)) {
          stop(paste("Error! Invalid data for `ebay_runame`. Must be a string:", `ebay_runame`))
        }
        self$`ebay_runame` <- `ebay_runame`
      }
      if (!is.null(`ebay_access_token`)) {
        if (!(is.character(`ebay_access_token`) && length(`ebay_access_token`) == 1)) {
          stop(paste("Error! Invalid data for `ebay_access_token`. Must be a string:", `ebay_access_token`))
        }
        self$`ebay_access_token` <- `ebay_access_token`
      }
      if (!is.null(`ebay_refresh_token`)) {
        if (!(is.character(`ebay_refresh_token`) && length(`ebay_refresh_token`) == 1)) {
          stop(paste("Error! Invalid data for `ebay_refresh_token`. Must be a string:", `ebay_refresh_token`))
        }
        self$`ebay_refresh_token` <- `ebay_refresh_token`
      }
      if (!is.null(`ebay_environment`)) {
        if (!(is.character(`ebay_environment`) && length(`ebay_environment`) == 1)) {
          stop(paste("Error! Invalid data for `ebay_environment`. Must be a string:", `ebay_environment`))
        }
        self$`ebay_environment` <- `ebay_environment`
      }
      if (!is.null(`ebay_site_id`)) {
        if (!(is.numeric(`ebay_site_id`) && length(`ebay_site_id`) == 1)) {
          stop(paste("Error! Invalid data for `ebay_site_id`. Must be an integer:", `ebay_site_id`))
        }
        self$`ebay_site_id` <- `ebay_site_id`
      }
      if (!is.null(`walmart_client_id`)) {
        if (!(is.character(`walmart_client_id`) && length(`walmart_client_id`) == 1)) {
          stop(paste("Error! Invalid data for `walmart_client_id`. Must be a string:", `walmart_client_id`))
        }
        self$`walmart_client_id` <- `walmart_client_id`
      }
      if (!is.null(`walmart_client_secret`)) {
        if (!(is.character(`walmart_client_secret`) && length(`walmart_client_secret`) == 1)) {
          stop(paste("Error! Invalid data for `walmart_client_secret`. Must be a string:", `walmart_client_secret`))
        }
        self$`walmart_client_secret` <- `walmart_client_secret`
      }
      if (!is.null(`walmart_environment`)) {
        if (!(is.character(`walmart_environment`) && length(`walmart_environment`) == 1)) {
          stop(paste("Error! Invalid data for `walmart_environment`. Must be a string:", `walmart_environment`))
        }
        self$`walmart_environment` <- `walmart_environment`
      }
      if (!is.null(`walmart_channel_type`)) {
        if (!(is.character(`walmart_channel_type`) && length(`walmart_channel_type`) == 1)) {
          stop(paste("Error! Invalid data for `walmart_channel_type`. Must be a string:", `walmart_channel_type`))
        }
        self$`walmart_channel_type` <- `walmart_channel_type`
      }
      if (!is.null(`walmart_region`)) {
        if (!(is.character(`walmart_region`) && length(`walmart_region`) == 1)) {
          stop(paste("Error! Invalid data for `walmart_region`. Must be a string:", `walmart_region`))
        }
        self$`walmart_region` <- `walmart_region`
      }
      if (!is.null(`ecwid_acess_token`)) {
        if (!(is.character(`ecwid_acess_token`) && length(`ecwid_acess_token`) == 1)) {
          stop(paste("Error! Invalid data for `ecwid_acess_token`. Must be a string:", `ecwid_acess_token`))
        }
        self$`ecwid_acess_token` <- `ecwid_acess_token`
      }
      if (!is.null(`ecwid_store_id`)) {
        if (!(is.character(`ecwid_store_id`) && length(`ecwid_store_id`) == 1)) {
          stop(paste("Error! Invalid data for `ecwid_store_id`. Must be a string:", `ecwid_store_id`))
        }
        self$`ecwid_store_id` <- `ecwid_store_id`
      }
      if (!is.null(`lazada_app_id`)) {
        if (!(is.character(`lazada_app_id`) && length(`lazada_app_id`) == 1)) {
          stop(paste("Error! Invalid data for `lazada_app_id`. Must be a string:", `lazada_app_id`))
        }
        self$`lazada_app_id` <- `lazada_app_id`
      }
      if (!is.null(`lazada_app_secret`)) {
        if (!(is.character(`lazada_app_secret`) && length(`lazada_app_secret`) == 1)) {
          stop(paste("Error! Invalid data for `lazada_app_secret`. Must be a string:", `lazada_app_secret`))
        }
        self$`lazada_app_secret` <- `lazada_app_secret`
      }
      if (!is.null(`lazada_refresh_token`)) {
        if (!(is.character(`lazada_refresh_token`) && length(`lazada_refresh_token`) == 1)) {
          stop(paste("Error! Invalid data for `lazada_refresh_token`. Must be a string:", `lazada_refresh_token`))
        }
        self$`lazada_refresh_token` <- `lazada_refresh_token`
      }
      if (!is.null(`lazada_region`)) {
        if (!(is.character(`lazada_region`) && length(`lazada_region`) == 1)) {
          stop(paste("Error! Invalid data for `lazada_region`. Must be a string:", `lazada_region`))
        }
        self$`lazada_region` <- `lazada_region`
      }
      if (!is.null(`lightspeed_api_key`)) {
        if (!(is.character(`lightspeed_api_key`) && length(`lightspeed_api_key`) == 1)) {
          stop(paste("Error! Invalid data for `lightspeed_api_key`. Must be a string:", `lightspeed_api_key`))
        }
        self$`lightspeed_api_key` <- `lightspeed_api_key`
      }
      if (!is.null(`lightspeed_api_secret`)) {
        if (!(is.character(`lightspeed_api_secret`) && length(`lightspeed_api_secret`) == 1)) {
          stop(paste("Error! Invalid data for `lightspeed_api_secret`. Must be a string:", `lightspeed_api_secret`))
        }
        self$`lightspeed_api_secret` <- `lightspeed_api_secret`
      }
      if (!is.null(`etsy_keystring`)) {
        if (!(is.character(`etsy_keystring`) && length(`etsy_keystring`) == 1)) {
          stop(paste("Error! Invalid data for `etsy_keystring`. Must be a string:", `etsy_keystring`))
        }
        self$`etsy_keystring` <- `etsy_keystring`
      }
      if (!is.null(`etsy_shared_secret`)) {
        if (!(is.character(`etsy_shared_secret`) && length(`etsy_shared_secret`) == 1)) {
          stop(paste("Error! Invalid data for `etsy_shared_secret`. Must be a string:", `etsy_shared_secret`))
        }
        self$`etsy_shared_secret` <- `etsy_shared_secret`
      }
      if (!is.null(`etsy_access_token`)) {
        if (!(is.character(`etsy_access_token`) && length(`etsy_access_token`) == 1)) {
          stop(paste("Error! Invalid data for `etsy_access_token`. Must be a string:", `etsy_access_token`))
        }
        self$`etsy_access_token` <- `etsy_access_token`
      }
      if (!is.null(`etsy_token_secret`)) {
        if (!(is.character(`etsy_token_secret`) && length(`etsy_token_secret`) == 1)) {
          stop(paste("Error! Invalid data for `etsy_token_secret`. Must be a string:", `etsy_token_secret`))
        }
        self$`etsy_token_secret` <- `etsy_token_secret`
      }
      if (!is.null(`etsy_client_id`)) {
        if (!(is.character(`etsy_client_id`) && length(`etsy_client_id`) == 1)) {
          stop(paste("Error! Invalid data for `etsy_client_id`. Must be a string:", `etsy_client_id`))
        }
        self$`etsy_client_id` <- `etsy_client_id`
      }
      if (!is.null(`etsy_refresh_token`)) {
        if (!(is.character(`etsy_refresh_token`) && length(`etsy_refresh_token`) == 1)) {
          stop(paste("Error! Invalid data for `etsy_refresh_token`. Must be a string:", `etsy_refresh_token`))
        }
        self$`etsy_refresh_token` <- `etsy_refresh_token`
      }
      if (!is.null(`facebook_app_id`)) {
        if (!(is.character(`facebook_app_id`) && length(`facebook_app_id`) == 1)) {
          stop(paste("Error! Invalid data for `facebook_app_id`. Must be a string:", `facebook_app_id`))
        }
        self$`facebook_app_id` <- `facebook_app_id`
      }
      if (!is.null(`facebook_app_secret`)) {
        if (!(is.character(`facebook_app_secret`) && length(`facebook_app_secret`) == 1)) {
          stop(paste("Error! Invalid data for `facebook_app_secret`. Must be a string:", `facebook_app_secret`))
        }
        self$`facebook_app_secret` <- `facebook_app_secret`
      }
      if (!is.null(`facebook_access_token`)) {
        if (!(is.character(`facebook_access_token`) && length(`facebook_access_token`) == 1)) {
          stop(paste("Error! Invalid data for `facebook_access_token`. Must be a string:", `facebook_access_token`))
        }
        self$`facebook_access_token` <- `facebook_access_token`
      }
      if (!is.null(`facebook_business_id`)) {
        if (!(is.character(`facebook_business_id`) && length(`facebook_business_id`) == 1)) {
          stop(paste("Error! Invalid data for `facebook_business_id`. Must be a string:", `facebook_business_id`))
        }
        self$`facebook_business_id` <- `facebook_business_id`
      }
      if (!is.null(`neto_api_key`)) {
        if (!(is.character(`neto_api_key`) && length(`neto_api_key`) == 1)) {
          stop(paste("Error! Invalid data for `neto_api_key`. Must be a string:", `neto_api_key`))
        }
        self$`neto_api_key` <- `neto_api_key`
      }
      if (!is.null(`neto_api_username`)) {
        if (!(is.character(`neto_api_username`) && length(`neto_api_username`) == 1)) {
          stop(paste("Error! Invalid data for `neto_api_username`. Must be a string:", `neto_api_username`))
        }
        self$`neto_api_username` <- `neto_api_username`
      }
      if (!is.null(`shopline_access_token`)) {
        if (!(is.character(`shopline_access_token`) && length(`shopline_access_token`) == 1)) {
          stop(paste("Error! Invalid data for `shopline_access_token`. Must be a string:", `shopline_access_token`))
        }
        self$`shopline_access_token` <- `shopline_access_token`
      }
      if (!is.null(`shopline_app_key`)) {
        if (!(is.character(`shopline_app_key`) && length(`shopline_app_key`) == 1)) {
          stop(paste("Error! Invalid data for `shopline_app_key`. Must be a string:", `shopline_app_key`))
        }
        self$`shopline_app_key` <- `shopline_app_key`
      }
      if (!is.null(`shopline_app_secret`)) {
        if (!(is.character(`shopline_app_secret`) && length(`shopline_app_secret`) == 1)) {
          stop(paste("Error! Invalid data for `shopline_app_secret`. Must be a string:", `shopline_app_secret`))
        }
        self$`shopline_app_secret` <- `shopline_app_secret`
      }
      if (!is.null(`shopline_shared_secret`)) {
        if (!(is.character(`shopline_shared_secret`) && length(`shopline_shared_secret`) == 1)) {
          stop(paste("Error! Invalid data for `shopline_shared_secret`. Must be a string:", `shopline_shared_secret`))
        }
        self$`shopline_shared_secret` <- `shopline_shared_secret`
      }
      if (!is.null(`shopify_access_token`)) {
        if (!(is.character(`shopify_access_token`) && length(`shopify_access_token`) == 1)) {
          stop(paste("Error! Invalid data for `shopify_access_token`. Must be a string:", `shopify_access_token`))
        }
        self$`shopify_access_token` <- `shopify_access_token`
      }
      if (!is.null(`shopify_client_id`)) {
        if (!(is.character(`shopify_client_id`) && length(`shopify_client_id`) == 1)) {
          stop(paste("Error! Invalid data for `shopify_client_id`. Must be a string:", `shopify_client_id`))
        }
        self$`shopify_client_id` <- `shopify_client_id`
      }
      if (!is.null(`shopify_api_key`)) {
        if (!(is.character(`shopify_api_key`) && length(`shopify_api_key`) == 1)) {
          stop(paste("Error! Invalid data for `shopify_api_key`. Must be a string:", `shopify_api_key`))
        }
        self$`shopify_api_key` <- `shopify_api_key`
      }
      if (!is.null(`shopify_api_password`)) {
        if (!(is.character(`shopify_api_password`) && length(`shopify_api_password`) == 1)) {
          stop(paste("Error! Invalid data for `shopify_api_password`. Must be a string:", `shopify_api_password`))
        }
        self$`shopify_api_password` <- `shopify_api_password`
      }
      if (!is.null(`shopify_shared_secret`)) {
        if (!(is.character(`shopify_shared_secret`) && length(`shopify_shared_secret`) == 1)) {
          stop(paste("Error! Invalid data for `shopify_shared_secret`. Must be a string:", `shopify_shared_secret`))
        }
        self$`shopify_shared_secret` <- `shopify_shared_secret`
      }
      if (!is.null(`shopee_partner_id`)) {
        if (!(is.character(`shopee_partner_id`) && length(`shopee_partner_id`) == 1)) {
          stop(paste("Error! Invalid data for `shopee_partner_id`. Must be a string:", `shopee_partner_id`))
        }
        self$`shopee_partner_id` <- `shopee_partner_id`
      }
      if (!is.null(`shopee_partner_key`)) {
        if (!(is.character(`shopee_partner_key`) && length(`shopee_partner_key`) == 1)) {
          stop(paste("Error! Invalid data for `shopee_partner_key`. Must be a string:", `shopee_partner_key`))
        }
        self$`shopee_partner_key` <- `shopee_partner_key`
      }
      if (!is.null(`shopee_shop_id`)) {
        if (!(is.character(`shopee_shop_id`) && length(`shopee_shop_id`) == 1)) {
          stop(paste("Error! Invalid data for `shopee_shop_id`. Must be a string:", `shopee_shop_id`))
        }
        self$`shopee_shop_id` <- `shopee_shop_id`
      }
      if (!is.null(`shopee_refresh_token`)) {
        if (!(is.character(`shopee_refresh_token`) && length(`shopee_refresh_token`) == 1)) {
          stop(paste("Error! Invalid data for `shopee_refresh_token`. Must be a string:", `shopee_refresh_token`))
        }
        self$`shopee_refresh_token` <- `shopee_refresh_token`
      }
      if (!is.null(`shopee_region`)) {
        if (!(is.character(`shopee_region`) && length(`shopee_region`) == 1)) {
          stop(paste("Error! Invalid data for `shopee_region`. Must be a string:", `shopee_region`))
        }
        self$`shopee_region` <- `shopee_region`
      }
      if (!is.null(`shopee_environment`)) {
        if (!(is.character(`shopee_environment`) && length(`shopee_environment`) == 1)) {
          stop(paste("Error! Invalid data for `shopee_environment`. Must be a string:", `shopee_environment`))
        }
        self$`shopee_environment` <- `shopee_environment`
      }
      if (!is.null(`shoplazza_access_token`)) {
        if (!(is.character(`shoplazza_access_token`) && length(`shoplazza_access_token`) == 1)) {
          stop(paste("Error! Invalid data for `shoplazza_access_token`. Must be a string:", `shoplazza_access_token`))
        }
        self$`shoplazza_access_token` <- `shoplazza_access_token`
      }
      if (!is.null(`shoplazza_shared_secret`)) {
        if (!(is.character(`shoplazza_shared_secret`) && length(`shoplazza_shared_secret`) == 1)) {
          stop(paste("Error! Invalid data for `shoplazza_shared_secret`. Must be a string:", `shoplazza_shared_secret`))
        }
        self$`shoplazza_shared_secret` <- `shoplazza_shared_secret`
      }
      if (!is.null(`shopware_access_key`)) {
        if (!(is.character(`shopware_access_key`) && length(`shopware_access_key`) == 1)) {
          stop(paste("Error! Invalid data for `shopware_access_key`. Must be a string:", `shopware_access_key`))
        }
        self$`shopware_access_key` <- `shopware_access_key`
      }
      if (!is.null(`unas_api_key`)) {
        if (!(is.character(`unas_api_key`) && length(`unas_api_key`) == 1)) {
          stop(paste("Error! Invalid data for `unas_api_key`. Must be a string:", `unas_api_key`))
        }
        self$`unas_api_key` <- `unas_api_key`
      }
      if (!is.null(`shopware_api_key`)) {
        if (!(is.character(`shopware_api_key`) && length(`shopware_api_key`) == 1)) {
          stop(paste("Error! Invalid data for `shopware_api_key`. Must be a string:", `shopware_api_key`))
        }
        self$`shopware_api_key` <- `shopware_api_key`
      }
      if (!is.null(`shopware_api_secret`)) {
        if (!(is.character(`shopware_api_secret`) && length(`shopware_api_secret`) == 1)) {
          stop(paste("Error! Invalid data for `shopware_api_secret`. Must be a string:", `shopware_api_secret`))
        }
        self$`shopware_api_secret` <- `shopware_api_secret`
      }
      if (!is.null(`miva_access_token`)) {
        if (!(is.character(`miva_access_token`) && length(`miva_access_token`) == 1)) {
          stop(paste("Error! Invalid data for `miva_access_token`. Must be a string:", `miva_access_token`))
        }
        self$`miva_access_token` <- `miva_access_token`
      }
      if (!is.null(`miva_signature`)) {
        if (!(is.character(`miva_signature`) && length(`miva_signature`) == 1)) {
          stop(paste("Error! Invalid data for `miva_signature`. Must be a string:", `miva_signature`))
        }
        self$`miva_signature` <- `miva_signature`
      }
      if (!is.null(`tiendanube_user_id`)) {
        if (!(is.numeric(`tiendanube_user_id`) && length(`tiendanube_user_id`) == 1)) {
          stop(paste("Error! Invalid data for `tiendanube_user_id`. Must be an integer:", `tiendanube_user_id`))
        }
        self$`tiendanube_user_id` <- `tiendanube_user_id`
      }
      if (!is.null(`tiendanube_access_token`)) {
        if (!(is.character(`tiendanube_access_token`) && length(`tiendanube_access_token`) == 1)) {
          stop(paste("Error! Invalid data for `tiendanube_access_token`. Must be a string:", `tiendanube_access_token`))
        }
        self$`tiendanube_access_token` <- `tiendanube_access_token`
      }
      if (!is.null(`tiendanube_client_secret`)) {
        if (!(is.character(`tiendanube_client_secret`) && length(`tiendanube_client_secret`) == 1)) {
          stop(paste("Error! Invalid data for `tiendanube_client_secret`. Must be a string:", `tiendanube_client_secret`))
        }
        self$`tiendanube_client_secret` <- `tiendanube_client_secret`
      }
      if (!is.null(`volusion_login`)) {
        if (!(is.character(`volusion_login`) && length(`volusion_login`) == 1)) {
          stop(paste("Error! Invalid data for `volusion_login`. Must be a string:", `volusion_login`))
        }
        self$`volusion_login` <- `volusion_login`
      }
      if (!is.null(`volusion_password`)) {
        if (!(is.character(`volusion_password`) && length(`volusion_password`) == 1)) {
          stop(paste("Error! Invalid data for `volusion_password`. Must be a string:", `volusion_password`))
        }
        self$`volusion_password` <- `volusion_password`
      }
      if (!is.null(`hybris_client_id`)) {
        if (!(is.character(`hybris_client_id`) && length(`hybris_client_id`) == 1)) {
          stop(paste("Error! Invalid data for `hybris_client_id`. Must be a string:", `hybris_client_id`))
        }
        self$`hybris_client_id` <- `hybris_client_id`
      }
      if (!is.null(`hybris_client_secret`)) {
        if (!(is.character(`hybris_client_secret`) && length(`hybris_client_secret`) == 1)) {
          stop(paste("Error! Invalid data for `hybris_client_secret`. Must be a string:", `hybris_client_secret`))
        }
        self$`hybris_client_secret` <- `hybris_client_secret`
      }
      if (!is.null(`hybris_username`)) {
        if (!(is.character(`hybris_username`) && length(`hybris_username`) == 1)) {
          stop(paste("Error! Invalid data for `hybris_username`. Must be a string:", `hybris_username`))
        }
        self$`hybris_username` <- `hybris_username`
      }
      if (!is.null(`hybris_password`)) {
        if (!(is.character(`hybris_password`) && length(`hybris_password`) == 1)) {
          stop(paste("Error! Invalid data for `hybris_password`. Must be a string:", `hybris_password`))
        }
        self$`hybris_password` <- `hybris_password`
      }
      if (!is.null(`hybris_websites`)) {
        stopifnot(is.vector(`hybris_websites`), length(`hybris_websites`) != 0)
        sapply(`hybris_websites`, function(x) stopifnot(R6::is.R6(x)))
        self$`hybris_websites` <- `hybris_websites`
      }
      if (!is.null(`square_client_id`)) {
        if (!(is.character(`square_client_id`) && length(`square_client_id`) == 1)) {
          stop(paste("Error! Invalid data for `square_client_id`. Must be a string:", `square_client_id`))
        }
        self$`square_client_id` <- `square_client_id`
      }
      if (!is.null(`square_client_secret`)) {
        if (!(is.character(`square_client_secret`) && length(`square_client_secret`) == 1)) {
          stop(paste("Error! Invalid data for `square_client_secret`. Must be a string:", `square_client_secret`))
        }
        self$`square_client_secret` <- `square_client_secret`
      }
      if (!is.null(`square_refresh_token`)) {
        if (!(is.character(`square_refresh_token`) && length(`square_refresh_token`) == 1)) {
          stop(paste("Error! Invalid data for `square_refresh_token`. Must be a string:", `square_refresh_token`))
        }
        self$`square_refresh_token` <- `square_refresh_token`
      }
      if (!is.null(`squarespace_api_key`)) {
        if (!(is.character(`squarespace_api_key`) && length(`squarespace_api_key`) == 1)) {
          stop(paste("Error! Invalid data for `squarespace_api_key`. Must be a string:", `squarespace_api_key`))
        }
        self$`squarespace_api_key` <- `squarespace_api_key`
      }
      if (!is.null(`squarespace_client_id`)) {
        if (!(is.character(`squarespace_client_id`) && length(`squarespace_client_id`) == 1)) {
          stop(paste("Error! Invalid data for `squarespace_client_id`. Must be a string:", `squarespace_client_id`))
        }
        self$`squarespace_client_id` <- `squarespace_client_id`
      }
      if (!is.null(`squarespace_client_secret`)) {
        if (!(is.character(`squarespace_client_secret`) && length(`squarespace_client_secret`) == 1)) {
          stop(paste("Error! Invalid data for `squarespace_client_secret`. Must be a string:", `squarespace_client_secret`))
        }
        self$`squarespace_client_secret` <- `squarespace_client_secret`
      }
      if (!is.null(`squarespace_access_token`)) {
        if (!(is.character(`squarespace_access_token`) && length(`squarespace_access_token`) == 1)) {
          stop(paste("Error! Invalid data for `squarespace_access_token`. Must be a string:", `squarespace_access_token`))
        }
        self$`squarespace_access_token` <- `squarespace_access_token`
      }
      if (!is.null(`squarespace_refresh_token`)) {
        if (!(is.character(`squarespace_refresh_token`) && length(`squarespace_refresh_token`) == 1)) {
          stop(paste("Error! Invalid data for `squarespace_refresh_token`. Must be a string:", `squarespace_refresh_token`))
        }
        self$`squarespace_refresh_token` <- `squarespace_refresh_token`
      }
      if (!is.null(`commercehq_api_key`)) {
        if (!(is.character(`commercehq_api_key`) && length(`commercehq_api_key`) == 1)) {
          stop(paste("Error! Invalid data for `commercehq_api_key`. Must be a string:", `commercehq_api_key`))
        }
        self$`commercehq_api_key` <- `commercehq_api_key`
      }
      if (!is.null(`commercehq_api_password`)) {
        if (!(is.character(`commercehq_api_password`) && length(`commercehq_api_password`) == 1)) {
          stop(paste("Error! Invalid data for `commercehq_api_password`. Must be a string:", `commercehq_api_password`))
        }
        self$`commercehq_api_password` <- `commercehq_api_password`
      }
      if (!is.null(`wc_consumer_key`)) {
        if (!(is.character(`wc_consumer_key`) && length(`wc_consumer_key`) == 1)) {
          stop(paste("Error! Invalid data for `wc_consumer_key`. Must be a string:", `wc_consumer_key`))
        }
        self$`wc_consumer_key` <- `wc_consumer_key`
      }
      if (!is.null(`wc_consumer_secret`)) {
        if (!(is.character(`wc_consumer_secret`) && length(`wc_consumer_secret`) == 1)) {
          stop(paste("Error! Invalid data for `wc_consumer_secret`. Must be a string:", `wc_consumer_secret`))
        }
        self$`wc_consumer_secret` <- `wc_consumer_secret`
      }
      if (!is.null(`magento_consumer_key`)) {
        if (!(is.character(`magento_consumer_key`) && length(`magento_consumer_key`) == 1)) {
          stop(paste("Error! Invalid data for `magento_consumer_key`. Must be a string:", `magento_consumer_key`))
        }
        self$`magento_consumer_key` <- `magento_consumer_key`
      }
      if (!is.null(`magento_consumer_secret`)) {
        if (!(is.character(`magento_consumer_secret`) && length(`magento_consumer_secret`) == 1)) {
          stop(paste("Error! Invalid data for `magento_consumer_secret`. Must be a string:", `magento_consumer_secret`))
        }
        self$`magento_consumer_secret` <- `magento_consumer_secret`
      }
      if (!is.null(`magento_access_token`)) {
        if (!(is.character(`magento_access_token`) && length(`magento_access_token`) == 1)) {
          stop(paste("Error! Invalid data for `magento_access_token`. Must be a string:", `magento_access_token`))
        }
        self$`magento_access_token` <- `magento_access_token`
      }
      if (!is.null(`magento_token_secret`)) {
        if (!(is.character(`magento_token_secret`) && length(`magento_token_secret`) == 1)) {
          stop(paste("Error! Invalid data for `magento_token_secret`. Must be a string:", `magento_token_secret`))
        }
        self$`magento_token_secret` <- `magento_token_secret`
      }
      if (!is.null(`prestashop_webservice_key`)) {
        if (!(is.character(`prestashop_webservice_key`) && length(`prestashop_webservice_key`) == 1)) {
          stop(paste("Error! Invalid data for `prestashop_webservice_key`. Must be a string:", `prestashop_webservice_key`))
        }
        self$`prestashop_webservice_key` <- `prestashop_webservice_key`
      }
      if (!is.null(`wix_app_id`)) {
        if (!(is.character(`wix_app_id`) && length(`wix_app_id`) == 1)) {
          stop(paste("Error! Invalid data for `wix_app_id`. Must be a string:", `wix_app_id`))
        }
        self$`wix_app_id` <- `wix_app_id`
      }
      if (!is.null(`wix_app_secret_key`)) {
        if (!(is.character(`wix_app_secret_key`) && length(`wix_app_secret_key`) == 1)) {
          stop(paste("Error! Invalid data for `wix_app_secret_key`. Must be a string:", `wix_app_secret_key`))
        }
        self$`wix_app_secret_key` <- `wix_app_secret_key`
      }
      if (!is.null(`wix_instance_id`)) {
        if (!(is.character(`wix_instance_id`) && length(`wix_instance_id`) == 1)) {
          stop(paste("Error! Invalid data for `wix_instance_id`. Must be a string:", `wix_instance_id`))
        }
        self$`wix_instance_id` <- `wix_instance_id`
      }
      if (!is.null(`wix_refresh_token`)) {
        if (!(is.character(`wix_refresh_token`) && length(`wix_refresh_token`) == 1)) {
          stop(paste("Error! Invalid data for `wix_refresh_token`. Must be a string:", `wix_refresh_token`))
        }
        self$`wix_refresh_token` <- `wix_refresh_token`
      }
      if (!is.null(`mercado_libre_app_id`)) {
        if (!(is.character(`mercado_libre_app_id`) && length(`mercado_libre_app_id`) == 1)) {
          stop(paste("Error! Invalid data for `mercado_libre_app_id`. Must be a string:", `mercado_libre_app_id`))
        }
        self$`mercado_libre_app_id` <- `mercado_libre_app_id`
      }
      if (!is.null(`mercado_libre_app_secret_key`)) {
        if (!(is.character(`mercado_libre_app_secret_key`) && length(`mercado_libre_app_secret_key`) == 1)) {
          stop(paste("Error! Invalid data for `mercado_libre_app_secret_key`. Must be a string:", `mercado_libre_app_secret_key`))
        }
        self$`mercado_libre_app_secret_key` <- `mercado_libre_app_secret_key`
      }
      if (!is.null(`mercado_libre_refresh_token`)) {
        if (!(is.character(`mercado_libre_refresh_token`) && length(`mercado_libre_refresh_token`) == 1)) {
          stop(paste("Error! Invalid data for `mercado_libre_refresh_token`. Must be a string:", `mercado_libre_refresh_token`))
        }
        self$`mercado_libre_refresh_token` <- `mercado_libre_refresh_token`
      }
      if (!is.null(`zid_client_id`)) {
        if (!(is.numeric(`zid_client_id`) && length(`zid_client_id`) == 1)) {
          stop(paste("Error! Invalid data for `zid_client_id`. Must be an integer:", `zid_client_id`))
        }
        self$`zid_client_id` <- `zid_client_id`
      }
      if (!is.null(`zid_client_secret`)) {
        if (!(is.character(`zid_client_secret`) && length(`zid_client_secret`) == 1)) {
          stop(paste("Error! Invalid data for `zid_client_secret`. Must be a string:", `zid_client_secret`))
        }
        self$`zid_client_secret` <- `zid_client_secret`
      }
      if (!is.null(`zid_access_token`)) {
        if (!(is.character(`zid_access_token`) && length(`zid_access_token`) == 1)) {
          stop(paste("Error! Invalid data for `zid_access_token`. Must be a string:", `zid_access_token`))
        }
        self$`zid_access_token` <- `zid_access_token`
      }
      if (!is.null(`zid_authorization`)) {
        if (!(is.character(`zid_authorization`) && length(`zid_authorization`) == 1)) {
          stop(paste("Error! Invalid data for `zid_authorization`. Must be a string:", `zid_authorization`))
        }
        self$`zid_authorization` <- `zid_authorization`
      }
      if (!is.null(`zid_refresh_token`)) {
        if (!(is.character(`zid_refresh_token`) && length(`zid_refresh_token`) == 1)) {
          stop(paste("Error! Invalid data for `zid_refresh_token`. Must be a string:", `zid_refresh_token`))
        }
        self$`zid_refresh_token` <- `zid_refresh_token`
      }
      if (!is.null(`jumpseller_client_id`)) {
        if (!(is.character(`jumpseller_client_id`) && length(`jumpseller_client_id`) == 1)) {
          stop(paste("Error! Invalid data for `jumpseller_client_id`. Must be a string:", `jumpseller_client_id`))
        }
        self$`jumpseller_client_id` <- `jumpseller_client_id`
      }
      if (!is.null(`jumpseller_client_secret`)) {
        if (!(is.character(`jumpseller_client_secret`) && length(`jumpseller_client_secret`) == 1)) {
          stop(paste("Error! Invalid data for `jumpseller_client_secret`. Must be a string:", `jumpseller_client_secret`))
        }
        self$`jumpseller_client_secret` <- `jumpseller_client_secret`
      }
      if (!is.null(`jumpseller_refresh_token`)) {
        if (!(is.character(`jumpseller_refresh_token`) && length(`jumpseller_refresh_token`) == 1)) {
          stop(paste("Error! Invalid data for `jumpseller_refresh_token`. Must be a string:", `jumpseller_refresh_token`))
        }
        self$`jumpseller_refresh_token` <- `jumpseller_refresh_token`
      }
      if (!is.null(`jumpseller_login`)) {
        if (!(is.character(`jumpseller_login`) && length(`jumpseller_login`) == 1)) {
          stop(paste("Error! Invalid data for `jumpseller_login`. Must be a string:", `jumpseller_login`))
        }
        self$`jumpseller_login` <- `jumpseller_login`
      }
      if (!is.null(`jumpseller_authtoken`)) {
        if (!(is.character(`jumpseller_authtoken`) && length(`jumpseller_authtoken`) == 1)) {
          stop(paste("Error! Invalid data for `jumpseller_authtoken`. Must be a string:", `jumpseller_authtoken`))
        }
        self$`jumpseller_authtoken` <- `jumpseller_authtoken`
      }
      if (!is.null(`flipkart_client_id`)) {
        if (!(is.character(`flipkart_client_id`) && length(`flipkart_client_id`) == 1)) {
          stop(paste("Error! Invalid data for `flipkart_client_id`. Must be a string:", `flipkart_client_id`))
        }
        self$`flipkart_client_id` <- `flipkart_client_id`
      }
      if (!is.null(`flipkart_client_secret`)) {
        if (!(is.character(`flipkart_client_secret`) && length(`flipkart_client_secret`) == 1)) {
          stop(paste("Error! Invalid data for `flipkart_client_secret`. Must be a string:", `flipkart_client_secret`))
        }
        self$`flipkart_client_secret` <- `flipkart_client_secret`
      }
      if (!is.null(`allegro_client_id`)) {
        if (!(is.character(`allegro_client_id`) && length(`allegro_client_id`) == 1)) {
          stop(paste("Error! Invalid data for `allegro_client_id`. Must be a string:", `allegro_client_id`))
        }
        self$`allegro_client_id` <- `allegro_client_id`
      }
      if (!is.null(`allegro_client_secret`)) {
        if (!(is.character(`allegro_client_secret`) && length(`allegro_client_secret`) == 1)) {
          stop(paste("Error! Invalid data for `allegro_client_secret`. Must be a string:", `allegro_client_secret`))
        }
        self$`allegro_client_secret` <- `allegro_client_secret`
      }
      if (!is.null(`allegro_access_token`)) {
        if (!(is.character(`allegro_access_token`) && length(`allegro_access_token`) == 1)) {
          stop(paste("Error! Invalid data for `allegro_access_token`. Must be a string:", `allegro_access_token`))
        }
        self$`allegro_access_token` <- `allegro_access_token`
      }
      if (!is.null(`allegro_refresh_token`)) {
        if (!(is.character(`allegro_refresh_token`) && length(`allegro_refresh_token`) == 1)) {
          stop(paste("Error! Invalid data for `allegro_refresh_token`. Must be a string:", `allegro_refresh_token`))
        }
        self$`allegro_refresh_token` <- `allegro_refresh_token`
      }
      if (!is.null(`allegro_environment`)) {
        if (!(is.character(`allegro_environment`) && length(`allegro_environment`) == 1)) {
          stop(paste("Error! Invalid data for `allegro_environment`. Must be a string:", `allegro_environment`))
        }
        self$`allegro_environment` <- `allegro_environment`
      }
      if (!is.null(`zoho_client_id`)) {
        if (!(is.character(`zoho_client_id`) && length(`zoho_client_id`) == 1)) {
          stop(paste("Error! Invalid data for `zoho_client_id`. Must be a string:", `zoho_client_id`))
        }
        self$`zoho_client_id` <- `zoho_client_id`
      }
      if (!is.null(`zoho_client_secret`)) {
        if (!(is.character(`zoho_client_secret`) && length(`zoho_client_secret`) == 1)) {
          stop(paste("Error! Invalid data for `zoho_client_secret`. Must be a string:", `zoho_client_secret`))
        }
        self$`zoho_client_secret` <- `zoho_client_secret`
      }
      if (!is.null(`zoho_refresh_token`)) {
        if (!(is.character(`zoho_refresh_token`) && length(`zoho_refresh_token`) == 1)) {
          stop(paste("Error! Invalid data for `zoho_refresh_token`. Must be a string:", `zoho_refresh_token`))
        }
        self$`zoho_refresh_token` <- `zoho_refresh_token`
      }
      if (!is.null(`zoho_region`)) {
        if (!(is.character(`zoho_region`) && length(`zoho_region`) == 1)) {
          stop(paste("Error! Invalid data for `zoho_region`. Must be a string:", `zoho_region`))
        }
        self$`zoho_region` <- `zoho_region`
      }
      if (!is.null(`otto_client_id`)) {
        if (!(is.character(`otto_client_id`) && length(`otto_client_id`) == 1)) {
          stop(paste("Error! Invalid data for `otto_client_id`. Must be a string:", `otto_client_id`))
        }
        self$`otto_client_id` <- `otto_client_id`
      }
      if (!is.null(`otto_client_secret`)) {
        if (!(is.character(`otto_client_secret`) && length(`otto_client_secret`) == 1)) {
          stop(paste("Error! Invalid data for `otto_client_secret`. Must be a string:", `otto_client_secret`))
        }
        self$`otto_client_secret` <- `otto_client_secret`
      }
      if (!is.null(`otto_app_id`)) {
        if (!(is.character(`otto_app_id`) && length(`otto_app_id`) == 1)) {
          stop(paste("Error! Invalid data for `otto_app_id`. Must be a string:", `otto_app_id`))
        }
        self$`otto_app_id` <- `otto_app_id`
      }
      if (!is.null(`otto_refresh_token`)) {
        if (!(is.character(`otto_refresh_token`) && length(`otto_refresh_token`) == 1)) {
          stop(paste("Error! Invalid data for `otto_refresh_token`. Must be a string:", `otto_refresh_token`))
        }
        self$`otto_refresh_token` <- `otto_refresh_token`
      }
      if (!is.null(`otto_environment`)) {
        if (!(is.character(`otto_environment`) && length(`otto_environment`) == 1)) {
          stop(paste("Error! Invalid data for `otto_environment`. Must be a string:", `otto_environment`))
        }
        self$`otto_environment` <- `otto_environment`
      }
      if (!is.null(`otto_access_token`)) {
        if (!(is.character(`otto_access_token`) && length(`otto_access_token`) == 1)) {
          stop(paste("Error! Invalid data for `otto_access_token`. Must be a string:", `otto_access_token`))
        }
        self$`otto_access_token` <- `otto_access_token`
      }
      if (!is.null(`tiktokshop_app_key`)) {
        if (!(is.character(`tiktokshop_app_key`) && length(`tiktokshop_app_key`) == 1)) {
          stop(paste("Error! Invalid data for `tiktokshop_app_key`. Must be a string:", `tiktokshop_app_key`))
        }
        self$`tiktokshop_app_key` <- `tiktokshop_app_key`
      }
      if (!is.null(`tiktokshop_app_secret`)) {
        if (!(is.character(`tiktokshop_app_secret`) && length(`tiktokshop_app_secret`) == 1)) {
          stop(paste("Error! Invalid data for `tiktokshop_app_secret`. Must be a string:", `tiktokshop_app_secret`))
        }
        self$`tiktokshop_app_secret` <- `tiktokshop_app_secret`
      }
      if (!is.null(`tiktokshop_refresh_token`)) {
        if (!(is.character(`tiktokshop_refresh_token`) && length(`tiktokshop_refresh_token`) == 1)) {
          stop(paste("Error! Invalid data for `tiktokshop_refresh_token`. Must be a string:", `tiktokshop_refresh_token`))
        }
        self$`tiktokshop_refresh_token` <- `tiktokshop_refresh_token`
      }
      if (!is.null(`tiktokshop_access_token`)) {
        if (!(is.character(`tiktokshop_access_token`) && length(`tiktokshop_access_token`) == 1)) {
          stop(paste("Error! Invalid data for `tiktokshop_access_token`. Must be a string:", `tiktokshop_access_token`))
        }
        self$`tiktokshop_access_token` <- `tiktokshop_access_token`
      }
      if (!is.null(`salla_client_id`)) {
        if (!(is.character(`salla_client_id`) && length(`salla_client_id`) == 1)) {
          stop(paste("Error! Invalid data for `salla_client_id`. Must be a string:", `salla_client_id`))
        }
        self$`salla_client_id` <- `salla_client_id`
      }
      if (!is.null(`salla_client_secret`)) {
        if (!(is.character(`salla_client_secret`) && length(`salla_client_secret`) == 1)) {
          stop(paste("Error! Invalid data for `salla_client_secret`. Must be a string:", `salla_client_secret`))
        }
        self$`salla_client_secret` <- `salla_client_secret`
      }
      if (!is.null(`salla_refresh_token`)) {
        if (!(is.character(`salla_refresh_token`) && length(`salla_refresh_token`) == 1)) {
          stop(paste("Error! Invalid data for `salla_refresh_token`. Must be a string:", `salla_refresh_token`))
        }
        self$`salla_refresh_token` <- `salla_refresh_token`
      }
      if (!is.null(`salla_access_token`)) {
        if (!(is.character(`salla_access_token`) && length(`salla_access_token`) == 1)) {
          stop(paste("Error! Invalid data for `salla_access_token`. Must be a string:", `salla_access_token`))
        }
        self$`salla_access_token` <- `salla_access_token`
      }
      if (!is.null(`temu_app_key`)) {
        if (!(is.character(`temu_app_key`) && length(`temu_app_key`) == 1)) {
          stop(paste("Error! Invalid data for `temu_app_key`. Must be a string:", `temu_app_key`))
        }
        self$`temu_app_key` <- `temu_app_key`
      }
      if (!is.null(`temu_app_secret`)) {
        if (!(is.character(`temu_app_secret`) && length(`temu_app_secret`) == 1)) {
          stop(paste("Error! Invalid data for `temu_app_secret`. Must be a string:", `temu_app_secret`))
        }
        self$`temu_app_secret` <- `temu_app_secret`
      }
      if (!is.null(`temu_access_token`)) {
        if (!(is.character(`temu_access_token`) && length(`temu_access_token`) == 1)) {
          stop(paste("Error! Invalid data for `temu_access_token`. Must be a string:", `temu_access_token`))
        }
        self$`temu_access_token` <- `temu_access_token`
      }
      if (!is.null(`temu_region`)) {
        if (!(is.character(`temu_region`) && length(`temu_region`) == 1)) {
          stop(paste("Error! Invalid data for `temu_region`. Must be a string:", `temu_region`))
        }
        self$`temu_region` <- `temu_region`
      }
      if (!is.null(`scapi_client_id`)) {
        if (!(is.character(`scapi_client_id`) && length(`scapi_client_id`) == 1)) {
          stop(paste("Error! Invalid data for `scapi_client_id`. Must be a string:", `scapi_client_id`))
        }
        self$`scapi_client_id` <- `scapi_client_id`
      }
      if (!is.null(`scapi_client_secret`)) {
        if (!(is.character(`scapi_client_secret`) && length(`scapi_client_secret`) == 1)) {
          stop(paste("Error! Invalid data for `scapi_client_secret`. Must be a string:", `scapi_client_secret`))
        }
        self$`scapi_client_secret` <- `scapi_client_secret`
      }
      if (!is.null(`scapi_organization_id`)) {
        if (!(is.character(`scapi_organization_id`) && length(`scapi_organization_id`) == 1)) {
          stop(paste("Error! Invalid data for `scapi_organization_id`. Must be a string:", `scapi_organization_id`))
        }
        self$`scapi_organization_id` <- `scapi_organization_id`
      }
      if (!is.null(`scapi_short_code`)) {
        if (!(is.character(`scapi_short_code`) && length(`scapi_short_code`) == 1)) {
          stop(paste("Error! Invalid data for `scapi_short_code`. Must be a string:", `scapi_short_code`))
        }
        self$`scapi_short_code` <- `scapi_short_code`
      }
      if (!is.null(`scapi_scopes`)) {
        if (!(is.character(`scapi_scopes`) && length(`scapi_scopes`) == 1)) {
          stop(paste("Error! Invalid data for `scapi_scopes`. Must be a string:", `scapi_scopes`))
        }
        self$`scapi_scopes` <- `scapi_scopes`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return AccountCartAdd as a base R list.
    #' @examples
    #' # convert array of AccountCartAdd (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert AccountCartAdd to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      AccountCartAddObject <- list()
      if (!is.null(self$`cart_id`)) {
        AccountCartAddObject[["cart_id"]] <-
          self$`cart_id`
      }
      if (!is.null(self$`store_url`)) {
        AccountCartAddObject[["store_url"]] <-
          self$`store_url`
      }
      if (!is.null(self$`bridge_url`)) {
        AccountCartAddObject[["bridge_url"]] <-
          self$`bridge_url`
      }
      if (!is.null(self$`store_root`)) {
        AccountCartAddObject[["store_root"]] <-
          self$`store_root`
      }
      if (!is.null(self$`store_key`)) {
        AccountCartAddObject[["store_key"]] <-
          self$`store_key`
      }
      if (!is.null(self$`label`)) {
        AccountCartAddObject[["label"]] <-
          self$`label`
      }
      if (!is.null(self$`custom_label`)) {
        AccountCartAddObject[["custom_label"]] <-
          self$`custom_label`
      }
      if (!is.null(self$`validate_version`)) {
        AccountCartAddObject[["validate_version"]] <-
          self$`validate_version`
      }
      if (!is.null(self$`verify`)) {
        AccountCartAddObject[["verify"]] <-
          self$`verify`
      }
      if (!is.null(self$`db_tables_prefix`)) {
        AccountCartAddObject[["db_tables_prefix"]] <-
          self$`db_tables_prefix`
      }
      if (!is.null(self$`user_agent`)) {
        AccountCartAddObject[["user_agent"]] <-
          self$`user_agent`
      }
      if (!is.null(self$`ftp_host`)) {
        AccountCartAddObject[["ftp_host"]] <-
          self$`ftp_host`
      }
      if (!is.null(self$`ftp_user`)) {
        AccountCartAddObject[["ftp_user"]] <-
          self$`ftp_user`
      }
      if (!is.null(self$`ftp_password`)) {
        AccountCartAddObject[["ftp_password"]] <-
          self$`ftp_password`
      }
      if (!is.null(self$`ftp_port`)) {
        AccountCartAddObject[["ftp_port"]] <-
          self$`ftp_port`
      }
      if (!is.null(self$`ftp_store_dir`)) {
        AccountCartAddObject[["ftp_store_dir"]] <-
          self$`ftp_store_dir`
      }
      if (!is.null(self$`3dcart_private_key`)) {
        AccountCartAddObject[["3dcart_private_key"]] <-
          self$`3dcart_private_key`
      }
      if (!is.null(self$`3dcart_access_token`)) {
        AccountCartAddObject[["3dcart_access_token"]] <-
          self$`3dcart_access_token`
      }
      if (!is.null(self$`3dcartapi_api_key`)) {
        AccountCartAddObject[["3dcartapi_api_key"]] <-
          self$`3dcartapi_api_key`
      }
      if (!is.null(self$`amazon_sp_client_id`)) {
        AccountCartAddObject[["amazon_sp_client_id"]] <-
          self$`amazon_sp_client_id`
      }
      if (!is.null(self$`amazon_sp_client_secret`)) {
        AccountCartAddObject[["amazon_sp_client_secret"]] <-
          self$`amazon_sp_client_secret`
      }
      if (!is.null(self$`amazon_sp_refresh_token`)) {
        AccountCartAddObject[["amazon_sp_refresh_token"]] <-
          self$`amazon_sp_refresh_token`
      }
      if (!is.null(self$`amazon_sp_aws_region`)) {
        AccountCartAddObject[["amazon_sp_aws_region"]] <-
          self$`amazon_sp_aws_region`
      }
      if (!is.null(self$`amazon_sp_api_environment`)) {
        AccountCartAddObject[["amazon_sp_api_environment"]] <-
          self$`amazon_sp_api_environment`
      }
      if (!is.null(self$`amazon_seller_id`)) {
        AccountCartAddObject[["amazon_seller_id"]] <-
          self$`amazon_seller_id`
      }
      if (!is.null(self$`aspdotnetstorefront_api_user`)) {
        AccountCartAddObject[["aspdotnetstorefront_api_user"]] <-
          self$`aspdotnetstorefront_api_user`
      }
      if (!is.null(self$`aspdotnetstorefront_api_pass`)) {
        AccountCartAddObject[["aspdotnetstorefront_api_pass"]] <-
          self$`aspdotnetstorefront_api_pass`
      }
      if (!is.null(self$`americommerce_app_id`)) {
        AccountCartAddObject[["americommerce_app_id"]] <-
          self$`americommerce_app_id`
      }
      if (!is.null(self$`americommerce_app_secret`)) {
        AccountCartAddObject[["americommerce_app_secret"]] <-
          self$`americommerce_app_secret`
      }
      if (!is.null(self$`americommerce_access_token`)) {
        AccountCartAddObject[["americommerce_access_token"]] <-
          self$`americommerce_access_token`
      }
      if (!is.null(self$`americommerce_refresh_token`)) {
        AccountCartAddObject[["americommerce_refresh_token"]] <-
          self$`americommerce_refresh_token`
      }
      if (!is.null(self$`bigcommerceapi_admin_account`)) {
        AccountCartAddObject[["bigcommerceapi_admin_account"]] <-
          self$`bigcommerceapi_admin_account`
      }
      if (!is.null(self$`bigcommerceapi_api_path`)) {
        AccountCartAddObject[["bigcommerceapi_api_path"]] <-
          self$`bigcommerceapi_api_path`
      }
      if (!is.null(self$`bigcommerceapi_api_key`)) {
        AccountCartAddObject[["bigcommerceapi_api_key"]] <-
          self$`bigcommerceapi_api_key`
      }
      if (!is.null(self$`bigcommerceapi_client_id`)) {
        AccountCartAddObject[["bigcommerceapi_client_id"]] <-
          self$`bigcommerceapi_client_id`
      }
      if (!is.null(self$`bigcommerceapi_access_token`)) {
        AccountCartAddObject[["bigcommerceapi_access_token"]] <-
          self$`bigcommerceapi_access_token`
      }
      if (!is.null(self$`bigcommerceapi_context`)) {
        AccountCartAddObject[["bigcommerceapi_context"]] <-
          self$`bigcommerceapi_context`
      }
      if (!is.null(self$`bol_api_key`)) {
        AccountCartAddObject[["bol_api_key"]] <-
          self$`bol_api_key`
      }
      if (!is.null(self$`bol_api_secret`)) {
        AccountCartAddObject[["bol_api_secret"]] <-
          self$`bol_api_secret`
      }
      if (!is.null(self$`bol_retailer_id`)) {
        AccountCartAddObject[["bol_retailer_id"]] <-
          self$`bol_retailer_id`
      }
      if (!is.null(self$`bigcartel_user_name`)) {
        AccountCartAddObject[["bigcartel_user_name"]] <-
          self$`bigcartel_user_name`
      }
      if (!is.null(self$`bigcartel_password`)) {
        AccountCartAddObject[["bigcartel_password"]] <-
          self$`bigcartel_password`
      }
      if (!is.null(self$`bricklink_consumer_key`)) {
        AccountCartAddObject[["bricklink_consumer_key"]] <-
          self$`bricklink_consumer_key`
      }
      if (!is.null(self$`bricklink_consumer_secret`)) {
        AccountCartAddObject[["bricklink_consumer_secret"]] <-
          self$`bricklink_consumer_secret`
      }
      if (!is.null(self$`bricklink_token`)) {
        AccountCartAddObject[["bricklink_token"]] <-
          self$`bricklink_token`
      }
      if (!is.null(self$`bricklink_token_secret`)) {
        AccountCartAddObject[["bricklink_token_secret"]] <-
          self$`bricklink_token_secret`
      }
      if (!is.null(self$`demandware_client_id`)) {
        AccountCartAddObject[["demandware_client_id"]] <-
          self$`demandware_client_id`
      }
      if (!is.null(self$`demandware_api_password`)) {
        AccountCartAddObject[["demandware_api_password"]] <-
          self$`demandware_api_password`
      }
      if (!is.null(self$`demandware_user_name`)) {
        AccountCartAddObject[["demandware_user_name"]] <-
          self$`demandware_user_name`
      }
      if (!is.null(self$`demandware_user_password`)) {
        AccountCartAddObject[["demandware_user_password"]] <-
          self$`demandware_user_password`
      }
      if (!is.null(self$`ebay_client_id`)) {
        AccountCartAddObject[["ebay_client_id"]] <-
          self$`ebay_client_id`
      }
      if (!is.null(self$`ebay_client_secret`)) {
        AccountCartAddObject[["ebay_client_secret"]] <-
          self$`ebay_client_secret`
      }
      if (!is.null(self$`ebay_runame`)) {
        AccountCartAddObject[["ebay_runame"]] <-
          self$`ebay_runame`
      }
      if (!is.null(self$`ebay_access_token`)) {
        AccountCartAddObject[["ebay_access_token"]] <-
          self$`ebay_access_token`
      }
      if (!is.null(self$`ebay_refresh_token`)) {
        AccountCartAddObject[["ebay_refresh_token"]] <-
          self$`ebay_refresh_token`
      }
      if (!is.null(self$`ebay_environment`)) {
        AccountCartAddObject[["ebay_environment"]] <-
          self$`ebay_environment`
      }
      if (!is.null(self$`ebay_site_id`)) {
        AccountCartAddObject[["ebay_site_id"]] <-
          self$`ebay_site_id`
      }
      if (!is.null(self$`walmart_client_id`)) {
        AccountCartAddObject[["walmart_client_id"]] <-
          self$`walmart_client_id`
      }
      if (!is.null(self$`walmart_client_secret`)) {
        AccountCartAddObject[["walmart_client_secret"]] <-
          self$`walmart_client_secret`
      }
      if (!is.null(self$`walmart_environment`)) {
        AccountCartAddObject[["walmart_environment"]] <-
          self$`walmart_environment`
      }
      if (!is.null(self$`walmart_channel_type`)) {
        AccountCartAddObject[["walmart_channel_type"]] <-
          self$`walmart_channel_type`
      }
      if (!is.null(self$`walmart_region`)) {
        AccountCartAddObject[["walmart_region"]] <-
          self$`walmart_region`
      }
      if (!is.null(self$`ecwid_acess_token`)) {
        AccountCartAddObject[["ecwid_acess_token"]] <-
          self$`ecwid_acess_token`
      }
      if (!is.null(self$`ecwid_store_id`)) {
        AccountCartAddObject[["ecwid_store_id"]] <-
          self$`ecwid_store_id`
      }
      if (!is.null(self$`lazada_app_id`)) {
        AccountCartAddObject[["lazada_app_id"]] <-
          self$`lazada_app_id`
      }
      if (!is.null(self$`lazada_app_secret`)) {
        AccountCartAddObject[["lazada_app_secret"]] <-
          self$`lazada_app_secret`
      }
      if (!is.null(self$`lazada_refresh_token`)) {
        AccountCartAddObject[["lazada_refresh_token"]] <-
          self$`lazada_refresh_token`
      }
      if (!is.null(self$`lazada_region`)) {
        AccountCartAddObject[["lazada_region"]] <-
          self$`lazada_region`
      }
      if (!is.null(self$`lightspeed_api_key`)) {
        AccountCartAddObject[["lightspeed_api_key"]] <-
          self$`lightspeed_api_key`
      }
      if (!is.null(self$`lightspeed_api_secret`)) {
        AccountCartAddObject[["lightspeed_api_secret"]] <-
          self$`lightspeed_api_secret`
      }
      if (!is.null(self$`etsy_keystring`)) {
        AccountCartAddObject[["etsy_keystring"]] <-
          self$`etsy_keystring`
      }
      if (!is.null(self$`etsy_shared_secret`)) {
        AccountCartAddObject[["etsy_shared_secret"]] <-
          self$`etsy_shared_secret`
      }
      if (!is.null(self$`etsy_access_token`)) {
        AccountCartAddObject[["etsy_access_token"]] <-
          self$`etsy_access_token`
      }
      if (!is.null(self$`etsy_token_secret`)) {
        AccountCartAddObject[["etsy_token_secret"]] <-
          self$`etsy_token_secret`
      }
      if (!is.null(self$`etsy_client_id`)) {
        AccountCartAddObject[["etsy_client_id"]] <-
          self$`etsy_client_id`
      }
      if (!is.null(self$`etsy_refresh_token`)) {
        AccountCartAddObject[["etsy_refresh_token"]] <-
          self$`etsy_refresh_token`
      }
      if (!is.null(self$`facebook_app_id`)) {
        AccountCartAddObject[["facebook_app_id"]] <-
          self$`facebook_app_id`
      }
      if (!is.null(self$`facebook_app_secret`)) {
        AccountCartAddObject[["facebook_app_secret"]] <-
          self$`facebook_app_secret`
      }
      if (!is.null(self$`facebook_access_token`)) {
        AccountCartAddObject[["facebook_access_token"]] <-
          self$`facebook_access_token`
      }
      if (!is.null(self$`facebook_business_id`)) {
        AccountCartAddObject[["facebook_business_id"]] <-
          self$`facebook_business_id`
      }
      if (!is.null(self$`neto_api_key`)) {
        AccountCartAddObject[["neto_api_key"]] <-
          self$`neto_api_key`
      }
      if (!is.null(self$`neto_api_username`)) {
        AccountCartAddObject[["neto_api_username"]] <-
          self$`neto_api_username`
      }
      if (!is.null(self$`shopline_access_token`)) {
        AccountCartAddObject[["shopline_access_token"]] <-
          self$`shopline_access_token`
      }
      if (!is.null(self$`shopline_app_key`)) {
        AccountCartAddObject[["shopline_app_key"]] <-
          self$`shopline_app_key`
      }
      if (!is.null(self$`shopline_app_secret`)) {
        AccountCartAddObject[["shopline_app_secret"]] <-
          self$`shopline_app_secret`
      }
      if (!is.null(self$`shopline_shared_secret`)) {
        AccountCartAddObject[["shopline_shared_secret"]] <-
          self$`shopline_shared_secret`
      }
      if (!is.null(self$`shopify_access_token`)) {
        AccountCartAddObject[["shopify_access_token"]] <-
          self$`shopify_access_token`
      }
      if (!is.null(self$`shopify_client_id`)) {
        AccountCartAddObject[["shopify_client_id"]] <-
          self$`shopify_client_id`
      }
      if (!is.null(self$`shopify_api_key`)) {
        AccountCartAddObject[["shopify_api_key"]] <-
          self$`shopify_api_key`
      }
      if (!is.null(self$`shopify_api_password`)) {
        AccountCartAddObject[["shopify_api_password"]] <-
          self$`shopify_api_password`
      }
      if (!is.null(self$`shopify_shared_secret`)) {
        AccountCartAddObject[["shopify_shared_secret"]] <-
          self$`shopify_shared_secret`
      }
      if (!is.null(self$`shopee_partner_id`)) {
        AccountCartAddObject[["shopee_partner_id"]] <-
          self$`shopee_partner_id`
      }
      if (!is.null(self$`shopee_partner_key`)) {
        AccountCartAddObject[["shopee_partner_key"]] <-
          self$`shopee_partner_key`
      }
      if (!is.null(self$`shopee_shop_id`)) {
        AccountCartAddObject[["shopee_shop_id"]] <-
          self$`shopee_shop_id`
      }
      if (!is.null(self$`shopee_refresh_token`)) {
        AccountCartAddObject[["shopee_refresh_token"]] <-
          self$`shopee_refresh_token`
      }
      if (!is.null(self$`shopee_region`)) {
        AccountCartAddObject[["shopee_region"]] <-
          self$`shopee_region`
      }
      if (!is.null(self$`shopee_environment`)) {
        AccountCartAddObject[["shopee_environment"]] <-
          self$`shopee_environment`
      }
      if (!is.null(self$`shoplazza_access_token`)) {
        AccountCartAddObject[["shoplazza_access_token"]] <-
          self$`shoplazza_access_token`
      }
      if (!is.null(self$`shoplazza_shared_secret`)) {
        AccountCartAddObject[["shoplazza_shared_secret"]] <-
          self$`shoplazza_shared_secret`
      }
      if (!is.null(self$`shopware_access_key`)) {
        AccountCartAddObject[["shopware_access_key"]] <-
          self$`shopware_access_key`
      }
      if (!is.null(self$`unas_api_key`)) {
        AccountCartAddObject[["unas_api_key"]] <-
          self$`unas_api_key`
      }
      if (!is.null(self$`shopware_api_key`)) {
        AccountCartAddObject[["shopware_api_key"]] <-
          self$`shopware_api_key`
      }
      if (!is.null(self$`shopware_api_secret`)) {
        AccountCartAddObject[["shopware_api_secret"]] <-
          self$`shopware_api_secret`
      }
      if (!is.null(self$`miva_access_token`)) {
        AccountCartAddObject[["miva_access_token"]] <-
          self$`miva_access_token`
      }
      if (!is.null(self$`miva_signature`)) {
        AccountCartAddObject[["miva_signature"]] <-
          self$`miva_signature`
      }
      if (!is.null(self$`tiendanube_user_id`)) {
        AccountCartAddObject[["tiendanube_user_id"]] <-
          self$`tiendanube_user_id`
      }
      if (!is.null(self$`tiendanube_access_token`)) {
        AccountCartAddObject[["tiendanube_access_token"]] <-
          self$`tiendanube_access_token`
      }
      if (!is.null(self$`tiendanube_client_secret`)) {
        AccountCartAddObject[["tiendanube_client_secret"]] <-
          self$`tiendanube_client_secret`
      }
      if (!is.null(self$`volusion_login`)) {
        AccountCartAddObject[["volusion_login"]] <-
          self$`volusion_login`
      }
      if (!is.null(self$`volusion_password`)) {
        AccountCartAddObject[["volusion_password"]] <-
          self$`volusion_password`
      }
      if (!is.null(self$`hybris_client_id`)) {
        AccountCartAddObject[["hybris_client_id"]] <-
          self$`hybris_client_id`
      }
      if (!is.null(self$`hybris_client_secret`)) {
        AccountCartAddObject[["hybris_client_secret"]] <-
          self$`hybris_client_secret`
      }
      if (!is.null(self$`hybris_username`)) {
        AccountCartAddObject[["hybris_username"]] <-
          self$`hybris_username`
      }
      if (!is.null(self$`hybris_password`)) {
        AccountCartAddObject[["hybris_password"]] <-
          self$`hybris_password`
      }
      if (!is.null(self$`hybris_websites`)) {
        AccountCartAddObject[["hybris_websites"]] <-
          lapply(self$`hybris_websites`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`square_client_id`)) {
        AccountCartAddObject[["square_client_id"]] <-
          self$`square_client_id`
      }
      if (!is.null(self$`square_client_secret`)) {
        AccountCartAddObject[["square_client_secret"]] <-
          self$`square_client_secret`
      }
      if (!is.null(self$`square_refresh_token`)) {
        AccountCartAddObject[["square_refresh_token"]] <-
          self$`square_refresh_token`
      }
      if (!is.null(self$`squarespace_api_key`)) {
        AccountCartAddObject[["squarespace_api_key"]] <-
          self$`squarespace_api_key`
      }
      if (!is.null(self$`squarespace_client_id`)) {
        AccountCartAddObject[["squarespace_client_id"]] <-
          self$`squarespace_client_id`
      }
      if (!is.null(self$`squarespace_client_secret`)) {
        AccountCartAddObject[["squarespace_client_secret"]] <-
          self$`squarespace_client_secret`
      }
      if (!is.null(self$`squarespace_access_token`)) {
        AccountCartAddObject[["squarespace_access_token"]] <-
          self$`squarespace_access_token`
      }
      if (!is.null(self$`squarespace_refresh_token`)) {
        AccountCartAddObject[["squarespace_refresh_token"]] <-
          self$`squarespace_refresh_token`
      }
      if (!is.null(self$`commercehq_api_key`)) {
        AccountCartAddObject[["commercehq_api_key"]] <-
          self$`commercehq_api_key`
      }
      if (!is.null(self$`commercehq_api_password`)) {
        AccountCartAddObject[["commercehq_api_password"]] <-
          self$`commercehq_api_password`
      }
      if (!is.null(self$`wc_consumer_key`)) {
        AccountCartAddObject[["wc_consumer_key"]] <-
          self$`wc_consumer_key`
      }
      if (!is.null(self$`wc_consumer_secret`)) {
        AccountCartAddObject[["wc_consumer_secret"]] <-
          self$`wc_consumer_secret`
      }
      if (!is.null(self$`magento_consumer_key`)) {
        AccountCartAddObject[["magento_consumer_key"]] <-
          self$`magento_consumer_key`
      }
      if (!is.null(self$`magento_consumer_secret`)) {
        AccountCartAddObject[["magento_consumer_secret"]] <-
          self$`magento_consumer_secret`
      }
      if (!is.null(self$`magento_access_token`)) {
        AccountCartAddObject[["magento_access_token"]] <-
          self$`magento_access_token`
      }
      if (!is.null(self$`magento_token_secret`)) {
        AccountCartAddObject[["magento_token_secret"]] <-
          self$`magento_token_secret`
      }
      if (!is.null(self$`prestashop_webservice_key`)) {
        AccountCartAddObject[["prestashop_webservice_key"]] <-
          self$`prestashop_webservice_key`
      }
      if (!is.null(self$`wix_app_id`)) {
        AccountCartAddObject[["wix_app_id"]] <-
          self$`wix_app_id`
      }
      if (!is.null(self$`wix_app_secret_key`)) {
        AccountCartAddObject[["wix_app_secret_key"]] <-
          self$`wix_app_secret_key`
      }
      if (!is.null(self$`wix_instance_id`)) {
        AccountCartAddObject[["wix_instance_id"]] <-
          self$`wix_instance_id`
      }
      if (!is.null(self$`wix_refresh_token`)) {
        AccountCartAddObject[["wix_refresh_token"]] <-
          self$`wix_refresh_token`
      }
      if (!is.null(self$`mercado_libre_app_id`)) {
        AccountCartAddObject[["mercado_libre_app_id"]] <-
          self$`mercado_libre_app_id`
      }
      if (!is.null(self$`mercado_libre_app_secret_key`)) {
        AccountCartAddObject[["mercado_libre_app_secret_key"]] <-
          self$`mercado_libre_app_secret_key`
      }
      if (!is.null(self$`mercado_libre_refresh_token`)) {
        AccountCartAddObject[["mercado_libre_refresh_token"]] <-
          self$`mercado_libre_refresh_token`
      }
      if (!is.null(self$`zid_client_id`)) {
        AccountCartAddObject[["zid_client_id"]] <-
          self$`zid_client_id`
      }
      if (!is.null(self$`zid_client_secret`)) {
        AccountCartAddObject[["zid_client_secret"]] <-
          self$`zid_client_secret`
      }
      if (!is.null(self$`zid_access_token`)) {
        AccountCartAddObject[["zid_access_token"]] <-
          self$`zid_access_token`
      }
      if (!is.null(self$`zid_authorization`)) {
        AccountCartAddObject[["zid_authorization"]] <-
          self$`zid_authorization`
      }
      if (!is.null(self$`zid_refresh_token`)) {
        AccountCartAddObject[["zid_refresh_token"]] <-
          self$`zid_refresh_token`
      }
      if (!is.null(self$`jumpseller_client_id`)) {
        AccountCartAddObject[["jumpseller_client_id"]] <-
          self$`jumpseller_client_id`
      }
      if (!is.null(self$`jumpseller_client_secret`)) {
        AccountCartAddObject[["jumpseller_client_secret"]] <-
          self$`jumpseller_client_secret`
      }
      if (!is.null(self$`jumpseller_refresh_token`)) {
        AccountCartAddObject[["jumpseller_refresh_token"]] <-
          self$`jumpseller_refresh_token`
      }
      if (!is.null(self$`jumpseller_login`)) {
        AccountCartAddObject[["jumpseller_login"]] <-
          self$`jumpseller_login`
      }
      if (!is.null(self$`jumpseller_authtoken`)) {
        AccountCartAddObject[["jumpseller_authtoken"]] <-
          self$`jumpseller_authtoken`
      }
      if (!is.null(self$`flipkart_client_id`)) {
        AccountCartAddObject[["flipkart_client_id"]] <-
          self$`flipkart_client_id`
      }
      if (!is.null(self$`flipkart_client_secret`)) {
        AccountCartAddObject[["flipkart_client_secret"]] <-
          self$`flipkart_client_secret`
      }
      if (!is.null(self$`allegro_client_id`)) {
        AccountCartAddObject[["allegro_client_id"]] <-
          self$`allegro_client_id`
      }
      if (!is.null(self$`allegro_client_secret`)) {
        AccountCartAddObject[["allegro_client_secret"]] <-
          self$`allegro_client_secret`
      }
      if (!is.null(self$`allegro_access_token`)) {
        AccountCartAddObject[["allegro_access_token"]] <-
          self$`allegro_access_token`
      }
      if (!is.null(self$`allegro_refresh_token`)) {
        AccountCartAddObject[["allegro_refresh_token"]] <-
          self$`allegro_refresh_token`
      }
      if (!is.null(self$`allegro_environment`)) {
        AccountCartAddObject[["allegro_environment"]] <-
          self$`allegro_environment`
      }
      if (!is.null(self$`zoho_client_id`)) {
        AccountCartAddObject[["zoho_client_id"]] <-
          self$`zoho_client_id`
      }
      if (!is.null(self$`zoho_client_secret`)) {
        AccountCartAddObject[["zoho_client_secret"]] <-
          self$`zoho_client_secret`
      }
      if (!is.null(self$`zoho_refresh_token`)) {
        AccountCartAddObject[["zoho_refresh_token"]] <-
          self$`zoho_refresh_token`
      }
      if (!is.null(self$`zoho_region`)) {
        AccountCartAddObject[["zoho_region"]] <-
          self$`zoho_region`
      }
      if (!is.null(self$`otto_client_id`)) {
        AccountCartAddObject[["otto_client_id"]] <-
          self$`otto_client_id`
      }
      if (!is.null(self$`otto_client_secret`)) {
        AccountCartAddObject[["otto_client_secret"]] <-
          self$`otto_client_secret`
      }
      if (!is.null(self$`otto_app_id`)) {
        AccountCartAddObject[["otto_app_id"]] <-
          self$`otto_app_id`
      }
      if (!is.null(self$`otto_refresh_token`)) {
        AccountCartAddObject[["otto_refresh_token"]] <-
          self$`otto_refresh_token`
      }
      if (!is.null(self$`otto_environment`)) {
        AccountCartAddObject[["otto_environment"]] <-
          self$`otto_environment`
      }
      if (!is.null(self$`otto_access_token`)) {
        AccountCartAddObject[["otto_access_token"]] <-
          self$`otto_access_token`
      }
      if (!is.null(self$`tiktokshop_app_key`)) {
        AccountCartAddObject[["tiktokshop_app_key"]] <-
          self$`tiktokshop_app_key`
      }
      if (!is.null(self$`tiktokshop_app_secret`)) {
        AccountCartAddObject[["tiktokshop_app_secret"]] <-
          self$`tiktokshop_app_secret`
      }
      if (!is.null(self$`tiktokshop_refresh_token`)) {
        AccountCartAddObject[["tiktokshop_refresh_token"]] <-
          self$`tiktokshop_refresh_token`
      }
      if (!is.null(self$`tiktokshop_access_token`)) {
        AccountCartAddObject[["tiktokshop_access_token"]] <-
          self$`tiktokshop_access_token`
      }
      if (!is.null(self$`salla_client_id`)) {
        AccountCartAddObject[["salla_client_id"]] <-
          self$`salla_client_id`
      }
      if (!is.null(self$`salla_client_secret`)) {
        AccountCartAddObject[["salla_client_secret"]] <-
          self$`salla_client_secret`
      }
      if (!is.null(self$`salla_refresh_token`)) {
        AccountCartAddObject[["salla_refresh_token"]] <-
          self$`salla_refresh_token`
      }
      if (!is.null(self$`salla_access_token`)) {
        AccountCartAddObject[["salla_access_token"]] <-
          self$`salla_access_token`
      }
      if (!is.null(self$`temu_app_key`)) {
        AccountCartAddObject[["temu_app_key"]] <-
          self$`temu_app_key`
      }
      if (!is.null(self$`temu_app_secret`)) {
        AccountCartAddObject[["temu_app_secret"]] <-
          self$`temu_app_secret`
      }
      if (!is.null(self$`temu_access_token`)) {
        AccountCartAddObject[["temu_access_token"]] <-
          self$`temu_access_token`
      }
      if (!is.null(self$`temu_region`)) {
        AccountCartAddObject[["temu_region"]] <-
          self$`temu_region`
      }
      if (!is.null(self$`scapi_client_id`)) {
        AccountCartAddObject[["scapi_client_id"]] <-
          self$`scapi_client_id`
      }
      if (!is.null(self$`scapi_client_secret`)) {
        AccountCartAddObject[["scapi_client_secret"]] <-
          self$`scapi_client_secret`
      }
      if (!is.null(self$`scapi_organization_id`)) {
        AccountCartAddObject[["scapi_organization_id"]] <-
          self$`scapi_organization_id`
      }
      if (!is.null(self$`scapi_short_code`)) {
        AccountCartAddObject[["scapi_short_code"]] <-
          self$`scapi_short_code`
      }
      if (!is.null(self$`scapi_scopes`)) {
        AccountCartAddObject[["scapi_scopes"]] <-
          self$`scapi_scopes`
      }
      return(AccountCartAddObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of AccountCartAdd
    #'
    #' @param input_json the JSON input
    #' @return the instance of AccountCartAdd
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`cart_id`)) {
        if (!is.null(this_object$`cart_id`) && !(this_object$`cart_id` %in% c("3DCart", "3DCartApi", "AceShop", "AmazonSP", "Americommerce", "AspDotNetStorefront", "BigCartel", "Bricklink", "BigcommerceApi", "Bol", "CommerceHQ", "Creloaded", "Cscart", "Cubecart", "Demandware", "EBay", "Ecwid", "EtsyAPIv3", "Facebook", "Flipkart", "Gambio", "Hybris", "JooCart", "Jumpseller", "Lazada", "LightSpeed", "Magento1212", "Magento2Api", "MercadoLibre", "MijoShop", "Miva", "Neto", "Opencart14", "Oscmax2", "Oscommerce22ms2", "Otto", "Oxid", "Pinnacle", "Prestashop", "PrestashopApi", "SSPremium", "Salla", "SCAPI", "Shopify", "Shopee", "Shoplazza", "Shopline", "Shopware", "ShopwareApi", "Square", "Squarespace", "Temu", "Tiendanube", "TikTokShop", "Tomatocart", "Ubercart", "Unas", "Virtuemart", "Volusion", "WPecommerce", "Walmart", "WebAsyst", "Wix", "Woocommerce", "WoocommerceApi", "Xcart", "Xtcommerce", "XtcommerceVeyton", "Zencart137", "Zid", "Zoey", "Zoho"))) {
          stop(paste("Error! \"", this_object$`cart_id`, "\" cannot be assigned to `cart_id`. Must be \"3DCart\", \"3DCartApi\", \"AceShop\", \"AmazonSP\", \"Americommerce\", \"AspDotNetStorefront\", \"BigCartel\", \"Bricklink\", \"BigcommerceApi\", \"Bol\", \"CommerceHQ\", \"Creloaded\", \"Cscart\", \"Cubecart\", \"Demandware\", \"EBay\", \"Ecwid\", \"EtsyAPIv3\", \"Facebook\", \"Flipkart\", \"Gambio\", \"Hybris\", \"JooCart\", \"Jumpseller\", \"Lazada\", \"LightSpeed\", \"Magento1212\", \"Magento2Api\", \"MercadoLibre\", \"MijoShop\", \"Miva\", \"Neto\", \"Opencart14\", \"Oscmax2\", \"Oscommerce22ms2\", \"Otto\", \"Oxid\", \"Pinnacle\", \"Prestashop\", \"PrestashopApi\", \"SSPremium\", \"Salla\", \"SCAPI\", \"Shopify\", \"Shopee\", \"Shoplazza\", \"Shopline\", \"Shopware\", \"ShopwareApi\", \"Square\", \"Squarespace\", \"Temu\", \"Tiendanube\", \"TikTokShop\", \"Tomatocart\", \"Ubercart\", \"Unas\", \"Virtuemart\", \"Volusion\", \"WPecommerce\", \"Walmart\", \"WebAsyst\", \"Wix\", \"Woocommerce\", \"WoocommerceApi\", \"Xcart\", \"Xtcommerce\", \"XtcommerceVeyton\", \"Zencart137\", \"Zid\", \"Zoey\", \"Zoho\".", sep = ""))
        }
        self$`cart_id` <- this_object$`cart_id`
      }
      if (!is.null(this_object$`store_url`)) {
        self$`store_url` <- this_object$`store_url`
      }
      if (!is.null(this_object$`bridge_url`)) {
        self$`bridge_url` <- this_object$`bridge_url`
      }
      if (!is.null(this_object$`store_root`)) {
        self$`store_root` <- this_object$`store_root`
      }
      if (!is.null(this_object$`store_key`)) {
        self$`store_key` <- this_object$`store_key`
      }
      if (!is.null(this_object$`label`)) {
        self$`label` <- this_object$`label`
      }
      if (!is.null(this_object$`custom_label`)) {
        self$`custom_label` <- this_object$`custom_label`
      }
      if (!is.null(this_object$`validate_version`)) {
        self$`validate_version` <- this_object$`validate_version`
      }
      if (!is.null(this_object$`verify`)) {
        self$`verify` <- this_object$`verify`
      }
      if (!is.null(this_object$`db_tables_prefix`)) {
        self$`db_tables_prefix` <- this_object$`db_tables_prefix`
      }
      if (!is.null(this_object$`user_agent`)) {
        self$`user_agent` <- this_object$`user_agent`
      }
      if (!is.null(this_object$`ftp_host`)) {
        self$`ftp_host` <- this_object$`ftp_host`
      }
      if (!is.null(this_object$`ftp_user`)) {
        self$`ftp_user` <- this_object$`ftp_user`
      }
      if (!is.null(this_object$`ftp_password`)) {
        self$`ftp_password` <- this_object$`ftp_password`
      }
      if (!is.null(this_object$`ftp_port`)) {
        self$`ftp_port` <- this_object$`ftp_port`
      }
      if (!is.null(this_object$`ftp_store_dir`)) {
        self$`ftp_store_dir` <- this_object$`ftp_store_dir`
      }
      if (!is.null(this_object$`3dcart_private_key`)) {
        self$`3dcart_private_key` <- this_object$`3dcart_private_key`
      }
      if (!is.null(this_object$`3dcart_access_token`)) {
        self$`3dcart_access_token` <- this_object$`3dcart_access_token`
      }
      if (!is.null(this_object$`3dcartapi_api_key`)) {
        self$`3dcartapi_api_key` <- this_object$`3dcartapi_api_key`
      }
      if (!is.null(this_object$`amazon_sp_client_id`)) {
        self$`amazon_sp_client_id` <- this_object$`amazon_sp_client_id`
      }
      if (!is.null(this_object$`amazon_sp_client_secret`)) {
        self$`amazon_sp_client_secret` <- this_object$`amazon_sp_client_secret`
      }
      if (!is.null(this_object$`amazon_sp_refresh_token`)) {
        self$`amazon_sp_refresh_token` <- this_object$`amazon_sp_refresh_token`
      }
      if (!is.null(this_object$`amazon_sp_aws_region`)) {
        self$`amazon_sp_aws_region` <- this_object$`amazon_sp_aws_region`
      }
      if (!is.null(this_object$`amazon_sp_api_environment`)) {
        self$`amazon_sp_api_environment` <- this_object$`amazon_sp_api_environment`
      }
      if (!is.null(this_object$`amazon_seller_id`)) {
        self$`amazon_seller_id` <- this_object$`amazon_seller_id`
      }
      if (!is.null(this_object$`aspdotnetstorefront_api_user`)) {
        self$`aspdotnetstorefront_api_user` <- this_object$`aspdotnetstorefront_api_user`
      }
      if (!is.null(this_object$`aspdotnetstorefront_api_pass`)) {
        self$`aspdotnetstorefront_api_pass` <- this_object$`aspdotnetstorefront_api_pass`
      }
      if (!is.null(this_object$`americommerce_app_id`)) {
        self$`americommerce_app_id` <- this_object$`americommerce_app_id`
      }
      if (!is.null(this_object$`americommerce_app_secret`)) {
        self$`americommerce_app_secret` <- this_object$`americommerce_app_secret`
      }
      if (!is.null(this_object$`americommerce_access_token`)) {
        self$`americommerce_access_token` <- this_object$`americommerce_access_token`
      }
      if (!is.null(this_object$`americommerce_refresh_token`)) {
        self$`americommerce_refresh_token` <- this_object$`americommerce_refresh_token`
      }
      if (!is.null(this_object$`bigcommerceapi_admin_account`)) {
        self$`bigcommerceapi_admin_account` <- this_object$`bigcommerceapi_admin_account`
      }
      if (!is.null(this_object$`bigcommerceapi_api_path`)) {
        self$`bigcommerceapi_api_path` <- this_object$`bigcommerceapi_api_path`
      }
      if (!is.null(this_object$`bigcommerceapi_api_key`)) {
        self$`bigcommerceapi_api_key` <- this_object$`bigcommerceapi_api_key`
      }
      if (!is.null(this_object$`bigcommerceapi_client_id`)) {
        self$`bigcommerceapi_client_id` <- this_object$`bigcommerceapi_client_id`
      }
      if (!is.null(this_object$`bigcommerceapi_access_token`)) {
        self$`bigcommerceapi_access_token` <- this_object$`bigcommerceapi_access_token`
      }
      if (!is.null(this_object$`bigcommerceapi_context`)) {
        self$`bigcommerceapi_context` <- this_object$`bigcommerceapi_context`
      }
      if (!is.null(this_object$`bol_api_key`)) {
        self$`bol_api_key` <- this_object$`bol_api_key`
      }
      if (!is.null(this_object$`bol_api_secret`)) {
        self$`bol_api_secret` <- this_object$`bol_api_secret`
      }
      if (!is.null(this_object$`bol_retailer_id`)) {
        self$`bol_retailer_id` <- this_object$`bol_retailer_id`
      }
      if (!is.null(this_object$`bigcartel_user_name`)) {
        self$`bigcartel_user_name` <- this_object$`bigcartel_user_name`
      }
      if (!is.null(this_object$`bigcartel_password`)) {
        self$`bigcartel_password` <- this_object$`bigcartel_password`
      }
      if (!is.null(this_object$`bricklink_consumer_key`)) {
        self$`bricklink_consumer_key` <- this_object$`bricklink_consumer_key`
      }
      if (!is.null(this_object$`bricklink_consumer_secret`)) {
        self$`bricklink_consumer_secret` <- this_object$`bricklink_consumer_secret`
      }
      if (!is.null(this_object$`bricklink_token`)) {
        self$`bricklink_token` <- this_object$`bricklink_token`
      }
      if (!is.null(this_object$`bricklink_token_secret`)) {
        self$`bricklink_token_secret` <- this_object$`bricklink_token_secret`
      }
      if (!is.null(this_object$`demandware_client_id`)) {
        self$`demandware_client_id` <- this_object$`demandware_client_id`
      }
      if (!is.null(this_object$`demandware_api_password`)) {
        self$`demandware_api_password` <- this_object$`demandware_api_password`
      }
      if (!is.null(this_object$`demandware_user_name`)) {
        self$`demandware_user_name` <- this_object$`demandware_user_name`
      }
      if (!is.null(this_object$`demandware_user_password`)) {
        self$`demandware_user_password` <- this_object$`demandware_user_password`
      }
      if (!is.null(this_object$`ebay_client_id`)) {
        self$`ebay_client_id` <- this_object$`ebay_client_id`
      }
      if (!is.null(this_object$`ebay_client_secret`)) {
        self$`ebay_client_secret` <- this_object$`ebay_client_secret`
      }
      if (!is.null(this_object$`ebay_runame`)) {
        self$`ebay_runame` <- this_object$`ebay_runame`
      }
      if (!is.null(this_object$`ebay_access_token`)) {
        self$`ebay_access_token` <- this_object$`ebay_access_token`
      }
      if (!is.null(this_object$`ebay_refresh_token`)) {
        self$`ebay_refresh_token` <- this_object$`ebay_refresh_token`
      }
      if (!is.null(this_object$`ebay_environment`)) {
        self$`ebay_environment` <- this_object$`ebay_environment`
      }
      if (!is.null(this_object$`ebay_site_id`)) {
        self$`ebay_site_id` <- this_object$`ebay_site_id`
      }
      if (!is.null(this_object$`walmart_client_id`)) {
        self$`walmart_client_id` <- this_object$`walmart_client_id`
      }
      if (!is.null(this_object$`walmart_client_secret`)) {
        self$`walmart_client_secret` <- this_object$`walmart_client_secret`
      }
      if (!is.null(this_object$`walmart_environment`)) {
        self$`walmart_environment` <- this_object$`walmart_environment`
      }
      if (!is.null(this_object$`walmart_channel_type`)) {
        self$`walmart_channel_type` <- this_object$`walmart_channel_type`
      }
      if (!is.null(this_object$`walmart_region`)) {
        self$`walmart_region` <- this_object$`walmart_region`
      }
      if (!is.null(this_object$`ecwid_acess_token`)) {
        self$`ecwid_acess_token` <- this_object$`ecwid_acess_token`
      }
      if (!is.null(this_object$`ecwid_store_id`)) {
        self$`ecwid_store_id` <- this_object$`ecwid_store_id`
      }
      if (!is.null(this_object$`lazada_app_id`)) {
        self$`lazada_app_id` <- this_object$`lazada_app_id`
      }
      if (!is.null(this_object$`lazada_app_secret`)) {
        self$`lazada_app_secret` <- this_object$`lazada_app_secret`
      }
      if (!is.null(this_object$`lazada_refresh_token`)) {
        self$`lazada_refresh_token` <- this_object$`lazada_refresh_token`
      }
      if (!is.null(this_object$`lazada_region`)) {
        self$`lazada_region` <- this_object$`lazada_region`
      }
      if (!is.null(this_object$`lightspeed_api_key`)) {
        self$`lightspeed_api_key` <- this_object$`lightspeed_api_key`
      }
      if (!is.null(this_object$`lightspeed_api_secret`)) {
        self$`lightspeed_api_secret` <- this_object$`lightspeed_api_secret`
      }
      if (!is.null(this_object$`etsy_keystring`)) {
        self$`etsy_keystring` <- this_object$`etsy_keystring`
      }
      if (!is.null(this_object$`etsy_shared_secret`)) {
        self$`etsy_shared_secret` <- this_object$`etsy_shared_secret`
      }
      if (!is.null(this_object$`etsy_access_token`)) {
        self$`etsy_access_token` <- this_object$`etsy_access_token`
      }
      if (!is.null(this_object$`etsy_token_secret`)) {
        self$`etsy_token_secret` <- this_object$`etsy_token_secret`
      }
      if (!is.null(this_object$`etsy_client_id`)) {
        self$`etsy_client_id` <- this_object$`etsy_client_id`
      }
      if (!is.null(this_object$`etsy_refresh_token`)) {
        self$`etsy_refresh_token` <- this_object$`etsy_refresh_token`
      }
      if (!is.null(this_object$`facebook_app_id`)) {
        self$`facebook_app_id` <- this_object$`facebook_app_id`
      }
      if (!is.null(this_object$`facebook_app_secret`)) {
        self$`facebook_app_secret` <- this_object$`facebook_app_secret`
      }
      if (!is.null(this_object$`facebook_access_token`)) {
        self$`facebook_access_token` <- this_object$`facebook_access_token`
      }
      if (!is.null(this_object$`facebook_business_id`)) {
        self$`facebook_business_id` <- this_object$`facebook_business_id`
      }
      if (!is.null(this_object$`neto_api_key`)) {
        self$`neto_api_key` <- this_object$`neto_api_key`
      }
      if (!is.null(this_object$`neto_api_username`)) {
        self$`neto_api_username` <- this_object$`neto_api_username`
      }
      if (!is.null(this_object$`shopline_access_token`)) {
        self$`shopline_access_token` <- this_object$`shopline_access_token`
      }
      if (!is.null(this_object$`shopline_app_key`)) {
        self$`shopline_app_key` <- this_object$`shopline_app_key`
      }
      if (!is.null(this_object$`shopline_app_secret`)) {
        self$`shopline_app_secret` <- this_object$`shopline_app_secret`
      }
      if (!is.null(this_object$`shopline_shared_secret`)) {
        self$`shopline_shared_secret` <- this_object$`shopline_shared_secret`
      }
      if (!is.null(this_object$`shopify_access_token`)) {
        self$`shopify_access_token` <- this_object$`shopify_access_token`
      }
      if (!is.null(this_object$`shopify_client_id`)) {
        self$`shopify_client_id` <- this_object$`shopify_client_id`
      }
      if (!is.null(this_object$`shopify_api_key`)) {
        self$`shopify_api_key` <- this_object$`shopify_api_key`
      }
      if (!is.null(this_object$`shopify_api_password`)) {
        self$`shopify_api_password` <- this_object$`shopify_api_password`
      }
      if (!is.null(this_object$`shopify_shared_secret`)) {
        self$`shopify_shared_secret` <- this_object$`shopify_shared_secret`
      }
      if (!is.null(this_object$`shopee_partner_id`)) {
        self$`shopee_partner_id` <- this_object$`shopee_partner_id`
      }
      if (!is.null(this_object$`shopee_partner_key`)) {
        self$`shopee_partner_key` <- this_object$`shopee_partner_key`
      }
      if (!is.null(this_object$`shopee_shop_id`)) {
        self$`shopee_shop_id` <- this_object$`shopee_shop_id`
      }
      if (!is.null(this_object$`shopee_refresh_token`)) {
        self$`shopee_refresh_token` <- this_object$`shopee_refresh_token`
      }
      if (!is.null(this_object$`shopee_region`)) {
        self$`shopee_region` <- this_object$`shopee_region`
      }
      if (!is.null(this_object$`shopee_environment`)) {
        self$`shopee_environment` <- this_object$`shopee_environment`
      }
      if (!is.null(this_object$`shoplazza_access_token`)) {
        self$`shoplazza_access_token` <- this_object$`shoplazza_access_token`
      }
      if (!is.null(this_object$`shoplazza_shared_secret`)) {
        self$`shoplazza_shared_secret` <- this_object$`shoplazza_shared_secret`
      }
      if (!is.null(this_object$`shopware_access_key`)) {
        self$`shopware_access_key` <- this_object$`shopware_access_key`
      }
      if (!is.null(this_object$`unas_api_key`)) {
        self$`unas_api_key` <- this_object$`unas_api_key`
      }
      if (!is.null(this_object$`shopware_api_key`)) {
        self$`shopware_api_key` <- this_object$`shopware_api_key`
      }
      if (!is.null(this_object$`shopware_api_secret`)) {
        self$`shopware_api_secret` <- this_object$`shopware_api_secret`
      }
      if (!is.null(this_object$`miva_access_token`)) {
        self$`miva_access_token` <- this_object$`miva_access_token`
      }
      if (!is.null(this_object$`miva_signature`)) {
        self$`miva_signature` <- this_object$`miva_signature`
      }
      if (!is.null(this_object$`tiendanube_user_id`)) {
        self$`tiendanube_user_id` <- this_object$`tiendanube_user_id`
      }
      if (!is.null(this_object$`tiendanube_access_token`)) {
        self$`tiendanube_access_token` <- this_object$`tiendanube_access_token`
      }
      if (!is.null(this_object$`tiendanube_client_secret`)) {
        self$`tiendanube_client_secret` <- this_object$`tiendanube_client_secret`
      }
      if (!is.null(this_object$`volusion_login`)) {
        self$`volusion_login` <- this_object$`volusion_login`
      }
      if (!is.null(this_object$`volusion_password`)) {
        self$`volusion_password` <- this_object$`volusion_password`
      }
      if (!is.null(this_object$`hybris_client_id`)) {
        self$`hybris_client_id` <- this_object$`hybris_client_id`
      }
      if (!is.null(this_object$`hybris_client_secret`)) {
        self$`hybris_client_secret` <- this_object$`hybris_client_secret`
      }
      if (!is.null(this_object$`hybris_username`)) {
        self$`hybris_username` <- this_object$`hybris_username`
      }
      if (!is.null(this_object$`hybris_password`)) {
        self$`hybris_password` <- this_object$`hybris_password`
      }
      if (!is.null(this_object$`hybris_websites`)) {
        self$`hybris_websites` <- ApiClient$new()$deserializeObj(this_object$`hybris_websites`, "array[AccountCartAddHybrisWebsitesInner]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`square_client_id`)) {
        self$`square_client_id` <- this_object$`square_client_id`
      }
      if (!is.null(this_object$`square_client_secret`)) {
        self$`square_client_secret` <- this_object$`square_client_secret`
      }
      if (!is.null(this_object$`square_refresh_token`)) {
        self$`square_refresh_token` <- this_object$`square_refresh_token`
      }
      if (!is.null(this_object$`squarespace_api_key`)) {
        self$`squarespace_api_key` <- this_object$`squarespace_api_key`
      }
      if (!is.null(this_object$`squarespace_client_id`)) {
        self$`squarespace_client_id` <- this_object$`squarespace_client_id`
      }
      if (!is.null(this_object$`squarespace_client_secret`)) {
        self$`squarespace_client_secret` <- this_object$`squarespace_client_secret`
      }
      if (!is.null(this_object$`squarespace_access_token`)) {
        self$`squarespace_access_token` <- this_object$`squarespace_access_token`
      }
      if (!is.null(this_object$`squarespace_refresh_token`)) {
        self$`squarespace_refresh_token` <- this_object$`squarespace_refresh_token`
      }
      if (!is.null(this_object$`commercehq_api_key`)) {
        self$`commercehq_api_key` <- this_object$`commercehq_api_key`
      }
      if (!is.null(this_object$`commercehq_api_password`)) {
        self$`commercehq_api_password` <- this_object$`commercehq_api_password`
      }
      if (!is.null(this_object$`wc_consumer_key`)) {
        self$`wc_consumer_key` <- this_object$`wc_consumer_key`
      }
      if (!is.null(this_object$`wc_consumer_secret`)) {
        self$`wc_consumer_secret` <- this_object$`wc_consumer_secret`
      }
      if (!is.null(this_object$`magento_consumer_key`)) {
        self$`magento_consumer_key` <- this_object$`magento_consumer_key`
      }
      if (!is.null(this_object$`magento_consumer_secret`)) {
        self$`magento_consumer_secret` <- this_object$`magento_consumer_secret`
      }
      if (!is.null(this_object$`magento_access_token`)) {
        self$`magento_access_token` <- this_object$`magento_access_token`
      }
      if (!is.null(this_object$`magento_token_secret`)) {
        self$`magento_token_secret` <- this_object$`magento_token_secret`
      }
      if (!is.null(this_object$`prestashop_webservice_key`)) {
        self$`prestashop_webservice_key` <- this_object$`prestashop_webservice_key`
      }
      if (!is.null(this_object$`wix_app_id`)) {
        self$`wix_app_id` <- this_object$`wix_app_id`
      }
      if (!is.null(this_object$`wix_app_secret_key`)) {
        self$`wix_app_secret_key` <- this_object$`wix_app_secret_key`
      }
      if (!is.null(this_object$`wix_instance_id`)) {
        self$`wix_instance_id` <- this_object$`wix_instance_id`
      }
      if (!is.null(this_object$`wix_refresh_token`)) {
        self$`wix_refresh_token` <- this_object$`wix_refresh_token`
      }
      if (!is.null(this_object$`mercado_libre_app_id`)) {
        self$`mercado_libre_app_id` <- this_object$`mercado_libre_app_id`
      }
      if (!is.null(this_object$`mercado_libre_app_secret_key`)) {
        self$`mercado_libre_app_secret_key` <- this_object$`mercado_libre_app_secret_key`
      }
      if (!is.null(this_object$`mercado_libre_refresh_token`)) {
        self$`mercado_libre_refresh_token` <- this_object$`mercado_libre_refresh_token`
      }
      if (!is.null(this_object$`zid_client_id`)) {
        self$`zid_client_id` <- this_object$`zid_client_id`
      }
      if (!is.null(this_object$`zid_client_secret`)) {
        self$`zid_client_secret` <- this_object$`zid_client_secret`
      }
      if (!is.null(this_object$`zid_access_token`)) {
        self$`zid_access_token` <- this_object$`zid_access_token`
      }
      if (!is.null(this_object$`zid_authorization`)) {
        self$`zid_authorization` <- this_object$`zid_authorization`
      }
      if (!is.null(this_object$`zid_refresh_token`)) {
        self$`zid_refresh_token` <- this_object$`zid_refresh_token`
      }
      if (!is.null(this_object$`jumpseller_client_id`)) {
        self$`jumpseller_client_id` <- this_object$`jumpseller_client_id`
      }
      if (!is.null(this_object$`jumpseller_client_secret`)) {
        self$`jumpseller_client_secret` <- this_object$`jumpseller_client_secret`
      }
      if (!is.null(this_object$`jumpseller_refresh_token`)) {
        self$`jumpseller_refresh_token` <- this_object$`jumpseller_refresh_token`
      }
      if (!is.null(this_object$`jumpseller_login`)) {
        self$`jumpseller_login` <- this_object$`jumpseller_login`
      }
      if (!is.null(this_object$`jumpseller_authtoken`)) {
        self$`jumpseller_authtoken` <- this_object$`jumpseller_authtoken`
      }
      if (!is.null(this_object$`flipkart_client_id`)) {
        self$`flipkart_client_id` <- this_object$`flipkart_client_id`
      }
      if (!is.null(this_object$`flipkart_client_secret`)) {
        self$`flipkart_client_secret` <- this_object$`flipkart_client_secret`
      }
      if (!is.null(this_object$`allegro_client_id`)) {
        self$`allegro_client_id` <- this_object$`allegro_client_id`
      }
      if (!is.null(this_object$`allegro_client_secret`)) {
        self$`allegro_client_secret` <- this_object$`allegro_client_secret`
      }
      if (!is.null(this_object$`allegro_access_token`)) {
        self$`allegro_access_token` <- this_object$`allegro_access_token`
      }
      if (!is.null(this_object$`allegro_refresh_token`)) {
        self$`allegro_refresh_token` <- this_object$`allegro_refresh_token`
      }
      if (!is.null(this_object$`allegro_environment`)) {
        self$`allegro_environment` <- this_object$`allegro_environment`
      }
      if (!is.null(this_object$`zoho_client_id`)) {
        self$`zoho_client_id` <- this_object$`zoho_client_id`
      }
      if (!is.null(this_object$`zoho_client_secret`)) {
        self$`zoho_client_secret` <- this_object$`zoho_client_secret`
      }
      if (!is.null(this_object$`zoho_refresh_token`)) {
        self$`zoho_refresh_token` <- this_object$`zoho_refresh_token`
      }
      if (!is.null(this_object$`zoho_region`)) {
        self$`zoho_region` <- this_object$`zoho_region`
      }
      if (!is.null(this_object$`otto_client_id`)) {
        self$`otto_client_id` <- this_object$`otto_client_id`
      }
      if (!is.null(this_object$`otto_client_secret`)) {
        self$`otto_client_secret` <- this_object$`otto_client_secret`
      }
      if (!is.null(this_object$`otto_app_id`)) {
        self$`otto_app_id` <- this_object$`otto_app_id`
      }
      if (!is.null(this_object$`otto_refresh_token`)) {
        self$`otto_refresh_token` <- this_object$`otto_refresh_token`
      }
      if (!is.null(this_object$`otto_environment`)) {
        self$`otto_environment` <- this_object$`otto_environment`
      }
      if (!is.null(this_object$`otto_access_token`)) {
        self$`otto_access_token` <- this_object$`otto_access_token`
      }
      if (!is.null(this_object$`tiktokshop_app_key`)) {
        self$`tiktokshop_app_key` <- this_object$`tiktokshop_app_key`
      }
      if (!is.null(this_object$`tiktokshop_app_secret`)) {
        self$`tiktokshop_app_secret` <- this_object$`tiktokshop_app_secret`
      }
      if (!is.null(this_object$`tiktokshop_refresh_token`)) {
        self$`tiktokshop_refresh_token` <- this_object$`tiktokshop_refresh_token`
      }
      if (!is.null(this_object$`tiktokshop_access_token`)) {
        self$`tiktokshop_access_token` <- this_object$`tiktokshop_access_token`
      }
      if (!is.null(this_object$`salla_client_id`)) {
        self$`salla_client_id` <- this_object$`salla_client_id`
      }
      if (!is.null(this_object$`salla_client_secret`)) {
        self$`salla_client_secret` <- this_object$`salla_client_secret`
      }
      if (!is.null(this_object$`salla_refresh_token`)) {
        self$`salla_refresh_token` <- this_object$`salla_refresh_token`
      }
      if (!is.null(this_object$`salla_access_token`)) {
        self$`salla_access_token` <- this_object$`salla_access_token`
      }
      if (!is.null(this_object$`temu_app_key`)) {
        self$`temu_app_key` <- this_object$`temu_app_key`
      }
      if (!is.null(this_object$`temu_app_secret`)) {
        self$`temu_app_secret` <- this_object$`temu_app_secret`
      }
      if (!is.null(this_object$`temu_access_token`)) {
        self$`temu_access_token` <- this_object$`temu_access_token`
      }
      if (!is.null(this_object$`temu_region`)) {
        self$`temu_region` <- this_object$`temu_region`
      }
      if (!is.null(this_object$`scapi_client_id`)) {
        self$`scapi_client_id` <- this_object$`scapi_client_id`
      }
      if (!is.null(this_object$`scapi_client_secret`)) {
        self$`scapi_client_secret` <- this_object$`scapi_client_secret`
      }
      if (!is.null(this_object$`scapi_organization_id`)) {
        self$`scapi_organization_id` <- this_object$`scapi_organization_id`
      }
      if (!is.null(this_object$`scapi_short_code`)) {
        self$`scapi_short_code` <- this_object$`scapi_short_code`
      }
      if (!is.null(this_object$`scapi_scopes`)) {
        self$`scapi_scopes` <- this_object$`scapi_scopes`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return AccountCartAdd in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of AccountCartAdd
    #'
    #' @param input_json the JSON input
    #' @return the instance of AccountCartAdd
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`cart_id`) && !(this_object$`cart_id` %in% c("3DCart", "3DCartApi", "AceShop", "AmazonSP", "Americommerce", "AspDotNetStorefront", "BigCartel", "Bricklink", "BigcommerceApi", "Bol", "CommerceHQ", "Creloaded", "Cscart", "Cubecart", "Demandware", "EBay", "Ecwid", "EtsyAPIv3", "Facebook", "Flipkart", "Gambio", "Hybris", "JooCart", "Jumpseller", "Lazada", "LightSpeed", "Magento1212", "Magento2Api", "MercadoLibre", "MijoShop", "Miva", "Neto", "Opencart14", "Oscmax2", "Oscommerce22ms2", "Otto", "Oxid", "Pinnacle", "Prestashop", "PrestashopApi", "SSPremium", "Salla", "SCAPI", "Shopify", "Shopee", "Shoplazza", "Shopline", "Shopware", "ShopwareApi", "Square", "Squarespace", "Temu", "Tiendanube", "TikTokShop", "Tomatocart", "Ubercart", "Unas", "Virtuemart", "Volusion", "WPecommerce", "Walmart", "WebAsyst", "Wix", "Woocommerce", "WoocommerceApi", "Xcart", "Xtcommerce", "XtcommerceVeyton", "Zencart137", "Zid", "Zoey", "Zoho"))) {
        stop(paste("Error! \"", this_object$`cart_id`, "\" cannot be assigned to `cart_id`. Must be \"3DCart\", \"3DCartApi\", \"AceShop\", \"AmazonSP\", \"Americommerce\", \"AspDotNetStorefront\", \"BigCartel\", \"Bricklink\", \"BigcommerceApi\", \"Bol\", \"CommerceHQ\", \"Creloaded\", \"Cscart\", \"Cubecart\", \"Demandware\", \"EBay\", \"Ecwid\", \"EtsyAPIv3\", \"Facebook\", \"Flipkart\", \"Gambio\", \"Hybris\", \"JooCart\", \"Jumpseller\", \"Lazada\", \"LightSpeed\", \"Magento1212\", \"Magento2Api\", \"MercadoLibre\", \"MijoShop\", \"Miva\", \"Neto\", \"Opencart14\", \"Oscmax2\", \"Oscommerce22ms2\", \"Otto\", \"Oxid\", \"Pinnacle\", \"Prestashop\", \"PrestashopApi\", \"SSPremium\", \"Salla\", \"SCAPI\", \"Shopify\", \"Shopee\", \"Shoplazza\", \"Shopline\", \"Shopware\", \"ShopwareApi\", \"Square\", \"Squarespace\", \"Temu\", \"Tiendanube\", \"TikTokShop\", \"Tomatocart\", \"Ubercart\", \"Unas\", \"Virtuemart\", \"Volusion\", \"WPecommerce\", \"Walmart\", \"WebAsyst\", \"Wix\", \"Woocommerce\", \"WoocommerceApi\", \"Xcart\", \"Xtcommerce\", \"XtcommerceVeyton\", \"Zencart137\", \"Zid\", \"Zoey\", \"Zoho\".", sep = ""))
      }
      self$`cart_id` <- this_object$`cart_id`
      self$`store_url` <- this_object$`store_url`
      self$`bridge_url` <- this_object$`bridge_url`
      self$`store_root` <- this_object$`store_root`
      self$`store_key` <- this_object$`store_key`
      self$`label` <- this_object$`label`
      self$`custom_label` <- this_object$`custom_label`
      self$`validate_version` <- this_object$`validate_version`
      self$`verify` <- this_object$`verify`
      self$`db_tables_prefix` <- this_object$`db_tables_prefix`
      self$`user_agent` <- this_object$`user_agent`
      self$`ftp_host` <- this_object$`ftp_host`
      self$`ftp_user` <- this_object$`ftp_user`
      self$`ftp_password` <- this_object$`ftp_password`
      self$`ftp_port` <- this_object$`ftp_port`
      self$`ftp_store_dir` <- this_object$`ftp_store_dir`
      self$`3dcart_private_key` <- this_object$`3dcart_private_key`
      self$`3dcart_access_token` <- this_object$`3dcart_access_token`
      self$`3dcartapi_api_key` <- this_object$`3dcartapi_api_key`
      self$`amazon_sp_client_id` <- this_object$`amazon_sp_client_id`
      self$`amazon_sp_client_secret` <- this_object$`amazon_sp_client_secret`
      self$`amazon_sp_refresh_token` <- this_object$`amazon_sp_refresh_token`
      self$`amazon_sp_aws_region` <- this_object$`amazon_sp_aws_region`
      self$`amazon_sp_api_environment` <- this_object$`amazon_sp_api_environment`
      self$`amazon_seller_id` <- this_object$`amazon_seller_id`
      self$`aspdotnetstorefront_api_user` <- this_object$`aspdotnetstorefront_api_user`
      self$`aspdotnetstorefront_api_pass` <- this_object$`aspdotnetstorefront_api_pass`
      self$`americommerce_app_id` <- this_object$`americommerce_app_id`
      self$`americommerce_app_secret` <- this_object$`americommerce_app_secret`
      self$`americommerce_access_token` <- this_object$`americommerce_access_token`
      self$`americommerce_refresh_token` <- this_object$`americommerce_refresh_token`
      self$`bigcommerceapi_admin_account` <- this_object$`bigcommerceapi_admin_account`
      self$`bigcommerceapi_api_path` <- this_object$`bigcommerceapi_api_path`
      self$`bigcommerceapi_api_key` <- this_object$`bigcommerceapi_api_key`
      self$`bigcommerceapi_client_id` <- this_object$`bigcommerceapi_client_id`
      self$`bigcommerceapi_access_token` <- this_object$`bigcommerceapi_access_token`
      self$`bigcommerceapi_context` <- this_object$`bigcommerceapi_context`
      self$`bol_api_key` <- this_object$`bol_api_key`
      self$`bol_api_secret` <- this_object$`bol_api_secret`
      self$`bol_retailer_id` <- this_object$`bol_retailer_id`
      self$`bigcartel_user_name` <- this_object$`bigcartel_user_name`
      self$`bigcartel_password` <- this_object$`bigcartel_password`
      self$`bricklink_consumer_key` <- this_object$`bricklink_consumer_key`
      self$`bricklink_consumer_secret` <- this_object$`bricklink_consumer_secret`
      self$`bricklink_token` <- this_object$`bricklink_token`
      self$`bricklink_token_secret` <- this_object$`bricklink_token_secret`
      self$`demandware_client_id` <- this_object$`demandware_client_id`
      self$`demandware_api_password` <- this_object$`demandware_api_password`
      self$`demandware_user_name` <- this_object$`demandware_user_name`
      self$`demandware_user_password` <- this_object$`demandware_user_password`
      self$`ebay_client_id` <- this_object$`ebay_client_id`
      self$`ebay_client_secret` <- this_object$`ebay_client_secret`
      self$`ebay_runame` <- this_object$`ebay_runame`
      self$`ebay_access_token` <- this_object$`ebay_access_token`
      self$`ebay_refresh_token` <- this_object$`ebay_refresh_token`
      self$`ebay_environment` <- this_object$`ebay_environment`
      self$`ebay_site_id` <- this_object$`ebay_site_id`
      self$`walmart_client_id` <- this_object$`walmart_client_id`
      self$`walmart_client_secret` <- this_object$`walmart_client_secret`
      self$`walmart_environment` <- this_object$`walmart_environment`
      self$`walmart_channel_type` <- this_object$`walmart_channel_type`
      self$`walmart_region` <- this_object$`walmart_region`
      self$`ecwid_acess_token` <- this_object$`ecwid_acess_token`
      self$`ecwid_store_id` <- this_object$`ecwid_store_id`
      self$`lazada_app_id` <- this_object$`lazada_app_id`
      self$`lazada_app_secret` <- this_object$`lazada_app_secret`
      self$`lazada_refresh_token` <- this_object$`lazada_refresh_token`
      self$`lazada_region` <- this_object$`lazada_region`
      self$`lightspeed_api_key` <- this_object$`lightspeed_api_key`
      self$`lightspeed_api_secret` <- this_object$`lightspeed_api_secret`
      self$`etsy_keystring` <- this_object$`etsy_keystring`
      self$`etsy_shared_secret` <- this_object$`etsy_shared_secret`
      self$`etsy_access_token` <- this_object$`etsy_access_token`
      self$`etsy_token_secret` <- this_object$`etsy_token_secret`
      self$`etsy_client_id` <- this_object$`etsy_client_id`
      self$`etsy_refresh_token` <- this_object$`etsy_refresh_token`
      self$`facebook_app_id` <- this_object$`facebook_app_id`
      self$`facebook_app_secret` <- this_object$`facebook_app_secret`
      self$`facebook_access_token` <- this_object$`facebook_access_token`
      self$`facebook_business_id` <- this_object$`facebook_business_id`
      self$`neto_api_key` <- this_object$`neto_api_key`
      self$`neto_api_username` <- this_object$`neto_api_username`
      self$`shopline_access_token` <- this_object$`shopline_access_token`
      self$`shopline_app_key` <- this_object$`shopline_app_key`
      self$`shopline_app_secret` <- this_object$`shopline_app_secret`
      self$`shopline_shared_secret` <- this_object$`shopline_shared_secret`
      self$`shopify_access_token` <- this_object$`shopify_access_token`
      self$`shopify_client_id` <- this_object$`shopify_client_id`
      self$`shopify_api_key` <- this_object$`shopify_api_key`
      self$`shopify_api_password` <- this_object$`shopify_api_password`
      self$`shopify_shared_secret` <- this_object$`shopify_shared_secret`
      self$`shopee_partner_id` <- this_object$`shopee_partner_id`
      self$`shopee_partner_key` <- this_object$`shopee_partner_key`
      self$`shopee_shop_id` <- this_object$`shopee_shop_id`
      self$`shopee_refresh_token` <- this_object$`shopee_refresh_token`
      self$`shopee_region` <- this_object$`shopee_region`
      self$`shopee_environment` <- this_object$`shopee_environment`
      self$`shoplazza_access_token` <- this_object$`shoplazza_access_token`
      self$`shoplazza_shared_secret` <- this_object$`shoplazza_shared_secret`
      self$`shopware_access_key` <- this_object$`shopware_access_key`
      self$`unas_api_key` <- this_object$`unas_api_key`
      self$`shopware_api_key` <- this_object$`shopware_api_key`
      self$`shopware_api_secret` <- this_object$`shopware_api_secret`
      self$`miva_access_token` <- this_object$`miva_access_token`
      self$`miva_signature` <- this_object$`miva_signature`
      self$`tiendanube_user_id` <- this_object$`tiendanube_user_id`
      self$`tiendanube_access_token` <- this_object$`tiendanube_access_token`
      self$`tiendanube_client_secret` <- this_object$`tiendanube_client_secret`
      self$`volusion_login` <- this_object$`volusion_login`
      self$`volusion_password` <- this_object$`volusion_password`
      self$`hybris_client_id` <- this_object$`hybris_client_id`
      self$`hybris_client_secret` <- this_object$`hybris_client_secret`
      self$`hybris_username` <- this_object$`hybris_username`
      self$`hybris_password` <- this_object$`hybris_password`
      self$`hybris_websites` <- ApiClient$new()$deserializeObj(this_object$`hybris_websites`, "array[AccountCartAddHybrisWebsitesInner]", loadNamespace("openapi"))
      self$`square_client_id` <- this_object$`square_client_id`
      self$`square_client_secret` <- this_object$`square_client_secret`
      self$`square_refresh_token` <- this_object$`square_refresh_token`
      self$`squarespace_api_key` <- this_object$`squarespace_api_key`
      self$`squarespace_client_id` <- this_object$`squarespace_client_id`
      self$`squarespace_client_secret` <- this_object$`squarespace_client_secret`
      self$`squarespace_access_token` <- this_object$`squarespace_access_token`
      self$`squarespace_refresh_token` <- this_object$`squarespace_refresh_token`
      self$`commercehq_api_key` <- this_object$`commercehq_api_key`
      self$`commercehq_api_password` <- this_object$`commercehq_api_password`
      self$`wc_consumer_key` <- this_object$`wc_consumer_key`
      self$`wc_consumer_secret` <- this_object$`wc_consumer_secret`
      self$`magento_consumer_key` <- this_object$`magento_consumer_key`
      self$`magento_consumer_secret` <- this_object$`magento_consumer_secret`
      self$`magento_access_token` <- this_object$`magento_access_token`
      self$`magento_token_secret` <- this_object$`magento_token_secret`
      self$`prestashop_webservice_key` <- this_object$`prestashop_webservice_key`
      self$`wix_app_id` <- this_object$`wix_app_id`
      self$`wix_app_secret_key` <- this_object$`wix_app_secret_key`
      self$`wix_instance_id` <- this_object$`wix_instance_id`
      self$`wix_refresh_token` <- this_object$`wix_refresh_token`
      self$`mercado_libre_app_id` <- this_object$`mercado_libre_app_id`
      self$`mercado_libre_app_secret_key` <- this_object$`mercado_libre_app_secret_key`
      self$`mercado_libre_refresh_token` <- this_object$`mercado_libre_refresh_token`
      self$`zid_client_id` <- this_object$`zid_client_id`
      self$`zid_client_secret` <- this_object$`zid_client_secret`
      self$`zid_access_token` <- this_object$`zid_access_token`
      self$`zid_authorization` <- this_object$`zid_authorization`
      self$`zid_refresh_token` <- this_object$`zid_refresh_token`
      self$`jumpseller_client_id` <- this_object$`jumpseller_client_id`
      self$`jumpseller_client_secret` <- this_object$`jumpseller_client_secret`
      self$`jumpseller_refresh_token` <- this_object$`jumpseller_refresh_token`
      self$`jumpseller_login` <- this_object$`jumpseller_login`
      self$`jumpseller_authtoken` <- this_object$`jumpseller_authtoken`
      self$`flipkart_client_id` <- this_object$`flipkart_client_id`
      self$`flipkart_client_secret` <- this_object$`flipkart_client_secret`
      self$`allegro_client_id` <- this_object$`allegro_client_id`
      self$`allegro_client_secret` <- this_object$`allegro_client_secret`
      self$`allegro_access_token` <- this_object$`allegro_access_token`
      self$`allegro_refresh_token` <- this_object$`allegro_refresh_token`
      self$`allegro_environment` <- this_object$`allegro_environment`
      self$`zoho_client_id` <- this_object$`zoho_client_id`
      self$`zoho_client_secret` <- this_object$`zoho_client_secret`
      self$`zoho_refresh_token` <- this_object$`zoho_refresh_token`
      self$`zoho_region` <- this_object$`zoho_region`
      self$`otto_client_id` <- this_object$`otto_client_id`
      self$`otto_client_secret` <- this_object$`otto_client_secret`
      self$`otto_app_id` <- this_object$`otto_app_id`
      self$`otto_refresh_token` <- this_object$`otto_refresh_token`
      self$`otto_environment` <- this_object$`otto_environment`
      self$`otto_access_token` <- this_object$`otto_access_token`
      self$`tiktokshop_app_key` <- this_object$`tiktokshop_app_key`
      self$`tiktokshop_app_secret` <- this_object$`tiktokshop_app_secret`
      self$`tiktokshop_refresh_token` <- this_object$`tiktokshop_refresh_token`
      self$`tiktokshop_access_token` <- this_object$`tiktokshop_access_token`
      self$`salla_client_id` <- this_object$`salla_client_id`
      self$`salla_client_secret` <- this_object$`salla_client_secret`
      self$`salla_refresh_token` <- this_object$`salla_refresh_token`
      self$`salla_access_token` <- this_object$`salla_access_token`
      self$`temu_app_key` <- this_object$`temu_app_key`
      self$`temu_app_secret` <- this_object$`temu_app_secret`
      self$`temu_access_token` <- this_object$`temu_access_token`
      self$`temu_region` <- this_object$`temu_region`
      self$`scapi_client_id` <- this_object$`scapi_client_id`
      self$`scapi_client_secret` <- this_object$`scapi_client_secret`
      self$`scapi_organization_id` <- this_object$`scapi_organization_id`
      self$`scapi_short_code` <- this_object$`scapi_short_code`
      self$`scapi_scopes` <- this_object$`scapi_scopes`
      self
    },

    #' @description
    #' Validate JSON input with respect to AccountCartAdd and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
      # check the required field `cart_id`
      if (!is.null(input_json$`cart_id`)) {
        if (!(is.character(input_json$`cart_id`) && length(input_json$`cart_id`) == 1)) {
          stop(paste("Error! Invalid data for `cart_id`. Must be a string:", input_json$`cart_id`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for AccountCartAdd: the required field `cart_id` is missing."))
      }
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of AccountCartAdd
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      # check if the required `cart_id` is null
      if (is.null(self$`cart_id`)) {
        return(FALSE)
      }

      if (length(self$`hybris_websites`) < 1) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      # check if the required `cart_id` is null
      if (is.null(self$`cart_id`)) {
        invalid_fields["cart_id"] <- "Non-nullable required field `cart_id` cannot be null."
      }

      if (length(self$`hybris_websites`) < 1) {
        invalid_fields["hybris_websites"] <- "Invalid length for ``, number of items must be greater than or equal to 1."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# AccountCartAdd$unlock()
#
## Below is an example to define the print function
# AccountCartAdd$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# AccountCartAdd$lock()

