#' Create a new ProductGroupItem
#'
#' @description
#' ProductGroupItem Class
#'
#' @docType class
#' @title ProductGroupItem
#' @description ProductGroupItem Class
#' @format An \code{R6Class} generator object
#' @field child_item_id  character [optional]
#' @field product_id  character [optional]
#' @field default_qty_in_pack  numeric [optional]
#' @field is_qty_in_pack_fixed  character [optional]
#' @field price  numeric [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductGroupItem <- R6::R6Class(
  "ProductGroupItem",
  public = list(
    `child_item_id` = NULL,
    `product_id` = NULL,
    `default_qty_in_pack` = NULL,
    `is_qty_in_pack_fixed` = NULL,
    `price` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new ProductGroupItem class.
    #'
    #' @param child_item_id child_item_id
    #' @param product_id product_id
    #' @param default_qty_in_pack default_qty_in_pack
    #' @param is_qty_in_pack_fixed is_qty_in_pack_fixed
    #' @param price price
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`child_item_id` = NULL, `product_id` = NULL, `default_qty_in_pack` = NULL, `is_qty_in_pack_fixed` = NULL, `price` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`child_item_id`)) {
        if (!(is.character(`child_item_id`) && length(`child_item_id`) == 1)) {
          stop(paste("Error! Invalid data for `child_item_id`. Must be a string:", `child_item_id`))
        }
        self$`child_item_id` <- `child_item_id`
      }
      if (!is.null(`product_id`)) {
        if (!(is.character(`product_id`) && length(`product_id`) == 1)) {
          stop(paste("Error! Invalid data for `product_id`. Must be a string:", `product_id`))
        }
        self$`product_id` <- `product_id`
      }
      if (!is.null(`default_qty_in_pack`)) {
        self$`default_qty_in_pack` <- `default_qty_in_pack`
      }
      if (!is.null(`is_qty_in_pack_fixed`)) {
        if (!(is.logical(`is_qty_in_pack_fixed`) && length(`is_qty_in_pack_fixed`) == 1)) {
          stop(paste("Error! Invalid data for `is_qty_in_pack_fixed`. Must be a boolean:", `is_qty_in_pack_fixed`))
        }
        self$`is_qty_in_pack_fixed` <- `is_qty_in_pack_fixed`
      }
      if (!is.null(`price`)) {
        self$`price` <- `price`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductGroupItem as a base R list.
    #' @examples
    #' # convert array of ProductGroupItem (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductGroupItem to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductGroupItemObject <- list()
      if (!is.null(self$`child_item_id`)) {
        ProductGroupItemObject[["child_item_id"]] <-
          self$`child_item_id`
      }
      if (!is.null(self$`product_id`)) {
        ProductGroupItemObject[["product_id"]] <-
          self$`product_id`
      }
      if (!is.null(self$`default_qty_in_pack`)) {
        ProductGroupItemObject[["default_qty_in_pack"]] <-
          self$`default_qty_in_pack`
      }
      if (!is.null(self$`is_qty_in_pack_fixed`)) {
        ProductGroupItemObject[["is_qty_in_pack_fixed"]] <-
          self$`is_qty_in_pack_fixed`
      }
      if (!is.null(self$`price`)) {
        ProductGroupItemObject[["price"]] <-
          self$`price`
      }
      if (!is.null(self$`additional_fields`)) {
        ProductGroupItemObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        ProductGroupItemObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(ProductGroupItemObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductGroupItem
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductGroupItem
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`child_item_id`)) {
        self$`child_item_id` <- this_object$`child_item_id`
      }
      if (!is.null(this_object$`product_id`)) {
        self$`product_id` <- this_object$`product_id`
      }
      if (!is.null(this_object$`default_qty_in_pack`)) {
        self$`default_qty_in_pack` <- this_object$`default_qty_in_pack`
      }
      if (!is.null(this_object$`is_qty_in_pack_fixed`)) {
        self$`is_qty_in_pack_fixed` <- this_object$`is_qty_in_pack_fixed`
      }
      if (!is.null(this_object$`price`)) {
        self$`price` <- this_object$`price`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductGroupItem in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductGroupItem
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductGroupItem
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`child_item_id` <- this_object$`child_item_id`
      self$`product_id` <- this_object$`product_id`
      self$`default_qty_in_pack` <- this_object$`default_qty_in_pack`
      self$`is_qty_in_pack_fixed` <- this_object$`is_qty_in_pack_fixed`
      self$`price` <- this_object$`price`
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductGroupItem and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductGroupItem
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductGroupItem$unlock()
#
## Below is an example to define the print function
# ProductGroupItem$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductGroupItem$lock()

