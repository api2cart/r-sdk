#' Create a new ProductInventory
#'
#' @description
#' ProductInventory Class
#'
#' @docType class
#' @title ProductInventory
#' @description ProductInventory Class
#' @format An \code{R6Class} generator object
#' @field warehouse_id  character [optional]
#' @field quantity  numeric [optional]
#' @field in_stock  character [optional]
#' @field priority  integer [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductInventory <- R6::R6Class(
  "ProductInventory",
  public = list(
    `warehouse_id` = NULL,
    `quantity` = NULL,
    `in_stock` = NULL,
    `priority` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new ProductInventory class.
    #'
    #' @param warehouse_id warehouse_id
    #' @param quantity quantity
    #' @param in_stock in_stock
    #' @param priority priority
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`warehouse_id` = NULL, `quantity` = NULL, `in_stock` = NULL, `priority` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`warehouse_id`)) {
        if (!(is.character(`warehouse_id`) && length(`warehouse_id`) == 1)) {
          stop(paste("Error! Invalid data for `warehouse_id`. Must be a string:", `warehouse_id`))
        }
        self$`warehouse_id` <- `warehouse_id`
      }
      if (!is.null(`quantity`)) {
        self$`quantity` <- `quantity`
      }
      if (!is.null(`in_stock`)) {
        if (!(is.logical(`in_stock`) && length(`in_stock`) == 1)) {
          stop(paste("Error! Invalid data for `in_stock`. Must be a boolean:", `in_stock`))
        }
        self$`in_stock` <- `in_stock`
      }
      if (!is.null(`priority`)) {
        if (!(is.numeric(`priority`) && length(`priority`) == 1)) {
          stop(paste("Error! Invalid data for `priority`. Must be an integer:", `priority`))
        }
        self$`priority` <- `priority`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductInventory as a base R list.
    #' @examples
    #' # convert array of ProductInventory (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductInventory to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductInventoryObject <- list()
      if (!is.null(self$`warehouse_id`)) {
        ProductInventoryObject[["warehouse_id"]] <-
          self$`warehouse_id`
      }
      if (!is.null(self$`quantity`)) {
        ProductInventoryObject[["quantity"]] <-
          self$`quantity`
      }
      if (!is.null(self$`in_stock`)) {
        ProductInventoryObject[["in_stock"]] <-
          self$`in_stock`
      }
      if (!is.null(self$`priority`)) {
        ProductInventoryObject[["priority"]] <-
          self$`priority`
      }
      if (!is.null(self$`additional_fields`)) {
        ProductInventoryObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        ProductInventoryObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(ProductInventoryObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductInventory
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductInventory
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`warehouse_id`)) {
        self$`warehouse_id` <- this_object$`warehouse_id`
      }
      if (!is.null(this_object$`quantity`)) {
        self$`quantity` <- this_object$`quantity`
      }
      if (!is.null(this_object$`in_stock`)) {
        self$`in_stock` <- this_object$`in_stock`
      }
      if (!is.null(this_object$`priority`)) {
        self$`priority` <- this_object$`priority`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductInventory in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductInventory
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductInventory
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`warehouse_id` <- this_object$`warehouse_id`
      self$`quantity` <- this_object$`quantity`
      self$`in_stock` <- this_object$`in_stock`
      self$`priority` <- this_object$`priority`
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductInventory and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductInventory
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductInventory$unlock()
#
## Below is an example to define the print function
# ProductInventory$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductInventory$lock()

