#' Create a new ProductAddSpecificsInner
#'
#' @description
#' ProductAddSpecificsInner Class
#'
#' @docType class
#' @title ProductAddSpecificsInner
#' @description ProductAddSpecificsInner Class
#' @format An \code{R6Class} generator object
#' @field name  character [optional]
#' @field value  character [optional]
#' @field values  list(character) [optional]
#' @field used_for_variations  character [optional]
#' @field scale_id  integer [optional]
#' @field input_value  character [optional]
#' @field food_details  \link{ProductAddSpecificsInnerFoodDetails} [optional]
#' @field group_products_details  list(\link{ProductAddSpecificsInnerGroupProductsDetailsInner}) [optional]
#' @field booking_details  \link{ProductAddSpecificsInnerBookingDetails} [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductAddSpecificsInner <- R6::R6Class(
  "ProductAddSpecificsInner",
  public = list(
    `name` = NULL,
    `value` = NULL,
    `values` = NULL,
    `used_for_variations` = NULL,
    `scale_id` = NULL,
    `input_value` = NULL,
    `food_details` = NULL,
    `group_products_details` = NULL,
    `booking_details` = NULL,

    #' @description
    #' Initialize a new ProductAddSpecificsInner class.
    #'
    #' @param name name
    #' @param value value
    #' @param values values
    #' @param used_for_variations used_for_variations. Default to FALSE.
    #' @param scale_id scale_id
    #' @param input_value input_value
    #' @param food_details food_details
    #' @param group_products_details group_products_details
    #' @param booking_details booking_details
    #' @param ... Other optional arguments.
    initialize = function(`name` = NULL, `value` = NULL, `values` = NULL, `used_for_variations` = FALSE, `scale_id` = NULL, `input_value` = NULL, `food_details` = NULL, `group_products_details` = NULL, `booking_details` = NULL, ...) {
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`value`)) {
        if (!(is.character(`value`) && length(`value`) == 1)) {
          stop(paste("Error! Invalid data for `value`. Must be a string:", `value`))
        }
        self$`value` <- `value`
      }
      if (!is.null(`values`)) {
        stopifnot(is.vector(`values`), length(`values`) != 0)
        sapply(`values`, function(x) stopifnot(is.character(x)))
        self$`values` <- `values`
      }
      if (!is.null(`used_for_variations`)) {
        if (!(is.logical(`used_for_variations`) && length(`used_for_variations`) == 1)) {
          stop(paste("Error! Invalid data for `used_for_variations`. Must be a boolean:", `used_for_variations`))
        }
        self$`used_for_variations` <- `used_for_variations`
      }
      if (!is.null(`scale_id`)) {
        if (!(is.numeric(`scale_id`) && length(`scale_id`) == 1)) {
          stop(paste("Error! Invalid data for `scale_id`. Must be an integer:", `scale_id`))
        }
        self$`scale_id` <- `scale_id`
      }
      if (!is.null(`input_value`)) {
        if (!(is.character(`input_value`) && length(`input_value`) == 1)) {
          stop(paste("Error! Invalid data for `input_value`. Must be a string:", `input_value`))
        }
        self$`input_value` <- `input_value`
      }
      if (!is.null(`food_details`)) {
        stopifnot(R6::is.R6(`food_details`))
        self$`food_details` <- `food_details`
      }
      if (!is.null(`group_products_details`)) {
        stopifnot(is.vector(`group_products_details`), length(`group_products_details`) != 0)
        sapply(`group_products_details`, function(x) stopifnot(R6::is.R6(x)))
        self$`group_products_details` <- `group_products_details`
      }
      if (!is.null(`booking_details`)) {
        stopifnot(R6::is.R6(`booking_details`))
        self$`booking_details` <- `booking_details`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductAddSpecificsInner as a base R list.
    #' @examples
    #' # convert array of ProductAddSpecificsInner (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductAddSpecificsInner to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductAddSpecificsInnerObject <- list()
      if (!is.null(self$`name`)) {
        ProductAddSpecificsInnerObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`value`)) {
        ProductAddSpecificsInnerObject[["value"]] <-
          self$`value`
      }
      if (!is.null(self$`values`)) {
        ProductAddSpecificsInnerObject[["values"]] <-
          self$`values`
      }
      if (!is.null(self$`used_for_variations`)) {
        ProductAddSpecificsInnerObject[["used_for_variations"]] <-
          self$`used_for_variations`
      }
      if (!is.null(self$`scale_id`)) {
        ProductAddSpecificsInnerObject[["scale_id"]] <-
          self$`scale_id`
      }
      if (!is.null(self$`input_value`)) {
        ProductAddSpecificsInnerObject[["input_value"]] <-
          self$`input_value`
      }
      if (!is.null(self$`food_details`)) {
        ProductAddSpecificsInnerObject[["food_details"]] <-
          self$`food_details`$toSimpleType()
      }
      if (!is.null(self$`group_products_details`)) {
        ProductAddSpecificsInnerObject[["group_products_details"]] <-
          lapply(self$`group_products_details`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`booking_details`)) {
        ProductAddSpecificsInnerObject[["booking_details"]] <-
          self$`booking_details`$toSimpleType()
      }
      return(ProductAddSpecificsInnerObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductAddSpecificsInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductAddSpecificsInner
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`value`)) {
        self$`value` <- this_object$`value`
      }
      if (!is.null(this_object$`values`)) {
        self$`values` <- ApiClient$new()$deserializeObj(this_object$`values`, "array[character]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`used_for_variations`)) {
        self$`used_for_variations` <- this_object$`used_for_variations`
      }
      if (!is.null(this_object$`scale_id`)) {
        self$`scale_id` <- this_object$`scale_id`
      }
      if (!is.null(this_object$`input_value`)) {
        self$`input_value` <- this_object$`input_value`
      }
      if (!is.null(this_object$`food_details`)) {
        `food_details_object` <- ProductAddSpecificsInnerFoodDetails$new()
        `food_details_object`$fromJSON(jsonlite::toJSON(this_object$`food_details`, auto_unbox = TRUE, digits = NA))
        self$`food_details` <- `food_details_object`
      }
      if (!is.null(this_object$`group_products_details`)) {
        self$`group_products_details` <- ApiClient$new()$deserializeObj(this_object$`group_products_details`, "array[ProductAddSpecificsInnerGroupProductsDetailsInner]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`booking_details`)) {
        `booking_details_object` <- ProductAddSpecificsInnerBookingDetails$new()
        `booking_details_object`$fromJSON(jsonlite::toJSON(this_object$`booking_details`, auto_unbox = TRUE, digits = NA))
        self$`booking_details` <- `booking_details_object`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductAddSpecificsInner in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductAddSpecificsInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductAddSpecificsInner
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`name` <- this_object$`name`
      self$`value` <- this_object$`value`
      self$`values` <- ApiClient$new()$deserializeObj(this_object$`values`, "array[character]", loadNamespace("openapi"))
      self$`used_for_variations` <- this_object$`used_for_variations`
      self$`scale_id` <- this_object$`scale_id`
      self$`input_value` <- this_object$`input_value`
      self$`food_details` <- ProductAddSpecificsInnerFoodDetails$new()$fromJSON(jsonlite::toJSON(this_object$`food_details`, auto_unbox = TRUE, digits = NA))
      self$`group_products_details` <- ApiClient$new()$deserializeObj(this_object$`group_products_details`, "array[ProductAddSpecificsInnerGroupProductsDetailsInner]", loadNamespace("openapi"))
      self$`booking_details` <- ProductAddSpecificsInnerBookingDetails$new()$fromJSON(jsonlite::toJSON(this_object$`booking_details`, auto_unbox = TRUE, digits = NA))
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductAddSpecificsInner and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductAddSpecificsInner
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      if (length(self$`values`) < 1) {
        return(FALSE)
      }

      if (length(self$`group_products_details`) < 1) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      if (length(self$`values`) < 1) {
        invalid_fields["values"] <- "Invalid length for ``, number of items must be greater than or equal to 1."
      }

      if (length(self$`group_products_details`) < 1) {
        invalid_fields["group_products_details"] <- "Invalid length for ``, number of items must be greater than or equal to 1."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductAddSpecificsInner$unlock()
#
## Below is an example to define the print function
# ProductAddSpecificsInner$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductAddSpecificsInner$lock()

