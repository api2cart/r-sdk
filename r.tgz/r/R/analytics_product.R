#' Create a new AnalyticsProduct
#'
#' @description
#' AnalyticsProduct Class
#'
#' @docType class
#' @title AnalyticsProduct
#' @description AnalyticsProduct Class
#' @format An \code{R6Class} generator object
#' @field product_id  character [optional]
#' @field variant_id  character [optional]
#' @field sku  character [optional]
#' @field name  character [optional]
#' @field category_ids  list(character) [optional]
#' @field metrics  \link{AnalyticsProductMetric} [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
AnalyticsProduct <- R6::R6Class(
  "AnalyticsProduct",
  public = list(
    `product_id` = NULL,
    `variant_id` = NULL,
    `sku` = NULL,
    `name` = NULL,
    `category_ids` = NULL,
    `metrics` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new AnalyticsProduct class.
    #'
    #' @param product_id product_id
    #' @param variant_id variant_id
    #' @param sku sku
    #' @param name name
    #' @param category_ids category_ids
    #' @param metrics metrics
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`product_id` = NULL, `variant_id` = NULL, `sku` = NULL, `name` = NULL, `category_ids` = NULL, `metrics` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`product_id`)) {
        if (!(is.character(`product_id`) && length(`product_id`) == 1)) {
          stop(paste("Error! Invalid data for `product_id`. Must be a string:", `product_id`))
        }
        self$`product_id` <- `product_id`
      }
      if (!is.null(`variant_id`)) {
        if (!(is.character(`variant_id`) && length(`variant_id`) == 1)) {
          stop(paste("Error! Invalid data for `variant_id`. Must be a string:", `variant_id`))
        }
        self$`variant_id` <- `variant_id`
      }
      if (!is.null(`sku`)) {
        if (!(is.character(`sku`) && length(`sku`) == 1)) {
          stop(paste("Error! Invalid data for `sku`. Must be a string:", `sku`))
        }
        self$`sku` <- `sku`
      }
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`category_ids`)) {
        stopifnot(is.vector(`category_ids`), length(`category_ids`) != 0)
        sapply(`category_ids`, function(x) stopifnot(is.character(x)))
        self$`category_ids` <- `category_ids`
      }
      if (!is.null(`metrics`)) {
        stopifnot(R6::is.R6(`metrics`))
        self$`metrics` <- `metrics`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return AnalyticsProduct as a base R list.
    #' @examples
    #' # convert array of AnalyticsProduct (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert AnalyticsProduct to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      AnalyticsProductObject <- list()
      if (!is.null(self$`product_id`)) {
        AnalyticsProductObject[["product_id"]] <-
          self$`product_id`
      }
      if (!is.null(self$`variant_id`)) {
        AnalyticsProductObject[["variant_id"]] <-
          self$`variant_id`
      }
      if (!is.null(self$`sku`)) {
        AnalyticsProductObject[["sku"]] <-
          self$`sku`
      }
      if (!is.null(self$`name`)) {
        AnalyticsProductObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`category_ids`)) {
        AnalyticsProductObject[["category_ids"]] <-
          self$`category_ids`
      }
      if (!is.null(self$`metrics`)) {
        AnalyticsProductObject[["metrics"]] <-
          self$`metrics`$toSimpleType()
      }
      if (!is.null(self$`additional_fields`)) {
        AnalyticsProductObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        AnalyticsProductObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(AnalyticsProductObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of AnalyticsProduct
    #'
    #' @param input_json the JSON input
    #' @return the instance of AnalyticsProduct
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`product_id`)) {
        self$`product_id` <- this_object$`product_id`
      }
      if (!is.null(this_object$`variant_id`)) {
        self$`variant_id` <- this_object$`variant_id`
      }
      if (!is.null(this_object$`sku`)) {
        self$`sku` <- this_object$`sku`
      }
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`category_ids`)) {
        self$`category_ids` <- ApiClient$new()$deserializeObj(this_object$`category_ids`, "array[character]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`metrics`)) {
        `metrics_object` <- AnalyticsProductMetric$new()
        `metrics_object`$fromJSON(jsonlite::toJSON(this_object$`metrics`, auto_unbox = TRUE, digits = NA))
        self$`metrics` <- `metrics_object`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return AnalyticsProduct in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of AnalyticsProduct
    #'
    #' @param input_json the JSON input
    #' @return the instance of AnalyticsProduct
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`product_id` <- this_object$`product_id`
      self$`variant_id` <- this_object$`variant_id`
      self$`sku` <- this_object$`sku`
      self$`name` <- this_object$`name`
      self$`category_ids` <- ApiClient$new()$deserializeObj(this_object$`category_ids`, "array[character]", loadNamespace("openapi"))
      self$`metrics` <- AnalyticsProductMetric$new()$fromJSON(jsonlite::toJSON(this_object$`metrics`, auto_unbox = TRUE, digits = NA))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to AnalyticsProduct and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of AnalyticsProduct
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# AnalyticsProduct$unlock()
#
## Below is an example to define the print function
# AnalyticsProduct$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# AnalyticsProduct$lock()

