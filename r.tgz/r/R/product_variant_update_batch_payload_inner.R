#' Create a new ProductVariantUpdateBatchPayloadInner
#'
#' @description
#' ProductVariantUpdateBatchPayloadInner Class
#'
#' @docType class
#' @title ProductVariantUpdateBatchPayloadInner
#' @description ProductVariantUpdateBatchPayloadInner Class
#' @format An \code{R6Class} generator object
#' @field id  character
#' @field product_id  character
#' @field name  character [optional]
#' @field description  character [optional]
#' @field short_description  character [optional]
#' @field sku  character [optional]
#' @field upc  character [optional]
#' @field mpn  character [optional]
#' @field gtin  character [optional]
#' @field isbn  character [optional]
#' @field status  character [optional]
#' @field price  numeric [optional]
#' @field special_price  numeric [optional]
#' @field cost_price  numeric [optional]
#' @field retail_price  numeric [optional]
#' @field advanced_prices If an empty array is passed, all entries will be deleted when the 'nested_items_update_behaviour' parameter is set to 'replace'. list(\link{ProductUpdateBatchPayloadInnerAdvancedPricesInner}) [optional]
#' @field quantity  numeric [optional]
#' @field reserve_quantity  numeric [optional]
#' @field increase_quantity  numeric [optional]
#' @field reduce_quantity  numeric [optional]
#' @field warehouse_id  character [optional]
#' @field manufacturer_id  character [optional]
#' @field weight  numeric [optional]
#' @field height  numeric [optional]
#' @field length  numeric [optional]
#' @field width  numeric [optional]
#' @field store_id  character [optional]
#' @field lang_id  character [optional]
#' @field tax_class_id  character [optional]
#' @field backorder_status  character [optional]
#' @field visible  character [optional]
#' @field is_default  character [optional]
#' @field in_stock  character [optional]
#' @field is_virtual  character [optional]
#' @field downloadable  character [optional]
#' @field manage_stock  character [optional]
#' @field is_free_shipping  character [optional]
#' @field seo_url  character [optional]
#' @field meta_title  character [optional]
#' @field meta_description  character [optional]
#' @field meta_keywords  list(character) [optional]
#' @field categories_ids If an empty array is passed, all entries will be deleted when the 'nested_items_update_behaviour' parameter is set to 'replace'. list(character) [optional]
#' @field stores_ids  list(character) [optional]
#' @field images The passed items will completely replace the original items list(\link{ProductAddBatchPayloadInnerImagesInner}) [optional]
#' @field product_images_ids  list(character) [optional]
#' @field related_products_ids If an empty array is passed, all entries will be deleted when the 'nested_items_update_behaviour' parameter is set to 'replace'. list(character) [optional]
#' @field up_sell_products_ids If an empty array is passed, all entries will be deleted when the 'nested_items_update_behaviour' parameter is set to 'replace'. list(character) [optional]
#' @field cross_sell_products_ids If an empty array is passed, all entries will be deleted when the 'nested_items_update_behaviour' parameter is set to 'replace'. list(character) [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductVariantUpdateBatchPayloadInner <- R6::R6Class(
  "ProductVariantUpdateBatchPayloadInner",
  public = list(
    `id` = NULL,
    `product_id` = NULL,
    `name` = NULL,
    `description` = NULL,
    `short_description` = NULL,
    `sku` = NULL,
    `upc` = NULL,
    `mpn` = NULL,
    `gtin` = NULL,
    `isbn` = NULL,
    `status` = NULL,
    `price` = NULL,
    `special_price` = NULL,
    `cost_price` = NULL,
    `retail_price` = NULL,
    `advanced_prices` = NULL,
    `quantity` = NULL,
    `reserve_quantity` = NULL,
    `increase_quantity` = NULL,
    `reduce_quantity` = NULL,
    `warehouse_id` = NULL,
    `manufacturer_id` = NULL,
    `weight` = NULL,
    `height` = NULL,
    `length` = NULL,
    `width` = NULL,
    `store_id` = NULL,
    `lang_id` = NULL,
    `tax_class_id` = NULL,
    `backorder_status` = NULL,
    `visible` = NULL,
    `is_default` = NULL,
    `in_stock` = NULL,
    `is_virtual` = NULL,
    `downloadable` = NULL,
    `manage_stock` = NULL,
    `is_free_shipping` = NULL,
    `seo_url` = NULL,
    `meta_title` = NULL,
    `meta_description` = NULL,
    `meta_keywords` = NULL,
    `categories_ids` = NULL,
    `stores_ids` = NULL,
    `images` = NULL,
    `product_images_ids` = NULL,
    `related_products_ids` = NULL,
    `up_sell_products_ids` = NULL,
    `cross_sell_products_ids` = NULL,

    #' @description
    #' Initialize a new ProductVariantUpdateBatchPayloadInner class.
    #'
    #' @param id id
    #' @param product_id product_id
    #' @param name name
    #' @param description description
    #' @param short_description short_description
    #' @param sku sku
    #' @param upc upc
    #' @param mpn mpn
    #' @param gtin gtin
    #' @param isbn isbn
    #' @param status status
    #' @param price price
    #' @param special_price special_price
    #' @param cost_price cost_price
    #' @param retail_price retail_price
    #' @param advanced_prices If an empty array is passed, all entries will be deleted when the 'nested_items_update_behaviour' parameter is set to 'replace'.
    #' @param quantity quantity
    #' @param reserve_quantity reserve_quantity
    #' @param increase_quantity increase_quantity
    #' @param reduce_quantity reduce_quantity
    #' @param warehouse_id warehouse_id
    #' @param manufacturer_id manufacturer_id
    #' @param weight weight
    #' @param height height
    #' @param length length
    #' @param width width
    #' @param store_id store_id
    #' @param lang_id lang_id
    #' @param tax_class_id tax_class_id
    #' @param backorder_status backorder_status
    #' @param visible visible
    #' @param is_default is_default
    #' @param in_stock in_stock
    #' @param is_virtual is_virtual
    #' @param downloadable downloadable
    #' @param manage_stock manage_stock
    #' @param is_free_shipping is_free_shipping
    #' @param seo_url seo_url
    #' @param meta_title meta_title
    #' @param meta_description meta_description
    #' @param meta_keywords meta_keywords
    #' @param categories_ids If an empty array is passed, all entries will be deleted when the 'nested_items_update_behaviour' parameter is set to 'replace'.
    #' @param stores_ids stores_ids
    #' @param images The passed items will completely replace the original items
    #' @param product_images_ids product_images_ids
    #' @param related_products_ids If an empty array is passed, all entries will be deleted when the 'nested_items_update_behaviour' parameter is set to 'replace'.
    #' @param up_sell_products_ids If an empty array is passed, all entries will be deleted when the 'nested_items_update_behaviour' parameter is set to 'replace'.
    #' @param cross_sell_products_ids If an empty array is passed, all entries will be deleted when the 'nested_items_update_behaviour' parameter is set to 'replace'.
    #' @param ... Other optional arguments.
    initialize = function(`id`, `product_id`, `name` = NULL, `description` = NULL, `short_description` = NULL, `sku` = NULL, `upc` = NULL, `mpn` = NULL, `gtin` = NULL, `isbn` = NULL, `status` = NULL, `price` = NULL, `special_price` = NULL, `cost_price` = NULL, `retail_price` = NULL, `advanced_prices` = NULL, `quantity` = NULL, `reserve_quantity` = NULL, `increase_quantity` = NULL, `reduce_quantity` = NULL, `warehouse_id` = NULL, `manufacturer_id` = NULL, `weight` = NULL, `height` = NULL, `length` = NULL, `width` = NULL, `store_id` = NULL, `lang_id` = NULL, `tax_class_id` = NULL, `backorder_status` = NULL, `visible` = NULL, `is_default` = NULL, `in_stock` = NULL, `is_virtual` = NULL, `downloadable` = NULL, `manage_stock` = NULL, `is_free_shipping` = NULL, `seo_url` = NULL, `meta_title` = NULL, `meta_description` = NULL, `meta_keywords` = NULL, `categories_ids` = NULL, `stores_ids` = NULL, `images` = NULL, `product_images_ids` = NULL, `related_products_ids` = NULL, `up_sell_products_ids` = NULL, `cross_sell_products_ids` = NULL, ...) {
      if (!missing(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!missing(`product_id`)) {
        if (!(is.character(`product_id`) && length(`product_id`) == 1)) {
          stop(paste("Error! Invalid data for `product_id`. Must be a string:", `product_id`))
        }
        self$`product_id` <- `product_id`
      }
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`description`)) {
        if (!(is.character(`description`) && length(`description`) == 1)) {
          stop(paste("Error! Invalid data for `description`. Must be a string:", `description`))
        }
        self$`description` <- `description`
      }
      if (!is.null(`short_description`)) {
        if (!(is.character(`short_description`) && length(`short_description`) == 1)) {
          stop(paste("Error! Invalid data for `short_description`. Must be a string:", `short_description`))
        }
        self$`short_description` <- `short_description`
      }
      if (!is.null(`sku`)) {
        if (!(is.character(`sku`) && length(`sku`) == 1)) {
          stop(paste("Error! Invalid data for `sku`. Must be a string:", `sku`))
        }
        self$`sku` <- `sku`
      }
      if (!is.null(`upc`)) {
        if (!(is.character(`upc`) && length(`upc`) == 1)) {
          stop(paste("Error! Invalid data for `upc`. Must be a string:", `upc`))
        }
        self$`upc` <- `upc`
      }
      if (!is.null(`mpn`)) {
        if (!(is.character(`mpn`) && length(`mpn`) == 1)) {
          stop(paste("Error! Invalid data for `mpn`. Must be a string:", `mpn`))
        }
        self$`mpn` <- `mpn`
      }
      if (!is.null(`gtin`)) {
        if (!(is.character(`gtin`) && length(`gtin`) == 1)) {
          stop(paste("Error! Invalid data for `gtin`. Must be a string:", `gtin`))
        }
        self$`gtin` <- `gtin`
      }
      if (!is.null(`isbn`)) {
        if (!(is.character(`isbn`) && length(`isbn`) == 1)) {
          stop(paste("Error! Invalid data for `isbn`. Must be a string:", `isbn`))
        }
        self$`isbn` <- `isbn`
      }
      if (!is.null(`status`)) {
        if (!(is.character(`status`) && length(`status`) == 1)) {
          stop(paste("Error! Invalid data for `status`. Must be a string:", `status`))
        }
        self$`status` <- `status`
      }
      if (!is.null(`price`)) {
        self$`price` <- `price`
      }
      if (!is.null(`special_price`)) {
        self$`special_price` <- `special_price`
      }
      if (!is.null(`cost_price`)) {
        self$`cost_price` <- `cost_price`
      }
      if (!is.null(`retail_price`)) {
        self$`retail_price` <- `retail_price`
      }
      if (!is.null(`advanced_prices`)) {
        stopifnot(is.vector(`advanced_prices`), length(`advanced_prices`) != 0)
        sapply(`advanced_prices`, function(x) stopifnot(R6::is.R6(x)))
        self$`advanced_prices` <- `advanced_prices`
      }
      if (!is.null(`quantity`)) {
        self$`quantity` <- `quantity`
      }
      if (!is.null(`reserve_quantity`)) {
        self$`reserve_quantity` <- `reserve_quantity`
      }
      if (!is.null(`increase_quantity`)) {
        self$`increase_quantity` <- `increase_quantity`
      }
      if (!is.null(`reduce_quantity`)) {
        self$`reduce_quantity` <- `reduce_quantity`
      }
      if (!is.null(`warehouse_id`)) {
        if (!(is.character(`warehouse_id`) && length(`warehouse_id`) == 1)) {
          stop(paste("Error! Invalid data for `warehouse_id`. Must be a string:", `warehouse_id`))
        }
        self$`warehouse_id` <- `warehouse_id`
      }
      if (!is.null(`manufacturer_id`)) {
        if (!(is.character(`manufacturer_id`) && length(`manufacturer_id`) == 1)) {
          stop(paste("Error! Invalid data for `manufacturer_id`. Must be a string:", `manufacturer_id`))
        }
        self$`manufacturer_id` <- `manufacturer_id`
      }
      if (!is.null(`weight`)) {
        self$`weight` <- `weight`
      }
      if (!is.null(`height`)) {
        self$`height` <- `height`
      }
      if (!is.null(`length`)) {
        self$`length` <- `length`
      }
      if (!is.null(`width`)) {
        self$`width` <- `width`
      }
      if (!is.null(`store_id`)) {
        if (!(is.character(`store_id`) && length(`store_id`) == 1)) {
          stop(paste("Error! Invalid data for `store_id`. Must be a string:", `store_id`))
        }
        self$`store_id` <- `store_id`
      }
      if (!is.null(`lang_id`)) {
        if (!(is.character(`lang_id`) && length(`lang_id`) == 1)) {
          stop(paste("Error! Invalid data for `lang_id`. Must be a string:", `lang_id`))
        }
        self$`lang_id` <- `lang_id`
      }
      if (!is.null(`tax_class_id`)) {
        if (!(is.character(`tax_class_id`) && length(`tax_class_id`) == 1)) {
          stop(paste("Error! Invalid data for `tax_class_id`. Must be a string:", `tax_class_id`))
        }
        self$`tax_class_id` <- `tax_class_id`
      }
      if (!is.null(`backorder_status`)) {
        if (!(is.character(`backorder_status`) && length(`backorder_status`) == 1)) {
          stop(paste("Error! Invalid data for `backorder_status`. Must be a string:", `backorder_status`))
        }
        self$`backorder_status` <- `backorder_status`
      }
      if (!is.null(`visible`)) {
        if (!(is.character(`visible`) && length(`visible`) == 1)) {
          stop(paste("Error! Invalid data for `visible`. Must be a string:", `visible`))
        }
        self$`visible` <- `visible`
      }
      if (!is.null(`is_default`)) {
        if (!(is.logical(`is_default`) && length(`is_default`) == 1)) {
          stop(paste("Error! Invalid data for `is_default`. Must be a boolean:", `is_default`))
        }
        self$`is_default` <- `is_default`
      }
      if (!is.null(`in_stock`)) {
        if (!(is.logical(`in_stock`) && length(`in_stock`) == 1)) {
          stop(paste("Error! Invalid data for `in_stock`. Must be a boolean:", `in_stock`))
        }
        self$`in_stock` <- `in_stock`
      }
      if (!is.null(`is_virtual`)) {
        if (!(is.logical(`is_virtual`) && length(`is_virtual`) == 1)) {
          stop(paste("Error! Invalid data for `is_virtual`. Must be a boolean:", `is_virtual`))
        }
        self$`is_virtual` <- `is_virtual`
      }
      if (!is.null(`downloadable`)) {
        if (!(is.logical(`downloadable`) && length(`downloadable`) == 1)) {
          stop(paste("Error! Invalid data for `downloadable`. Must be a boolean:", `downloadable`))
        }
        self$`downloadable` <- `downloadable`
      }
      if (!is.null(`manage_stock`)) {
        if (!(is.logical(`manage_stock`) && length(`manage_stock`) == 1)) {
          stop(paste("Error! Invalid data for `manage_stock`. Must be a boolean:", `manage_stock`))
        }
        self$`manage_stock` <- `manage_stock`
      }
      if (!is.null(`is_free_shipping`)) {
        if (!(is.logical(`is_free_shipping`) && length(`is_free_shipping`) == 1)) {
          stop(paste("Error! Invalid data for `is_free_shipping`. Must be a boolean:", `is_free_shipping`))
        }
        self$`is_free_shipping` <- `is_free_shipping`
      }
      if (!is.null(`seo_url`)) {
        if (!(is.character(`seo_url`) && length(`seo_url`) == 1)) {
          stop(paste("Error! Invalid data for `seo_url`. Must be a string:", `seo_url`))
        }
        self$`seo_url` <- `seo_url`
      }
      if (!is.null(`meta_title`)) {
        if (!(is.character(`meta_title`) && length(`meta_title`) == 1)) {
          stop(paste("Error! Invalid data for `meta_title`. Must be a string:", `meta_title`))
        }
        self$`meta_title` <- `meta_title`
      }
      if (!is.null(`meta_description`)) {
        if (!(is.character(`meta_description`) && length(`meta_description`) == 1)) {
          stop(paste("Error! Invalid data for `meta_description`. Must be a string:", `meta_description`))
        }
        self$`meta_description` <- `meta_description`
      }
      if (!is.null(`meta_keywords`)) {
        stopifnot(is.vector(`meta_keywords`), length(`meta_keywords`) != 0)
        sapply(`meta_keywords`, function(x) stopifnot(is.character(x)))
        self$`meta_keywords` <- `meta_keywords`
      }
      if (!is.null(`categories_ids`)) {
        stopifnot(is.vector(`categories_ids`), length(`categories_ids`) != 0)
        sapply(`categories_ids`, function(x) stopifnot(is.character(x)))
        self$`categories_ids` <- `categories_ids`
      }
      if (!is.null(`stores_ids`)) {
        stopifnot(is.vector(`stores_ids`), length(`stores_ids`) != 0)
        sapply(`stores_ids`, function(x) stopifnot(is.character(x)))
        self$`stores_ids` <- `stores_ids`
      }
      if (!is.null(`images`)) {
        stopifnot(is.vector(`images`), length(`images`) != 0)
        sapply(`images`, function(x) stopifnot(R6::is.R6(x)))
        self$`images` <- `images`
      }
      if (!is.null(`product_images_ids`)) {
        stopifnot(is.vector(`product_images_ids`), length(`product_images_ids`) != 0)
        sapply(`product_images_ids`, function(x) stopifnot(is.character(x)))
        self$`product_images_ids` <- `product_images_ids`
      }
      if (!is.null(`related_products_ids`)) {
        stopifnot(is.vector(`related_products_ids`), length(`related_products_ids`) != 0)
        sapply(`related_products_ids`, function(x) stopifnot(is.character(x)))
        self$`related_products_ids` <- `related_products_ids`
      }
      if (!is.null(`up_sell_products_ids`)) {
        stopifnot(is.vector(`up_sell_products_ids`), length(`up_sell_products_ids`) != 0)
        sapply(`up_sell_products_ids`, function(x) stopifnot(is.character(x)))
        self$`up_sell_products_ids` <- `up_sell_products_ids`
      }
      if (!is.null(`cross_sell_products_ids`)) {
        stopifnot(is.vector(`cross_sell_products_ids`), length(`cross_sell_products_ids`) != 0)
        sapply(`cross_sell_products_ids`, function(x) stopifnot(is.character(x)))
        self$`cross_sell_products_ids` <- `cross_sell_products_ids`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductVariantUpdateBatchPayloadInner as a base R list.
    #' @examples
    #' # convert array of ProductVariantUpdateBatchPayloadInner (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductVariantUpdateBatchPayloadInner to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductVariantUpdateBatchPayloadInnerObject <- list()
      if (!is.null(self$`id`)) {
        ProductVariantUpdateBatchPayloadInnerObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`product_id`)) {
        ProductVariantUpdateBatchPayloadInnerObject[["product_id"]] <-
          self$`product_id`
      }
      if (!is.null(self$`name`)) {
        ProductVariantUpdateBatchPayloadInnerObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`description`)) {
        ProductVariantUpdateBatchPayloadInnerObject[["description"]] <-
          self$`description`
      }
      if (!is.null(self$`short_description`)) {
        ProductVariantUpdateBatchPayloadInnerObject[["short_description"]] <-
          self$`short_description`
      }
      if (!is.null(self$`sku`)) {
        ProductVariantUpdateBatchPayloadInnerObject[["sku"]] <-
          self$`sku`
      }
      if (!is.null(self$`upc`)) {
        ProductVariantUpdateBatchPayloadInnerObject[["upc"]] <-
          self$`upc`
      }
      if (!is.null(self$`mpn`)) {
        ProductVariantUpdateBatchPayloadInnerObject[["mpn"]] <-
          self$`mpn`
      }
      if (!is.null(self$`gtin`)) {
        ProductVariantUpdateBatchPayloadInnerObject[["gtin"]] <-
          self$`gtin`
      }
      if (!is.null(self$`isbn`)) {
        ProductVariantUpdateBatchPayloadInnerObject[["isbn"]] <-
          self$`isbn`
      }
      if (!is.null(self$`status`)) {
        ProductVariantUpdateBatchPayloadInnerObject[["status"]] <-
          self$`status`
      }
      if (!is.null(self$`price`)) {
        ProductVariantUpdateBatchPayloadInnerObject[["price"]] <-
          self$`price`
      }
      if (!is.null(self$`special_price`)) {
        ProductVariantUpdateBatchPayloadInnerObject[["special_price"]] <-
          self$`special_price`
      }
      if (!is.null(self$`cost_price`)) {
        ProductVariantUpdateBatchPayloadInnerObject[["cost_price"]] <-
          self$`cost_price`
      }
      if (!is.null(self$`retail_price`)) {
        ProductVariantUpdateBatchPayloadInnerObject[["retail_price"]] <-
          self$`retail_price`
      }
      if (!is.null(self$`advanced_prices`)) {
        ProductVariantUpdateBatchPayloadInnerObject[["advanced_prices"]] <-
          lapply(self$`advanced_prices`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`quantity`)) {
        ProductVariantUpdateBatchPayloadInnerObject[["quantity"]] <-
          self$`quantity`
      }
      if (!is.null(self$`reserve_quantity`)) {
        ProductVariantUpdateBatchPayloadInnerObject[["reserve_quantity"]] <-
          self$`reserve_quantity`
      }
      if (!is.null(self$`increase_quantity`)) {
        ProductVariantUpdateBatchPayloadInnerObject[["increase_quantity"]] <-
          self$`increase_quantity`
      }
      if (!is.null(self$`reduce_quantity`)) {
        ProductVariantUpdateBatchPayloadInnerObject[["reduce_quantity"]] <-
          self$`reduce_quantity`
      }
      if (!is.null(self$`warehouse_id`)) {
        ProductVariantUpdateBatchPayloadInnerObject[["warehouse_id"]] <-
          self$`warehouse_id`
      }
      if (!is.null(self$`manufacturer_id`)) {
        ProductVariantUpdateBatchPayloadInnerObject[["manufacturer_id"]] <-
          self$`manufacturer_id`
      }
      if (!is.null(self$`weight`)) {
        ProductVariantUpdateBatchPayloadInnerObject[["weight"]] <-
          self$`weight`
      }
      if (!is.null(self$`height`)) {
        ProductVariantUpdateBatchPayloadInnerObject[["height"]] <-
          self$`height`
      }
      if (!is.null(self$`length`)) {
        ProductVariantUpdateBatchPayloadInnerObject[["length"]] <-
          self$`length`
      }
      if (!is.null(self$`width`)) {
        ProductVariantUpdateBatchPayloadInnerObject[["width"]] <-
          self$`width`
      }
      if (!is.null(self$`store_id`)) {
        ProductVariantUpdateBatchPayloadInnerObject[["store_id"]] <-
          self$`store_id`
      }
      if (!is.null(self$`lang_id`)) {
        ProductVariantUpdateBatchPayloadInnerObject[["lang_id"]] <-
          self$`lang_id`
      }
      if (!is.null(self$`tax_class_id`)) {
        ProductVariantUpdateBatchPayloadInnerObject[["tax_class_id"]] <-
          self$`tax_class_id`
      }
      if (!is.null(self$`backorder_status`)) {
        ProductVariantUpdateBatchPayloadInnerObject[["backorder_status"]] <-
          self$`backorder_status`
      }
      if (!is.null(self$`visible`)) {
        ProductVariantUpdateBatchPayloadInnerObject[["visible"]] <-
          self$`visible`
      }
      if (!is.null(self$`is_default`)) {
        ProductVariantUpdateBatchPayloadInnerObject[["is_default"]] <-
          self$`is_default`
      }
      if (!is.null(self$`in_stock`)) {
        ProductVariantUpdateBatchPayloadInnerObject[["in_stock"]] <-
          self$`in_stock`
      }
      if (!is.null(self$`is_virtual`)) {
        ProductVariantUpdateBatchPayloadInnerObject[["is_virtual"]] <-
          self$`is_virtual`
      }
      if (!is.null(self$`downloadable`)) {
        ProductVariantUpdateBatchPayloadInnerObject[["downloadable"]] <-
          self$`downloadable`
      }
      if (!is.null(self$`manage_stock`)) {
        ProductVariantUpdateBatchPayloadInnerObject[["manage_stock"]] <-
          self$`manage_stock`
      }
      if (!is.null(self$`is_free_shipping`)) {
        ProductVariantUpdateBatchPayloadInnerObject[["is_free_shipping"]] <-
          self$`is_free_shipping`
      }
      if (!is.null(self$`seo_url`)) {
        ProductVariantUpdateBatchPayloadInnerObject[["seo_url"]] <-
          self$`seo_url`
      }
      if (!is.null(self$`meta_title`)) {
        ProductVariantUpdateBatchPayloadInnerObject[["meta_title"]] <-
          self$`meta_title`
      }
      if (!is.null(self$`meta_description`)) {
        ProductVariantUpdateBatchPayloadInnerObject[["meta_description"]] <-
          self$`meta_description`
      }
      if (!is.null(self$`meta_keywords`)) {
        ProductVariantUpdateBatchPayloadInnerObject[["meta_keywords"]] <-
          self$`meta_keywords`
      }
      if (!is.null(self$`categories_ids`)) {
        ProductVariantUpdateBatchPayloadInnerObject[["categories_ids"]] <-
          self$`categories_ids`
      }
      if (!is.null(self$`stores_ids`)) {
        ProductVariantUpdateBatchPayloadInnerObject[["stores_ids"]] <-
          self$`stores_ids`
      }
      if (!is.null(self$`images`)) {
        ProductVariantUpdateBatchPayloadInnerObject[["images"]] <-
          lapply(self$`images`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`product_images_ids`)) {
        ProductVariantUpdateBatchPayloadInnerObject[["product_images_ids"]] <-
          self$`product_images_ids`
      }
      if (!is.null(self$`related_products_ids`)) {
        ProductVariantUpdateBatchPayloadInnerObject[["related_products_ids"]] <-
          self$`related_products_ids`
      }
      if (!is.null(self$`up_sell_products_ids`)) {
        ProductVariantUpdateBatchPayloadInnerObject[["up_sell_products_ids"]] <-
          self$`up_sell_products_ids`
      }
      if (!is.null(self$`cross_sell_products_ids`)) {
        ProductVariantUpdateBatchPayloadInnerObject[["cross_sell_products_ids"]] <-
          self$`cross_sell_products_ids`
      }
      return(ProductVariantUpdateBatchPayloadInnerObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductVariantUpdateBatchPayloadInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductVariantUpdateBatchPayloadInner
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`product_id`)) {
        self$`product_id` <- this_object$`product_id`
      }
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`description`)) {
        self$`description` <- this_object$`description`
      }
      if (!is.null(this_object$`short_description`)) {
        self$`short_description` <- this_object$`short_description`
      }
      if (!is.null(this_object$`sku`)) {
        self$`sku` <- this_object$`sku`
      }
      if (!is.null(this_object$`upc`)) {
        self$`upc` <- this_object$`upc`
      }
      if (!is.null(this_object$`mpn`)) {
        self$`mpn` <- this_object$`mpn`
      }
      if (!is.null(this_object$`gtin`)) {
        self$`gtin` <- this_object$`gtin`
      }
      if (!is.null(this_object$`isbn`)) {
        self$`isbn` <- this_object$`isbn`
      }
      if (!is.null(this_object$`status`)) {
        self$`status` <- this_object$`status`
      }
      if (!is.null(this_object$`price`)) {
        self$`price` <- this_object$`price`
      }
      if (!is.null(this_object$`special_price`)) {
        self$`special_price` <- this_object$`special_price`
      }
      if (!is.null(this_object$`cost_price`)) {
        self$`cost_price` <- this_object$`cost_price`
      }
      if (!is.null(this_object$`retail_price`)) {
        self$`retail_price` <- this_object$`retail_price`
      }
      if (!is.null(this_object$`advanced_prices`)) {
        self$`advanced_prices` <- ApiClient$new()$deserializeObj(this_object$`advanced_prices`, "array[ProductUpdateBatchPayloadInnerAdvancedPricesInner]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`quantity`)) {
        self$`quantity` <- this_object$`quantity`
      }
      if (!is.null(this_object$`reserve_quantity`)) {
        self$`reserve_quantity` <- this_object$`reserve_quantity`
      }
      if (!is.null(this_object$`increase_quantity`)) {
        self$`increase_quantity` <- this_object$`increase_quantity`
      }
      if (!is.null(this_object$`reduce_quantity`)) {
        self$`reduce_quantity` <- this_object$`reduce_quantity`
      }
      if (!is.null(this_object$`warehouse_id`)) {
        self$`warehouse_id` <- this_object$`warehouse_id`
      }
      if (!is.null(this_object$`manufacturer_id`)) {
        self$`manufacturer_id` <- this_object$`manufacturer_id`
      }
      if (!is.null(this_object$`weight`)) {
        self$`weight` <- this_object$`weight`
      }
      if (!is.null(this_object$`height`)) {
        self$`height` <- this_object$`height`
      }
      if (!is.null(this_object$`length`)) {
        self$`length` <- this_object$`length`
      }
      if (!is.null(this_object$`width`)) {
        self$`width` <- this_object$`width`
      }
      if (!is.null(this_object$`store_id`)) {
        self$`store_id` <- this_object$`store_id`
      }
      if (!is.null(this_object$`lang_id`)) {
        self$`lang_id` <- this_object$`lang_id`
      }
      if (!is.null(this_object$`tax_class_id`)) {
        self$`tax_class_id` <- this_object$`tax_class_id`
      }
      if (!is.null(this_object$`backorder_status`)) {
        self$`backorder_status` <- this_object$`backorder_status`
      }
      if (!is.null(this_object$`visible`)) {
        self$`visible` <- this_object$`visible`
      }
      if (!is.null(this_object$`is_default`)) {
        self$`is_default` <- this_object$`is_default`
      }
      if (!is.null(this_object$`in_stock`)) {
        self$`in_stock` <- this_object$`in_stock`
      }
      if (!is.null(this_object$`is_virtual`)) {
        self$`is_virtual` <- this_object$`is_virtual`
      }
      if (!is.null(this_object$`downloadable`)) {
        self$`downloadable` <- this_object$`downloadable`
      }
      if (!is.null(this_object$`manage_stock`)) {
        self$`manage_stock` <- this_object$`manage_stock`
      }
      if (!is.null(this_object$`is_free_shipping`)) {
        self$`is_free_shipping` <- this_object$`is_free_shipping`
      }
      if (!is.null(this_object$`seo_url`)) {
        self$`seo_url` <- this_object$`seo_url`
      }
      if (!is.null(this_object$`meta_title`)) {
        self$`meta_title` <- this_object$`meta_title`
      }
      if (!is.null(this_object$`meta_description`)) {
        self$`meta_description` <- this_object$`meta_description`
      }
      if (!is.null(this_object$`meta_keywords`)) {
        self$`meta_keywords` <- ApiClient$new()$deserializeObj(this_object$`meta_keywords`, "array[character]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`categories_ids`)) {
        self$`categories_ids` <- ApiClient$new()$deserializeObj(this_object$`categories_ids`, "array[character]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`stores_ids`)) {
        self$`stores_ids` <- ApiClient$new()$deserializeObj(this_object$`stores_ids`, "array[character]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`images`)) {
        self$`images` <- ApiClient$new()$deserializeObj(this_object$`images`, "array[ProductAddBatchPayloadInnerImagesInner]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`product_images_ids`)) {
        self$`product_images_ids` <- ApiClient$new()$deserializeObj(this_object$`product_images_ids`, "array[character]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`related_products_ids`)) {
        self$`related_products_ids` <- ApiClient$new()$deserializeObj(this_object$`related_products_ids`, "array[character]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`up_sell_products_ids`)) {
        self$`up_sell_products_ids` <- ApiClient$new()$deserializeObj(this_object$`up_sell_products_ids`, "array[character]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`cross_sell_products_ids`)) {
        self$`cross_sell_products_ids` <- ApiClient$new()$deserializeObj(this_object$`cross_sell_products_ids`, "array[character]", loadNamespace("openapi"))
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductVariantUpdateBatchPayloadInner in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductVariantUpdateBatchPayloadInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductVariantUpdateBatchPayloadInner
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`product_id` <- this_object$`product_id`
      self$`name` <- this_object$`name`
      self$`description` <- this_object$`description`
      self$`short_description` <- this_object$`short_description`
      self$`sku` <- this_object$`sku`
      self$`upc` <- this_object$`upc`
      self$`mpn` <- this_object$`mpn`
      self$`gtin` <- this_object$`gtin`
      self$`isbn` <- this_object$`isbn`
      self$`status` <- this_object$`status`
      self$`price` <- this_object$`price`
      self$`special_price` <- this_object$`special_price`
      self$`cost_price` <- this_object$`cost_price`
      self$`retail_price` <- this_object$`retail_price`
      self$`advanced_prices` <- ApiClient$new()$deserializeObj(this_object$`advanced_prices`, "array[ProductUpdateBatchPayloadInnerAdvancedPricesInner]", loadNamespace("openapi"))
      self$`quantity` <- this_object$`quantity`
      self$`reserve_quantity` <- this_object$`reserve_quantity`
      self$`increase_quantity` <- this_object$`increase_quantity`
      self$`reduce_quantity` <- this_object$`reduce_quantity`
      self$`warehouse_id` <- this_object$`warehouse_id`
      self$`manufacturer_id` <- this_object$`manufacturer_id`
      self$`weight` <- this_object$`weight`
      self$`height` <- this_object$`height`
      self$`length` <- this_object$`length`
      self$`width` <- this_object$`width`
      self$`store_id` <- this_object$`store_id`
      self$`lang_id` <- this_object$`lang_id`
      self$`tax_class_id` <- this_object$`tax_class_id`
      self$`backorder_status` <- this_object$`backorder_status`
      self$`visible` <- this_object$`visible`
      self$`is_default` <- this_object$`is_default`
      self$`in_stock` <- this_object$`in_stock`
      self$`is_virtual` <- this_object$`is_virtual`
      self$`downloadable` <- this_object$`downloadable`
      self$`manage_stock` <- this_object$`manage_stock`
      self$`is_free_shipping` <- this_object$`is_free_shipping`
      self$`seo_url` <- this_object$`seo_url`
      self$`meta_title` <- this_object$`meta_title`
      self$`meta_description` <- this_object$`meta_description`
      self$`meta_keywords` <- ApiClient$new()$deserializeObj(this_object$`meta_keywords`, "array[character]", loadNamespace("openapi"))
      self$`categories_ids` <- ApiClient$new()$deserializeObj(this_object$`categories_ids`, "array[character]", loadNamespace("openapi"))
      self$`stores_ids` <- ApiClient$new()$deserializeObj(this_object$`stores_ids`, "array[character]", loadNamespace("openapi"))
      self$`images` <- ApiClient$new()$deserializeObj(this_object$`images`, "array[ProductAddBatchPayloadInnerImagesInner]", loadNamespace("openapi"))
      self$`product_images_ids` <- ApiClient$new()$deserializeObj(this_object$`product_images_ids`, "array[character]", loadNamespace("openapi"))
      self$`related_products_ids` <- ApiClient$new()$deserializeObj(this_object$`related_products_ids`, "array[character]", loadNamespace("openapi"))
      self$`up_sell_products_ids` <- ApiClient$new()$deserializeObj(this_object$`up_sell_products_ids`, "array[character]", loadNamespace("openapi"))
      self$`cross_sell_products_ids` <- ApiClient$new()$deserializeObj(this_object$`cross_sell_products_ids`, "array[character]", loadNamespace("openapi"))
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductVariantUpdateBatchPayloadInner and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
      # check the required field `id`
      if (!is.null(input_json$`id`)) {
        if (!(is.character(input_json$`id`) && length(input_json$`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", input_json$`id`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for ProductVariantUpdateBatchPayloadInner: the required field `id` is missing."))
      }
      # check the required field `product_id`
      if (!is.null(input_json$`product_id`)) {
        if (!(is.character(input_json$`product_id`) && length(input_json$`product_id`) == 1)) {
          stop(paste("Error! Invalid data for `product_id`. Must be a string:", input_json$`product_id`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for ProductVariantUpdateBatchPayloadInner: the required field `product_id` is missing."))
      }
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductVariantUpdateBatchPayloadInner
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      # check if the required `id` is null
      if (is.null(self$`id`)) {
        return(FALSE)
      }

      # check if the required `product_id` is null
      if (is.null(self$`product_id`)) {
        return(FALSE)
      }

      if (length(self$`meta_keywords`) < 1) {
        return(FALSE)
      }

      if (length(self$`stores_ids`) < 1) {
        return(FALSE)
      }

      if (length(self$`images`) < 1) {
        return(FALSE)
      }

      if (length(self$`product_images_ids`) < 1) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      # check if the required `id` is null
      if (is.null(self$`id`)) {
        invalid_fields["id"] <- "Non-nullable required field `id` cannot be null."
      }

      # check if the required `product_id` is null
      if (is.null(self$`product_id`)) {
        invalid_fields["product_id"] <- "Non-nullable required field `product_id` cannot be null."
      }

      if (length(self$`meta_keywords`) < 1) {
        invalid_fields["meta_keywords"] <- "Invalid length for ``, number of items must be greater than or equal to 1."
      }

      if (length(self$`stores_ids`) < 1) {
        invalid_fields["stores_ids"] <- "Invalid length for ``, number of items must be greater than or equal to 1."
      }

      if (length(self$`images`) < 1) {
        invalid_fields["images"] <- "Invalid length for ``, number of items must be greater than or equal to 1."
      }

      if (length(self$`product_images_ids`) < 1) {
        invalid_fields["product_images_ids"] <- "Invalid length for ``, number of items must be greater than or equal to 1."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductVariantUpdateBatchPayloadInner$unlock()
#
## Below is an example to define the print function
# ProductVariantUpdateBatchPayloadInner$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductVariantUpdateBatchPayloadInner$lock()

