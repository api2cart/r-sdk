#' Create a new ProductOptionAdd
#'
#' @description
#' ProductOptionAdd Class
#'
#' @docType class
#' @title ProductOptionAdd
#' @description ProductOptionAdd Class
#' @format An \code{R6Class} generator object
#' @field name Defines option's name character
#' @field type Defines option's type that has to be added character
#' @field product_id Defines product id where the option should be added character [optional]
#' @field default_option_value Defines default option value that has to be added character [optional]
#' @field option_values Defines option values that has to be added character [optional]
#' @field description Defines option's description character [optional]
#' @field avail Defines whether the option is available character [optional]
#' @field sort_order Sort number in the list integer [optional]
#' @field required Defines if the option is required character [optional]
#' @field values An array of option values.</b> list(\link{ProductOptionAddValuesInner}) [optional]
#' @field clear_cache Is cache clear required character [optional]
#' @field idempotency_key A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong> character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductOptionAdd <- R6::R6Class(
  "ProductOptionAdd",
  public = list(
    `name` = NULL,
    `type` = NULL,
    `product_id` = NULL,
    `default_option_value` = NULL,
    `option_values` = NULL,
    `description` = NULL,
    `avail` = NULL,
    `sort_order` = NULL,
    `required` = NULL,
    `values` = NULL,
    `clear_cache` = NULL,
    `idempotency_key` = NULL,

    #' @description
    #' Initialize a new ProductOptionAdd class.
    #'
    #' @param name Defines option's name
    #' @param type Defines option's type that has to be added
    #' @param product_id Defines product id where the option should be added
    #' @param default_option_value Defines default option value that has to be added
    #' @param option_values Defines option values that has to be added
    #' @param description Defines option's description
    #' @param avail Defines whether the option is available. Default to TRUE.
    #' @param sort_order Sort number in the list. Default to 0.
    #' @param required Defines if the option is required. Default to FALSE.
    #' @param values An array of option values.</b>
    #' @param clear_cache Is cache clear required. Default to TRUE.
    #' @param idempotency_key A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong>
    #' @param ... Other optional arguments.
    initialize = function(`name`, `type`, `product_id` = NULL, `default_option_value` = NULL, `option_values` = NULL, `description` = NULL, `avail` = TRUE, `sort_order` = 0, `required` = FALSE, `values` = NULL, `clear_cache` = TRUE, `idempotency_key` = NULL, ...) {
      if (!missing(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!missing(`type`)) {
        if (!(`type` %in% c("option_type_select", "option_type_text", "option_type_radio", "option_type_checkbox", "option_type_textarea", "option_type_readonly", "option_type_multiselect", "option_type_multicheckbox", "option_type_file", "option_type_date", "option_type_datetime", "option_type_time"))) {
          stop(paste("Error! \"", `type`, "\" cannot be assigned to `type`. Must be \"option_type_select\", \"option_type_text\", \"option_type_radio\", \"option_type_checkbox\", \"option_type_textarea\", \"option_type_readonly\", \"option_type_multiselect\", \"option_type_multicheckbox\", \"option_type_file\", \"option_type_date\", \"option_type_datetime\", \"option_type_time\".", sep = ""))
        }
        if (!(is.character(`type`) && length(`type`) == 1)) {
          stop(paste("Error! Invalid data for `type`. Must be a string:", `type`))
        }
        self$`type` <- `type`
      }
      if (!is.null(`product_id`)) {
        if (!(is.character(`product_id`) && length(`product_id`) == 1)) {
          stop(paste("Error! Invalid data for `product_id`. Must be a string:", `product_id`))
        }
        self$`product_id` <- `product_id`
      }
      if (!is.null(`default_option_value`)) {
        if (!(is.character(`default_option_value`) && length(`default_option_value`) == 1)) {
          stop(paste("Error! Invalid data for `default_option_value`. Must be a string:", `default_option_value`))
        }
        self$`default_option_value` <- `default_option_value`
      }
      if (!is.null(`option_values`)) {
        if (!(is.character(`option_values`) && length(`option_values`) == 1)) {
          stop(paste("Error! Invalid data for `option_values`. Must be a string:", `option_values`))
        }
        self$`option_values` <- `option_values`
      }
      if (!is.null(`description`)) {
        if (!(is.character(`description`) && length(`description`) == 1)) {
          stop(paste("Error! Invalid data for `description`. Must be a string:", `description`))
        }
        self$`description` <- `description`
      }
      if (!is.null(`avail`)) {
        if (!(is.logical(`avail`) && length(`avail`) == 1)) {
          stop(paste("Error! Invalid data for `avail`. Must be a boolean:", `avail`))
        }
        self$`avail` <- `avail`
      }
      if (!is.null(`sort_order`)) {
        if (!(is.numeric(`sort_order`) && length(`sort_order`) == 1)) {
          stop(paste("Error! Invalid data for `sort_order`. Must be an integer:", `sort_order`))
        }
        self$`sort_order` <- `sort_order`
      }
      if (!is.null(`required`)) {
        if (!(is.logical(`required`) && length(`required`) == 1)) {
          stop(paste("Error! Invalid data for `required`. Must be a boolean:", `required`))
        }
        self$`required` <- `required`
      }
      if (!is.null(`values`)) {
        stopifnot(is.vector(`values`), length(`values`) != 0)
        sapply(`values`, function(x) stopifnot(R6::is.R6(x)))
        self$`values` <- `values`
      }
      if (!is.null(`clear_cache`)) {
        if (!(is.logical(`clear_cache`) && length(`clear_cache`) == 1)) {
          stop(paste("Error! Invalid data for `clear_cache`. Must be a boolean:", `clear_cache`))
        }
        self$`clear_cache` <- `clear_cache`
      }
      if (!is.null(`idempotency_key`)) {
        if (!(is.character(`idempotency_key`) && length(`idempotency_key`) == 1)) {
          stop(paste("Error! Invalid data for `idempotency_key`. Must be a string:", `idempotency_key`))
        }
        self$`idempotency_key` <- `idempotency_key`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductOptionAdd as a base R list.
    #' @examples
    #' # convert array of ProductOptionAdd (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductOptionAdd to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductOptionAddObject <- list()
      if (!is.null(self$`name`)) {
        ProductOptionAddObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`type`)) {
        ProductOptionAddObject[["type"]] <-
          self$`type`
      }
      if (!is.null(self$`product_id`)) {
        ProductOptionAddObject[["product_id"]] <-
          self$`product_id`
      }
      if (!is.null(self$`default_option_value`)) {
        ProductOptionAddObject[["default_option_value"]] <-
          self$`default_option_value`
      }
      if (!is.null(self$`option_values`)) {
        ProductOptionAddObject[["option_values"]] <-
          self$`option_values`
      }
      if (!is.null(self$`description`)) {
        ProductOptionAddObject[["description"]] <-
          self$`description`
      }
      if (!is.null(self$`avail`)) {
        ProductOptionAddObject[["avail"]] <-
          self$`avail`
      }
      if (!is.null(self$`sort_order`)) {
        ProductOptionAddObject[["sort_order"]] <-
          self$`sort_order`
      }
      if (!is.null(self$`required`)) {
        ProductOptionAddObject[["required"]] <-
          self$`required`
      }
      if (!is.null(self$`values`)) {
        ProductOptionAddObject[["values"]] <-
          lapply(self$`values`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`clear_cache`)) {
        ProductOptionAddObject[["clear_cache"]] <-
          self$`clear_cache`
      }
      if (!is.null(self$`idempotency_key`)) {
        ProductOptionAddObject[["idempotency_key"]] <-
          self$`idempotency_key`
      }
      return(ProductOptionAddObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductOptionAdd
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductOptionAdd
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`type`)) {
        if (!is.null(this_object$`type`) && !(this_object$`type` %in% c("option_type_select", "option_type_text", "option_type_radio", "option_type_checkbox", "option_type_textarea", "option_type_readonly", "option_type_multiselect", "option_type_multicheckbox", "option_type_file", "option_type_date", "option_type_datetime", "option_type_time"))) {
          stop(paste("Error! \"", this_object$`type`, "\" cannot be assigned to `type`. Must be \"option_type_select\", \"option_type_text\", \"option_type_radio\", \"option_type_checkbox\", \"option_type_textarea\", \"option_type_readonly\", \"option_type_multiselect\", \"option_type_multicheckbox\", \"option_type_file\", \"option_type_date\", \"option_type_datetime\", \"option_type_time\".", sep = ""))
        }
        self$`type` <- this_object$`type`
      }
      if (!is.null(this_object$`product_id`)) {
        self$`product_id` <- this_object$`product_id`
      }
      if (!is.null(this_object$`default_option_value`)) {
        self$`default_option_value` <- this_object$`default_option_value`
      }
      if (!is.null(this_object$`option_values`)) {
        self$`option_values` <- this_object$`option_values`
      }
      if (!is.null(this_object$`description`)) {
        self$`description` <- this_object$`description`
      }
      if (!is.null(this_object$`avail`)) {
        self$`avail` <- this_object$`avail`
      }
      if (!is.null(this_object$`sort_order`)) {
        self$`sort_order` <- this_object$`sort_order`
      }
      if (!is.null(this_object$`required`)) {
        self$`required` <- this_object$`required`
      }
      if (!is.null(this_object$`values`)) {
        self$`values` <- ApiClient$new()$deserializeObj(this_object$`values`, "array[ProductOptionAddValuesInner]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`clear_cache`)) {
        self$`clear_cache` <- this_object$`clear_cache`
      }
      if (!is.null(this_object$`idempotency_key`)) {
        self$`idempotency_key` <- this_object$`idempotency_key`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductOptionAdd in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductOptionAdd
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductOptionAdd
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`name` <- this_object$`name`
      if (!is.null(this_object$`type`) && !(this_object$`type` %in% c("option_type_select", "option_type_text", "option_type_radio", "option_type_checkbox", "option_type_textarea", "option_type_readonly", "option_type_multiselect", "option_type_multicheckbox", "option_type_file", "option_type_date", "option_type_datetime", "option_type_time"))) {
        stop(paste("Error! \"", this_object$`type`, "\" cannot be assigned to `type`. Must be \"option_type_select\", \"option_type_text\", \"option_type_radio\", \"option_type_checkbox\", \"option_type_textarea\", \"option_type_readonly\", \"option_type_multiselect\", \"option_type_multicheckbox\", \"option_type_file\", \"option_type_date\", \"option_type_datetime\", \"option_type_time\".", sep = ""))
      }
      self$`type` <- this_object$`type`
      self$`product_id` <- this_object$`product_id`
      self$`default_option_value` <- this_object$`default_option_value`
      self$`option_values` <- this_object$`option_values`
      self$`description` <- this_object$`description`
      self$`avail` <- this_object$`avail`
      self$`sort_order` <- this_object$`sort_order`
      self$`required` <- this_object$`required`
      self$`values` <- ApiClient$new()$deserializeObj(this_object$`values`, "array[ProductOptionAddValuesInner]", loadNamespace("openapi"))
      self$`clear_cache` <- this_object$`clear_cache`
      self$`idempotency_key` <- this_object$`idempotency_key`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductOptionAdd and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
      # check the required field `name`
      if (!is.null(input_json$`name`)) {
        if (!(is.character(input_json$`name`) && length(input_json$`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", input_json$`name`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for ProductOptionAdd: the required field `name` is missing."))
      }
      # check the required field `type`
      if (!is.null(input_json$`type`)) {
        if (!(is.character(input_json$`type`) && length(input_json$`type`) == 1)) {
          stop(paste("Error! Invalid data for `type`. Must be a string:", input_json$`type`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for ProductOptionAdd: the required field `type` is missing."))
      }
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductOptionAdd
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      # check if the required `name` is null
      if (is.null(self$`name`)) {
        return(FALSE)
      }

      # check if the required `type` is null
      if (is.null(self$`type`)) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      # check if the required `name` is null
      if (is.null(self$`name`)) {
        invalid_fields["name"] <- "Non-nullable required field `name` cannot be null."
      }

      # check if the required `type` is null
      if (is.null(self$`type`)) {
        invalid_fields["type"] <- "Non-nullable required field `type` cannot be null."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductOptionAdd$unlock()
#
## Below is an example to define the print function
# ProductOptionAdd$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductOptionAdd$lock()

