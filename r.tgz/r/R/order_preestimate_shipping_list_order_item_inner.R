#' Create a new OrderPreestimateShippingListOrderItemInner
#'
#' @description
#' OrderPreestimateShippingListOrderItemInner Class
#'
#' @docType class
#' @title OrderPreestimateShippingListOrderItemInner
#' @description OrderPreestimateShippingListOrderItemInner Class
#' @format An \code{R6Class} generator object
#' @field order_item_id Defines orders specified by order item id character
#' @field order_item_model Defines orders specified by order item model character [optional]
#' @field order_item_quantity Defines orders specified by order item quantity integer
#' @field order_item_weight Defines orders specified by order item weight numeric [optional]
#' @field order_item_variant_id Ordered product variant. Where x is order item ID character [optional]
#' @field order_item_option  list(\link{OrderPreestimateShippingListOrderItemInnerOrderItemOptionInner}) [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
OrderPreestimateShippingListOrderItemInner <- R6::R6Class(
  "OrderPreestimateShippingListOrderItemInner",
  public = list(
    `order_item_id` = NULL,
    `order_item_model` = NULL,
    `order_item_quantity` = NULL,
    `order_item_weight` = NULL,
    `order_item_variant_id` = NULL,
    `order_item_option` = NULL,

    #' @description
    #' Initialize a new OrderPreestimateShippingListOrderItemInner class.
    #'
    #' @param order_item_id Defines orders specified by order item id
    #' @param order_item_quantity Defines orders specified by order item quantity
    #' @param order_item_model Defines orders specified by order item model
    #' @param order_item_weight Defines orders specified by order item weight
    #' @param order_item_variant_id Ordered product variant. Where x is order item ID
    #' @param order_item_option order_item_option
    #' @param ... Other optional arguments.
    initialize = function(`order_item_id`, `order_item_quantity`, `order_item_model` = NULL, `order_item_weight` = NULL, `order_item_variant_id` = NULL, `order_item_option` = NULL, ...) {
      if (!missing(`order_item_id`)) {
        if (!(is.character(`order_item_id`) && length(`order_item_id`) == 1)) {
          stop(paste("Error! Invalid data for `order_item_id`. Must be a string:", `order_item_id`))
        }
        self$`order_item_id` <- `order_item_id`
      }
      if (!missing(`order_item_quantity`)) {
        if (!(is.numeric(`order_item_quantity`) && length(`order_item_quantity`) == 1)) {
          stop(paste("Error! Invalid data for `order_item_quantity`. Must be an integer:", `order_item_quantity`))
        }
        self$`order_item_quantity` <- `order_item_quantity`
      }
      if (!is.null(`order_item_model`)) {
        if (!(is.character(`order_item_model`) && length(`order_item_model`) == 1)) {
          stop(paste("Error! Invalid data for `order_item_model`. Must be a string:", `order_item_model`))
        }
        self$`order_item_model` <- `order_item_model`
      }
      if (!is.null(`order_item_weight`)) {
        self$`order_item_weight` <- `order_item_weight`
      }
      if (!is.null(`order_item_variant_id`)) {
        if (!(is.character(`order_item_variant_id`) && length(`order_item_variant_id`) == 1)) {
          stop(paste("Error! Invalid data for `order_item_variant_id`. Must be a string:", `order_item_variant_id`))
        }
        self$`order_item_variant_id` <- `order_item_variant_id`
      }
      if (!is.null(`order_item_option`)) {
        stopifnot(is.vector(`order_item_option`), length(`order_item_option`) != 0)
        sapply(`order_item_option`, function(x) stopifnot(R6::is.R6(x)))
        self$`order_item_option` <- `order_item_option`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return OrderPreestimateShippingListOrderItemInner as a base R list.
    #' @examples
    #' # convert array of OrderPreestimateShippingListOrderItemInner (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert OrderPreestimateShippingListOrderItemInner to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      OrderPreestimateShippingListOrderItemInnerObject <- list()
      if (!is.null(self$`order_item_id`)) {
        OrderPreestimateShippingListOrderItemInnerObject[["order_item_id"]] <-
          self$`order_item_id`
      }
      if (!is.null(self$`order_item_model`)) {
        OrderPreestimateShippingListOrderItemInnerObject[["order_item_model"]] <-
          self$`order_item_model`
      }
      if (!is.null(self$`order_item_quantity`)) {
        OrderPreestimateShippingListOrderItemInnerObject[["order_item_quantity"]] <-
          self$`order_item_quantity`
      }
      if (!is.null(self$`order_item_weight`)) {
        OrderPreestimateShippingListOrderItemInnerObject[["order_item_weight"]] <-
          self$`order_item_weight`
      }
      if (!is.null(self$`order_item_variant_id`)) {
        OrderPreestimateShippingListOrderItemInnerObject[["order_item_variant_id"]] <-
          self$`order_item_variant_id`
      }
      if (!is.null(self$`order_item_option`)) {
        OrderPreestimateShippingListOrderItemInnerObject[["order_item_option"]] <-
          lapply(self$`order_item_option`, function(x) x$toSimpleType())
      }
      return(OrderPreestimateShippingListOrderItemInnerObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderPreestimateShippingListOrderItemInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderPreestimateShippingListOrderItemInner
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`order_item_id`)) {
        self$`order_item_id` <- this_object$`order_item_id`
      }
      if (!is.null(this_object$`order_item_model`)) {
        self$`order_item_model` <- this_object$`order_item_model`
      }
      if (!is.null(this_object$`order_item_quantity`)) {
        self$`order_item_quantity` <- this_object$`order_item_quantity`
      }
      if (!is.null(this_object$`order_item_weight`)) {
        self$`order_item_weight` <- this_object$`order_item_weight`
      }
      if (!is.null(this_object$`order_item_variant_id`)) {
        self$`order_item_variant_id` <- this_object$`order_item_variant_id`
      }
      if (!is.null(this_object$`order_item_option`)) {
        self$`order_item_option` <- ApiClient$new()$deserializeObj(this_object$`order_item_option`, "array[OrderPreestimateShippingListOrderItemInnerOrderItemOptionInner]", loadNamespace("openapi"))
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return OrderPreestimateShippingListOrderItemInner in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderPreestimateShippingListOrderItemInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderPreestimateShippingListOrderItemInner
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`order_item_id` <- this_object$`order_item_id`
      self$`order_item_model` <- this_object$`order_item_model`
      self$`order_item_quantity` <- this_object$`order_item_quantity`
      self$`order_item_weight` <- this_object$`order_item_weight`
      self$`order_item_variant_id` <- this_object$`order_item_variant_id`
      self$`order_item_option` <- ApiClient$new()$deserializeObj(this_object$`order_item_option`, "array[OrderPreestimateShippingListOrderItemInnerOrderItemOptionInner]", loadNamespace("openapi"))
      self
    },

    #' @description
    #' Validate JSON input with respect to OrderPreestimateShippingListOrderItemInner and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
      # check the required field `order_item_id`
      if (!is.null(input_json$`order_item_id`)) {
        if (!(is.character(input_json$`order_item_id`) && length(input_json$`order_item_id`) == 1)) {
          stop(paste("Error! Invalid data for `order_item_id`. Must be a string:", input_json$`order_item_id`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for OrderPreestimateShippingListOrderItemInner: the required field `order_item_id` is missing."))
      }
      # check the required field `order_item_quantity`
      if (!is.null(input_json$`order_item_quantity`)) {
        if (!(is.numeric(input_json$`order_item_quantity`) && length(input_json$`order_item_quantity`) == 1)) {
          stop(paste("Error! Invalid data for `order_item_quantity`. Must be an integer:", input_json$`order_item_quantity`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for OrderPreestimateShippingListOrderItemInner: the required field `order_item_quantity` is missing."))
      }
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of OrderPreestimateShippingListOrderItemInner
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      # check if the required `order_item_id` is null
      if (is.null(self$`order_item_id`)) {
        return(FALSE)
      }

      # check if the required `order_item_quantity` is null
      if (is.null(self$`order_item_quantity`)) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      # check if the required `order_item_id` is null
      if (is.null(self$`order_item_id`)) {
        invalid_fields["order_item_id"] <- "Non-nullable required field `order_item_id` cannot be null."
      }

      # check if the required `order_item_quantity` is null
      if (is.null(self$`order_item_quantity`)) {
        invalid_fields["order_item_quantity"] <- "Non-nullable required field `order_item_quantity` cannot be null."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# OrderPreestimateShippingListOrderItemInner$unlock()
#
## Below is an example to define the print function
# OrderPreestimateShippingListOrderItemInner$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# OrderPreestimateShippingListOrderItemInner$lock()

