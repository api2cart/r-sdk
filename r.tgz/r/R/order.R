#' Create a new Order
#'
#' @description
#' Order Class
#'
#' @docType class
#' @title Order
#' @description Order Class
#' @format An \code{R6Class} generator object
#' @field id  character [optional]
#' @field order_id  character [optional]
#' @field basket_id  character [optional]
#' @field channel_id  character [optional]
#' @field customer  \link{BaseCustomer} [optional]
#' @field create_at  \link{A2CDateTime} [optional]
#' @field currency  \link{Currency} [optional]
#' @field shipping_address  \link{CustomerAddress} [optional]
#' @field billing_address  \link{CustomerAddress} [optional]
#' @field payment_method  \link{OrderPaymentMethod} [optional]
#' @field shipping_method  \link{OrderShippingMethod} [optional]
#' @field shipping_methods  list(\link{OrderShippingMethod}) [optional]
#' @field status  \link{OrderStatus} [optional]
#' @field totals  \link{OrderTotals} [optional]
#' @field total  \link{OrderTotal} [optional]
#' @field discounts  list(\link{OrderTotalsNewDiscount}) [optional]
#' @field order_products  list(\link{OrderItem}) [optional]
#' @field bundles  list(\link{OrderItem}) [optional]
#' @field modified_at  \link{A2CDateTime} [optional]
#' @field finished_time  \link{A2CDateTime} [optional]
#' @field comment  character [optional]
#' @field store_id  character [optional]
#' @field warehouses_ids  list(character) [optional]
#' @field refunds  list(\link{OrderRefund}) [optional]
#' @field gift_message  character [optional]
#' @field order_details_url  character [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
Order <- R6::R6Class(
  "Order",
  public = list(
    `id` = NULL,
    `order_id` = NULL,
    `basket_id` = NULL,
    `channel_id` = NULL,
    `customer` = NULL,
    `create_at` = NULL,
    `currency` = NULL,
    `shipping_address` = NULL,
    `billing_address` = NULL,
    `payment_method` = NULL,
    `shipping_method` = NULL,
    `shipping_methods` = NULL,
    `status` = NULL,
    `totals` = NULL,
    `total` = NULL,
    `discounts` = NULL,
    `order_products` = NULL,
    `bundles` = NULL,
    `modified_at` = NULL,
    `finished_time` = NULL,
    `comment` = NULL,
    `store_id` = NULL,
    `warehouses_ids` = NULL,
    `refunds` = NULL,
    `gift_message` = NULL,
    `order_details_url` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new Order class.
    #'
    #' @param id id
    #' @param order_id order_id
    #' @param basket_id basket_id
    #' @param channel_id channel_id
    #' @param customer customer
    #' @param create_at create_at
    #' @param currency currency
    #' @param shipping_address shipping_address
    #' @param billing_address billing_address
    #' @param payment_method payment_method
    #' @param shipping_method shipping_method
    #' @param shipping_methods shipping_methods
    #' @param status status
    #' @param totals totals
    #' @param total total
    #' @param discounts discounts
    #' @param order_products order_products
    #' @param bundles bundles
    #' @param modified_at modified_at
    #' @param finished_time finished_time
    #' @param comment comment
    #' @param store_id store_id
    #' @param warehouses_ids warehouses_ids
    #' @param refunds refunds
    #' @param gift_message gift_message
    #' @param order_details_url order_details_url
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `order_id` = NULL, `basket_id` = NULL, `channel_id` = NULL, `customer` = NULL, `create_at` = NULL, `currency` = NULL, `shipping_address` = NULL, `billing_address` = NULL, `payment_method` = NULL, `shipping_method` = NULL, `shipping_methods` = NULL, `status` = NULL, `totals` = NULL, `total` = NULL, `discounts` = NULL, `order_products` = NULL, `bundles` = NULL, `modified_at` = NULL, `finished_time` = NULL, `comment` = NULL, `store_id` = NULL, `warehouses_ids` = NULL, `refunds` = NULL, `gift_message` = NULL, `order_details_url` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`order_id`)) {
        if (!(is.character(`order_id`) && length(`order_id`) == 1)) {
          stop(paste("Error! Invalid data for `order_id`. Must be a string:", `order_id`))
        }
        self$`order_id` <- `order_id`
      }
      if (!is.null(`basket_id`)) {
        if (!(is.character(`basket_id`) && length(`basket_id`) == 1)) {
          stop(paste("Error! Invalid data for `basket_id`. Must be a string:", `basket_id`))
        }
        self$`basket_id` <- `basket_id`
      }
      if (!is.null(`channel_id`)) {
        if (!(is.character(`channel_id`) && length(`channel_id`) == 1)) {
          stop(paste("Error! Invalid data for `channel_id`. Must be a string:", `channel_id`))
        }
        self$`channel_id` <- `channel_id`
      }
      if (!is.null(`customer`)) {
        stopifnot(R6::is.R6(`customer`))
        self$`customer` <- `customer`
      }
      if (!is.null(`create_at`)) {
        stopifnot(R6::is.R6(`create_at`))
        self$`create_at` <- `create_at`
      }
      if (!is.null(`currency`)) {
        stopifnot(R6::is.R6(`currency`))
        self$`currency` <- `currency`
      }
      if (!is.null(`shipping_address`)) {
        stopifnot(R6::is.R6(`shipping_address`))
        self$`shipping_address` <- `shipping_address`
      }
      if (!is.null(`billing_address`)) {
        stopifnot(R6::is.R6(`billing_address`))
        self$`billing_address` <- `billing_address`
      }
      if (!is.null(`payment_method`)) {
        stopifnot(R6::is.R6(`payment_method`))
        self$`payment_method` <- `payment_method`
      }
      if (!is.null(`shipping_method`)) {
        stopifnot(R6::is.R6(`shipping_method`))
        self$`shipping_method` <- `shipping_method`
      }
      if (!is.null(`shipping_methods`)) {
        stopifnot(is.vector(`shipping_methods`), length(`shipping_methods`) != 0)
        sapply(`shipping_methods`, function(x) stopifnot(R6::is.R6(x)))
        self$`shipping_methods` <- `shipping_methods`
      }
      if (!is.null(`status`)) {
        stopifnot(R6::is.R6(`status`))
        self$`status` <- `status`
      }
      if (!is.null(`totals`)) {
        stopifnot(R6::is.R6(`totals`))
        self$`totals` <- `totals`
      }
      if (!is.null(`total`)) {
        stopifnot(R6::is.R6(`total`))
        self$`total` <- `total`
      }
      if (!is.null(`discounts`)) {
        stopifnot(is.vector(`discounts`), length(`discounts`) != 0)
        sapply(`discounts`, function(x) stopifnot(R6::is.R6(x)))
        self$`discounts` <- `discounts`
      }
      if (!is.null(`order_products`)) {
        stopifnot(is.vector(`order_products`), length(`order_products`) != 0)
        sapply(`order_products`, function(x) stopifnot(R6::is.R6(x)))
        self$`order_products` <- `order_products`
      }
      if (!is.null(`bundles`)) {
        stopifnot(is.vector(`bundles`), length(`bundles`) != 0)
        sapply(`bundles`, function(x) stopifnot(R6::is.R6(x)))
        self$`bundles` <- `bundles`
      }
      if (!is.null(`modified_at`)) {
        stopifnot(R6::is.R6(`modified_at`))
        self$`modified_at` <- `modified_at`
      }
      if (!is.null(`finished_time`)) {
        stopifnot(R6::is.R6(`finished_time`))
        self$`finished_time` <- `finished_time`
      }
      if (!is.null(`comment`)) {
        if (!(is.character(`comment`) && length(`comment`) == 1)) {
          stop(paste("Error! Invalid data for `comment`. Must be a string:", `comment`))
        }
        self$`comment` <- `comment`
      }
      if (!is.null(`store_id`)) {
        if (!(is.character(`store_id`) && length(`store_id`) == 1)) {
          stop(paste("Error! Invalid data for `store_id`. Must be a string:", `store_id`))
        }
        self$`store_id` <- `store_id`
      }
      if (!is.null(`warehouses_ids`)) {
        stopifnot(is.vector(`warehouses_ids`), length(`warehouses_ids`) != 0)
        sapply(`warehouses_ids`, function(x) stopifnot(is.character(x)))
        self$`warehouses_ids` <- `warehouses_ids`
      }
      if (!is.null(`refunds`)) {
        stopifnot(is.vector(`refunds`), length(`refunds`) != 0)
        sapply(`refunds`, function(x) stopifnot(R6::is.R6(x)))
        self$`refunds` <- `refunds`
      }
      if (!is.null(`gift_message`)) {
        if (!(is.character(`gift_message`) && length(`gift_message`) == 1)) {
          stop(paste("Error! Invalid data for `gift_message`. Must be a string:", `gift_message`))
        }
        self$`gift_message` <- `gift_message`
      }
      if (!is.null(`order_details_url`)) {
        if (!(is.character(`order_details_url`) && length(`order_details_url`) == 1)) {
          stop(paste("Error! Invalid data for `order_details_url`. Must be a string:", `order_details_url`))
        }
        self$`order_details_url` <- `order_details_url`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return Order as a base R list.
    #' @examples
    #' # convert array of Order (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert Order to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      OrderObject <- list()
      if (!is.null(self$`id`)) {
        OrderObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`order_id`)) {
        OrderObject[["order_id"]] <-
          self$`order_id`
      }
      if (!is.null(self$`basket_id`)) {
        OrderObject[["basket_id"]] <-
          self$`basket_id`
      }
      if (!is.null(self$`channel_id`)) {
        OrderObject[["channel_id"]] <-
          self$`channel_id`
      }
      if (!is.null(self$`customer`)) {
        OrderObject[["customer"]] <-
          self$`customer`$toSimpleType()
      }
      if (!is.null(self$`create_at`)) {
        OrderObject[["create_at"]] <-
          self$`create_at`$toSimpleType()
      }
      if (!is.null(self$`currency`)) {
        OrderObject[["currency"]] <-
          self$`currency`$toSimpleType()
      }
      if (!is.null(self$`shipping_address`)) {
        OrderObject[["shipping_address"]] <-
          self$`shipping_address`$toSimpleType()
      }
      if (!is.null(self$`billing_address`)) {
        OrderObject[["billing_address"]] <-
          self$`billing_address`$toSimpleType()
      }
      if (!is.null(self$`payment_method`)) {
        OrderObject[["payment_method"]] <-
          self$`payment_method`$toSimpleType()
      }
      if (!is.null(self$`shipping_method`)) {
        OrderObject[["shipping_method"]] <-
          self$`shipping_method`$toSimpleType()
      }
      if (!is.null(self$`shipping_methods`)) {
        OrderObject[["shipping_methods"]] <-
          lapply(self$`shipping_methods`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`status`)) {
        OrderObject[["status"]] <-
          self$`status`$toSimpleType()
      }
      if (!is.null(self$`totals`)) {
        OrderObject[["totals"]] <-
          self$`totals`$toSimpleType()
      }
      if (!is.null(self$`total`)) {
        OrderObject[["total"]] <-
          self$`total`$toSimpleType()
      }
      if (!is.null(self$`discounts`)) {
        OrderObject[["discounts"]] <-
          lapply(self$`discounts`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`order_products`)) {
        OrderObject[["order_products"]] <-
          lapply(self$`order_products`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`bundles`)) {
        OrderObject[["bundles"]] <-
          lapply(self$`bundles`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`modified_at`)) {
        OrderObject[["modified_at"]] <-
          self$`modified_at`$toSimpleType()
      }
      if (!is.null(self$`finished_time`)) {
        OrderObject[["finished_time"]] <-
          self$`finished_time`$toSimpleType()
      }
      if (!is.null(self$`comment`)) {
        OrderObject[["comment"]] <-
          self$`comment`
      }
      if (!is.null(self$`store_id`)) {
        OrderObject[["store_id"]] <-
          self$`store_id`
      }
      if (!is.null(self$`warehouses_ids`)) {
        OrderObject[["warehouses_ids"]] <-
          self$`warehouses_ids`
      }
      if (!is.null(self$`refunds`)) {
        OrderObject[["refunds"]] <-
          lapply(self$`refunds`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`gift_message`)) {
        OrderObject[["gift_message"]] <-
          self$`gift_message`
      }
      if (!is.null(self$`order_details_url`)) {
        OrderObject[["order_details_url"]] <-
          self$`order_details_url`
      }
      if (!is.null(self$`additional_fields`)) {
        OrderObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        OrderObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(OrderObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of Order
    #'
    #' @param input_json the JSON input
    #' @return the instance of Order
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`order_id`)) {
        self$`order_id` <- this_object$`order_id`
      }
      if (!is.null(this_object$`basket_id`)) {
        self$`basket_id` <- this_object$`basket_id`
      }
      if (!is.null(this_object$`channel_id`)) {
        self$`channel_id` <- this_object$`channel_id`
      }
      if (!is.null(this_object$`customer`)) {
        `customer_object` <- BaseCustomer$new()
        `customer_object`$fromJSON(jsonlite::toJSON(this_object$`customer`, auto_unbox = TRUE, digits = NA))
        self$`customer` <- `customer_object`
      }
      if (!is.null(this_object$`create_at`)) {
        `create_at_object` <- A2CDateTime$new()
        `create_at_object`$fromJSON(jsonlite::toJSON(this_object$`create_at`, auto_unbox = TRUE, digits = NA))
        self$`create_at` <- `create_at_object`
      }
      if (!is.null(this_object$`currency`)) {
        `currency_object` <- Currency$new()
        `currency_object`$fromJSON(jsonlite::toJSON(this_object$`currency`, auto_unbox = TRUE, digits = NA))
        self$`currency` <- `currency_object`
      }
      if (!is.null(this_object$`shipping_address`)) {
        `shipping_address_object` <- CustomerAddress$new()
        `shipping_address_object`$fromJSON(jsonlite::toJSON(this_object$`shipping_address`, auto_unbox = TRUE, digits = NA))
        self$`shipping_address` <- `shipping_address_object`
      }
      if (!is.null(this_object$`billing_address`)) {
        `billing_address_object` <- CustomerAddress$new()
        `billing_address_object`$fromJSON(jsonlite::toJSON(this_object$`billing_address`, auto_unbox = TRUE, digits = NA))
        self$`billing_address` <- `billing_address_object`
      }
      if (!is.null(this_object$`payment_method`)) {
        `payment_method_object` <- OrderPaymentMethod$new()
        `payment_method_object`$fromJSON(jsonlite::toJSON(this_object$`payment_method`, auto_unbox = TRUE, digits = NA))
        self$`payment_method` <- `payment_method_object`
      }
      if (!is.null(this_object$`shipping_method`)) {
        `shipping_method_object` <- OrderShippingMethod$new()
        `shipping_method_object`$fromJSON(jsonlite::toJSON(this_object$`shipping_method`, auto_unbox = TRUE, digits = NA))
        self$`shipping_method` <- `shipping_method_object`
      }
      if (!is.null(this_object$`shipping_methods`)) {
        self$`shipping_methods` <- ApiClient$new()$deserializeObj(this_object$`shipping_methods`, "array[OrderShippingMethod]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`status`)) {
        `status_object` <- OrderStatus$new()
        `status_object`$fromJSON(jsonlite::toJSON(this_object$`status`, auto_unbox = TRUE, digits = NA))
        self$`status` <- `status_object`
      }
      if (!is.null(this_object$`totals`)) {
        `totals_object` <- OrderTotals$new()
        `totals_object`$fromJSON(jsonlite::toJSON(this_object$`totals`, auto_unbox = TRUE, digits = NA))
        self$`totals` <- `totals_object`
      }
      if (!is.null(this_object$`total`)) {
        `total_object` <- OrderTotal$new()
        `total_object`$fromJSON(jsonlite::toJSON(this_object$`total`, auto_unbox = TRUE, digits = NA))
        self$`total` <- `total_object`
      }
      if (!is.null(this_object$`discounts`)) {
        self$`discounts` <- ApiClient$new()$deserializeObj(this_object$`discounts`, "array[OrderTotalsNewDiscount]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`order_products`)) {
        self$`order_products` <- ApiClient$new()$deserializeObj(this_object$`order_products`, "array[OrderItem]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`bundles`)) {
        self$`bundles` <- ApiClient$new()$deserializeObj(this_object$`bundles`, "array[OrderItem]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`modified_at`)) {
        `modified_at_object` <- A2CDateTime$new()
        `modified_at_object`$fromJSON(jsonlite::toJSON(this_object$`modified_at`, auto_unbox = TRUE, digits = NA))
        self$`modified_at` <- `modified_at_object`
      }
      if (!is.null(this_object$`finished_time`)) {
        `finished_time_object` <- A2CDateTime$new()
        `finished_time_object`$fromJSON(jsonlite::toJSON(this_object$`finished_time`, auto_unbox = TRUE, digits = NA))
        self$`finished_time` <- `finished_time_object`
      }
      if (!is.null(this_object$`comment`)) {
        self$`comment` <- this_object$`comment`
      }
      if (!is.null(this_object$`store_id`)) {
        self$`store_id` <- this_object$`store_id`
      }
      if (!is.null(this_object$`warehouses_ids`)) {
        self$`warehouses_ids` <- ApiClient$new()$deserializeObj(this_object$`warehouses_ids`, "array[character]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`refunds`)) {
        self$`refunds` <- ApiClient$new()$deserializeObj(this_object$`refunds`, "array[OrderRefund]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`gift_message`)) {
        self$`gift_message` <- this_object$`gift_message`
      }
      if (!is.null(this_object$`order_details_url`)) {
        self$`order_details_url` <- this_object$`order_details_url`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return Order in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of Order
    #'
    #' @param input_json the JSON input
    #' @return the instance of Order
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`order_id` <- this_object$`order_id`
      self$`basket_id` <- this_object$`basket_id`
      self$`channel_id` <- this_object$`channel_id`
      self$`customer` <- BaseCustomer$new()$fromJSON(jsonlite::toJSON(this_object$`customer`, auto_unbox = TRUE, digits = NA))
      self$`create_at` <- A2CDateTime$new()$fromJSON(jsonlite::toJSON(this_object$`create_at`, auto_unbox = TRUE, digits = NA))
      self$`currency` <- Currency$new()$fromJSON(jsonlite::toJSON(this_object$`currency`, auto_unbox = TRUE, digits = NA))
      self$`shipping_address` <- CustomerAddress$new()$fromJSON(jsonlite::toJSON(this_object$`shipping_address`, auto_unbox = TRUE, digits = NA))
      self$`billing_address` <- CustomerAddress$new()$fromJSON(jsonlite::toJSON(this_object$`billing_address`, auto_unbox = TRUE, digits = NA))
      self$`payment_method` <- OrderPaymentMethod$new()$fromJSON(jsonlite::toJSON(this_object$`payment_method`, auto_unbox = TRUE, digits = NA))
      self$`shipping_method` <- OrderShippingMethod$new()$fromJSON(jsonlite::toJSON(this_object$`shipping_method`, auto_unbox = TRUE, digits = NA))
      self$`shipping_methods` <- ApiClient$new()$deserializeObj(this_object$`shipping_methods`, "array[OrderShippingMethod]", loadNamespace("openapi"))
      self$`status` <- OrderStatus$new()$fromJSON(jsonlite::toJSON(this_object$`status`, auto_unbox = TRUE, digits = NA))
      self$`totals` <- OrderTotals$new()$fromJSON(jsonlite::toJSON(this_object$`totals`, auto_unbox = TRUE, digits = NA))
      self$`total` <- OrderTotal$new()$fromJSON(jsonlite::toJSON(this_object$`total`, auto_unbox = TRUE, digits = NA))
      self$`discounts` <- ApiClient$new()$deserializeObj(this_object$`discounts`, "array[OrderTotalsNewDiscount]", loadNamespace("openapi"))
      self$`order_products` <- ApiClient$new()$deserializeObj(this_object$`order_products`, "array[OrderItem]", loadNamespace("openapi"))
      self$`bundles` <- ApiClient$new()$deserializeObj(this_object$`bundles`, "array[OrderItem]", loadNamespace("openapi"))
      self$`modified_at` <- A2CDateTime$new()$fromJSON(jsonlite::toJSON(this_object$`modified_at`, auto_unbox = TRUE, digits = NA))
      self$`finished_time` <- A2CDateTime$new()$fromJSON(jsonlite::toJSON(this_object$`finished_time`, auto_unbox = TRUE, digits = NA))
      self$`comment` <- this_object$`comment`
      self$`store_id` <- this_object$`store_id`
      self$`warehouses_ids` <- ApiClient$new()$deserializeObj(this_object$`warehouses_ids`, "array[character]", loadNamespace("openapi"))
      self$`refunds` <- ApiClient$new()$deserializeObj(this_object$`refunds`, "array[OrderRefund]", loadNamespace("openapi"))
      self$`gift_message` <- this_object$`gift_message`
      self$`order_details_url` <- this_object$`order_details_url`
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to Order and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of Order
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# Order$unlock()
#
## Below is an example to define the print function
# Order$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# Order$lock()

