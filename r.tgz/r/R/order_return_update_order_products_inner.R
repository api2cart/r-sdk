#' Create a new OrderReturnUpdateOrderProductsInner
#'
#' @description
#' OrderReturnUpdateOrderProductsInner Class
#'
#' @docType class
#' @title OrderReturnUpdateOrderProductsInner
#' @description OrderReturnUpdateOrderProductsInner Class
#' @format An \code{R6Class} generator object
#' @field order_product_id Defines which products from the order should be returned character
#' @field order_product_quantity Defines how many product units from the order should be returned integer
#' @field order_product_status Defines product return status character [optional]
#' @field order_product_action_id Defines the ID of the return action character
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
OrderReturnUpdateOrderProductsInner <- R6::R6Class(
  "OrderReturnUpdateOrderProductsInner",
  public = list(
    `order_product_id` = NULL,
    `order_product_quantity` = NULL,
    `order_product_status` = NULL,
    `order_product_action_id` = NULL,

    #' @description
    #' Initialize a new OrderReturnUpdateOrderProductsInner class.
    #'
    #' @param order_product_id Defines which products from the order should be returned
    #' @param order_product_quantity Defines how many product units from the order should be returned
    #' @param order_product_action_id Defines the ID of the return action
    #' @param order_product_status Defines product return status
    #' @param ... Other optional arguments.
    initialize = function(`order_product_id`, `order_product_quantity`, `order_product_action_id`, `order_product_status` = NULL, ...) {
      if (!missing(`order_product_id`)) {
        if (!(is.character(`order_product_id`) && length(`order_product_id`) == 1)) {
          stop(paste("Error! Invalid data for `order_product_id`. Must be a string:", `order_product_id`))
        }
        self$`order_product_id` <- `order_product_id`
      }
      if (!missing(`order_product_quantity`)) {
        if (!(is.numeric(`order_product_quantity`) && length(`order_product_quantity`) == 1)) {
          stop(paste("Error! Invalid data for `order_product_quantity`. Must be an integer:", `order_product_quantity`))
        }
        self$`order_product_quantity` <- `order_product_quantity`
      }
      if (!missing(`order_product_action_id`)) {
        if (!(is.character(`order_product_action_id`) && length(`order_product_action_id`) == 1)) {
          stop(paste("Error! Invalid data for `order_product_action_id`. Must be a string:", `order_product_action_id`))
        }
        self$`order_product_action_id` <- `order_product_action_id`
      }
      if (!is.null(`order_product_status`)) {
        if (!(is.character(`order_product_status`) && length(`order_product_status`) == 1)) {
          stop(paste("Error! Invalid data for `order_product_status`. Must be a string:", `order_product_status`))
        }
        self$`order_product_status` <- `order_product_status`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return OrderReturnUpdateOrderProductsInner as a base R list.
    #' @examples
    #' # convert array of OrderReturnUpdateOrderProductsInner (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert OrderReturnUpdateOrderProductsInner to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      OrderReturnUpdateOrderProductsInnerObject <- list()
      if (!is.null(self$`order_product_id`)) {
        OrderReturnUpdateOrderProductsInnerObject[["order_product_id"]] <-
          self$`order_product_id`
      }
      if (!is.null(self$`order_product_quantity`)) {
        OrderReturnUpdateOrderProductsInnerObject[["order_product_quantity"]] <-
          self$`order_product_quantity`
      }
      if (!is.null(self$`order_product_status`)) {
        OrderReturnUpdateOrderProductsInnerObject[["order_product_status"]] <-
          self$`order_product_status`
      }
      if (!is.null(self$`order_product_action_id`)) {
        OrderReturnUpdateOrderProductsInnerObject[["order_product_action_id"]] <-
          self$`order_product_action_id`
      }
      return(OrderReturnUpdateOrderProductsInnerObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderReturnUpdateOrderProductsInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderReturnUpdateOrderProductsInner
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`order_product_id`)) {
        self$`order_product_id` <- this_object$`order_product_id`
      }
      if (!is.null(this_object$`order_product_quantity`)) {
        self$`order_product_quantity` <- this_object$`order_product_quantity`
      }
      if (!is.null(this_object$`order_product_status`)) {
        self$`order_product_status` <- this_object$`order_product_status`
      }
      if (!is.null(this_object$`order_product_action_id`)) {
        self$`order_product_action_id` <- this_object$`order_product_action_id`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return OrderReturnUpdateOrderProductsInner in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderReturnUpdateOrderProductsInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderReturnUpdateOrderProductsInner
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`order_product_id` <- this_object$`order_product_id`
      self$`order_product_quantity` <- this_object$`order_product_quantity`
      self$`order_product_status` <- this_object$`order_product_status`
      self$`order_product_action_id` <- this_object$`order_product_action_id`
      self
    },

    #' @description
    #' Validate JSON input with respect to OrderReturnUpdateOrderProductsInner and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
      # check the required field `order_product_id`
      if (!is.null(input_json$`order_product_id`)) {
        if (!(is.character(input_json$`order_product_id`) && length(input_json$`order_product_id`) == 1)) {
          stop(paste("Error! Invalid data for `order_product_id`. Must be a string:", input_json$`order_product_id`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for OrderReturnUpdateOrderProductsInner: the required field `order_product_id` is missing."))
      }
      # check the required field `order_product_quantity`
      if (!is.null(input_json$`order_product_quantity`)) {
        if (!(is.numeric(input_json$`order_product_quantity`) && length(input_json$`order_product_quantity`) == 1)) {
          stop(paste("Error! Invalid data for `order_product_quantity`. Must be an integer:", input_json$`order_product_quantity`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for OrderReturnUpdateOrderProductsInner: the required field `order_product_quantity` is missing."))
      }
      # check the required field `order_product_action_id`
      if (!is.null(input_json$`order_product_action_id`)) {
        if (!(is.character(input_json$`order_product_action_id`) && length(input_json$`order_product_action_id`) == 1)) {
          stop(paste("Error! Invalid data for `order_product_action_id`. Must be a string:", input_json$`order_product_action_id`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for OrderReturnUpdateOrderProductsInner: the required field `order_product_action_id` is missing."))
      }
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of OrderReturnUpdateOrderProductsInner
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      # check if the required `order_product_id` is null
      if (is.null(self$`order_product_id`)) {
        return(FALSE)
      }

      # check if the required `order_product_quantity` is null
      if (is.null(self$`order_product_quantity`)) {
        return(FALSE)
      }

      # check if the required `order_product_action_id` is null
      if (is.null(self$`order_product_action_id`)) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      # check if the required `order_product_id` is null
      if (is.null(self$`order_product_id`)) {
        invalid_fields["order_product_id"] <- "Non-nullable required field `order_product_id` cannot be null."
      }

      # check if the required `order_product_quantity` is null
      if (is.null(self$`order_product_quantity`)) {
        invalid_fields["order_product_quantity"] <- "Non-nullable required field `order_product_quantity` cannot be null."
      }

      # check if the required `order_product_action_id` is null
      if (is.null(self$`order_product_action_id`)) {
        invalid_fields["order_product_action_id"] <- "Non-nullable required field `order_product_action_id` cannot be null."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# OrderReturnUpdateOrderProductsInner$unlock()
#
## Below is an example to define the print function
# OrderReturnUpdateOrderProductsInner$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# OrderReturnUpdateOrderProductsInner$lock()

