#' Create a new ProductUpdateBatchPayloadInnerAdvancedPricesInner
#'
#' @description
#' ProductUpdateBatchPayloadInnerAdvancedPricesInner Class
#'
#' @docType class
#' @title ProductUpdateBatchPayloadInnerAdvancedPricesInner
#' @description ProductUpdateBatchPayloadInnerAdvancedPricesInner Class
#' @format An \code{R6Class} generator object
#' @field value  numeric
#' @field group_id  integer [optional]
#' @field quantity  numeric
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductUpdateBatchPayloadInnerAdvancedPricesInner <- R6::R6Class(
  "ProductUpdateBatchPayloadInnerAdvancedPricesInner",
  public = list(
    `value` = NULL,
    `group_id` = NULL,
    `quantity` = NULL,

    #' @description
    #' Initialize a new ProductUpdateBatchPayloadInnerAdvancedPricesInner class.
    #'
    #' @param value value
    #' @param quantity quantity
    #' @param group_id group_id
    #' @param ... Other optional arguments.
    initialize = function(`value`, `quantity`, `group_id` = NULL, ...) {
      if (!missing(`value`)) {
        self$`value` <- `value`
      }
      if (!missing(`quantity`)) {
        self$`quantity` <- `quantity`
      }
      if (!is.null(`group_id`)) {
        if (!(is.numeric(`group_id`) && length(`group_id`) == 1)) {
          stop(paste("Error! Invalid data for `group_id`. Must be an integer:", `group_id`))
        }
        self$`group_id` <- `group_id`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductUpdateBatchPayloadInnerAdvancedPricesInner as a base R list.
    #' @examples
    #' # convert array of ProductUpdateBatchPayloadInnerAdvancedPricesInner (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductUpdateBatchPayloadInnerAdvancedPricesInner to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductUpdateBatchPayloadInnerAdvancedPricesInnerObject <- list()
      if (!is.null(self$`value`)) {
        ProductUpdateBatchPayloadInnerAdvancedPricesInnerObject[["value"]] <-
          self$`value`
      }
      if (!is.null(self$`group_id`)) {
        ProductUpdateBatchPayloadInnerAdvancedPricesInnerObject[["group_id"]] <-
          self$`group_id`
      }
      if (!is.null(self$`quantity`)) {
        ProductUpdateBatchPayloadInnerAdvancedPricesInnerObject[["quantity"]] <-
          self$`quantity`
      }
      return(ProductUpdateBatchPayloadInnerAdvancedPricesInnerObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductUpdateBatchPayloadInnerAdvancedPricesInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductUpdateBatchPayloadInnerAdvancedPricesInner
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`value`)) {
        self$`value` <- this_object$`value`
      }
      if (!is.null(this_object$`group_id`)) {
        self$`group_id` <- this_object$`group_id`
      }
      if (!is.null(this_object$`quantity`)) {
        self$`quantity` <- this_object$`quantity`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductUpdateBatchPayloadInnerAdvancedPricesInner in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductUpdateBatchPayloadInnerAdvancedPricesInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductUpdateBatchPayloadInnerAdvancedPricesInner
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`value` <- this_object$`value`
      self$`group_id` <- this_object$`group_id`
      self$`quantity` <- this_object$`quantity`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductUpdateBatchPayloadInnerAdvancedPricesInner and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
      # check the required field `value`
      if (!is.null(input_json$`value`)) {
      } else {
        stop(paste("The JSON input `", input, "` is invalid for ProductUpdateBatchPayloadInnerAdvancedPricesInner: the required field `value` is missing."))
      }
      # check the required field `quantity`
      if (!is.null(input_json$`quantity`)) {
      } else {
        stop(paste("The JSON input `", input, "` is invalid for ProductUpdateBatchPayloadInnerAdvancedPricesInner: the required field `quantity` is missing."))
      }
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductUpdateBatchPayloadInnerAdvancedPricesInner
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      # check if the required `value` is null
      if (is.null(self$`value`)) {
        return(FALSE)
      }

      # check if the required `quantity` is null
      if (is.null(self$`quantity`)) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      # check if the required `value` is null
      if (is.null(self$`value`)) {
        invalid_fields["value"] <- "Non-nullable required field `value` cannot be null."
      }

      # check if the required `quantity` is null
      if (is.null(self$`quantity`)) {
        invalid_fields["quantity"] <- "Non-nullable required field `quantity` cannot be null."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductUpdateBatchPayloadInnerAdvancedPricesInner$unlock()
#
## Below is an example to define the print function
# ProductUpdateBatchPayloadInnerAdvancedPricesInner$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductUpdateBatchPayloadInnerAdvancedPricesInner$lock()

