#' Create a new OrderStatusRefund
#'
#' @description
#' OrderStatusRefund Class
#'
#' @docType class
#' @title OrderStatusRefund
#' @description OrderStatusRefund Class
#' @format An \code{R6Class} generator object
#' @field shipping  numeric [optional]
#' @field fee  numeric [optional]
#' @field tax  numeric [optional]
#' @field total_refunded  numeric [optional]
#' @field time  \link{A2CDateTime} [optional]
#' @field comment  character [optional]
#' @field refunded_items  list(\link{OrderStatusRefundItem}) [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
OrderStatusRefund <- R6::R6Class(
  "OrderStatusRefund",
  public = list(
    `shipping` = NULL,
    `fee` = NULL,
    `tax` = NULL,
    `total_refunded` = NULL,
    `time` = NULL,
    `comment` = NULL,
    `refunded_items` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new OrderStatusRefund class.
    #'
    #' @param shipping shipping
    #' @param fee fee
    #' @param tax tax
    #' @param total_refunded total_refunded
    #' @param time time
    #' @param comment comment
    #' @param refunded_items refunded_items
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`shipping` = NULL, `fee` = NULL, `tax` = NULL, `total_refunded` = NULL, `time` = NULL, `comment` = NULL, `refunded_items` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`shipping`)) {
        self$`shipping` <- `shipping`
      }
      if (!is.null(`fee`)) {
        self$`fee` <- `fee`
      }
      if (!is.null(`tax`)) {
        self$`tax` <- `tax`
      }
      if (!is.null(`total_refunded`)) {
        self$`total_refunded` <- `total_refunded`
      }
      if (!is.null(`time`)) {
        stopifnot(R6::is.R6(`time`))
        self$`time` <- `time`
      }
      if (!is.null(`comment`)) {
        if (!(is.character(`comment`) && length(`comment`) == 1)) {
          stop(paste("Error! Invalid data for `comment`. Must be a string:", `comment`))
        }
        self$`comment` <- `comment`
      }
      if (!is.null(`refunded_items`)) {
        stopifnot(is.vector(`refunded_items`), length(`refunded_items`) != 0)
        sapply(`refunded_items`, function(x) stopifnot(R6::is.R6(x)))
        self$`refunded_items` <- `refunded_items`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return OrderStatusRefund as a base R list.
    #' @examples
    #' # convert array of OrderStatusRefund (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert OrderStatusRefund to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      OrderStatusRefundObject <- list()
      if (!is.null(self$`shipping`)) {
        OrderStatusRefundObject[["shipping"]] <-
          self$`shipping`
      }
      if (!is.null(self$`fee`)) {
        OrderStatusRefundObject[["fee"]] <-
          self$`fee`
      }
      if (!is.null(self$`tax`)) {
        OrderStatusRefundObject[["tax"]] <-
          self$`tax`
      }
      if (!is.null(self$`total_refunded`)) {
        OrderStatusRefundObject[["total_refunded"]] <-
          self$`total_refunded`
      }
      if (!is.null(self$`time`)) {
        OrderStatusRefundObject[["time"]] <-
          self$`time`$toSimpleType()
      }
      if (!is.null(self$`comment`)) {
        OrderStatusRefundObject[["comment"]] <-
          self$`comment`
      }
      if (!is.null(self$`refunded_items`)) {
        OrderStatusRefundObject[["refunded_items"]] <-
          lapply(self$`refunded_items`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`additional_fields`)) {
        OrderStatusRefundObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        OrderStatusRefundObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(OrderStatusRefundObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderStatusRefund
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderStatusRefund
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`shipping`)) {
        self$`shipping` <- this_object$`shipping`
      }
      if (!is.null(this_object$`fee`)) {
        self$`fee` <- this_object$`fee`
      }
      if (!is.null(this_object$`tax`)) {
        self$`tax` <- this_object$`tax`
      }
      if (!is.null(this_object$`total_refunded`)) {
        self$`total_refunded` <- this_object$`total_refunded`
      }
      if (!is.null(this_object$`time`)) {
        `time_object` <- A2CDateTime$new()
        `time_object`$fromJSON(jsonlite::toJSON(this_object$`time`, auto_unbox = TRUE, digits = NA))
        self$`time` <- `time_object`
      }
      if (!is.null(this_object$`comment`)) {
        self$`comment` <- this_object$`comment`
      }
      if (!is.null(this_object$`refunded_items`)) {
        self$`refunded_items` <- ApiClient$new()$deserializeObj(this_object$`refunded_items`, "array[OrderStatusRefundItem]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return OrderStatusRefund in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderStatusRefund
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderStatusRefund
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`shipping` <- this_object$`shipping`
      self$`fee` <- this_object$`fee`
      self$`tax` <- this_object$`tax`
      self$`total_refunded` <- this_object$`total_refunded`
      self$`time` <- A2CDateTime$new()$fromJSON(jsonlite::toJSON(this_object$`time`, auto_unbox = TRUE, digits = NA))
      self$`comment` <- this_object$`comment`
      self$`refunded_items` <- ApiClient$new()$deserializeObj(this_object$`refunded_items`, "array[OrderStatusRefundItem]", loadNamespace("openapi"))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to OrderStatusRefund and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of OrderStatusRefund
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# OrderStatusRefund$unlock()
#
## Below is an example to define the print function
# OrderStatusRefund$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# OrderStatusRefund$lock()

