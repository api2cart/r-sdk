#' Create a new OrderAdd
#'
#' @description
#' OrderAdd Class
#'
#' @docType class
#' @title OrderAdd
#' @description OrderAdd Class
#' @format An \code{R6Class} generator object
#' @field id Defines order's id character [optional]
#' @field order_id Defines the order id if it is supported by the cart character [optional]
#' @field store_id Defines store id where the order should be assigned character [optional]
#' @field channel_id Channel ID character [optional]
#' @field order_status Defines order status. character
#' @field fulfillment_status Create order with fulfillment status character [optional]
#' @field financial_status Create order with financial status character [optional]
#' @field customer_email Defines the customer specified by email for whom order has to be created character
#' @field customer_first_name Specifies customer's first name character [optional]
#' @field customer_last_name Specifies customer’s last name character [optional]
#' @field customer_phone Specifies customer’s phone character [optional]
#' @field customer_country Specifies customer's address ISO code or name of country character [optional]
#' @field customer_birthday Specifies customer’s birthday character [optional]
#' @field customer_fax Specifies customer’s fax character [optional]
#' @field is_guest Indicates whether the customer is a guest customer character [optional]
#' @field order_payment_method Defines order payment method.<br/>Setting order_payment_method on Shopify will also change financial_status field value to 'paid' character [optional]
#' @field transaction_id Payment transaction id character [optional]
#' @field currency Currency code of order character [optional]
#' @field date Specifies an order creation date in format Y-m-d H:i:s character [optional]
#' @field date_modified Specifies order's  modification date character [optional]
#' @field date_finished Specifies order's  finished date character [optional]
#' @field bill_first_name Specifies billing first name character
#' @field bill_last_name Specifies billing last name character
#' @field bill_address_1 Specifies first billing address character
#' @field bill_address_2 Specifies second billing address character [optional]
#' @field bill_city Specifies billing city character
#' @field bill_postcode Specifies billing postcode character
#' @field bill_state Specifies billing state code character
#' @field bill_country Specifies billing country code character
#' @field bill_company Specifies billing company character [optional]
#' @field bill_phone Specifies billing phone character [optional]
#' @field bill_fax Specifies billing fax character [optional]
#' @field shipp_first_name Specifies shipping first name character [optional]
#' @field shipp_last_name Specifies shipping last name character [optional]
#' @field shipp_address_1 Specifies first shipping address character [optional]
#' @field shipp_address_2 Specifies second address line of a shipping street address character [optional]
#' @field shipp_city Specifies shipping city character [optional]
#' @field shipp_postcode Specifies shipping postcode character [optional]
#' @field shipp_state Specifies shipping state code character [optional]
#' @field shipp_country Specifies shipping country code character [optional]
#' @field shipp_company Specifies shipping company character [optional]
#' @field shipp_phone Specifies shipping phone character [optional]
#' @field shipp_fax Specifies shipping fax character [optional]
#' @field subtotal_price Total price of all ordered products multiplied by their number, excluding tax, shipping price and discounts numeric [optional]
#' @field tax_price The value of tax cost for order numeric [optional]
#' @field total_price Defines order's total price numeric [optional]
#' @field total_paid Defines total paid amount for the order numeric [optional]
#' @field total_weight Defines the sum of all line item weights in grams for the order integer [optional]
#' @field prices_inc_tax Indicates whether prices and subtotal include tax. character [optional]
#' @field shipping_price Specifies order's shipping price numeric [optional]
#' @field shipping_tax Specifies order's shipping price tax numeric [optional]
#' @field discount Specifies order's discount numeric [optional]
#' @field coupon_discount Specifies order's coupon discount numeric [optional]
#' @field gift_certificate_discount Discounts for order with gift certificates numeric [optional]
#' @field order_shipping_method Defines order shipping method character [optional]
#' @field carrier_id Defines tracking carrier id character [optional]
#' @field warehouse_id This parameter is used for selecting a warehouse where you need to set/modify a product quantity. character [optional]
#' @field coupons Coupons that will be applied to order list(character) [optional]
#' @field tags Order tags character [optional]
#' @field comment Specifies order comment character [optional]
#' @field admin_comment Specifies admin's order comment character [optional]
#' @field admin_private_comment Specifies private admin's order comment character [optional]
#' @field send_notifications Send notifications to customer after order was created character [optional]
#' @field send_admin_notifications Notify admin when new order was created. character [optional]
#' @field external_source Identifying the system used to generate the order character [optional]
#' @field inventory_behaviour The behaviour to use when updating inventory.<hr><div style=\"font-style:normal\">Values description:<div style=\"margin-left: 2\%; padding-top: 2\%\"><div style=\"font-size:85\%\"><b>bypass</b> = Do not claim inventory </br></br><b>decrement_ignoring_policy</b> = Ignore the product's </br> inventory policy and claim amounts</br></br><b>decrement_obeying_policy</b> =  Obey the product's </br> inventory policy.</br></br></div></div></div> character [optional]
#' @field create_invoice Defines whether the invoice is created automatically along with the order character [optional]
#' @field note_attributes Defines note attributes list(\link{OrderAddNoteAttributesInner}) [optional]
#' @field clear_cache Is cache clear required character [optional]
#' @field origin The source of the order character [optional]
#' @field fee_price Specifies refund's fee price numeric [optional]
#' @field idempotency_key A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong> character [optional]
#' @field order_item  list(\link{OrderAddOrderItemInner})
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
OrderAdd <- R6::R6Class(
  "OrderAdd",
  public = list(
    `id` = NULL,
    `order_id` = NULL,
    `store_id` = NULL,
    `channel_id` = NULL,
    `order_status` = NULL,
    `fulfillment_status` = NULL,
    `financial_status` = NULL,
    `customer_email` = NULL,
    `customer_first_name` = NULL,
    `customer_last_name` = NULL,
    `customer_phone` = NULL,
    `customer_country` = NULL,
    `customer_birthday` = NULL,
    `customer_fax` = NULL,
    `is_guest` = NULL,
    `order_payment_method` = NULL,
    `transaction_id` = NULL,
    `currency` = NULL,
    `date` = NULL,
    `date_modified` = NULL,
    `date_finished` = NULL,
    `bill_first_name` = NULL,
    `bill_last_name` = NULL,
    `bill_address_1` = NULL,
    `bill_address_2` = NULL,
    `bill_city` = NULL,
    `bill_postcode` = NULL,
    `bill_state` = NULL,
    `bill_country` = NULL,
    `bill_company` = NULL,
    `bill_phone` = NULL,
    `bill_fax` = NULL,
    `shipp_first_name` = NULL,
    `shipp_last_name` = NULL,
    `shipp_address_1` = NULL,
    `shipp_address_2` = NULL,
    `shipp_city` = NULL,
    `shipp_postcode` = NULL,
    `shipp_state` = NULL,
    `shipp_country` = NULL,
    `shipp_company` = NULL,
    `shipp_phone` = NULL,
    `shipp_fax` = NULL,
    `subtotal_price` = NULL,
    `tax_price` = NULL,
    `total_price` = NULL,
    `total_paid` = NULL,
    `total_weight` = NULL,
    `prices_inc_tax` = NULL,
    `shipping_price` = NULL,
    `shipping_tax` = NULL,
    `discount` = NULL,
    `coupon_discount` = NULL,
    `gift_certificate_discount` = NULL,
    `order_shipping_method` = NULL,
    `carrier_id` = NULL,
    `warehouse_id` = NULL,
    `coupons` = NULL,
    `tags` = NULL,
    `comment` = NULL,
    `admin_comment` = NULL,
    `admin_private_comment` = NULL,
    `send_notifications` = NULL,
    `send_admin_notifications` = NULL,
    `external_source` = NULL,
    `inventory_behaviour` = NULL,
    `create_invoice` = NULL,
    `note_attributes` = NULL,
    `clear_cache` = NULL,
    `origin` = NULL,
    `fee_price` = NULL,
    `idempotency_key` = NULL,
    `order_item` = NULL,

    #' @description
    #' Initialize a new OrderAdd class.
    #'
    #' @param order_status Defines order status.
    #' @param customer_email Defines the customer specified by email for whom order has to be created
    #' @param bill_first_name Specifies billing first name
    #' @param bill_last_name Specifies billing last name
    #' @param bill_address_1 Specifies first billing address
    #' @param bill_city Specifies billing city
    #' @param bill_postcode Specifies billing postcode
    #' @param bill_state Specifies billing state code
    #' @param bill_country Specifies billing country code
    #' @param order_item order_item
    #' @param id Defines order's id
    #' @param order_id Defines the order id if it is supported by the cart
    #' @param store_id Defines store id where the order should be assigned
    #' @param channel_id Channel ID
    #' @param fulfillment_status Create order with fulfillment status
    #' @param financial_status Create order with financial status
    #' @param customer_first_name Specifies customer's first name
    #' @param customer_last_name Specifies customer’s last name
    #' @param customer_phone Specifies customer’s phone
    #' @param customer_country Specifies customer's address ISO code or name of country
    #' @param customer_birthday Specifies customer’s birthday
    #' @param customer_fax Specifies customer’s fax
    #' @param is_guest Indicates whether the customer is a guest customer. Default to FALSE.
    #' @param order_payment_method Defines order payment method.<br/>Setting order_payment_method on Shopify will also change financial_status field value to 'paid'
    #' @param transaction_id Payment transaction id
    #' @param currency Currency code of order
    #' @param date Specifies an order creation date in format Y-m-d H:i:s
    #' @param date_modified Specifies order's  modification date
    #' @param date_finished Specifies order's  finished date
    #' @param bill_address_2 Specifies second billing address
    #' @param bill_company Specifies billing company
    #' @param bill_phone Specifies billing phone
    #' @param bill_fax Specifies billing fax
    #' @param shipp_first_name Specifies shipping first name
    #' @param shipp_last_name Specifies shipping last name
    #' @param shipp_address_1 Specifies first shipping address
    #' @param shipp_address_2 Specifies second address line of a shipping street address
    #' @param shipp_city Specifies shipping city
    #' @param shipp_postcode Specifies shipping postcode
    #' @param shipp_state Specifies shipping state code
    #' @param shipp_country Specifies shipping country code
    #' @param shipp_company Specifies shipping company
    #' @param shipp_phone Specifies shipping phone
    #' @param shipp_fax Specifies shipping fax
    #' @param subtotal_price Total price of all ordered products multiplied by their number, excluding tax, shipping price and discounts
    #' @param tax_price The value of tax cost for order. Default to 0.
    #' @param total_price Defines order's total price
    #' @param total_paid Defines total paid amount for the order
    #' @param total_weight Defines the sum of all line item weights in grams for the order
    #' @param prices_inc_tax Indicates whether prices and subtotal include tax.. Default to FALSE.
    #' @param shipping_price Specifies order's shipping price. Default to 0.
    #' @param shipping_tax Specifies order's shipping price tax
    #' @param discount Specifies order's discount
    #' @param coupon_discount Specifies order's coupon discount
    #' @param gift_certificate_discount Discounts for order with gift certificates
    #' @param order_shipping_method Defines order shipping method
    #' @param carrier_id Defines tracking carrier id
    #' @param warehouse_id This parameter is used for selecting a warehouse where you need to set/modify a product quantity.
    #' @param coupons Coupons that will be applied to order
    #' @param tags Order tags
    #' @param comment Specifies order comment
    #' @param admin_comment Specifies admin's order comment
    #' @param admin_private_comment Specifies private admin's order comment
    #' @param send_notifications Send notifications to customer after order was created. Default to FALSE.
    #' @param send_admin_notifications Notify admin when new order was created.. Default to FALSE.
    #' @param external_source Identifying the system used to generate the order
    #' @param inventory_behaviour The behaviour to use when updating inventory.<hr><div style=\"font-style:normal\">Values description:<div style=\"margin-left: 2\%; padding-top: 2\%\"><div style=\"font-size:85\%\"><b>bypass</b> = Do not claim inventory </br></br><b>decrement_ignoring_policy</b> = Ignore the product's </br> inventory policy and claim amounts</br></br><b>decrement_obeying_policy</b> =  Obey the product's </br> inventory policy.</br></br></div></div></div>. Default to "bypass".
    #' @param create_invoice Defines whether the invoice is created automatically along with the order. Default to FALSE.
    #' @param note_attributes Defines note attributes
    #' @param clear_cache Is cache clear required. Default to TRUE.
    #' @param origin The source of the order
    #' @param fee_price Specifies refund's fee price
    #' @param idempotency_key A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong>
    #' @param ... Other optional arguments.
    initialize = function(`order_status`, `customer_email`, `bill_first_name`, `bill_last_name`, `bill_address_1`, `bill_city`, `bill_postcode`, `bill_state`, `bill_country`, `order_item`, `id` = NULL, `order_id` = NULL, `store_id` = NULL, `channel_id` = NULL, `fulfillment_status` = NULL, `financial_status` = NULL, `customer_first_name` = NULL, `customer_last_name` = NULL, `customer_phone` = NULL, `customer_country` = NULL, `customer_birthday` = NULL, `customer_fax` = NULL, `is_guest` = FALSE, `order_payment_method` = NULL, `transaction_id` = NULL, `currency` = NULL, `date` = NULL, `date_modified` = NULL, `date_finished` = NULL, `bill_address_2` = NULL, `bill_company` = NULL, `bill_phone` = NULL, `bill_fax` = NULL, `shipp_first_name` = NULL, `shipp_last_name` = NULL, `shipp_address_1` = NULL, `shipp_address_2` = NULL, `shipp_city` = NULL, `shipp_postcode` = NULL, `shipp_state` = NULL, `shipp_country` = NULL, `shipp_company` = NULL, `shipp_phone` = NULL, `shipp_fax` = NULL, `subtotal_price` = NULL, `tax_price` = 0, `total_price` = NULL, `total_paid` = NULL, `total_weight` = NULL, `prices_inc_tax` = FALSE, `shipping_price` = 0, `shipping_tax` = NULL, `discount` = NULL, `coupon_discount` = NULL, `gift_certificate_discount` = NULL, `order_shipping_method` = NULL, `carrier_id` = NULL, `warehouse_id` = NULL, `coupons` = NULL, `tags` = NULL, `comment` = NULL, `admin_comment` = NULL, `admin_private_comment` = NULL, `send_notifications` = FALSE, `send_admin_notifications` = FALSE, `external_source` = NULL, `inventory_behaviour` = "bypass", `create_invoice` = FALSE, `note_attributes` = NULL, `clear_cache` = TRUE, `origin` = NULL, `fee_price` = NULL, `idempotency_key` = NULL, ...) {
      if (!missing(`order_status`)) {
        if (!(is.character(`order_status`) && length(`order_status`) == 1)) {
          stop(paste("Error! Invalid data for `order_status`. Must be a string:", `order_status`))
        }
        self$`order_status` <- `order_status`
      }
      if (!missing(`customer_email`)) {
        if (!(is.character(`customer_email`) && length(`customer_email`) == 1)) {
          stop(paste("Error! Invalid data for `customer_email`. Must be a string:", `customer_email`))
        }
        self$`customer_email` <- `customer_email`
      }
      if (!missing(`bill_first_name`)) {
        if (!(is.character(`bill_first_name`) && length(`bill_first_name`) == 1)) {
          stop(paste("Error! Invalid data for `bill_first_name`. Must be a string:", `bill_first_name`))
        }
        self$`bill_first_name` <- `bill_first_name`
      }
      if (!missing(`bill_last_name`)) {
        if (!(is.character(`bill_last_name`) && length(`bill_last_name`) == 1)) {
          stop(paste("Error! Invalid data for `bill_last_name`. Must be a string:", `bill_last_name`))
        }
        self$`bill_last_name` <- `bill_last_name`
      }
      if (!missing(`bill_address_1`)) {
        if (!(is.character(`bill_address_1`) && length(`bill_address_1`) == 1)) {
          stop(paste("Error! Invalid data for `bill_address_1`. Must be a string:", `bill_address_1`))
        }
        self$`bill_address_1` <- `bill_address_1`
      }
      if (!missing(`bill_city`)) {
        if (!(is.character(`bill_city`) && length(`bill_city`) == 1)) {
          stop(paste("Error! Invalid data for `bill_city`. Must be a string:", `bill_city`))
        }
        self$`bill_city` <- `bill_city`
      }
      if (!missing(`bill_postcode`)) {
        if (!(is.character(`bill_postcode`) && length(`bill_postcode`) == 1)) {
          stop(paste("Error! Invalid data for `bill_postcode`. Must be a string:", `bill_postcode`))
        }
        self$`bill_postcode` <- `bill_postcode`
      }
      if (!missing(`bill_state`)) {
        if (!(is.character(`bill_state`) && length(`bill_state`) == 1)) {
          stop(paste("Error! Invalid data for `bill_state`. Must be a string:", `bill_state`))
        }
        self$`bill_state` <- `bill_state`
      }
      if (!missing(`bill_country`)) {
        if (!(is.character(`bill_country`) && length(`bill_country`) == 1)) {
          stop(paste("Error! Invalid data for `bill_country`. Must be a string:", `bill_country`))
        }
        self$`bill_country` <- `bill_country`
      }
      if (!missing(`order_item`)) {
        stopifnot(is.vector(`order_item`), length(`order_item`) != 0)
        sapply(`order_item`, function(x) stopifnot(R6::is.R6(x)))
        self$`order_item` <- `order_item`
      }
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`order_id`)) {
        if (!(is.character(`order_id`) && length(`order_id`) == 1)) {
          stop(paste("Error! Invalid data for `order_id`. Must be a string:", `order_id`))
        }
        self$`order_id` <- `order_id`
      }
      if (!is.null(`store_id`)) {
        if (!(is.character(`store_id`) && length(`store_id`) == 1)) {
          stop(paste("Error! Invalid data for `store_id`. Must be a string:", `store_id`))
        }
        self$`store_id` <- `store_id`
      }
      if (!is.null(`channel_id`)) {
        if (!(is.character(`channel_id`) && length(`channel_id`) == 1)) {
          stop(paste("Error! Invalid data for `channel_id`. Must be a string:", `channel_id`))
        }
        self$`channel_id` <- `channel_id`
      }
      if (!is.null(`fulfillment_status`)) {
        if (!(is.character(`fulfillment_status`) && length(`fulfillment_status`) == 1)) {
          stop(paste("Error! Invalid data for `fulfillment_status`. Must be a string:", `fulfillment_status`))
        }
        self$`fulfillment_status` <- `fulfillment_status`
      }
      if (!is.null(`financial_status`)) {
        if (!(is.character(`financial_status`) && length(`financial_status`) == 1)) {
          stop(paste("Error! Invalid data for `financial_status`. Must be a string:", `financial_status`))
        }
        self$`financial_status` <- `financial_status`
      }
      if (!is.null(`customer_first_name`)) {
        if (!(is.character(`customer_first_name`) && length(`customer_first_name`) == 1)) {
          stop(paste("Error! Invalid data for `customer_first_name`. Must be a string:", `customer_first_name`))
        }
        self$`customer_first_name` <- `customer_first_name`
      }
      if (!is.null(`customer_last_name`)) {
        if (!(is.character(`customer_last_name`) && length(`customer_last_name`) == 1)) {
          stop(paste("Error! Invalid data for `customer_last_name`. Must be a string:", `customer_last_name`))
        }
        self$`customer_last_name` <- `customer_last_name`
      }
      if (!is.null(`customer_phone`)) {
        if (!(is.character(`customer_phone`) && length(`customer_phone`) == 1)) {
          stop(paste("Error! Invalid data for `customer_phone`. Must be a string:", `customer_phone`))
        }
        self$`customer_phone` <- `customer_phone`
      }
      if (!is.null(`customer_country`)) {
        if (!(is.character(`customer_country`) && length(`customer_country`) == 1)) {
          stop(paste("Error! Invalid data for `customer_country`. Must be a string:", `customer_country`))
        }
        self$`customer_country` <- `customer_country`
      }
      if (!is.null(`customer_birthday`)) {
        if (!(is.character(`customer_birthday`) && length(`customer_birthday`) == 1)) {
          stop(paste("Error! Invalid data for `customer_birthday`. Must be a string:", `customer_birthday`))
        }
        self$`customer_birthday` <- `customer_birthday`
      }
      if (!is.null(`customer_fax`)) {
        if (!(is.character(`customer_fax`) && length(`customer_fax`) == 1)) {
          stop(paste("Error! Invalid data for `customer_fax`. Must be a string:", `customer_fax`))
        }
        self$`customer_fax` <- `customer_fax`
      }
      if (!is.null(`is_guest`)) {
        if (!(is.logical(`is_guest`) && length(`is_guest`) == 1)) {
          stop(paste("Error! Invalid data for `is_guest`. Must be a boolean:", `is_guest`))
        }
        self$`is_guest` <- `is_guest`
      }
      if (!is.null(`order_payment_method`)) {
        if (!(is.character(`order_payment_method`) && length(`order_payment_method`) == 1)) {
          stop(paste("Error! Invalid data for `order_payment_method`. Must be a string:", `order_payment_method`))
        }
        self$`order_payment_method` <- `order_payment_method`
      }
      if (!is.null(`transaction_id`)) {
        if (!(is.character(`transaction_id`) && length(`transaction_id`) == 1)) {
          stop(paste("Error! Invalid data for `transaction_id`. Must be a string:", `transaction_id`))
        }
        self$`transaction_id` <- `transaction_id`
      }
      if (!is.null(`currency`)) {
        if (!(is.character(`currency`) && length(`currency`) == 1)) {
          stop(paste("Error! Invalid data for `currency`. Must be a string:", `currency`))
        }
        self$`currency` <- `currency`
      }
      if (!is.null(`date`)) {
        if (!(is.character(`date`) && length(`date`) == 1)) {
          stop(paste("Error! Invalid data for `date`. Must be a string:", `date`))
        }
        self$`date` <- `date`
      }
      if (!is.null(`date_modified`)) {
        if (!(is.character(`date_modified`) && length(`date_modified`) == 1)) {
          stop(paste("Error! Invalid data for `date_modified`. Must be a string:", `date_modified`))
        }
        self$`date_modified` <- `date_modified`
      }
      if (!is.null(`date_finished`)) {
        if (!(is.character(`date_finished`) && length(`date_finished`) == 1)) {
          stop(paste("Error! Invalid data for `date_finished`. Must be a string:", `date_finished`))
        }
        self$`date_finished` <- `date_finished`
      }
      if (!is.null(`bill_address_2`)) {
        if (!(is.character(`bill_address_2`) && length(`bill_address_2`) == 1)) {
          stop(paste("Error! Invalid data for `bill_address_2`. Must be a string:", `bill_address_2`))
        }
        self$`bill_address_2` <- `bill_address_2`
      }
      if (!is.null(`bill_company`)) {
        if (!(is.character(`bill_company`) && length(`bill_company`) == 1)) {
          stop(paste("Error! Invalid data for `bill_company`. Must be a string:", `bill_company`))
        }
        self$`bill_company` <- `bill_company`
      }
      if (!is.null(`bill_phone`)) {
        if (!(is.character(`bill_phone`) && length(`bill_phone`) == 1)) {
          stop(paste("Error! Invalid data for `bill_phone`. Must be a string:", `bill_phone`))
        }
        self$`bill_phone` <- `bill_phone`
      }
      if (!is.null(`bill_fax`)) {
        if (!(is.character(`bill_fax`) && length(`bill_fax`) == 1)) {
          stop(paste("Error! Invalid data for `bill_fax`. Must be a string:", `bill_fax`))
        }
        self$`bill_fax` <- `bill_fax`
      }
      if (!is.null(`shipp_first_name`)) {
        if (!(is.character(`shipp_first_name`) && length(`shipp_first_name`) == 1)) {
          stop(paste("Error! Invalid data for `shipp_first_name`. Must be a string:", `shipp_first_name`))
        }
        self$`shipp_first_name` <- `shipp_first_name`
      }
      if (!is.null(`shipp_last_name`)) {
        if (!(is.character(`shipp_last_name`) && length(`shipp_last_name`) == 1)) {
          stop(paste("Error! Invalid data for `shipp_last_name`. Must be a string:", `shipp_last_name`))
        }
        self$`shipp_last_name` <- `shipp_last_name`
      }
      if (!is.null(`shipp_address_1`)) {
        if (!(is.character(`shipp_address_1`) && length(`shipp_address_1`) == 1)) {
          stop(paste("Error! Invalid data for `shipp_address_1`. Must be a string:", `shipp_address_1`))
        }
        self$`shipp_address_1` <- `shipp_address_1`
      }
      if (!is.null(`shipp_address_2`)) {
        if (!(is.character(`shipp_address_2`) && length(`shipp_address_2`) == 1)) {
          stop(paste("Error! Invalid data for `shipp_address_2`. Must be a string:", `shipp_address_2`))
        }
        self$`shipp_address_2` <- `shipp_address_2`
      }
      if (!is.null(`shipp_city`)) {
        if (!(is.character(`shipp_city`) && length(`shipp_city`) == 1)) {
          stop(paste("Error! Invalid data for `shipp_city`. Must be a string:", `shipp_city`))
        }
        self$`shipp_city` <- `shipp_city`
      }
      if (!is.null(`shipp_postcode`)) {
        if (!(is.character(`shipp_postcode`) && length(`shipp_postcode`) == 1)) {
          stop(paste("Error! Invalid data for `shipp_postcode`. Must be a string:", `shipp_postcode`))
        }
        self$`shipp_postcode` <- `shipp_postcode`
      }
      if (!is.null(`shipp_state`)) {
        if (!(is.character(`shipp_state`) && length(`shipp_state`) == 1)) {
          stop(paste("Error! Invalid data for `shipp_state`. Must be a string:", `shipp_state`))
        }
        self$`shipp_state` <- `shipp_state`
      }
      if (!is.null(`shipp_country`)) {
        if (!(is.character(`shipp_country`) && length(`shipp_country`) == 1)) {
          stop(paste("Error! Invalid data for `shipp_country`. Must be a string:", `shipp_country`))
        }
        self$`shipp_country` <- `shipp_country`
      }
      if (!is.null(`shipp_company`)) {
        if (!(is.character(`shipp_company`) && length(`shipp_company`) == 1)) {
          stop(paste("Error! Invalid data for `shipp_company`. Must be a string:", `shipp_company`))
        }
        self$`shipp_company` <- `shipp_company`
      }
      if (!is.null(`shipp_phone`)) {
        if (!(is.character(`shipp_phone`) && length(`shipp_phone`) == 1)) {
          stop(paste("Error! Invalid data for `shipp_phone`. Must be a string:", `shipp_phone`))
        }
        self$`shipp_phone` <- `shipp_phone`
      }
      if (!is.null(`shipp_fax`)) {
        if (!(is.character(`shipp_fax`) && length(`shipp_fax`) == 1)) {
          stop(paste("Error! Invalid data for `shipp_fax`. Must be a string:", `shipp_fax`))
        }
        self$`shipp_fax` <- `shipp_fax`
      }
      if (!is.null(`subtotal_price`)) {
        self$`subtotal_price` <- `subtotal_price`
      }
      if (!is.null(`tax_price`)) {
        self$`tax_price` <- `tax_price`
      }
      if (!is.null(`total_price`)) {
        self$`total_price` <- `total_price`
      }
      if (!is.null(`total_paid`)) {
        self$`total_paid` <- `total_paid`
      }
      if (!is.null(`total_weight`)) {
        if (!(is.numeric(`total_weight`) && length(`total_weight`) == 1)) {
          stop(paste("Error! Invalid data for `total_weight`. Must be an integer:", `total_weight`))
        }
        self$`total_weight` <- `total_weight`
      }
      if (!is.null(`prices_inc_tax`)) {
        if (!(is.logical(`prices_inc_tax`) && length(`prices_inc_tax`) == 1)) {
          stop(paste("Error! Invalid data for `prices_inc_tax`. Must be a boolean:", `prices_inc_tax`))
        }
        self$`prices_inc_tax` <- `prices_inc_tax`
      }
      if (!is.null(`shipping_price`)) {
        self$`shipping_price` <- `shipping_price`
      }
      if (!is.null(`shipping_tax`)) {
        self$`shipping_tax` <- `shipping_tax`
      }
      if (!is.null(`discount`)) {
        self$`discount` <- `discount`
      }
      if (!is.null(`coupon_discount`)) {
        self$`coupon_discount` <- `coupon_discount`
      }
      if (!is.null(`gift_certificate_discount`)) {
        self$`gift_certificate_discount` <- `gift_certificate_discount`
      }
      if (!is.null(`order_shipping_method`)) {
        if (!(is.character(`order_shipping_method`) && length(`order_shipping_method`) == 1)) {
          stop(paste("Error! Invalid data for `order_shipping_method`. Must be a string:", `order_shipping_method`))
        }
        self$`order_shipping_method` <- `order_shipping_method`
      }
      if (!is.null(`carrier_id`)) {
        if (!(is.character(`carrier_id`) && length(`carrier_id`) == 1)) {
          stop(paste("Error! Invalid data for `carrier_id`. Must be a string:", `carrier_id`))
        }
        self$`carrier_id` <- `carrier_id`
      }
      if (!is.null(`warehouse_id`)) {
        if (!(is.character(`warehouse_id`) && length(`warehouse_id`) == 1)) {
          stop(paste("Error! Invalid data for `warehouse_id`. Must be a string:", `warehouse_id`))
        }
        self$`warehouse_id` <- `warehouse_id`
      }
      if (!is.null(`coupons`)) {
        stopifnot(is.vector(`coupons`), length(`coupons`) != 0)
        sapply(`coupons`, function(x) stopifnot(is.character(x)))
        self$`coupons` <- `coupons`
      }
      if (!is.null(`tags`)) {
        if (!(is.character(`tags`) && length(`tags`) == 1)) {
          stop(paste("Error! Invalid data for `tags`. Must be a string:", `tags`))
        }
        self$`tags` <- `tags`
      }
      if (!is.null(`comment`)) {
        if (!(is.character(`comment`) && length(`comment`) == 1)) {
          stop(paste("Error! Invalid data for `comment`. Must be a string:", `comment`))
        }
        self$`comment` <- `comment`
      }
      if (!is.null(`admin_comment`)) {
        if (!(is.character(`admin_comment`) && length(`admin_comment`) == 1)) {
          stop(paste("Error! Invalid data for `admin_comment`. Must be a string:", `admin_comment`))
        }
        self$`admin_comment` <- `admin_comment`
      }
      if (!is.null(`admin_private_comment`)) {
        if (!(is.character(`admin_private_comment`) && length(`admin_private_comment`) == 1)) {
          stop(paste("Error! Invalid data for `admin_private_comment`. Must be a string:", `admin_private_comment`))
        }
        self$`admin_private_comment` <- `admin_private_comment`
      }
      if (!is.null(`send_notifications`)) {
        if (!(is.logical(`send_notifications`) && length(`send_notifications`) == 1)) {
          stop(paste("Error! Invalid data for `send_notifications`. Must be a boolean:", `send_notifications`))
        }
        self$`send_notifications` <- `send_notifications`
      }
      if (!is.null(`send_admin_notifications`)) {
        if (!(is.logical(`send_admin_notifications`) && length(`send_admin_notifications`) == 1)) {
          stop(paste("Error! Invalid data for `send_admin_notifications`. Must be a boolean:", `send_admin_notifications`))
        }
        self$`send_admin_notifications` <- `send_admin_notifications`
      }
      if (!is.null(`external_source`)) {
        if (!(is.character(`external_source`) && length(`external_source`) == 1)) {
          stop(paste("Error! Invalid data for `external_source`. Must be a string:", `external_source`))
        }
        self$`external_source` <- `external_source`
      }
      if (!is.null(`inventory_behaviour`)) {
        if (!(is.character(`inventory_behaviour`) && length(`inventory_behaviour`) == 1)) {
          stop(paste("Error! Invalid data for `inventory_behaviour`. Must be a string:", `inventory_behaviour`))
        }
        self$`inventory_behaviour` <- `inventory_behaviour`
      }
      if (!is.null(`create_invoice`)) {
        if (!(is.logical(`create_invoice`) && length(`create_invoice`) == 1)) {
          stop(paste("Error! Invalid data for `create_invoice`. Must be a boolean:", `create_invoice`))
        }
        self$`create_invoice` <- `create_invoice`
      }
      if (!is.null(`note_attributes`)) {
        stopifnot(is.vector(`note_attributes`), length(`note_attributes`) != 0)
        sapply(`note_attributes`, function(x) stopifnot(R6::is.R6(x)))
        self$`note_attributes` <- `note_attributes`
      }
      if (!is.null(`clear_cache`)) {
        if (!(is.logical(`clear_cache`) && length(`clear_cache`) == 1)) {
          stop(paste("Error! Invalid data for `clear_cache`. Must be a boolean:", `clear_cache`))
        }
        self$`clear_cache` <- `clear_cache`
      }
      if (!is.null(`origin`)) {
        if (!(is.character(`origin`) && length(`origin`) == 1)) {
          stop(paste("Error! Invalid data for `origin`. Must be a string:", `origin`))
        }
        self$`origin` <- `origin`
      }
      if (!is.null(`fee_price`)) {
        self$`fee_price` <- `fee_price`
      }
      if (!is.null(`idempotency_key`)) {
        if (!(is.character(`idempotency_key`) && length(`idempotency_key`) == 1)) {
          stop(paste("Error! Invalid data for `idempotency_key`. Must be a string:", `idempotency_key`))
        }
        self$`idempotency_key` <- `idempotency_key`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return OrderAdd as a base R list.
    #' @examples
    #' # convert array of OrderAdd (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert OrderAdd to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      OrderAddObject <- list()
      if (!is.null(self$`id`)) {
        OrderAddObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`order_id`)) {
        OrderAddObject[["order_id"]] <-
          self$`order_id`
      }
      if (!is.null(self$`store_id`)) {
        OrderAddObject[["store_id"]] <-
          self$`store_id`
      }
      if (!is.null(self$`channel_id`)) {
        OrderAddObject[["channel_id"]] <-
          self$`channel_id`
      }
      if (!is.null(self$`order_status`)) {
        OrderAddObject[["order_status"]] <-
          self$`order_status`
      }
      if (!is.null(self$`fulfillment_status`)) {
        OrderAddObject[["fulfillment_status"]] <-
          self$`fulfillment_status`
      }
      if (!is.null(self$`financial_status`)) {
        OrderAddObject[["financial_status"]] <-
          self$`financial_status`
      }
      if (!is.null(self$`customer_email`)) {
        OrderAddObject[["customer_email"]] <-
          self$`customer_email`
      }
      if (!is.null(self$`customer_first_name`)) {
        OrderAddObject[["customer_first_name"]] <-
          self$`customer_first_name`
      }
      if (!is.null(self$`customer_last_name`)) {
        OrderAddObject[["customer_last_name"]] <-
          self$`customer_last_name`
      }
      if (!is.null(self$`customer_phone`)) {
        OrderAddObject[["customer_phone"]] <-
          self$`customer_phone`
      }
      if (!is.null(self$`customer_country`)) {
        OrderAddObject[["customer_country"]] <-
          self$`customer_country`
      }
      if (!is.null(self$`customer_birthday`)) {
        OrderAddObject[["customer_birthday"]] <-
          self$`customer_birthday`
      }
      if (!is.null(self$`customer_fax`)) {
        OrderAddObject[["customer_fax"]] <-
          self$`customer_fax`
      }
      if (!is.null(self$`is_guest`)) {
        OrderAddObject[["is_guest"]] <-
          self$`is_guest`
      }
      if (!is.null(self$`order_payment_method`)) {
        OrderAddObject[["order_payment_method"]] <-
          self$`order_payment_method`
      }
      if (!is.null(self$`transaction_id`)) {
        OrderAddObject[["transaction_id"]] <-
          self$`transaction_id`
      }
      if (!is.null(self$`currency`)) {
        OrderAddObject[["currency"]] <-
          self$`currency`
      }
      if (!is.null(self$`date`)) {
        OrderAddObject[["date"]] <-
          self$`date`
      }
      if (!is.null(self$`date_modified`)) {
        OrderAddObject[["date_modified"]] <-
          self$`date_modified`
      }
      if (!is.null(self$`date_finished`)) {
        OrderAddObject[["date_finished"]] <-
          self$`date_finished`
      }
      if (!is.null(self$`bill_first_name`)) {
        OrderAddObject[["bill_first_name"]] <-
          self$`bill_first_name`
      }
      if (!is.null(self$`bill_last_name`)) {
        OrderAddObject[["bill_last_name"]] <-
          self$`bill_last_name`
      }
      if (!is.null(self$`bill_address_1`)) {
        OrderAddObject[["bill_address_1"]] <-
          self$`bill_address_1`
      }
      if (!is.null(self$`bill_address_2`)) {
        OrderAddObject[["bill_address_2"]] <-
          self$`bill_address_2`
      }
      if (!is.null(self$`bill_city`)) {
        OrderAddObject[["bill_city"]] <-
          self$`bill_city`
      }
      if (!is.null(self$`bill_postcode`)) {
        OrderAddObject[["bill_postcode"]] <-
          self$`bill_postcode`
      }
      if (!is.null(self$`bill_state`)) {
        OrderAddObject[["bill_state"]] <-
          self$`bill_state`
      }
      if (!is.null(self$`bill_country`)) {
        OrderAddObject[["bill_country"]] <-
          self$`bill_country`
      }
      if (!is.null(self$`bill_company`)) {
        OrderAddObject[["bill_company"]] <-
          self$`bill_company`
      }
      if (!is.null(self$`bill_phone`)) {
        OrderAddObject[["bill_phone"]] <-
          self$`bill_phone`
      }
      if (!is.null(self$`bill_fax`)) {
        OrderAddObject[["bill_fax"]] <-
          self$`bill_fax`
      }
      if (!is.null(self$`shipp_first_name`)) {
        OrderAddObject[["shipp_first_name"]] <-
          self$`shipp_first_name`
      }
      if (!is.null(self$`shipp_last_name`)) {
        OrderAddObject[["shipp_last_name"]] <-
          self$`shipp_last_name`
      }
      if (!is.null(self$`shipp_address_1`)) {
        OrderAddObject[["shipp_address_1"]] <-
          self$`shipp_address_1`
      }
      if (!is.null(self$`shipp_address_2`)) {
        OrderAddObject[["shipp_address_2"]] <-
          self$`shipp_address_2`
      }
      if (!is.null(self$`shipp_city`)) {
        OrderAddObject[["shipp_city"]] <-
          self$`shipp_city`
      }
      if (!is.null(self$`shipp_postcode`)) {
        OrderAddObject[["shipp_postcode"]] <-
          self$`shipp_postcode`
      }
      if (!is.null(self$`shipp_state`)) {
        OrderAddObject[["shipp_state"]] <-
          self$`shipp_state`
      }
      if (!is.null(self$`shipp_country`)) {
        OrderAddObject[["shipp_country"]] <-
          self$`shipp_country`
      }
      if (!is.null(self$`shipp_company`)) {
        OrderAddObject[["shipp_company"]] <-
          self$`shipp_company`
      }
      if (!is.null(self$`shipp_phone`)) {
        OrderAddObject[["shipp_phone"]] <-
          self$`shipp_phone`
      }
      if (!is.null(self$`shipp_fax`)) {
        OrderAddObject[["shipp_fax"]] <-
          self$`shipp_fax`
      }
      if (!is.null(self$`subtotal_price`)) {
        OrderAddObject[["subtotal_price"]] <-
          self$`subtotal_price`
      }
      if (!is.null(self$`tax_price`)) {
        OrderAddObject[["tax_price"]] <-
          self$`tax_price`
      }
      if (!is.null(self$`total_price`)) {
        OrderAddObject[["total_price"]] <-
          self$`total_price`
      }
      if (!is.null(self$`total_paid`)) {
        OrderAddObject[["total_paid"]] <-
          self$`total_paid`
      }
      if (!is.null(self$`total_weight`)) {
        OrderAddObject[["total_weight"]] <-
          self$`total_weight`
      }
      if (!is.null(self$`prices_inc_tax`)) {
        OrderAddObject[["prices_inc_tax"]] <-
          self$`prices_inc_tax`
      }
      if (!is.null(self$`shipping_price`)) {
        OrderAddObject[["shipping_price"]] <-
          self$`shipping_price`
      }
      if (!is.null(self$`shipping_tax`)) {
        OrderAddObject[["shipping_tax"]] <-
          self$`shipping_tax`
      }
      if (!is.null(self$`discount`)) {
        OrderAddObject[["discount"]] <-
          self$`discount`
      }
      if (!is.null(self$`coupon_discount`)) {
        OrderAddObject[["coupon_discount"]] <-
          self$`coupon_discount`
      }
      if (!is.null(self$`gift_certificate_discount`)) {
        OrderAddObject[["gift_certificate_discount"]] <-
          self$`gift_certificate_discount`
      }
      if (!is.null(self$`order_shipping_method`)) {
        OrderAddObject[["order_shipping_method"]] <-
          self$`order_shipping_method`
      }
      if (!is.null(self$`carrier_id`)) {
        OrderAddObject[["carrier_id"]] <-
          self$`carrier_id`
      }
      if (!is.null(self$`warehouse_id`)) {
        OrderAddObject[["warehouse_id"]] <-
          self$`warehouse_id`
      }
      if (!is.null(self$`coupons`)) {
        OrderAddObject[["coupons"]] <-
          self$`coupons`
      }
      if (!is.null(self$`tags`)) {
        OrderAddObject[["tags"]] <-
          self$`tags`
      }
      if (!is.null(self$`comment`)) {
        OrderAddObject[["comment"]] <-
          self$`comment`
      }
      if (!is.null(self$`admin_comment`)) {
        OrderAddObject[["admin_comment"]] <-
          self$`admin_comment`
      }
      if (!is.null(self$`admin_private_comment`)) {
        OrderAddObject[["admin_private_comment"]] <-
          self$`admin_private_comment`
      }
      if (!is.null(self$`send_notifications`)) {
        OrderAddObject[["send_notifications"]] <-
          self$`send_notifications`
      }
      if (!is.null(self$`send_admin_notifications`)) {
        OrderAddObject[["send_admin_notifications"]] <-
          self$`send_admin_notifications`
      }
      if (!is.null(self$`external_source`)) {
        OrderAddObject[["external_source"]] <-
          self$`external_source`
      }
      if (!is.null(self$`inventory_behaviour`)) {
        OrderAddObject[["inventory_behaviour"]] <-
          self$`inventory_behaviour`
      }
      if (!is.null(self$`create_invoice`)) {
        OrderAddObject[["create_invoice"]] <-
          self$`create_invoice`
      }
      if (!is.null(self$`note_attributes`)) {
        OrderAddObject[["note_attributes"]] <-
          lapply(self$`note_attributes`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`clear_cache`)) {
        OrderAddObject[["clear_cache"]] <-
          self$`clear_cache`
      }
      if (!is.null(self$`origin`)) {
        OrderAddObject[["origin"]] <-
          self$`origin`
      }
      if (!is.null(self$`fee_price`)) {
        OrderAddObject[["fee_price"]] <-
          self$`fee_price`
      }
      if (!is.null(self$`idempotency_key`)) {
        OrderAddObject[["idempotency_key"]] <-
          self$`idempotency_key`
      }
      if (!is.null(self$`order_item`)) {
        OrderAddObject[["order_item"]] <-
          lapply(self$`order_item`, function(x) x$toSimpleType())
      }
      return(OrderAddObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderAdd
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderAdd
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`order_id`)) {
        self$`order_id` <- this_object$`order_id`
      }
      if (!is.null(this_object$`store_id`)) {
        self$`store_id` <- this_object$`store_id`
      }
      if (!is.null(this_object$`channel_id`)) {
        self$`channel_id` <- this_object$`channel_id`
      }
      if (!is.null(this_object$`order_status`)) {
        self$`order_status` <- this_object$`order_status`
      }
      if (!is.null(this_object$`fulfillment_status`)) {
        self$`fulfillment_status` <- this_object$`fulfillment_status`
      }
      if (!is.null(this_object$`financial_status`)) {
        self$`financial_status` <- this_object$`financial_status`
      }
      if (!is.null(this_object$`customer_email`)) {
        self$`customer_email` <- this_object$`customer_email`
      }
      if (!is.null(this_object$`customer_first_name`)) {
        self$`customer_first_name` <- this_object$`customer_first_name`
      }
      if (!is.null(this_object$`customer_last_name`)) {
        self$`customer_last_name` <- this_object$`customer_last_name`
      }
      if (!is.null(this_object$`customer_phone`)) {
        self$`customer_phone` <- this_object$`customer_phone`
      }
      if (!is.null(this_object$`customer_country`)) {
        self$`customer_country` <- this_object$`customer_country`
      }
      if (!is.null(this_object$`customer_birthday`)) {
        self$`customer_birthday` <- this_object$`customer_birthday`
      }
      if (!is.null(this_object$`customer_fax`)) {
        self$`customer_fax` <- this_object$`customer_fax`
      }
      if (!is.null(this_object$`is_guest`)) {
        self$`is_guest` <- this_object$`is_guest`
      }
      if (!is.null(this_object$`order_payment_method`)) {
        self$`order_payment_method` <- this_object$`order_payment_method`
      }
      if (!is.null(this_object$`transaction_id`)) {
        self$`transaction_id` <- this_object$`transaction_id`
      }
      if (!is.null(this_object$`currency`)) {
        self$`currency` <- this_object$`currency`
      }
      if (!is.null(this_object$`date`)) {
        self$`date` <- this_object$`date`
      }
      if (!is.null(this_object$`date_modified`)) {
        self$`date_modified` <- this_object$`date_modified`
      }
      if (!is.null(this_object$`date_finished`)) {
        self$`date_finished` <- this_object$`date_finished`
      }
      if (!is.null(this_object$`bill_first_name`)) {
        self$`bill_first_name` <- this_object$`bill_first_name`
      }
      if (!is.null(this_object$`bill_last_name`)) {
        self$`bill_last_name` <- this_object$`bill_last_name`
      }
      if (!is.null(this_object$`bill_address_1`)) {
        self$`bill_address_1` <- this_object$`bill_address_1`
      }
      if (!is.null(this_object$`bill_address_2`)) {
        self$`bill_address_2` <- this_object$`bill_address_2`
      }
      if (!is.null(this_object$`bill_city`)) {
        self$`bill_city` <- this_object$`bill_city`
      }
      if (!is.null(this_object$`bill_postcode`)) {
        self$`bill_postcode` <- this_object$`bill_postcode`
      }
      if (!is.null(this_object$`bill_state`)) {
        self$`bill_state` <- this_object$`bill_state`
      }
      if (!is.null(this_object$`bill_country`)) {
        self$`bill_country` <- this_object$`bill_country`
      }
      if (!is.null(this_object$`bill_company`)) {
        self$`bill_company` <- this_object$`bill_company`
      }
      if (!is.null(this_object$`bill_phone`)) {
        self$`bill_phone` <- this_object$`bill_phone`
      }
      if (!is.null(this_object$`bill_fax`)) {
        self$`bill_fax` <- this_object$`bill_fax`
      }
      if (!is.null(this_object$`shipp_first_name`)) {
        self$`shipp_first_name` <- this_object$`shipp_first_name`
      }
      if (!is.null(this_object$`shipp_last_name`)) {
        self$`shipp_last_name` <- this_object$`shipp_last_name`
      }
      if (!is.null(this_object$`shipp_address_1`)) {
        self$`shipp_address_1` <- this_object$`shipp_address_1`
      }
      if (!is.null(this_object$`shipp_address_2`)) {
        self$`shipp_address_2` <- this_object$`shipp_address_2`
      }
      if (!is.null(this_object$`shipp_city`)) {
        self$`shipp_city` <- this_object$`shipp_city`
      }
      if (!is.null(this_object$`shipp_postcode`)) {
        self$`shipp_postcode` <- this_object$`shipp_postcode`
      }
      if (!is.null(this_object$`shipp_state`)) {
        self$`shipp_state` <- this_object$`shipp_state`
      }
      if (!is.null(this_object$`shipp_country`)) {
        self$`shipp_country` <- this_object$`shipp_country`
      }
      if (!is.null(this_object$`shipp_company`)) {
        self$`shipp_company` <- this_object$`shipp_company`
      }
      if (!is.null(this_object$`shipp_phone`)) {
        self$`shipp_phone` <- this_object$`shipp_phone`
      }
      if (!is.null(this_object$`shipp_fax`)) {
        self$`shipp_fax` <- this_object$`shipp_fax`
      }
      if (!is.null(this_object$`subtotal_price`)) {
        self$`subtotal_price` <- this_object$`subtotal_price`
      }
      if (!is.null(this_object$`tax_price`)) {
        self$`tax_price` <- this_object$`tax_price`
      }
      if (!is.null(this_object$`total_price`)) {
        self$`total_price` <- this_object$`total_price`
      }
      if (!is.null(this_object$`total_paid`)) {
        self$`total_paid` <- this_object$`total_paid`
      }
      if (!is.null(this_object$`total_weight`)) {
        self$`total_weight` <- this_object$`total_weight`
      }
      if (!is.null(this_object$`prices_inc_tax`)) {
        self$`prices_inc_tax` <- this_object$`prices_inc_tax`
      }
      if (!is.null(this_object$`shipping_price`)) {
        self$`shipping_price` <- this_object$`shipping_price`
      }
      if (!is.null(this_object$`shipping_tax`)) {
        self$`shipping_tax` <- this_object$`shipping_tax`
      }
      if (!is.null(this_object$`discount`)) {
        self$`discount` <- this_object$`discount`
      }
      if (!is.null(this_object$`coupon_discount`)) {
        self$`coupon_discount` <- this_object$`coupon_discount`
      }
      if (!is.null(this_object$`gift_certificate_discount`)) {
        self$`gift_certificate_discount` <- this_object$`gift_certificate_discount`
      }
      if (!is.null(this_object$`order_shipping_method`)) {
        self$`order_shipping_method` <- this_object$`order_shipping_method`
      }
      if (!is.null(this_object$`carrier_id`)) {
        self$`carrier_id` <- this_object$`carrier_id`
      }
      if (!is.null(this_object$`warehouse_id`)) {
        self$`warehouse_id` <- this_object$`warehouse_id`
      }
      if (!is.null(this_object$`coupons`)) {
        self$`coupons` <- ApiClient$new()$deserializeObj(this_object$`coupons`, "array[character]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`tags`)) {
        self$`tags` <- this_object$`tags`
      }
      if (!is.null(this_object$`comment`)) {
        self$`comment` <- this_object$`comment`
      }
      if (!is.null(this_object$`admin_comment`)) {
        self$`admin_comment` <- this_object$`admin_comment`
      }
      if (!is.null(this_object$`admin_private_comment`)) {
        self$`admin_private_comment` <- this_object$`admin_private_comment`
      }
      if (!is.null(this_object$`send_notifications`)) {
        self$`send_notifications` <- this_object$`send_notifications`
      }
      if (!is.null(this_object$`send_admin_notifications`)) {
        self$`send_admin_notifications` <- this_object$`send_admin_notifications`
      }
      if (!is.null(this_object$`external_source`)) {
        self$`external_source` <- this_object$`external_source`
      }
      if (!is.null(this_object$`inventory_behaviour`)) {
        self$`inventory_behaviour` <- this_object$`inventory_behaviour`
      }
      if (!is.null(this_object$`create_invoice`)) {
        self$`create_invoice` <- this_object$`create_invoice`
      }
      if (!is.null(this_object$`note_attributes`)) {
        self$`note_attributes` <- ApiClient$new()$deserializeObj(this_object$`note_attributes`, "array[OrderAddNoteAttributesInner]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`clear_cache`)) {
        self$`clear_cache` <- this_object$`clear_cache`
      }
      if (!is.null(this_object$`origin`)) {
        self$`origin` <- this_object$`origin`
      }
      if (!is.null(this_object$`fee_price`)) {
        self$`fee_price` <- this_object$`fee_price`
      }
      if (!is.null(this_object$`idempotency_key`)) {
        self$`idempotency_key` <- this_object$`idempotency_key`
      }
      if (!is.null(this_object$`order_item`)) {
        self$`order_item` <- ApiClient$new()$deserializeObj(this_object$`order_item`, "array[OrderAddOrderItemInner]", loadNamespace("openapi"))
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return OrderAdd in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderAdd
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderAdd
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`order_id` <- this_object$`order_id`
      self$`store_id` <- this_object$`store_id`
      self$`channel_id` <- this_object$`channel_id`
      self$`order_status` <- this_object$`order_status`
      self$`fulfillment_status` <- this_object$`fulfillment_status`
      self$`financial_status` <- this_object$`financial_status`
      self$`customer_email` <- this_object$`customer_email`
      self$`customer_first_name` <- this_object$`customer_first_name`
      self$`customer_last_name` <- this_object$`customer_last_name`
      self$`customer_phone` <- this_object$`customer_phone`
      self$`customer_country` <- this_object$`customer_country`
      self$`customer_birthday` <- this_object$`customer_birthday`
      self$`customer_fax` <- this_object$`customer_fax`
      self$`is_guest` <- this_object$`is_guest`
      self$`order_payment_method` <- this_object$`order_payment_method`
      self$`transaction_id` <- this_object$`transaction_id`
      self$`currency` <- this_object$`currency`
      self$`date` <- this_object$`date`
      self$`date_modified` <- this_object$`date_modified`
      self$`date_finished` <- this_object$`date_finished`
      self$`bill_first_name` <- this_object$`bill_first_name`
      self$`bill_last_name` <- this_object$`bill_last_name`
      self$`bill_address_1` <- this_object$`bill_address_1`
      self$`bill_address_2` <- this_object$`bill_address_2`
      self$`bill_city` <- this_object$`bill_city`
      self$`bill_postcode` <- this_object$`bill_postcode`
      self$`bill_state` <- this_object$`bill_state`
      self$`bill_country` <- this_object$`bill_country`
      self$`bill_company` <- this_object$`bill_company`
      self$`bill_phone` <- this_object$`bill_phone`
      self$`bill_fax` <- this_object$`bill_fax`
      self$`shipp_first_name` <- this_object$`shipp_first_name`
      self$`shipp_last_name` <- this_object$`shipp_last_name`
      self$`shipp_address_1` <- this_object$`shipp_address_1`
      self$`shipp_address_2` <- this_object$`shipp_address_2`
      self$`shipp_city` <- this_object$`shipp_city`
      self$`shipp_postcode` <- this_object$`shipp_postcode`
      self$`shipp_state` <- this_object$`shipp_state`
      self$`shipp_country` <- this_object$`shipp_country`
      self$`shipp_company` <- this_object$`shipp_company`
      self$`shipp_phone` <- this_object$`shipp_phone`
      self$`shipp_fax` <- this_object$`shipp_fax`
      self$`subtotal_price` <- this_object$`subtotal_price`
      self$`tax_price` <- this_object$`tax_price`
      self$`total_price` <- this_object$`total_price`
      self$`total_paid` <- this_object$`total_paid`
      self$`total_weight` <- this_object$`total_weight`
      self$`prices_inc_tax` <- this_object$`prices_inc_tax`
      self$`shipping_price` <- this_object$`shipping_price`
      self$`shipping_tax` <- this_object$`shipping_tax`
      self$`discount` <- this_object$`discount`
      self$`coupon_discount` <- this_object$`coupon_discount`
      self$`gift_certificate_discount` <- this_object$`gift_certificate_discount`
      self$`order_shipping_method` <- this_object$`order_shipping_method`
      self$`carrier_id` <- this_object$`carrier_id`
      self$`warehouse_id` <- this_object$`warehouse_id`
      self$`coupons` <- ApiClient$new()$deserializeObj(this_object$`coupons`, "array[character]", loadNamespace("openapi"))
      self$`tags` <- this_object$`tags`
      self$`comment` <- this_object$`comment`
      self$`admin_comment` <- this_object$`admin_comment`
      self$`admin_private_comment` <- this_object$`admin_private_comment`
      self$`send_notifications` <- this_object$`send_notifications`
      self$`send_admin_notifications` <- this_object$`send_admin_notifications`
      self$`external_source` <- this_object$`external_source`
      self$`inventory_behaviour` <- this_object$`inventory_behaviour`
      self$`create_invoice` <- this_object$`create_invoice`
      self$`note_attributes` <- ApiClient$new()$deserializeObj(this_object$`note_attributes`, "array[OrderAddNoteAttributesInner]", loadNamespace("openapi"))
      self$`clear_cache` <- this_object$`clear_cache`
      self$`origin` <- this_object$`origin`
      self$`fee_price` <- this_object$`fee_price`
      self$`idempotency_key` <- this_object$`idempotency_key`
      self$`order_item` <- ApiClient$new()$deserializeObj(this_object$`order_item`, "array[OrderAddOrderItemInner]", loadNamespace("openapi"))
      self
    },

    #' @description
    #' Validate JSON input with respect to OrderAdd and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
      # check the required field `order_status`
      if (!is.null(input_json$`order_status`)) {
        if (!(is.character(input_json$`order_status`) && length(input_json$`order_status`) == 1)) {
          stop(paste("Error! Invalid data for `order_status`. Must be a string:", input_json$`order_status`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for OrderAdd: the required field `order_status` is missing."))
      }
      # check the required field `customer_email`
      if (!is.null(input_json$`customer_email`)) {
        if (!(is.character(input_json$`customer_email`) && length(input_json$`customer_email`) == 1)) {
          stop(paste("Error! Invalid data for `customer_email`. Must be a string:", input_json$`customer_email`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for OrderAdd: the required field `customer_email` is missing."))
      }
      # check the required field `bill_first_name`
      if (!is.null(input_json$`bill_first_name`)) {
        if (!(is.character(input_json$`bill_first_name`) && length(input_json$`bill_first_name`) == 1)) {
          stop(paste("Error! Invalid data for `bill_first_name`. Must be a string:", input_json$`bill_first_name`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for OrderAdd: the required field `bill_first_name` is missing."))
      }
      # check the required field `bill_last_name`
      if (!is.null(input_json$`bill_last_name`)) {
        if (!(is.character(input_json$`bill_last_name`) && length(input_json$`bill_last_name`) == 1)) {
          stop(paste("Error! Invalid data for `bill_last_name`. Must be a string:", input_json$`bill_last_name`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for OrderAdd: the required field `bill_last_name` is missing."))
      }
      # check the required field `bill_address_1`
      if (!is.null(input_json$`bill_address_1`)) {
        if (!(is.character(input_json$`bill_address_1`) && length(input_json$`bill_address_1`) == 1)) {
          stop(paste("Error! Invalid data for `bill_address_1`. Must be a string:", input_json$`bill_address_1`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for OrderAdd: the required field `bill_address_1` is missing."))
      }
      # check the required field `bill_city`
      if (!is.null(input_json$`bill_city`)) {
        if (!(is.character(input_json$`bill_city`) && length(input_json$`bill_city`) == 1)) {
          stop(paste("Error! Invalid data for `bill_city`. Must be a string:", input_json$`bill_city`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for OrderAdd: the required field `bill_city` is missing."))
      }
      # check the required field `bill_postcode`
      if (!is.null(input_json$`bill_postcode`)) {
        if (!(is.character(input_json$`bill_postcode`) && length(input_json$`bill_postcode`) == 1)) {
          stop(paste("Error! Invalid data for `bill_postcode`. Must be a string:", input_json$`bill_postcode`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for OrderAdd: the required field `bill_postcode` is missing."))
      }
      # check the required field `bill_state`
      if (!is.null(input_json$`bill_state`)) {
        if (!(is.character(input_json$`bill_state`) && length(input_json$`bill_state`) == 1)) {
          stop(paste("Error! Invalid data for `bill_state`. Must be a string:", input_json$`bill_state`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for OrderAdd: the required field `bill_state` is missing."))
      }
      # check the required field `bill_country`
      if (!is.null(input_json$`bill_country`)) {
        if (!(is.character(input_json$`bill_country`) && length(input_json$`bill_country`) == 1)) {
          stop(paste("Error! Invalid data for `bill_country`. Must be a string:", input_json$`bill_country`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for OrderAdd: the required field `bill_country` is missing."))
      }
      # check the required field `order_item`
      if (!is.null(input_json$`order_item`)) {
        stopifnot(is.vector(input_json$`order_item`), length(input_json$`order_item`) != 0)
        tmp <- sapply(input_json$`order_item`, function(x) stopifnot(R6::is.R6(x)))
      } else {
        stop(paste("The JSON input `", input, "` is invalid for OrderAdd: the required field `order_item` is missing."))
      }
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of OrderAdd
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      # check if the required `order_status` is null
      if (is.null(self$`order_status`)) {
        return(FALSE)
      }

      # check if the required `customer_email` is null
      if (is.null(self$`customer_email`)) {
        return(FALSE)
      }

      # check if the required `bill_first_name` is null
      if (is.null(self$`bill_first_name`)) {
        return(FALSE)
      }

      # check if the required `bill_last_name` is null
      if (is.null(self$`bill_last_name`)) {
        return(FALSE)
      }

      # check if the required `bill_address_1` is null
      if (is.null(self$`bill_address_1`)) {
        return(FALSE)
      }

      # check if the required `bill_city` is null
      if (is.null(self$`bill_city`)) {
        return(FALSE)
      }

      # check if the required `bill_postcode` is null
      if (is.null(self$`bill_postcode`)) {
        return(FALSE)
      }

      # check if the required `bill_state` is null
      if (is.null(self$`bill_state`)) {
        return(FALSE)
      }

      # check if the required `bill_country` is null
      if (is.null(self$`bill_country`)) {
        return(FALSE)
      }

      if (length(self$`coupons`) < 1) {
        return(FALSE)
      }

      # check if the required `order_item` is null
      if (is.null(self$`order_item`)) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      # check if the required `order_status` is null
      if (is.null(self$`order_status`)) {
        invalid_fields["order_status"] <- "Non-nullable required field `order_status` cannot be null."
      }

      # check if the required `customer_email` is null
      if (is.null(self$`customer_email`)) {
        invalid_fields["customer_email"] <- "Non-nullable required field `customer_email` cannot be null."
      }

      # check if the required `bill_first_name` is null
      if (is.null(self$`bill_first_name`)) {
        invalid_fields["bill_first_name"] <- "Non-nullable required field `bill_first_name` cannot be null."
      }

      # check if the required `bill_last_name` is null
      if (is.null(self$`bill_last_name`)) {
        invalid_fields["bill_last_name"] <- "Non-nullable required field `bill_last_name` cannot be null."
      }

      # check if the required `bill_address_1` is null
      if (is.null(self$`bill_address_1`)) {
        invalid_fields["bill_address_1"] <- "Non-nullable required field `bill_address_1` cannot be null."
      }

      # check if the required `bill_city` is null
      if (is.null(self$`bill_city`)) {
        invalid_fields["bill_city"] <- "Non-nullable required field `bill_city` cannot be null."
      }

      # check if the required `bill_postcode` is null
      if (is.null(self$`bill_postcode`)) {
        invalid_fields["bill_postcode"] <- "Non-nullable required field `bill_postcode` cannot be null."
      }

      # check if the required `bill_state` is null
      if (is.null(self$`bill_state`)) {
        invalid_fields["bill_state"] <- "Non-nullable required field `bill_state` cannot be null."
      }

      # check if the required `bill_country` is null
      if (is.null(self$`bill_country`)) {
        invalid_fields["bill_country"] <- "Non-nullable required field `bill_country` cannot be null."
      }

      if (length(self$`coupons`) < 1) {
        invalid_fields["coupons"] <- "Invalid length for ``, number of items must be greater than or equal to 1."
      }

      # check if the required `order_item` is null
      if (is.null(self$`order_item`)) {
        invalid_fields["order_item"] <- "Non-nullable required field `order_item` cannot be null."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# OrderAdd$unlock()
#
## Below is an example to define the print function
# OrderAdd$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# OrderAdd$lock()

