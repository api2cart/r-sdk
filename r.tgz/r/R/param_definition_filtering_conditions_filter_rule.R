#' Create a new ParamDefinitionFilteringConditionsFilterRule
#'
#' @description
#' ParamDefinitionFilteringConditionsFilterRule Class
#'
#' @docType class
#' @title ParamDefinitionFilteringConditionsFilterRule
#' @description ParamDefinitionFilteringConditionsFilterRule Class
#' @format An \code{R6Class} generator object
#' @field field  character [optional]
#' @field operator  character [optional]
#' @field value  \link{ParamDefinitionFilteringConditionsFilterRuleValue} [optional]
#' @field match_items  character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ParamDefinitionFilteringConditionsFilterRule <- R6::R6Class(
  "ParamDefinitionFilteringConditionsFilterRule",
  public = list(
    `field` = NULL,
    `operator` = NULL,
    `value` = NULL,
    `match_items` = NULL,

    #' @description
    #' Initialize a new ParamDefinitionFilteringConditionsFilterRule class.
    #'
    #' @param field field
    #' @param operator operator
    #' @param value value
    #' @param match_items match_items
    #' @param ... Other optional arguments.
    initialize = function(`field` = NULL, `operator` = NULL, `value` = NULL, `match_items` = NULL, ...) {
      if (!is.null(`field`)) {
        if (!(is.character(`field`) && length(`field`) == 1)) {
          stop(paste("Error! Invalid data for `field`. Must be a string:", `field`))
        }
        self$`field` <- `field`
      }
      if (!is.null(`operator`)) {
        if (!(is.character(`operator`) && length(`operator`) == 1)) {
          stop(paste("Error! Invalid data for `operator`. Must be a string:", `operator`))
        }
        self$`operator` <- `operator`
      }
      if (!is.null(`value`)) {
        stopifnot(R6::is.R6(`value`))
        self$`value` <- `value`
      }
      if (!is.null(`match_items`)) {
        if (!(is.character(`match_items`) && length(`match_items`) == 1)) {
          stop(paste("Error! Invalid data for `match_items`. Must be a string:", `match_items`))
        }
        self$`match_items` <- `match_items`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ParamDefinitionFilteringConditionsFilterRule as a base R list.
    #' @examples
    #' # convert array of ParamDefinitionFilteringConditionsFilterRule (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ParamDefinitionFilteringConditionsFilterRule to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ParamDefinitionFilteringConditionsFilterRuleObject <- list()
      if (!is.null(self$`field`)) {
        ParamDefinitionFilteringConditionsFilterRuleObject[["field"]] <-
          self$`field`
      }
      if (!is.null(self$`operator`)) {
        ParamDefinitionFilteringConditionsFilterRuleObject[["operator"]] <-
          self$`operator`
      }
      if (!is.null(self$`value`)) {
        ParamDefinitionFilteringConditionsFilterRuleObject[["value"]] <-
          self$`value`$toSimpleType()
      }
      if (!is.null(self$`match_items`)) {
        ParamDefinitionFilteringConditionsFilterRuleObject[["match_items"]] <-
          self$`match_items`
      }
      return(ParamDefinitionFilteringConditionsFilterRuleObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ParamDefinitionFilteringConditionsFilterRule
    #'
    #' @param input_json the JSON input
    #' @return the instance of ParamDefinitionFilteringConditionsFilterRule
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`field`)) {
        self$`field` <- this_object$`field`
      }
      if (!is.null(this_object$`operator`)) {
        self$`operator` <- this_object$`operator`
      }
      if (!is.null(this_object$`value`)) {
        `value_object` <- ParamDefinitionFilteringConditionsFilterRuleValue$new()
        `value_object`$fromJSON(jsonlite::toJSON(this_object$`value`, auto_unbox = TRUE, digits = NA))
        self$`value` <- `value_object`
      }
      if (!is.null(this_object$`match_items`)) {
        self$`match_items` <- this_object$`match_items`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ParamDefinitionFilteringConditionsFilterRule in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ParamDefinitionFilteringConditionsFilterRule
    #'
    #' @param input_json the JSON input
    #' @return the instance of ParamDefinitionFilteringConditionsFilterRule
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`field` <- this_object$`field`
      self$`operator` <- this_object$`operator`
      self$`value` <- ParamDefinitionFilteringConditionsFilterRuleValue$new()$fromJSON(jsonlite::toJSON(this_object$`value`, auto_unbox = TRUE, digits = NA))
      self$`match_items` <- this_object$`match_items`
      self
    },

    #' @description
    #' Validate JSON input with respect to ParamDefinitionFilteringConditionsFilterRule and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ParamDefinitionFilteringConditionsFilterRule
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ParamDefinitionFilteringConditionsFilterRule$unlock()
#
## Below is an example to define the print function
# ParamDefinitionFilteringConditionsFilterRule$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ParamDefinitionFilteringConditionsFilterRule$lock()

