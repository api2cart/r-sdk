#' Create a new OrderFinancialStatusList200ResponseResult
#'
#' @description
#' OrderFinancialStatusList200ResponseResult Class
#'
#' @docType class
#' @title OrderFinancialStatusList200ResponseResult
#' @description OrderFinancialStatusList200ResponseResult Class
#' @format An \code{R6Class} generator object
#' @field order_financial_statuses  list(\link{OrderFinancialStatusList200ResponseResultOrderFinancialStatusesInner}) [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
OrderFinancialStatusList200ResponseResult <- R6::R6Class(
  "OrderFinancialStatusList200ResponseResult",
  public = list(
    `order_financial_statuses` = NULL,

    #' @description
    #' Initialize a new OrderFinancialStatusList200ResponseResult class.
    #'
    #' @param order_financial_statuses order_financial_statuses
    #' @param ... Other optional arguments.
    initialize = function(`order_financial_statuses` = NULL, ...) {
      if (!is.null(`order_financial_statuses`)) {
        stopifnot(is.vector(`order_financial_statuses`), length(`order_financial_statuses`) != 0)
        sapply(`order_financial_statuses`, function(x) stopifnot(R6::is.R6(x)))
        self$`order_financial_statuses` <- `order_financial_statuses`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return OrderFinancialStatusList200ResponseResult as a base R list.
    #' @examples
    #' # convert array of OrderFinancialStatusList200ResponseResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert OrderFinancialStatusList200ResponseResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      OrderFinancialStatusList200ResponseResultObject <- list()
      if (!is.null(self$`order_financial_statuses`)) {
        OrderFinancialStatusList200ResponseResultObject[["order_financial_statuses"]] <-
          lapply(self$`order_financial_statuses`, function(x) x$toSimpleType())
      }
      return(OrderFinancialStatusList200ResponseResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderFinancialStatusList200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderFinancialStatusList200ResponseResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`order_financial_statuses`)) {
        self$`order_financial_statuses` <- ApiClient$new()$deserializeObj(this_object$`order_financial_statuses`, "array[OrderFinancialStatusList200ResponseResultOrderFinancialStatusesInner]", loadNamespace("openapi"))
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return OrderFinancialStatusList200ResponseResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderFinancialStatusList200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderFinancialStatusList200ResponseResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`order_financial_statuses` <- ApiClient$new()$deserializeObj(this_object$`order_financial_statuses`, "array[OrderFinancialStatusList200ResponseResultOrderFinancialStatusesInner]", loadNamespace("openapi"))
      self
    },

    #' @description
    #' Validate JSON input with respect to OrderFinancialStatusList200ResponseResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of OrderFinancialStatusList200ResponseResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# OrderFinancialStatusList200ResponseResult$unlock()
#
## Below is an example to define the print function
# OrderFinancialStatusList200ResponseResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# OrderFinancialStatusList200ResponseResult$lock()

