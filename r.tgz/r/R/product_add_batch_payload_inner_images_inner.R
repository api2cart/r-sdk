#' Create a new ProductAddBatchPayloadInnerImagesInner
#'
#' @description
#' ProductAddBatchPayloadInnerImagesInner Class
#'
#' @docType class
#' @title ProductAddBatchPayloadInnerImagesInner
#' @description ProductAddBatchPayloadInnerImagesInner Class
#' @format An \code{R6Class} generator object
#' @field type  character [optional]
#' @field url  character
#' @field label  character [optional]
#' @field name  character [optional]
#' @field position  integer [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductAddBatchPayloadInnerImagesInner <- R6::R6Class(
  "ProductAddBatchPayloadInnerImagesInner",
  public = list(
    `type` = NULL,
    `url` = NULL,
    `label` = NULL,
    `name` = NULL,
    `position` = NULL,

    #' @description
    #' Initialize a new ProductAddBatchPayloadInnerImagesInner class.
    #'
    #' @param url url
    #' @param type type
    #' @param label label
    #' @param name name
    #' @param position position
    #' @param ... Other optional arguments.
    initialize = function(`url`, `type` = NULL, `label` = NULL, `name` = NULL, `position` = NULL, ...) {
      if (!missing(`url`)) {
        if (!(is.character(`url`) && length(`url`) == 1)) {
          stop(paste("Error! Invalid data for `url`. Must be a string:", `url`))
        }
        self$`url` <- `url`
      }
      if (!is.null(`type`)) {
        if (!(is.character(`type`) && length(`type`) == 1)) {
          stop(paste("Error! Invalid data for `type`. Must be a string:", `type`))
        }
        self$`type` <- `type`
      }
      if (!is.null(`label`)) {
        if (!(is.character(`label`) && length(`label`) == 1)) {
          stop(paste("Error! Invalid data for `label`. Must be a string:", `label`))
        }
        self$`label` <- `label`
      }
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`position`)) {
        if (!(is.numeric(`position`) && length(`position`) == 1)) {
          stop(paste("Error! Invalid data for `position`. Must be an integer:", `position`))
        }
        self$`position` <- `position`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductAddBatchPayloadInnerImagesInner as a base R list.
    #' @examples
    #' # convert array of ProductAddBatchPayloadInnerImagesInner (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductAddBatchPayloadInnerImagesInner to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductAddBatchPayloadInnerImagesInnerObject <- list()
      if (!is.null(self$`type`)) {
        ProductAddBatchPayloadInnerImagesInnerObject[["type"]] <-
          self$`type`
      }
      if (!is.null(self$`url`)) {
        ProductAddBatchPayloadInnerImagesInnerObject[["url"]] <-
          self$`url`
      }
      if (!is.null(self$`label`)) {
        ProductAddBatchPayloadInnerImagesInnerObject[["label"]] <-
          self$`label`
      }
      if (!is.null(self$`name`)) {
        ProductAddBatchPayloadInnerImagesInnerObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`position`)) {
        ProductAddBatchPayloadInnerImagesInnerObject[["position"]] <-
          self$`position`
      }
      return(ProductAddBatchPayloadInnerImagesInnerObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductAddBatchPayloadInnerImagesInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductAddBatchPayloadInnerImagesInner
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`type`)) {
        self$`type` <- this_object$`type`
      }
      if (!is.null(this_object$`url`)) {
        self$`url` <- this_object$`url`
      }
      if (!is.null(this_object$`label`)) {
        self$`label` <- this_object$`label`
      }
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`position`)) {
        self$`position` <- this_object$`position`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductAddBatchPayloadInnerImagesInner in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductAddBatchPayloadInnerImagesInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductAddBatchPayloadInnerImagesInner
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`type` <- this_object$`type`
      self$`url` <- this_object$`url`
      self$`label` <- this_object$`label`
      self$`name` <- this_object$`name`
      self$`position` <- this_object$`position`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductAddBatchPayloadInnerImagesInner and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
      # check the required field `url`
      if (!is.null(input_json$`url`)) {
        if (!(is.character(input_json$`url`) && length(input_json$`url`) == 1)) {
          stop(paste("Error! Invalid data for `url`. Must be a string:", input_json$`url`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for ProductAddBatchPayloadInnerImagesInner: the required field `url` is missing."))
      }
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductAddBatchPayloadInnerImagesInner
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      # check if the required `url` is null
      if (is.null(self$`url`)) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      # check if the required `url` is null
      if (is.null(self$`url`)) {
        invalid_fields["url"] <- "Non-nullable required field `url` cannot be null."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductAddBatchPayloadInnerImagesInner$unlock()
#
## Below is an example to define the print function
# ProductAddBatchPayloadInnerImagesInner$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductAddBatchPayloadInnerImagesInner$lock()

