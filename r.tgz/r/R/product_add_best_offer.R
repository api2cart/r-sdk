#' Create a new ProductAddBestOffer
#'
#' @description
#' The price at which Best Offers are automatically accepted.<hr><div style=\"font-style:normal\">Param structure:<div style=\"margin-left: 2%;\"><code style=\"padding:0; background-color:#ffffff;font-size:85%;font-family:monospace;\">best_offer[<b>minimum_offer_price</b>] = decimal</br>best_offer[<b>auto_accept_price</b>] = decimal</br></code></div></div>
#'
#' @docType class
#' @title ProductAddBestOffer
#' @description ProductAddBestOffer Class
#' @format An \code{R6Class} generator object
#' @field minimum_offer_price  numeric [optional]
#' @field auto_accept_price  numeric [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductAddBestOffer <- R6::R6Class(
  "ProductAddBestOffer",
  public = list(
    `minimum_offer_price` = NULL,
    `auto_accept_price` = NULL,

    #' @description
    #' Initialize a new ProductAddBestOffer class.
    #'
    #' @param minimum_offer_price minimum_offer_price
    #' @param auto_accept_price auto_accept_price
    #' @param ... Other optional arguments.
    initialize = function(`minimum_offer_price` = NULL, `auto_accept_price` = NULL, ...) {
      if (!is.null(`minimum_offer_price`)) {
        self$`minimum_offer_price` <- `minimum_offer_price`
      }
      if (!is.null(`auto_accept_price`)) {
        self$`auto_accept_price` <- `auto_accept_price`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductAddBestOffer as a base R list.
    #' @examples
    #' # convert array of ProductAddBestOffer (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductAddBestOffer to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductAddBestOfferObject <- list()
      if (!is.null(self$`minimum_offer_price`)) {
        ProductAddBestOfferObject[["minimum_offer_price"]] <-
          self$`minimum_offer_price`
      }
      if (!is.null(self$`auto_accept_price`)) {
        ProductAddBestOfferObject[["auto_accept_price"]] <-
          self$`auto_accept_price`
      }
      return(ProductAddBestOfferObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductAddBestOffer
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductAddBestOffer
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`minimum_offer_price`)) {
        self$`minimum_offer_price` <- this_object$`minimum_offer_price`
      }
      if (!is.null(this_object$`auto_accept_price`)) {
        self$`auto_accept_price` <- this_object$`auto_accept_price`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductAddBestOffer in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductAddBestOffer
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductAddBestOffer
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`minimum_offer_price` <- this_object$`minimum_offer_price`
      self$`auto_accept_price` <- this_object$`auto_accept_price`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductAddBestOffer and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductAddBestOffer
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductAddBestOffer$unlock()
#
## Below is an example to define the print function
# ProductAddBestOffer$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductAddBestOffer$lock()

