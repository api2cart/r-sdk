#' Create a new ProductOptionItem
#'
#' @description
#' ProductOptionItem Class
#'
#' @docType class
#' @title ProductOptionItem
#' @description ProductOptionItem Class
#' @format An \code{R6Class} generator object
#' @field id  character [optional]
#' @field product_option_item_id  character [optional]
#' @field name  character [optional]
#' @field sort_order  integer [optional]
#' @field price  numeric [optional]
#' @field weight  numeric [optional]
#' @field quantity  integer [optional]
#' @field type_price  character [optional]
#' @field sku  character [optional]
#' @field is_default  character [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductOptionItem <- R6::R6Class(
  "ProductOptionItem",
  public = list(
    `id` = NULL,
    `product_option_item_id` = NULL,
    `name` = NULL,
    `sort_order` = NULL,
    `price` = NULL,
    `weight` = NULL,
    `quantity` = NULL,
    `type_price` = NULL,
    `sku` = NULL,
    `is_default` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new ProductOptionItem class.
    #'
    #' @param id id
    #' @param product_option_item_id product_option_item_id
    #' @param name name
    #' @param sort_order sort_order
    #' @param price price
    #' @param weight weight
    #' @param quantity quantity
    #' @param type_price type_price
    #' @param sku sku
    #' @param is_default is_default
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `product_option_item_id` = NULL, `name` = NULL, `sort_order` = NULL, `price` = NULL, `weight` = NULL, `quantity` = NULL, `type_price` = NULL, `sku` = NULL, `is_default` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`product_option_item_id`)) {
        if (!(is.character(`product_option_item_id`) && length(`product_option_item_id`) == 1)) {
          stop(paste("Error! Invalid data for `product_option_item_id`. Must be a string:", `product_option_item_id`))
        }
        self$`product_option_item_id` <- `product_option_item_id`
      }
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`sort_order`)) {
        if (!(is.numeric(`sort_order`) && length(`sort_order`) == 1)) {
          stop(paste("Error! Invalid data for `sort_order`. Must be an integer:", `sort_order`))
        }
        self$`sort_order` <- `sort_order`
      }
      if (!is.null(`price`)) {
        self$`price` <- `price`
      }
      if (!is.null(`weight`)) {
        self$`weight` <- `weight`
      }
      if (!is.null(`quantity`)) {
        if (!(is.numeric(`quantity`) && length(`quantity`) == 1)) {
          stop(paste("Error! Invalid data for `quantity`. Must be an integer:", `quantity`))
        }
        self$`quantity` <- `quantity`
      }
      if (!is.null(`type_price`)) {
        if (!(is.character(`type_price`) && length(`type_price`) == 1)) {
          stop(paste("Error! Invalid data for `type_price`. Must be a string:", `type_price`))
        }
        self$`type_price` <- `type_price`
      }
      if (!is.null(`sku`)) {
        if (!(is.character(`sku`) && length(`sku`) == 1)) {
          stop(paste("Error! Invalid data for `sku`. Must be a string:", `sku`))
        }
        self$`sku` <- `sku`
      }
      if (!is.null(`is_default`)) {
        if (!(is.logical(`is_default`) && length(`is_default`) == 1)) {
          stop(paste("Error! Invalid data for `is_default`. Must be a boolean:", `is_default`))
        }
        self$`is_default` <- `is_default`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductOptionItem as a base R list.
    #' @examples
    #' # convert array of ProductOptionItem (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductOptionItem to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductOptionItemObject <- list()
      if (!is.null(self$`id`)) {
        ProductOptionItemObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`product_option_item_id`)) {
        ProductOptionItemObject[["product_option_item_id"]] <-
          self$`product_option_item_id`
      }
      if (!is.null(self$`name`)) {
        ProductOptionItemObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`sort_order`)) {
        ProductOptionItemObject[["sort_order"]] <-
          self$`sort_order`
      }
      if (!is.null(self$`price`)) {
        ProductOptionItemObject[["price"]] <-
          self$`price`
      }
      if (!is.null(self$`weight`)) {
        ProductOptionItemObject[["weight"]] <-
          self$`weight`
      }
      if (!is.null(self$`quantity`)) {
        ProductOptionItemObject[["quantity"]] <-
          self$`quantity`
      }
      if (!is.null(self$`type_price`)) {
        ProductOptionItemObject[["type_price"]] <-
          self$`type_price`
      }
      if (!is.null(self$`sku`)) {
        ProductOptionItemObject[["sku"]] <-
          self$`sku`
      }
      if (!is.null(self$`is_default`)) {
        ProductOptionItemObject[["is_default"]] <-
          self$`is_default`
      }
      if (!is.null(self$`additional_fields`)) {
        ProductOptionItemObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        ProductOptionItemObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(ProductOptionItemObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductOptionItem
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductOptionItem
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`product_option_item_id`)) {
        self$`product_option_item_id` <- this_object$`product_option_item_id`
      }
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`sort_order`)) {
        self$`sort_order` <- this_object$`sort_order`
      }
      if (!is.null(this_object$`price`)) {
        self$`price` <- this_object$`price`
      }
      if (!is.null(this_object$`weight`)) {
        self$`weight` <- this_object$`weight`
      }
      if (!is.null(this_object$`quantity`)) {
        self$`quantity` <- this_object$`quantity`
      }
      if (!is.null(this_object$`type_price`)) {
        self$`type_price` <- this_object$`type_price`
      }
      if (!is.null(this_object$`sku`)) {
        self$`sku` <- this_object$`sku`
      }
      if (!is.null(this_object$`is_default`)) {
        self$`is_default` <- this_object$`is_default`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductOptionItem in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductOptionItem
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductOptionItem
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`product_option_item_id` <- this_object$`product_option_item_id`
      self$`name` <- this_object$`name`
      self$`sort_order` <- this_object$`sort_order`
      self$`price` <- this_object$`price`
      self$`weight` <- this_object$`weight`
      self$`quantity` <- this_object$`quantity`
      self$`type_price` <- this_object$`type_price`
      self$`sku` <- this_object$`sku`
      self$`is_default` <- this_object$`is_default`
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductOptionItem and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductOptionItem
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductOptionItem$unlock()
#
## Below is an example to define the print function
# ProductOptionItem$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductOptionItem$lock()

