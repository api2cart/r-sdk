#' Create a new StoreAttribute
#'
#' @description
#' StoreAttribute Class
#'
#' @docType class
#' @title StoreAttribute
#' @description StoreAttribute Class
#' @format An \code{R6Class} generator object
#' @field id  character [optional]
#' @field code  character [optional]
#' @field type  character [optional]
#' @field name  character [optional]
#' @field default_values  list(character) [optional]
#' @field position  integer [optional]
#' @field visible  character [optional]
#' @field required  character [optional]
#' @field system  character [optional]
#' @field values  list(character) [optional]
#' @field store_id  character [optional]
#' @field lang_id  character [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
StoreAttribute <- R6::R6Class(
  "StoreAttribute",
  public = list(
    `id` = NULL,
    `code` = NULL,
    `type` = NULL,
    `name` = NULL,
    `default_values` = NULL,
    `position` = NULL,
    `visible` = NULL,
    `required` = NULL,
    `system` = NULL,
    `values` = NULL,
    `store_id` = NULL,
    `lang_id` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new StoreAttribute class.
    #'
    #' @param id id
    #' @param code code
    #' @param type type
    #' @param name name
    #' @param default_values default_values
    #' @param position position
    #' @param visible visible
    #' @param required required
    #' @param system system
    #' @param values values
    #' @param store_id store_id
    #' @param lang_id lang_id
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `code` = NULL, `type` = NULL, `name` = NULL, `default_values` = NULL, `position` = NULL, `visible` = NULL, `required` = NULL, `system` = NULL, `values` = NULL, `store_id` = NULL, `lang_id` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`code`)) {
        if (!(is.character(`code`) && length(`code`) == 1)) {
          stop(paste("Error! Invalid data for `code`. Must be a string:", `code`))
        }
        self$`code` <- `code`
      }
      if (!is.null(`type`)) {
        if (!(is.character(`type`) && length(`type`) == 1)) {
          stop(paste("Error! Invalid data for `type`. Must be a string:", `type`))
        }
        self$`type` <- `type`
      }
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`default_values`)) {
        stopifnot(is.vector(`default_values`), length(`default_values`) != 0)
        sapply(`default_values`, function(x) stopifnot(is.character(x)))
        self$`default_values` <- `default_values`
      }
      if (!is.null(`position`)) {
        if (!(is.numeric(`position`) && length(`position`) == 1)) {
          stop(paste("Error! Invalid data for `position`. Must be an integer:", `position`))
        }
        self$`position` <- `position`
      }
      if (!is.null(`visible`)) {
        if (!(is.logical(`visible`) && length(`visible`) == 1)) {
          stop(paste("Error! Invalid data for `visible`. Must be a boolean:", `visible`))
        }
        self$`visible` <- `visible`
      }
      if (!is.null(`required`)) {
        if (!(is.logical(`required`) && length(`required`) == 1)) {
          stop(paste("Error! Invalid data for `required`. Must be a boolean:", `required`))
        }
        self$`required` <- `required`
      }
      if (!is.null(`system`)) {
        if (!(is.logical(`system`) && length(`system`) == 1)) {
          stop(paste("Error! Invalid data for `system`. Must be a boolean:", `system`))
        }
        self$`system` <- `system`
      }
      if (!is.null(`values`)) {
        stopifnot(is.vector(`values`), length(`values`) != 0)
        sapply(`values`, function(x) stopifnot(is.character(x)))
        self$`values` <- `values`
      }
      if (!is.null(`store_id`)) {
        if (!(is.character(`store_id`) && length(`store_id`) == 1)) {
          stop(paste("Error! Invalid data for `store_id`. Must be a string:", `store_id`))
        }
        self$`store_id` <- `store_id`
      }
      if (!is.null(`lang_id`)) {
        if (!(is.character(`lang_id`) && length(`lang_id`) == 1)) {
          stop(paste("Error! Invalid data for `lang_id`. Must be a string:", `lang_id`))
        }
        self$`lang_id` <- `lang_id`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return StoreAttribute as a base R list.
    #' @examples
    #' # convert array of StoreAttribute (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert StoreAttribute to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      StoreAttributeObject <- list()
      if (!is.null(self$`id`)) {
        StoreAttributeObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`code`)) {
        StoreAttributeObject[["code"]] <-
          self$`code`
      }
      if (!is.null(self$`type`)) {
        StoreAttributeObject[["type"]] <-
          self$`type`
      }
      if (!is.null(self$`name`)) {
        StoreAttributeObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`default_values`)) {
        StoreAttributeObject[["default_values"]] <-
          self$`default_values`
      }
      if (!is.null(self$`position`)) {
        StoreAttributeObject[["position"]] <-
          self$`position`
      }
      if (!is.null(self$`visible`)) {
        StoreAttributeObject[["visible"]] <-
          self$`visible`
      }
      if (!is.null(self$`required`)) {
        StoreAttributeObject[["required"]] <-
          self$`required`
      }
      if (!is.null(self$`system`)) {
        StoreAttributeObject[["system"]] <-
          self$`system`
      }
      if (!is.null(self$`values`)) {
        StoreAttributeObject[["values"]] <-
          self$`values`
      }
      if (!is.null(self$`store_id`)) {
        StoreAttributeObject[["store_id"]] <-
          self$`store_id`
      }
      if (!is.null(self$`lang_id`)) {
        StoreAttributeObject[["lang_id"]] <-
          self$`lang_id`
      }
      if (!is.null(self$`additional_fields`)) {
        StoreAttributeObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        StoreAttributeObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(StoreAttributeObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of StoreAttribute
    #'
    #' @param input_json the JSON input
    #' @return the instance of StoreAttribute
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`code`)) {
        self$`code` <- this_object$`code`
      }
      if (!is.null(this_object$`type`)) {
        self$`type` <- this_object$`type`
      }
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`default_values`)) {
        self$`default_values` <- ApiClient$new()$deserializeObj(this_object$`default_values`, "array[character]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`position`)) {
        self$`position` <- this_object$`position`
      }
      if (!is.null(this_object$`visible`)) {
        self$`visible` <- this_object$`visible`
      }
      if (!is.null(this_object$`required`)) {
        self$`required` <- this_object$`required`
      }
      if (!is.null(this_object$`system`)) {
        self$`system` <- this_object$`system`
      }
      if (!is.null(this_object$`values`)) {
        self$`values` <- ApiClient$new()$deserializeObj(this_object$`values`, "array[character]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`store_id`)) {
        self$`store_id` <- this_object$`store_id`
      }
      if (!is.null(this_object$`lang_id`)) {
        self$`lang_id` <- this_object$`lang_id`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return StoreAttribute in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of StoreAttribute
    #'
    #' @param input_json the JSON input
    #' @return the instance of StoreAttribute
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`code` <- this_object$`code`
      self$`type` <- this_object$`type`
      self$`name` <- this_object$`name`
      self$`default_values` <- ApiClient$new()$deserializeObj(this_object$`default_values`, "array[character]", loadNamespace("openapi"))
      self$`position` <- this_object$`position`
      self$`visible` <- this_object$`visible`
      self$`required` <- this_object$`required`
      self$`system` <- this_object$`system`
      self$`values` <- ApiClient$new()$deserializeObj(this_object$`values`, "array[character]", loadNamespace("openapi"))
      self$`store_id` <- this_object$`store_id`
      self$`lang_id` <- this_object$`lang_id`
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to StoreAttribute and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of StoreAttribute
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# StoreAttribute$unlock()
#
## Below is an example to define the print function
# StoreAttribute$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# StoreAttribute$lock()

