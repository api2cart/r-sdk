#' Create a new BatchJobResult
#'
#' @description
#' BatchJobResult Class
#'
#' @docType class
#' @title BatchJobResult
#' @description BatchJobResult Class
#' @format An \code{R6Class} generator object
#' @field job_id  integer [optional]
#' @field job_name  character [optional]
#' @field items_processed  integer [optional]
#' @field items_succeed  integer [optional]
#' @field items  list(\link{BatchJobResultItem}) [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
BatchJobResult <- R6::R6Class(
  "BatchJobResult",
  public = list(
    `job_id` = NULL,
    `job_name` = NULL,
    `items_processed` = NULL,
    `items_succeed` = NULL,
    `items` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new BatchJobResult class.
    #'
    #' @param job_id job_id
    #' @param job_name job_name
    #' @param items_processed items_processed
    #' @param items_succeed items_succeed
    #' @param items items
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`job_id` = NULL, `job_name` = NULL, `items_processed` = NULL, `items_succeed` = NULL, `items` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`job_id`)) {
        if (!(is.numeric(`job_id`) && length(`job_id`) == 1)) {
          stop(paste("Error! Invalid data for `job_id`. Must be an integer:", `job_id`))
        }
        self$`job_id` <- `job_id`
      }
      if (!is.null(`job_name`)) {
        if (!(is.character(`job_name`) && length(`job_name`) == 1)) {
          stop(paste("Error! Invalid data for `job_name`. Must be a string:", `job_name`))
        }
        self$`job_name` <- `job_name`
      }
      if (!is.null(`items_processed`)) {
        if (!(is.numeric(`items_processed`) && length(`items_processed`) == 1)) {
          stop(paste("Error! Invalid data for `items_processed`. Must be an integer:", `items_processed`))
        }
        self$`items_processed` <- `items_processed`
      }
      if (!is.null(`items_succeed`)) {
        if (!(is.numeric(`items_succeed`) && length(`items_succeed`) == 1)) {
          stop(paste("Error! Invalid data for `items_succeed`. Must be an integer:", `items_succeed`))
        }
        self$`items_succeed` <- `items_succeed`
      }
      if (!is.null(`items`)) {
        stopifnot(is.vector(`items`), length(`items`) != 0)
        sapply(`items`, function(x) stopifnot(R6::is.R6(x)))
        self$`items` <- `items`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return BatchJobResult as a base R list.
    #' @examples
    #' # convert array of BatchJobResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert BatchJobResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      BatchJobResultObject <- list()
      if (!is.null(self$`job_id`)) {
        BatchJobResultObject[["job_id"]] <-
          self$`job_id`
      }
      if (!is.null(self$`job_name`)) {
        BatchJobResultObject[["job_name"]] <-
          self$`job_name`
      }
      if (!is.null(self$`items_processed`)) {
        BatchJobResultObject[["items_processed"]] <-
          self$`items_processed`
      }
      if (!is.null(self$`items_succeed`)) {
        BatchJobResultObject[["items_succeed"]] <-
          self$`items_succeed`
      }
      if (!is.null(self$`items`)) {
        BatchJobResultObject[["items"]] <-
          lapply(self$`items`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`additional_fields`)) {
        BatchJobResultObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        BatchJobResultObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(BatchJobResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of BatchJobResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of BatchJobResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`job_id`)) {
        self$`job_id` <- this_object$`job_id`
      }
      if (!is.null(this_object$`job_name`)) {
        self$`job_name` <- this_object$`job_name`
      }
      if (!is.null(this_object$`items_processed`)) {
        self$`items_processed` <- this_object$`items_processed`
      }
      if (!is.null(this_object$`items_succeed`)) {
        self$`items_succeed` <- this_object$`items_succeed`
      }
      if (!is.null(this_object$`items`)) {
        self$`items` <- ApiClient$new()$deserializeObj(this_object$`items`, "array[BatchJobResultItem]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return BatchJobResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of BatchJobResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of BatchJobResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`job_id` <- this_object$`job_id`
      self$`job_name` <- this_object$`job_name`
      self$`items_processed` <- this_object$`items_processed`
      self$`items_succeed` <- this_object$`items_succeed`
      self$`items` <- ApiClient$new()$deserializeObj(this_object$`items`, "array[BatchJobResultItem]", loadNamespace("openapi"))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to BatchJobResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of BatchJobResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# BatchJobResult$unlock()
#
## Below is an example to define the print function
# BatchJobResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# BatchJobResult$lock()

