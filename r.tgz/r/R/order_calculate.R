#' Create a new OrderCalculate
#'
#' @description
#' OrderCalculate Class
#'
#' @docType class
#' @title OrderCalculate
#' @description OrderCalculate Class
#' @format An \code{R6Class} generator object
#' @field customer_email Defines the customer specified by email for whom the order needs to be calculated character
#' @field currency_id Currency Id character [optional]
#' @field store_id Store Id character [optional]
#' @field coupons Coupons that will be applied to order. If the order isn't eligible for any given discount code or there is no discount with such a code it will be skipped during calculation list(character) [optional]
#' @field rounding_precision <p>Specifies the rounding precision for fractional numeric values (such as prices, taxes, and weights).</p> <p>Supported values range from <b>1</b> to <b>6</b>.</p> <p>The default rounding precision may vary depending on the platform. You can retrieve the default value using the <strong>cart.info</strong> method in the <code>default_rounding_precision</code> field. </p><p>Values are rounded to the nearest number at the specified precision. Fractions of .5 or higher are rounded up, while fractions lower than .5 are rounded down.</p> integer [optional]
#' @field shipp_first_name Specifies shipping first name character
#' @field shipp_last_name Specifies shipping last name character
#' @field shipp_address_1 Specifies first shipping address character
#' @field shipp_address_2 Specifies second address line of a shipping street address character [optional]
#' @field shipp_city Specifies shipping city character
#' @field shipp_postcode Specifies shipping postcode character
#' @field shipp_state Specifies shipping state code character [optional]
#' @field shipp_country Specifies shipping country code character
#' @field shipp_company Specifies shipping company character [optional]
#' @field shipp_phone Specifies shipping phone character [optional]
#' @field bill_first_name Specifies billing first name character [optional]
#' @field bill_last_name Specifies billing last name character [optional]
#' @field bill_address_1 Specifies first billing address character [optional]
#' @field bill_address_2 Specifies second billing address character [optional]
#' @field bill_city Specifies billing city character [optional]
#' @field bill_postcode Specifies billing postcode character [optional]
#' @field bill_state Specifies billing state code character [optional]
#' @field bill_country Specifies billing country code character [optional]
#' @field bill_company Specifies billing company character [optional]
#' @field bill_phone Specifies billing phone character [optional]
#' @field response_fields Set this parameter in order to choose which entity fields you want to retrieve character [optional]
#' @field idempotency_key A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong> character [optional]
#' @field order_item  list(\link{OrderCalculateOrderItemInner})
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
OrderCalculate <- R6::R6Class(
  "OrderCalculate",
  public = list(
    `customer_email` = NULL,
    `currency_id` = NULL,
    `store_id` = NULL,
    `coupons` = NULL,
    `rounding_precision` = NULL,
    `shipp_first_name` = NULL,
    `shipp_last_name` = NULL,
    `shipp_address_1` = NULL,
    `shipp_address_2` = NULL,
    `shipp_city` = NULL,
    `shipp_postcode` = NULL,
    `shipp_state` = NULL,
    `shipp_country` = NULL,
    `shipp_company` = NULL,
    `shipp_phone` = NULL,
    `bill_first_name` = NULL,
    `bill_last_name` = NULL,
    `bill_address_1` = NULL,
    `bill_address_2` = NULL,
    `bill_city` = NULL,
    `bill_postcode` = NULL,
    `bill_state` = NULL,
    `bill_country` = NULL,
    `bill_company` = NULL,
    `bill_phone` = NULL,
    `response_fields` = NULL,
    `idempotency_key` = NULL,
    `order_item` = NULL,

    #' @description
    #' Initialize a new OrderCalculate class.
    #'
    #' @param customer_email Defines the customer specified by email for whom the order needs to be calculated
    #' @param shipp_first_name Specifies shipping first name
    #' @param shipp_last_name Specifies shipping last name
    #' @param shipp_address_1 Specifies first shipping address
    #' @param shipp_city Specifies shipping city
    #' @param shipp_postcode Specifies shipping postcode
    #' @param shipp_country Specifies shipping country code
    #' @param order_item order_item
    #' @param currency_id Currency Id
    #' @param store_id Store Id
    #' @param coupons Coupons that will be applied to order. If the order isn't eligible for any given discount code or there is no discount with such a code it will be skipped during calculation
    #' @param rounding_precision <p>Specifies the rounding precision for fractional numeric values (such as prices, taxes, and weights).</p> <p>Supported values range from <b>1</b> to <b>6</b>.</p> <p>The default rounding precision may vary depending on the platform. You can retrieve the default value using the <strong>cart.info</strong> method in the <code>default_rounding_precision</code> field. </p><p>Values are rounded to the nearest number at the specified precision. Fractions of .5 or higher are rounded up, while fractions lower than .5 are rounded down.</p>
    #' @param shipp_address_2 Specifies second address line of a shipping street address
    #' @param shipp_state Specifies shipping state code
    #' @param shipp_company Specifies shipping company
    #' @param shipp_phone Specifies shipping phone
    #' @param bill_first_name Specifies billing first name
    #' @param bill_last_name Specifies billing last name
    #' @param bill_address_1 Specifies first billing address
    #' @param bill_address_2 Specifies second billing address
    #' @param bill_city Specifies billing city
    #' @param bill_postcode Specifies billing postcode
    #' @param bill_state Specifies billing state code
    #' @param bill_country Specifies billing country code
    #' @param bill_company Specifies billing company
    #' @param bill_phone Specifies billing phone
    #' @param response_fields Set this parameter in order to choose which entity fields you want to retrieve
    #' @param idempotency_key A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong>
    #' @param ... Other optional arguments.
    initialize = function(`customer_email`, `shipp_first_name`, `shipp_last_name`, `shipp_address_1`, `shipp_city`, `shipp_postcode`, `shipp_country`, `order_item`, `currency_id` = NULL, `store_id` = NULL, `coupons` = NULL, `rounding_precision` = NULL, `shipp_address_2` = NULL, `shipp_state` = NULL, `shipp_company` = NULL, `shipp_phone` = NULL, `bill_first_name` = NULL, `bill_last_name` = NULL, `bill_address_1` = NULL, `bill_address_2` = NULL, `bill_city` = NULL, `bill_postcode` = NULL, `bill_state` = NULL, `bill_country` = NULL, `bill_company` = NULL, `bill_phone` = NULL, `response_fields` = NULL, `idempotency_key` = NULL, ...) {
      if (!missing(`customer_email`)) {
        if (!(is.character(`customer_email`) && length(`customer_email`) == 1)) {
          stop(paste("Error! Invalid data for `customer_email`. Must be a string:", `customer_email`))
        }
        self$`customer_email` <- `customer_email`
      }
      if (!missing(`shipp_first_name`)) {
        if (!(is.character(`shipp_first_name`) && length(`shipp_first_name`) == 1)) {
          stop(paste("Error! Invalid data for `shipp_first_name`. Must be a string:", `shipp_first_name`))
        }
        self$`shipp_first_name` <- `shipp_first_name`
      }
      if (!missing(`shipp_last_name`)) {
        if (!(is.character(`shipp_last_name`) && length(`shipp_last_name`) == 1)) {
          stop(paste("Error! Invalid data for `shipp_last_name`. Must be a string:", `shipp_last_name`))
        }
        self$`shipp_last_name` <- `shipp_last_name`
      }
      if (!missing(`shipp_address_1`)) {
        if (!(is.character(`shipp_address_1`) && length(`shipp_address_1`) == 1)) {
          stop(paste("Error! Invalid data for `shipp_address_1`. Must be a string:", `shipp_address_1`))
        }
        self$`shipp_address_1` <- `shipp_address_1`
      }
      if (!missing(`shipp_city`)) {
        if (!(is.character(`shipp_city`) && length(`shipp_city`) == 1)) {
          stop(paste("Error! Invalid data for `shipp_city`. Must be a string:", `shipp_city`))
        }
        self$`shipp_city` <- `shipp_city`
      }
      if (!missing(`shipp_postcode`)) {
        if (!(is.character(`shipp_postcode`) && length(`shipp_postcode`) == 1)) {
          stop(paste("Error! Invalid data for `shipp_postcode`. Must be a string:", `shipp_postcode`))
        }
        self$`shipp_postcode` <- `shipp_postcode`
      }
      if (!missing(`shipp_country`)) {
        if (!(is.character(`shipp_country`) && length(`shipp_country`) == 1)) {
          stop(paste("Error! Invalid data for `shipp_country`. Must be a string:", `shipp_country`))
        }
        self$`shipp_country` <- `shipp_country`
      }
      if (!missing(`order_item`)) {
        stopifnot(is.vector(`order_item`), length(`order_item`) != 0)
        sapply(`order_item`, function(x) stopifnot(R6::is.R6(x)))
        self$`order_item` <- `order_item`
      }
      if (!is.null(`currency_id`)) {
        if (!(is.character(`currency_id`) && length(`currency_id`) == 1)) {
          stop(paste("Error! Invalid data for `currency_id`. Must be a string:", `currency_id`))
        }
        self$`currency_id` <- `currency_id`
      }
      if (!is.null(`store_id`)) {
        if (!(is.character(`store_id`) && length(`store_id`) == 1)) {
          stop(paste("Error! Invalid data for `store_id`. Must be a string:", `store_id`))
        }
        self$`store_id` <- `store_id`
      }
      if (!is.null(`coupons`)) {
        stopifnot(is.vector(`coupons`), length(`coupons`) != 0)
        sapply(`coupons`, function(x) stopifnot(is.character(x)))
        self$`coupons` <- `coupons`
      }
      if (!is.null(`rounding_precision`)) {
        if (!(is.numeric(`rounding_precision`) && length(`rounding_precision`) == 1)) {
          stop(paste("Error! Invalid data for `rounding_precision`. Must be an integer:", `rounding_precision`))
        }
        self$`rounding_precision` <- `rounding_precision`
      }
      if (!is.null(`shipp_address_2`)) {
        if (!(is.character(`shipp_address_2`) && length(`shipp_address_2`) == 1)) {
          stop(paste("Error! Invalid data for `shipp_address_2`. Must be a string:", `shipp_address_2`))
        }
        self$`shipp_address_2` <- `shipp_address_2`
      }
      if (!is.null(`shipp_state`)) {
        if (!(is.character(`shipp_state`) && length(`shipp_state`) == 1)) {
          stop(paste("Error! Invalid data for `shipp_state`. Must be a string:", `shipp_state`))
        }
        self$`shipp_state` <- `shipp_state`
      }
      if (!is.null(`shipp_company`)) {
        if (!(is.character(`shipp_company`) && length(`shipp_company`) == 1)) {
          stop(paste("Error! Invalid data for `shipp_company`. Must be a string:", `shipp_company`))
        }
        self$`shipp_company` <- `shipp_company`
      }
      if (!is.null(`shipp_phone`)) {
        if (!(is.character(`shipp_phone`) && length(`shipp_phone`) == 1)) {
          stop(paste("Error! Invalid data for `shipp_phone`. Must be a string:", `shipp_phone`))
        }
        self$`shipp_phone` <- `shipp_phone`
      }
      if (!is.null(`bill_first_name`)) {
        if (!(is.character(`bill_first_name`) && length(`bill_first_name`) == 1)) {
          stop(paste("Error! Invalid data for `bill_first_name`. Must be a string:", `bill_first_name`))
        }
        self$`bill_first_name` <- `bill_first_name`
      }
      if (!is.null(`bill_last_name`)) {
        if (!(is.character(`bill_last_name`) && length(`bill_last_name`) == 1)) {
          stop(paste("Error! Invalid data for `bill_last_name`. Must be a string:", `bill_last_name`))
        }
        self$`bill_last_name` <- `bill_last_name`
      }
      if (!is.null(`bill_address_1`)) {
        if (!(is.character(`bill_address_1`) && length(`bill_address_1`) == 1)) {
          stop(paste("Error! Invalid data for `bill_address_1`. Must be a string:", `bill_address_1`))
        }
        self$`bill_address_1` <- `bill_address_1`
      }
      if (!is.null(`bill_address_2`)) {
        if (!(is.character(`bill_address_2`) && length(`bill_address_2`) == 1)) {
          stop(paste("Error! Invalid data for `bill_address_2`. Must be a string:", `bill_address_2`))
        }
        self$`bill_address_2` <- `bill_address_2`
      }
      if (!is.null(`bill_city`)) {
        if (!(is.character(`bill_city`) && length(`bill_city`) == 1)) {
          stop(paste("Error! Invalid data for `bill_city`. Must be a string:", `bill_city`))
        }
        self$`bill_city` <- `bill_city`
      }
      if (!is.null(`bill_postcode`)) {
        if (!(is.character(`bill_postcode`) && length(`bill_postcode`) == 1)) {
          stop(paste("Error! Invalid data for `bill_postcode`. Must be a string:", `bill_postcode`))
        }
        self$`bill_postcode` <- `bill_postcode`
      }
      if (!is.null(`bill_state`)) {
        if (!(is.character(`bill_state`) && length(`bill_state`) == 1)) {
          stop(paste("Error! Invalid data for `bill_state`. Must be a string:", `bill_state`))
        }
        self$`bill_state` <- `bill_state`
      }
      if (!is.null(`bill_country`)) {
        if (!(is.character(`bill_country`) && length(`bill_country`) == 1)) {
          stop(paste("Error! Invalid data for `bill_country`. Must be a string:", `bill_country`))
        }
        self$`bill_country` <- `bill_country`
      }
      if (!is.null(`bill_company`)) {
        if (!(is.character(`bill_company`) && length(`bill_company`) == 1)) {
          stop(paste("Error! Invalid data for `bill_company`. Must be a string:", `bill_company`))
        }
        self$`bill_company` <- `bill_company`
      }
      if (!is.null(`bill_phone`)) {
        if (!(is.character(`bill_phone`) && length(`bill_phone`) == 1)) {
          stop(paste("Error! Invalid data for `bill_phone`. Must be a string:", `bill_phone`))
        }
        self$`bill_phone` <- `bill_phone`
      }
      if (!is.null(`response_fields`)) {
        if (!(is.character(`response_fields`) && length(`response_fields`) == 1)) {
          stop(paste("Error! Invalid data for `response_fields`. Must be a string:", `response_fields`))
        }
        self$`response_fields` <- `response_fields`
      }
      if (!is.null(`idempotency_key`)) {
        if (!(is.character(`idempotency_key`) && length(`idempotency_key`) == 1)) {
          stop(paste("Error! Invalid data for `idempotency_key`. Must be a string:", `idempotency_key`))
        }
        self$`idempotency_key` <- `idempotency_key`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return OrderCalculate as a base R list.
    #' @examples
    #' # convert array of OrderCalculate (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert OrderCalculate to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      OrderCalculateObject <- list()
      if (!is.null(self$`customer_email`)) {
        OrderCalculateObject[["customer_email"]] <-
          self$`customer_email`
      }
      if (!is.null(self$`currency_id`)) {
        OrderCalculateObject[["currency_id"]] <-
          self$`currency_id`
      }
      if (!is.null(self$`store_id`)) {
        OrderCalculateObject[["store_id"]] <-
          self$`store_id`
      }
      if (!is.null(self$`coupons`)) {
        OrderCalculateObject[["coupons"]] <-
          self$`coupons`
      }
      if (!is.null(self$`rounding_precision`)) {
        OrderCalculateObject[["rounding_precision"]] <-
          self$`rounding_precision`
      }
      if (!is.null(self$`shipp_first_name`)) {
        OrderCalculateObject[["shipp_first_name"]] <-
          self$`shipp_first_name`
      }
      if (!is.null(self$`shipp_last_name`)) {
        OrderCalculateObject[["shipp_last_name"]] <-
          self$`shipp_last_name`
      }
      if (!is.null(self$`shipp_address_1`)) {
        OrderCalculateObject[["shipp_address_1"]] <-
          self$`shipp_address_1`
      }
      if (!is.null(self$`shipp_address_2`)) {
        OrderCalculateObject[["shipp_address_2"]] <-
          self$`shipp_address_2`
      }
      if (!is.null(self$`shipp_city`)) {
        OrderCalculateObject[["shipp_city"]] <-
          self$`shipp_city`
      }
      if (!is.null(self$`shipp_postcode`)) {
        OrderCalculateObject[["shipp_postcode"]] <-
          self$`shipp_postcode`
      }
      if (!is.null(self$`shipp_state`)) {
        OrderCalculateObject[["shipp_state"]] <-
          self$`shipp_state`
      }
      if (!is.null(self$`shipp_country`)) {
        OrderCalculateObject[["shipp_country"]] <-
          self$`shipp_country`
      }
      if (!is.null(self$`shipp_company`)) {
        OrderCalculateObject[["shipp_company"]] <-
          self$`shipp_company`
      }
      if (!is.null(self$`shipp_phone`)) {
        OrderCalculateObject[["shipp_phone"]] <-
          self$`shipp_phone`
      }
      if (!is.null(self$`bill_first_name`)) {
        OrderCalculateObject[["bill_first_name"]] <-
          self$`bill_first_name`
      }
      if (!is.null(self$`bill_last_name`)) {
        OrderCalculateObject[["bill_last_name"]] <-
          self$`bill_last_name`
      }
      if (!is.null(self$`bill_address_1`)) {
        OrderCalculateObject[["bill_address_1"]] <-
          self$`bill_address_1`
      }
      if (!is.null(self$`bill_address_2`)) {
        OrderCalculateObject[["bill_address_2"]] <-
          self$`bill_address_2`
      }
      if (!is.null(self$`bill_city`)) {
        OrderCalculateObject[["bill_city"]] <-
          self$`bill_city`
      }
      if (!is.null(self$`bill_postcode`)) {
        OrderCalculateObject[["bill_postcode"]] <-
          self$`bill_postcode`
      }
      if (!is.null(self$`bill_state`)) {
        OrderCalculateObject[["bill_state"]] <-
          self$`bill_state`
      }
      if (!is.null(self$`bill_country`)) {
        OrderCalculateObject[["bill_country"]] <-
          self$`bill_country`
      }
      if (!is.null(self$`bill_company`)) {
        OrderCalculateObject[["bill_company"]] <-
          self$`bill_company`
      }
      if (!is.null(self$`bill_phone`)) {
        OrderCalculateObject[["bill_phone"]] <-
          self$`bill_phone`
      }
      if (!is.null(self$`response_fields`)) {
        OrderCalculateObject[["response_fields"]] <-
          self$`response_fields`
      }
      if (!is.null(self$`idempotency_key`)) {
        OrderCalculateObject[["idempotency_key"]] <-
          self$`idempotency_key`
      }
      if (!is.null(self$`order_item`)) {
        OrderCalculateObject[["order_item"]] <-
          lapply(self$`order_item`, function(x) x$toSimpleType())
      }
      return(OrderCalculateObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderCalculate
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderCalculate
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`customer_email`)) {
        self$`customer_email` <- this_object$`customer_email`
      }
      if (!is.null(this_object$`currency_id`)) {
        self$`currency_id` <- this_object$`currency_id`
      }
      if (!is.null(this_object$`store_id`)) {
        self$`store_id` <- this_object$`store_id`
      }
      if (!is.null(this_object$`coupons`)) {
        self$`coupons` <- ApiClient$new()$deserializeObj(this_object$`coupons`, "array[character]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`rounding_precision`)) {
        self$`rounding_precision` <- this_object$`rounding_precision`
      }
      if (!is.null(this_object$`shipp_first_name`)) {
        self$`shipp_first_name` <- this_object$`shipp_first_name`
      }
      if (!is.null(this_object$`shipp_last_name`)) {
        self$`shipp_last_name` <- this_object$`shipp_last_name`
      }
      if (!is.null(this_object$`shipp_address_1`)) {
        self$`shipp_address_1` <- this_object$`shipp_address_1`
      }
      if (!is.null(this_object$`shipp_address_2`)) {
        self$`shipp_address_2` <- this_object$`shipp_address_2`
      }
      if (!is.null(this_object$`shipp_city`)) {
        self$`shipp_city` <- this_object$`shipp_city`
      }
      if (!is.null(this_object$`shipp_postcode`)) {
        self$`shipp_postcode` <- this_object$`shipp_postcode`
      }
      if (!is.null(this_object$`shipp_state`)) {
        self$`shipp_state` <- this_object$`shipp_state`
      }
      if (!is.null(this_object$`shipp_country`)) {
        self$`shipp_country` <- this_object$`shipp_country`
      }
      if (!is.null(this_object$`shipp_company`)) {
        self$`shipp_company` <- this_object$`shipp_company`
      }
      if (!is.null(this_object$`shipp_phone`)) {
        self$`shipp_phone` <- this_object$`shipp_phone`
      }
      if (!is.null(this_object$`bill_first_name`)) {
        self$`bill_first_name` <- this_object$`bill_first_name`
      }
      if (!is.null(this_object$`bill_last_name`)) {
        self$`bill_last_name` <- this_object$`bill_last_name`
      }
      if (!is.null(this_object$`bill_address_1`)) {
        self$`bill_address_1` <- this_object$`bill_address_1`
      }
      if (!is.null(this_object$`bill_address_2`)) {
        self$`bill_address_2` <- this_object$`bill_address_2`
      }
      if (!is.null(this_object$`bill_city`)) {
        self$`bill_city` <- this_object$`bill_city`
      }
      if (!is.null(this_object$`bill_postcode`)) {
        self$`bill_postcode` <- this_object$`bill_postcode`
      }
      if (!is.null(this_object$`bill_state`)) {
        self$`bill_state` <- this_object$`bill_state`
      }
      if (!is.null(this_object$`bill_country`)) {
        self$`bill_country` <- this_object$`bill_country`
      }
      if (!is.null(this_object$`bill_company`)) {
        self$`bill_company` <- this_object$`bill_company`
      }
      if (!is.null(this_object$`bill_phone`)) {
        self$`bill_phone` <- this_object$`bill_phone`
      }
      if (!is.null(this_object$`response_fields`)) {
        self$`response_fields` <- this_object$`response_fields`
      }
      if (!is.null(this_object$`idempotency_key`)) {
        self$`idempotency_key` <- this_object$`idempotency_key`
      }
      if (!is.null(this_object$`order_item`)) {
        self$`order_item` <- ApiClient$new()$deserializeObj(this_object$`order_item`, "array[OrderCalculateOrderItemInner]", loadNamespace("openapi"))
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return OrderCalculate in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderCalculate
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderCalculate
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`customer_email` <- this_object$`customer_email`
      self$`currency_id` <- this_object$`currency_id`
      self$`store_id` <- this_object$`store_id`
      self$`coupons` <- ApiClient$new()$deserializeObj(this_object$`coupons`, "array[character]", loadNamespace("openapi"))
      self$`rounding_precision` <- this_object$`rounding_precision`
      self$`shipp_first_name` <- this_object$`shipp_first_name`
      self$`shipp_last_name` <- this_object$`shipp_last_name`
      self$`shipp_address_1` <- this_object$`shipp_address_1`
      self$`shipp_address_2` <- this_object$`shipp_address_2`
      self$`shipp_city` <- this_object$`shipp_city`
      self$`shipp_postcode` <- this_object$`shipp_postcode`
      self$`shipp_state` <- this_object$`shipp_state`
      self$`shipp_country` <- this_object$`shipp_country`
      self$`shipp_company` <- this_object$`shipp_company`
      self$`shipp_phone` <- this_object$`shipp_phone`
      self$`bill_first_name` <- this_object$`bill_first_name`
      self$`bill_last_name` <- this_object$`bill_last_name`
      self$`bill_address_1` <- this_object$`bill_address_1`
      self$`bill_address_2` <- this_object$`bill_address_2`
      self$`bill_city` <- this_object$`bill_city`
      self$`bill_postcode` <- this_object$`bill_postcode`
      self$`bill_state` <- this_object$`bill_state`
      self$`bill_country` <- this_object$`bill_country`
      self$`bill_company` <- this_object$`bill_company`
      self$`bill_phone` <- this_object$`bill_phone`
      self$`response_fields` <- this_object$`response_fields`
      self$`idempotency_key` <- this_object$`idempotency_key`
      self$`order_item` <- ApiClient$new()$deserializeObj(this_object$`order_item`, "array[OrderCalculateOrderItemInner]", loadNamespace("openapi"))
      self
    },

    #' @description
    #' Validate JSON input with respect to OrderCalculate and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
      # check the required field `customer_email`
      if (!is.null(input_json$`customer_email`)) {
        if (!(is.character(input_json$`customer_email`) && length(input_json$`customer_email`) == 1)) {
          stop(paste("Error! Invalid data for `customer_email`. Must be a string:", input_json$`customer_email`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for OrderCalculate: the required field `customer_email` is missing."))
      }
      # check the required field `shipp_first_name`
      if (!is.null(input_json$`shipp_first_name`)) {
        if (!(is.character(input_json$`shipp_first_name`) && length(input_json$`shipp_first_name`) == 1)) {
          stop(paste("Error! Invalid data for `shipp_first_name`. Must be a string:", input_json$`shipp_first_name`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for OrderCalculate: the required field `shipp_first_name` is missing."))
      }
      # check the required field `shipp_last_name`
      if (!is.null(input_json$`shipp_last_name`)) {
        if (!(is.character(input_json$`shipp_last_name`) && length(input_json$`shipp_last_name`) == 1)) {
          stop(paste("Error! Invalid data for `shipp_last_name`. Must be a string:", input_json$`shipp_last_name`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for OrderCalculate: the required field `shipp_last_name` is missing."))
      }
      # check the required field `shipp_address_1`
      if (!is.null(input_json$`shipp_address_1`)) {
        if (!(is.character(input_json$`shipp_address_1`) && length(input_json$`shipp_address_1`) == 1)) {
          stop(paste("Error! Invalid data for `shipp_address_1`. Must be a string:", input_json$`shipp_address_1`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for OrderCalculate: the required field `shipp_address_1` is missing."))
      }
      # check the required field `shipp_city`
      if (!is.null(input_json$`shipp_city`)) {
        if (!(is.character(input_json$`shipp_city`) && length(input_json$`shipp_city`) == 1)) {
          stop(paste("Error! Invalid data for `shipp_city`. Must be a string:", input_json$`shipp_city`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for OrderCalculate: the required field `shipp_city` is missing."))
      }
      # check the required field `shipp_postcode`
      if (!is.null(input_json$`shipp_postcode`)) {
        if (!(is.character(input_json$`shipp_postcode`) && length(input_json$`shipp_postcode`) == 1)) {
          stop(paste("Error! Invalid data for `shipp_postcode`. Must be a string:", input_json$`shipp_postcode`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for OrderCalculate: the required field `shipp_postcode` is missing."))
      }
      # check the required field `shipp_country`
      if (!is.null(input_json$`shipp_country`)) {
        if (!(is.character(input_json$`shipp_country`) && length(input_json$`shipp_country`) == 1)) {
          stop(paste("Error! Invalid data for `shipp_country`. Must be a string:", input_json$`shipp_country`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for OrderCalculate: the required field `shipp_country` is missing."))
      }
      # check the required field `order_item`
      if (!is.null(input_json$`order_item`)) {
        stopifnot(is.vector(input_json$`order_item`), length(input_json$`order_item`) != 0)
        tmp <- sapply(input_json$`order_item`, function(x) stopifnot(R6::is.R6(x)))
      } else {
        stop(paste("The JSON input `", input, "` is invalid for OrderCalculate: the required field `order_item` is missing."))
      }
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of OrderCalculate
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      # check if the required `customer_email` is null
      if (is.null(self$`customer_email`)) {
        return(FALSE)
      }

      if (length(self$`coupons`) < 1) {
        return(FALSE)
      }

      # check if the required `shipp_first_name` is null
      if (is.null(self$`shipp_first_name`)) {
        return(FALSE)
      }

      # check if the required `shipp_last_name` is null
      if (is.null(self$`shipp_last_name`)) {
        return(FALSE)
      }

      # check if the required `shipp_address_1` is null
      if (is.null(self$`shipp_address_1`)) {
        return(FALSE)
      }

      # check if the required `shipp_city` is null
      if (is.null(self$`shipp_city`)) {
        return(FALSE)
      }

      # check if the required `shipp_postcode` is null
      if (is.null(self$`shipp_postcode`)) {
        return(FALSE)
      }

      # check if the required `shipp_country` is null
      if (is.null(self$`shipp_country`)) {
        return(FALSE)
      }

      # check if the required `order_item` is null
      if (is.null(self$`order_item`)) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      # check if the required `customer_email` is null
      if (is.null(self$`customer_email`)) {
        invalid_fields["customer_email"] <- "Non-nullable required field `customer_email` cannot be null."
      }

      if (length(self$`coupons`) < 1) {
        invalid_fields["coupons"] <- "Invalid length for ``, number of items must be greater than or equal to 1."
      }

      # check if the required `shipp_first_name` is null
      if (is.null(self$`shipp_first_name`)) {
        invalid_fields["shipp_first_name"] <- "Non-nullable required field `shipp_first_name` cannot be null."
      }

      # check if the required `shipp_last_name` is null
      if (is.null(self$`shipp_last_name`)) {
        invalid_fields["shipp_last_name"] <- "Non-nullable required field `shipp_last_name` cannot be null."
      }

      # check if the required `shipp_address_1` is null
      if (is.null(self$`shipp_address_1`)) {
        invalid_fields["shipp_address_1"] <- "Non-nullable required field `shipp_address_1` cannot be null."
      }

      # check if the required `shipp_city` is null
      if (is.null(self$`shipp_city`)) {
        invalid_fields["shipp_city"] <- "Non-nullable required field `shipp_city` cannot be null."
      }

      # check if the required `shipp_postcode` is null
      if (is.null(self$`shipp_postcode`)) {
        invalid_fields["shipp_postcode"] <- "Non-nullable required field `shipp_postcode` cannot be null."
      }

      # check if the required `shipp_country` is null
      if (is.null(self$`shipp_country`)) {
        invalid_fields["shipp_country"] <- "Non-nullable required field `shipp_country` cannot be null."
      }

      # check if the required `order_item` is null
      if (is.null(self$`order_item`)) {
        invalid_fields["order_item"] <- "Non-nullable required field `order_item` cannot be null."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# OrderCalculate$unlock()
#
## Below is an example to define the print function
# OrderCalculate$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# OrderCalculate$lock()

