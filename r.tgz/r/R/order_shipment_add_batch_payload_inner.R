#' Create a new OrderShipmentAddBatchPayloadInner
#'
#' @description
#' OrderShipmentAddBatchPayloadInner Class
#'
#' @docType class
#' @title OrderShipmentAddBatchPayloadInner
#' @description OrderShipmentAddBatchPayloadInner Class
#' @format An \code{R6Class} generator object
#' @field order_id  character
#' @field store_id  character [optional]
#' @field warehouse_id  character [optional]
#' @field carrier_id  character [optional]
#' @field carrier_name  character [optional]
#' @field tracking_number  character
#' @field tracking_link  character [optional]
#' @field shipment_provider  character [optional]
#' @field items  list(\link{OrderShipmentAddBatchPayloadInnerItemsInner}) [optional]
#' @field send_notifications  character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
OrderShipmentAddBatchPayloadInner <- R6::R6Class(
  "OrderShipmentAddBatchPayloadInner",
  public = list(
    `order_id` = NULL,
    `store_id` = NULL,
    `warehouse_id` = NULL,
    `carrier_id` = NULL,
    `carrier_name` = NULL,
    `tracking_number` = NULL,
    `tracking_link` = NULL,
    `shipment_provider` = NULL,
    `items` = NULL,
    `send_notifications` = NULL,

    #' @description
    #' Initialize a new OrderShipmentAddBatchPayloadInner class.
    #'
    #' @param order_id order_id
    #' @param tracking_number tracking_number
    #' @param store_id store_id
    #' @param warehouse_id warehouse_id
    #' @param carrier_id carrier_id
    #' @param carrier_name carrier_name
    #' @param tracking_link tracking_link
    #' @param shipment_provider shipment_provider
    #' @param items items
    #' @param send_notifications send_notifications
    #' @param ... Other optional arguments.
    initialize = function(`order_id`, `tracking_number`, `store_id` = NULL, `warehouse_id` = NULL, `carrier_id` = NULL, `carrier_name` = NULL, `tracking_link` = NULL, `shipment_provider` = NULL, `items` = NULL, `send_notifications` = NULL, ...) {
      if (!missing(`order_id`)) {
        if (!(is.character(`order_id`) && length(`order_id`) == 1)) {
          stop(paste("Error! Invalid data for `order_id`. Must be a string:", `order_id`))
        }
        self$`order_id` <- `order_id`
      }
      if (!missing(`tracking_number`)) {
        if (!(is.character(`tracking_number`) && length(`tracking_number`) == 1)) {
          stop(paste("Error! Invalid data for `tracking_number`. Must be a string:", `tracking_number`))
        }
        self$`tracking_number` <- `tracking_number`
      }
      if (!is.null(`store_id`)) {
        if (!(is.character(`store_id`) && length(`store_id`) == 1)) {
          stop(paste("Error! Invalid data for `store_id`. Must be a string:", `store_id`))
        }
        self$`store_id` <- `store_id`
      }
      if (!is.null(`warehouse_id`)) {
        if (!(is.character(`warehouse_id`) && length(`warehouse_id`) == 1)) {
          stop(paste("Error! Invalid data for `warehouse_id`. Must be a string:", `warehouse_id`))
        }
        self$`warehouse_id` <- `warehouse_id`
      }
      if (!is.null(`carrier_id`)) {
        if (!(is.character(`carrier_id`) && length(`carrier_id`) == 1)) {
          stop(paste("Error! Invalid data for `carrier_id`. Must be a string:", `carrier_id`))
        }
        self$`carrier_id` <- `carrier_id`
      }
      if (!is.null(`carrier_name`)) {
        if (!(is.character(`carrier_name`) && length(`carrier_name`) == 1)) {
          stop(paste("Error! Invalid data for `carrier_name`. Must be a string:", `carrier_name`))
        }
        self$`carrier_name` <- `carrier_name`
      }
      if (!is.null(`tracking_link`)) {
        if (!(is.character(`tracking_link`) && length(`tracking_link`) == 1)) {
          stop(paste("Error! Invalid data for `tracking_link`. Must be a string:", `tracking_link`))
        }
        self$`tracking_link` <- `tracking_link`
      }
      if (!is.null(`shipment_provider`)) {
        if (!(is.character(`shipment_provider`) && length(`shipment_provider`) == 1)) {
          stop(paste("Error! Invalid data for `shipment_provider`. Must be a string:", `shipment_provider`))
        }
        self$`shipment_provider` <- `shipment_provider`
      }
      if (!is.null(`items`)) {
        stopifnot(is.vector(`items`), length(`items`) != 0)
        sapply(`items`, function(x) stopifnot(R6::is.R6(x)))
        self$`items` <- `items`
      }
      if (!is.null(`send_notifications`)) {
        if (!(is.logical(`send_notifications`) && length(`send_notifications`) == 1)) {
          stop(paste("Error! Invalid data for `send_notifications`. Must be a boolean:", `send_notifications`))
        }
        self$`send_notifications` <- `send_notifications`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return OrderShipmentAddBatchPayloadInner as a base R list.
    #' @examples
    #' # convert array of OrderShipmentAddBatchPayloadInner (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert OrderShipmentAddBatchPayloadInner to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      OrderShipmentAddBatchPayloadInnerObject <- list()
      if (!is.null(self$`order_id`)) {
        OrderShipmentAddBatchPayloadInnerObject[["order_id"]] <-
          self$`order_id`
      }
      if (!is.null(self$`store_id`)) {
        OrderShipmentAddBatchPayloadInnerObject[["store_id"]] <-
          self$`store_id`
      }
      if (!is.null(self$`warehouse_id`)) {
        OrderShipmentAddBatchPayloadInnerObject[["warehouse_id"]] <-
          self$`warehouse_id`
      }
      if (!is.null(self$`carrier_id`)) {
        OrderShipmentAddBatchPayloadInnerObject[["carrier_id"]] <-
          self$`carrier_id`
      }
      if (!is.null(self$`carrier_name`)) {
        OrderShipmentAddBatchPayloadInnerObject[["carrier_name"]] <-
          self$`carrier_name`
      }
      if (!is.null(self$`tracking_number`)) {
        OrderShipmentAddBatchPayloadInnerObject[["tracking_number"]] <-
          self$`tracking_number`
      }
      if (!is.null(self$`tracking_link`)) {
        OrderShipmentAddBatchPayloadInnerObject[["tracking_link"]] <-
          self$`tracking_link`
      }
      if (!is.null(self$`shipment_provider`)) {
        OrderShipmentAddBatchPayloadInnerObject[["shipment_provider"]] <-
          self$`shipment_provider`
      }
      if (!is.null(self$`items`)) {
        OrderShipmentAddBatchPayloadInnerObject[["items"]] <-
          lapply(self$`items`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`send_notifications`)) {
        OrderShipmentAddBatchPayloadInnerObject[["send_notifications"]] <-
          self$`send_notifications`
      }
      return(OrderShipmentAddBatchPayloadInnerObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderShipmentAddBatchPayloadInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderShipmentAddBatchPayloadInner
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`order_id`)) {
        self$`order_id` <- this_object$`order_id`
      }
      if (!is.null(this_object$`store_id`)) {
        self$`store_id` <- this_object$`store_id`
      }
      if (!is.null(this_object$`warehouse_id`)) {
        self$`warehouse_id` <- this_object$`warehouse_id`
      }
      if (!is.null(this_object$`carrier_id`)) {
        self$`carrier_id` <- this_object$`carrier_id`
      }
      if (!is.null(this_object$`carrier_name`)) {
        self$`carrier_name` <- this_object$`carrier_name`
      }
      if (!is.null(this_object$`tracking_number`)) {
        self$`tracking_number` <- this_object$`tracking_number`
      }
      if (!is.null(this_object$`tracking_link`)) {
        self$`tracking_link` <- this_object$`tracking_link`
      }
      if (!is.null(this_object$`shipment_provider`)) {
        self$`shipment_provider` <- this_object$`shipment_provider`
      }
      if (!is.null(this_object$`items`)) {
        self$`items` <- ApiClient$new()$deserializeObj(this_object$`items`, "array[OrderShipmentAddBatchPayloadInnerItemsInner]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`send_notifications`)) {
        self$`send_notifications` <- this_object$`send_notifications`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return OrderShipmentAddBatchPayloadInner in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderShipmentAddBatchPayloadInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderShipmentAddBatchPayloadInner
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`order_id` <- this_object$`order_id`
      self$`store_id` <- this_object$`store_id`
      self$`warehouse_id` <- this_object$`warehouse_id`
      self$`carrier_id` <- this_object$`carrier_id`
      self$`carrier_name` <- this_object$`carrier_name`
      self$`tracking_number` <- this_object$`tracking_number`
      self$`tracking_link` <- this_object$`tracking_link`
      self$`shipment_provider` <- this_object$`shipment_provider`
      self$`items` <- ApiClient$new()$deserializeObj(this_object$`items`, "array[OrderShipmentAddBatchPayloadInnerItemsInner]", loadNamespace("openapi"))
      self$`send_notifications` <- this_object$`send_notifications`
      self
    },

    #' @description
    #' Validate JSON input with respect to OrderShipmentAddBatchPayloadInner and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
      # check the required field `order_id`
      if (!is.null(input_json$`order_id`)) {
        if (!(is.character(input_json$`order_id`) && length(input_json$`order_id`) == 1)) {
          stop(paste("Error! Invalid data for `order_id`. Must be a string:", input_json$`order_id`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for OrderShipmentAddBatchPayloadInner: the required field `order_id` is missing."))
      }
      # check the required field `tracking_number`
      if (!is.null(input_json$`tracking_number`)) {
        if (!(is.character(input_json$`tracking_number`) && length(input_json$`tracking_number`) == 1)) {
          stop(paste("Error! Invalid data for `tracking_number`. Must be a string:", input_json$`tracking_number`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for OrderShipmentAddBatchPayloadInner: the required field `tracking_number` is missing."))
      }
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of OrderShipmentAddBatchPayloadInner
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      # check if the required `order_id` is null
      if (is.null(self$`order_id`)) {
        return(FALSE)
      }

      # check if the required `tracking_number` is null
      if (is.null(self$`tracking_number`)) {
        return(FALSE)
      }

      if (length(self$`items`) < 1) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      # check if the required `order_id` is null
      if (is.null(self$`order_id`)) {
        invalid_fields["order_id"] <- "Non-nullable required field `order_id` cannot be null."
      }

      # check if the required `tracking_number` is null
      if (is.null(self$`tracking_number`)) {
        invalid_fields["tracking_number"] <- "Non-nullable required field `tracking_number` cannot be null."
      }

      if (length(self$`items`) < 1) {
        invalid_fields["items"] <- "Invalid length for ``, number of items must be greater than or equal to 1."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# OrderShipmentAddBatchPayloadInner$unlock()
#
## Below is an example to define the print function
# OrderShipmentAddBatchPayloadInner$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# OrderShipmentAddBatchPayloadInner$lock()

