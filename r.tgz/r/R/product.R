#' Create a new Product
#'
#' @description
#' Product Class
#'
#' @docType class
#' @title Product
#' @description Product Class
#' @format An \code{R6Class} generator object
#' @field id  character [optional]
#' @field type  character [optional]
#' @field u_model  character [optional]
#' @field u_sku  character [optional]
#' @field name  character [optional]
#' @field description  character [optional]
#' @field short_description  character [optional]
#' @field price  numeric [optional]
#' @field advanced_price  list(\link{ProductAdvancedPrice}) [optional]
#' @field cost_price  numeric [optional]
#' @field unit_price  numeric [optional]
#' @field measure_unit  character [optional]
#' @field quantity  numeric [optional]
#' @field inventory  list(\link{ProductInventory}) [optional]
#' @field group_items  list(\link{ProductGroupItem}) [optional]
#' @field u_brand_id  character [optional]
#' @field u_brand  character [optional]
#' @field categories_ids  list(character) [optional]
#' @field stores_ids  list(character) [optional]
#' @field url  character [optional]
#' @field seo_url  character [optional]
#' @field meta_title  character [optional]
#' @field meta_keywords  character [optional]
#' @field meta_description  character [optional]
#' @field avail_sale  character [optional]
#' @field avail_view  character [optional]
#' @field is_virtual  character [optional]
#' @field is_downloadable  character [optional]
#' @field weight  numeric [optional]
#' @field weight_unit  character [optional]
#' @field sort_order  integer [optional]
#' @field in_stock  character [optional]
#' @field backorders  character [optional]
#' @field manage_stock  character [optional]
#' @field is_stock_managed  character [optional]
#' @field on_sale  character [optional]
#' @field create_at  \link{A2CDateTime} [optional]
#' @field modified_at  \link{A2CDateTime} [optional]
#' @field tax_class_id  character [optional]
#' @field special_price  \link{SpecialPrice} [optional]
#' @field tier_price  list(\link{ProductTierPrice}) [optional]
#' @field group_price  list(\link{ProductGroupPrice}) [optional]
#' @field images  list(\link{Image}) [optional]
#' @field product_options  list(\link{ProductOption}) [optional]
#' @field u_upc  character [optional]
#' @field u_mpn  character [optional]
#' @field u_gtin  character [optional]
#' @field u_isbn  character [optional]
#' @field u_ean  character [optional]
#' @field related_products_ids  list(character) [optional]
#' @field up_sell_products_ids  list(character) [optional]
#' @field cross_sell_products_ids  list(character) [optional]
#' @field dimensions_unit  character [optional]
#' @field width  numeric [optional]
#' @field height  numeric [optional]
#' @field length  numeric [optional]
#' @field discounts  list(\link{Discount}) [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
Product <- R6::R6Class(
  "Product",
  public = list(
    `id` = NULL,
    `type` = NULL,
    `u_model` = NULL,
    `u_sku` = NULL,
    `name` = NULL,
    `description` = NULL,
    `short_description` = NULL,
    `price` = NULL,
    `advanced_price` = NULL,
    `cost_price` = NULL,
    `unit_price` = NULL,
    `measure_unit` = NULL,
    `quantity` = NULL,
    `inventory` = NULL,
    `group_items` = NULL,
    `u_brand_id` = NULL,
    `u_brand` = NULL,
    `categories_ids` = NULL,
    `stores_ids` = NULL,
    `url` = NULL,
    `seo_url` = NULL,
    `meta_title` = NULL,
    `meta_keywords` = NULL,
    `meta_description` = NULL,
    `avail_sale` = NULL,
    `avail_view` = NULL,
    `is_virtual` = NULL,
    `is_downloadable` = NULL,
    `weight` = NULL,
    `weight_unit` = NULL,
    `sort_order` = NULL,
    `in_stock` = NULL,
    `backorders` = NULL,
    `manage_stock` = NULL,
    `is_stock_managed` = NULL,
    `on_sale` = NULL,
    `create_at` = NULL,
    `modified_at` = NULL,
    `tax_class_id` = NULL,
    `special_price` = NULL,
    `tier_price` = NULL,
    `group_price` = NULL,
    `images` = NULL,
    `product_options` = NULL,
    `u_upc` = NULL,
    `u_mpn` = NULL,
    `u_gtin` = NULL,
    `u_isbn` = NULL,
    `u_ean` = NULL,
    `related_products_ids` = NULL,
    `up_sell_products_ids` = NULL,
    `cross_sell_products_ids` = NULL,
    `dimensions_unit` = NULL,
    `width` = NULL,
    `height` = NULL,
    `length` = NULL,
    `discounts` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new Product class.
    #'
    #' @param id id
    #' @param type type
    #' @param u_model u_model
    #' @param u_sku u_sku
    #' @param name name
    #' @param description description
    #' @param short_description short_description
    #' @param price price
    #' @param advanced_price advanced_price
    #' @param cost_price cost_price
    #' @param unit_price unit_price
    #' @param measure_unit measure_unit
    #' @param quantity quantity
    #' @param inventory inventory
    #' @param group_items group_items
    #' @param u_brand_id u_brand_id
    #' @param u_brand u_brand
    #' @param categories_ids categories_ids
    #' @param stores_ids stores_ids
    #' @param url url
    #' @param seo_url seo_url
    #' @param meta_title meta_title
    #' @param meta_keywords meta_keywords
    #' @param meta_description meta_description
    #' @param avail_sale avail_sale
    #' @param avail_view avail_view
    #' @param is_virtual is_virtual
    #' @param is_downloadable is_downloadable
    #' @param weight weight
    #' @param weight_unit weight_unit
    #' @param sort_order sort_order
    #' @param in_stock in_stock
    #' @param backorders backorders
    #' @param manage_stock manage_stock
    #' @param is_stock_managed is_stock_managed
    #' @param on_sale on_sale
    #' @param create_at create_at
    #' @param modified_at modified_at
    #' @param tax_class_id tax_class_id
    #' @param special_price special_price
    #' @param tier_price tier_price
    #' @param group_price group_price
    #' @param images images
    #' @param product_options product_options
    #' @param u_upc u_upc
    #' @param u_mpn u_mpn
    #' @param u_gtin u_gtin
    #' @param u_isbn u_isbn
    #' @param u_ean u_ean
    #' @param related_products_ids related_products_ids
    #' @param up_sell_products_ids up_sell_products_ids
    #' @param cross_sell_products_ids cross_sell_products_ids
    #' @param dimensions_unit dimensions_unit
    #' @param width width
    #' @param height height
    #' @param length length
    #' @param discounts discounts
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `type` = NULL, `u_model` = NULL, `u_sku` = NULL, `name` = NULL, `description` = NULL, `short_description` = NULL, `price` = NULL, `advanced_price` = NULL, `cost_price` = NULL, `unit_price` = NULL, `measure_unit` = NULL, `quantity` = NULL, `inventory` = NULL, `group_items` = NULL, `u_brand_id` = NULL, `u_brand` = NULL, `categories_ids` = NULL, `stores_ids` = NULL, `url` = NULL, `seo_url` = NULL, `meta_title` = NULL, `meta_keywords` = NULL, `meta_description` = NULL, `avail_sale` = NULL, `avail_view` = NULL, `is_virtual` = NULL, `is_downloadable` = NULL, `weight` = NULL, `weight_unit` = NULL, `sort_order` = NULL, `in_stock` = NULL, `backorders` = NULL, `manage_stock` = NULL, `is_stock_managed` = NULL, `on_sale` = NULL, `create_at` = NULL, `modified_at` = NULL, `tax_class_id` = NULL, `special_price` = NULL, `tier_price` = NULL, `group_price` = NULL, `images` = NULL, `product_options` = NULL, `u_upc` = NULL, `u_mpn` = NULL, `u_gtin` = NULL, `u_isbn` = NULL, `u_ean` = NULL, `related_products_ids` = NULL, `up_sell_products_ids` = NULL, `cross_sell_products_ids` = NULL, `dimensions_unit` = NULL, `width` = NULL, `height` = NULL, `length` = NULL, `discounts` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`type`)) {
        if (!(is.character(`type`) && length(`type`) == 1)) {
          stop(paste("Error! Invalid data for `type`. Must be a string:", `type`))
        }
        self$`type` <- `type`
      }
      if (!is.null(`u_model`)) {
        if (!(is.character(`u_model`) && length(`u_model`) == 1)) {
          stop(paste("Error! Invalid data for `u_model`. Must be a string:", `u_model`))
        }
        self$`u_model` <- `u_model`
      }
      if (!is.null(`u_sku`)) {
        if (!(is.character(`u_sku`) && length(`u_sku`) == 1)) {
          stop(paste("Error! Invalid data for `u_sku`. Must be a string:", `u_sku`))
        }
        self$`u_sku` <- `u_sku`
      }
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`description`)) {
        if (!(is.character(`description`) && length(`description`) == 1)) {
          stop(paste("Error! Invalid data for `description`. Must be a string:", `description`))
        }
        self$`description` <- `description`
      }
      if (!is.null(`short_description`)) {
        if (!(is.character(`short_description`) && length(`short_description`) == 1)) {
          stop(paste("Error! Invalid data for `short_description`. Must be a string:", `short_description`))
        }
        self$`short_description` <- `short_description`
      }
      if (!is.null(`price`)) {
        self$`price` <- `price`
      }
      if (!is.null(`advanced_price`)) {
        stopifnot(is.vector(`advanced_price`), length(`advanced_price`) != 0)
        sapply(`advanced_price`, function(x) stopifnot(R6::is.R6(x)))
        self$`advanced_price` <- `advanced_price`
      }
      if (!is.null(`cost_price`)) {
        self$`cost_price` <- `cost_price`
      }
      if (!is.null(`unit_price`)) {
        self$`unit_price` <- `unit_price`
      }
      if (!is.null(`measure_unit`)) {
        if (!(is.character(`measure_unit`) && length(`measure_unit`) == 1)) {
          stop(paste("Error! Invalid data for `measure_unit`. Must be a string:", `measure_unit`))
        }
        self$`measure_unit` <- `measure_unit`
      }
      if (!is.null(`quantity`)) {
        self$`quantity` <- `quantity`
      }
      if (!is.null(`inventory`)) {
        stopifnot(is.vector(`inventory`), length(`inventory`) != 0)
        sapply(`inventory`, function(x) stopifnot(R6::is.R6(x)))
        self$`inventory` <- `inventory`
      }
      if (!is.null(`group_items`)) {
        stopifnot(is.vector(`group_items`), length(`group_items`) != 0)
        sapply(`group_items`, function(x) stopifnot(R6::is.R6(x)))
        self$`group_items` <- `group_items`
      }
      if (!is.null(`u_brand_id`)) {
        if (!(is.character(`u_brand_id`) && length(`u_brand_id`) == 1)) {
          stop(paste("Error! Invalid data for `u_brand_id`. Must be a string:", `u_brand_id`))
        }
        self$`u_brand_id` <- `u_brand_id`
      }
      if (!is.null(`u_brand`)) {
        if (!(is.character(`u_brand`) && length(`u_brand`) == 1)) {
          stop(paste("Error! Invalid data for `u_brand`. Must be a string:", `u_brand`))
        }
        self$`u_brand` <- `u_brand`
      }
      if (!is.null(`categories_ids`)) {
        stopifnot(is.vector(`categories_ids`), length(`categories_ids`) != 0)
        sapply(`categories_ids`, function(x) stopifnot(is.character(x)))
        self$`categories_ids` <- `categories_ids`
      }
      if (!is.null(`stores_ids`)) {
        stopifnot(is.vector(`stores_ids`), length(`stores_ids`) != 0)
        sapply(`stores_ids`, function(x) stopifnot(is.character(x)))
        self$`stores_ids` <- `stores_ids`
      }
      if (!is.null(`url`)) {
        if (!(is.character(`url`) && length(`url`) == 1)) {
          stop(paste("Error! Invalid data for `url`. Must be a string:", `url`))
        }
        self$`url` <- `url`
      }
      if (!is.null(`seo_url`)) {
        if (!(is.character(`seo_url`) && length(`seo_url`) == 1)) {
          stop(paste("Error! Invalid data for `seo_url`. Must be a string:", `seo_url`))
        }
        self$`seo_url` <- `seo_url`
      }
      if (!is.null(`meta_title`)) {
        if (!(is.character(`meta_title`) && length(`meta_title`) == 1)) {
          stop(paste("Error! Invalid data for `meta_title`. Must be a string:", `meta_title`))
        }
        self$`meta_title` <- `meta_title`
      }
      if (!is.null(`meta_keywords`)) {
        if (!(is.character(`meta_keywords`) && length(`meta_keywords`) == 1)) {
          stop(paste("Error! Invalid data for `meta_keywords`. Must be a string:", `meta_keywords`))
        }
        self$`meta_keywords` <- `meta_keywords`
      }
      if (!is.null(`meta_description`)) {
        if (!(is.character(`meta_description`) && length(`meta_description`) == 1)) {
          stop(paste("Error! Invalid data for `meta_description`. Must be a string:", `meta_description`))
        }
        self$`meta_description` <- `meta_description`
      }
      if (!is.null(`avail_sale`)) {
        if (!(is.logical(`avail_sale`) && length(`avail_sale`) == 1)) {
          stop(paste("Error! Invalid data for `avail_sale`. Must be a boolean:", `avail_sale`))
        }
        self$`avail_sale` <- `avail_sale`
      }
      if (!is.null(`avail_view`)) {
        if (!(is.logical(`avail_view`) && length(`avail_view`) == 1)) {
          stop(paste("Error! Invalid data for `avail_view`. Must be a boolean:", `avail_view`))
        }
        self$`avail_view` <- `avail_view`
      }
      if (!is.null(`is_virtual`)) {
        if (!(is.logical(`is_virtual`) && length(`is_virtual`) == 1)) {
          stop(paste("Error! Invalid data for `is_virtual`. Must be a boolean:", `is_virtual`))
        }
        self$`is_virtual` <- `is_virtual`
      }
      if (!is.null(`is_downloadable`)) {
        if (!(is.logical(`is_downloadable`) && length(`is_downloadable`) == 1)) {
          stop(paste("Error! Invalid data for `is_downloadable`. Must be a boolean:", `is_downloadable`))
        }
        self$`is_downloadable` <- `is_downloadable`
      }
      if (!is.null(`weight`)) {
        self$`weight` <- `weight`
      }
      if (!is.null(`weight_unit`)) {
        if (!(is.character(`weight_unit`) && length(`weight_unit`) == 1)) {
          stop(paste("Error! Invalid data for `weight_unit`. Must be a string:", `weight_unit`))
        }
        self$`weight_unit` <- `weight_unit`
      }
      if (!is.null(`sort_order`)) {
        if (!(is.numeric(`sort_order`) && length(`sort_order`) == 1)) {
          stop(paste("Error! Invalid data for `sort_order`. Must be an integer:", `sort_order`))
        }
        self$`sort_order` <- `sort_order`
      }
      if (!is.null(`in_stock`)) {
        if (!(is.logical(`in_stock`) && length(`in_stock`) == 1)) {
          stop(paste("Error! Invalid data for `in_stock`. Must be a boolean:", `in_stock`))
        }
        self$`in_stock` <- `in_stock`
      }
      if (!is.null(`backorders`)) {
        if (!(is.character(`backorders`) && length(`backorders`) == 1)) {
          stop(paste("Error! Invalid data for `backorders`. Must be a string:", `backorders`))
        }
        self$`backorders` <- `backorders`
      }
      if (!is.null(`manage_stock`)) {
        if (!(is.character(`manage_stock`) && length(`manage_stock`) == 1)) {
          stop(paste("Error! Invalid data for `manage_stock`. Must be a string:", `manage_stock`))
        }
        self$`manage_stock` <- `manage_stock`
      }
      if (!is.null(`is_stock_managed`)) {
        if (!(is.logical(`is_stock_managed`) && length(`is_stock_managed`) == 1)) {
          stop(paste("Error! Invalid data for `is_stock_managed`. Must be a boolean:", `is_stock_managed`))
        }
        self$`is_stock_managed` <- `is_stock_managed`
      }
      if (!is.null(`on_sale`)) {
        if (!(is.logical(`on_sale`) && length(`on_sale`) == 1)) {
          stop(paste("Error! Invalid data for `on_sale`. Must be a boolean:", `on_sale`))
        }
        self$`on_sale` <- `on_sale`
      }
      if (!is.null(`create_at`)) {
        stopifnot(R6::is.R6(`create_at`))
        self$`create_at` <- `create_at`
      }
      if (!is.null(`modified_at`)) {
        stopifnot(R6::is.R6(`modified_at`))
        self$`modified_at` <- `modified_at`
      }
      if (!is.null(`tax_class_id`)) {
        if (!(is.character(`tax_class_id`) && length(`tax_class_id`) == 1)) {
          stop(paste("Error! Invalid data for `tax_class_id`. Must be a string:", `tax_class_id`))
        }
        self$`tax_class_id` <- `tax_class_id`
      }
      if (!is.null(`special_price`)) {
        stopifnot(R6::is.R6(`special_price`))
        self$`special_price` <- `special_price`
      }
      if (!is.null(`tier_price`)) {
        stopifnot(is.vector(`tier_price`), length(`tier_price`) != 0)
        sapply(`tier_price`, function(x) stopifnot(R6::is.R6(x)))
        self$`tier_price` <- `tier_price`
      }
      if (!is.null(`group_price`)) {
        stopifnot(is.vector(`group_price`), length(`group_price`) != 0)
        sapply(`group_price`, function(x) stopifnot(R6::is.R6(x)))
        self$`group_price` <- `group_price`
      }
      if (!is.null(`images`)) {
        stopifnot(is.vector(`images`), length(`images`) != 0)
        sapply(`images`, function(x) stopifnot(R6::is.R6(x)))
        self$`images` <- `images`
      }
      if (!is.null(`product_options`)) {
        stopifnot(is.vector(`product_options`), length(`product_options`) != 0)
        sapply(`product_options`, function(x) stopifnot(R6::is.R6(x)))
        self$`product_options` <- `product_options`
      }
      if (!is.null(`u_upc`)) {
        if (!(is.character(`u_upc`) && length(`u_upc`) == 1)) {
          stop(paste("Error! Invalid data for `u_upc`. Must be a string:", `u_upc`))
        }
        self$`u_upc` <- `u_upc`
      }
      if (!is.null(`u_mpn`)) {
        if (!(is.character(`u_mpn`) && length(`u_mpn`) == 1)) {
          stop(paste("Error! Invalid data for `u_mpn`. Must be a string:", `u_mpn`))
        }
        self$`u_mpn` <- `u_mpn`
      }
      if (!is.null(`u_gtin`)) {
        if (!(is.character(`u_gtin`) && length(`u_gtin`) == 1)) {
          stop(paste("Error! Invalid data for `u_gtin`. Must be a string:", `u_gtin`))
        }
        self$`u_gtin` <- `u_gtin`
      }
      if (!is.null(`u_isbn`)) {
        if (!(is.character(`u_isbn`) && length(`u_isbn`) == 1)) {
          stop(paste("Error! Invalid data for `u_isbn`. Must be a string:", `u_isbn`))
        }
        self$`u_isbn` <- `u_isbn`
      }
      if (!is.null(`u_ean`)) {
        if (!(is.character(`u_ean`) && length(`u_ean`) == 1)) {
          stop(paste("Error! Invalid data for `u_ean`. Must be a string:", `u_ean`))
        }
        self$`u_ean` <- `u_ean`
      }
      if (!is.null(`related_products_ids`)) {
        stopifnot(is.vector(`related_products_ids`), length(`related_products_ids`) != 0)
        sapply(`related_products_ids`, function(x) stopifnot(is.character(x)))
        self$`related_products_ids` <- `related_products_ids`
      }
      if (!is.null(`up_sell_products_ids`)) {
        stopifnot(is.vector(`up_sell_products_ids`), length(`up_sell_products_ids`) != 0)
        sapply(`up_sell_products_ids`, function(x) stopifnot(is.character(x)))
        self$`up_sell_products_ids` <- `up_sell_products_ids`
      }
      if (!is.null(`cross_sell_products_ids`)) {
        stopifnot(is.vector(`cross_sell_products_ids`), length(`cross_sell_products_ids`) != 0)
        sapply(`cross_sell_products_ids`, function(x) stopifnot(is.character(x)))
        self$`cross_sell_products_ids` <- `cross_sell_products_ids`
      }
      if (!is.null(`dimensions_unit`)) {
        if (!(is.character(`dimensions_unit`) && length(`dimensions_unit`) == 1)) {
          stop(paste("Error! Invalid data for `dimensions_unit`. Must be a string:", `dimensions_unit`))
        }
        self$`dimensions_unit` <- `dimensions_unit`
      }
      if (!is.null(`width`)) {
        self$`width` <- `width`
      }
      if (!is.null(`height`)) {
        self$`height` <- `height`
      }
      if (!is.null(`length`)) {
        self$`length` <- `length`
      }
      if (!is.null(`discounts`)) {
        stopifnot(is.vector(`discounts`), length(`discounts`) != 0)
        sapply(`discounts`, function(x) stopifnot(R6::is.R6(x)))
        self$`discounts` <- `discounts`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return Product as a base R list.
    #' @examples
    #' # convert array of Product (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert Product to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductObject <- list()
      if (!is.null(self$`id`)) {
        ProductObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`type`)) {
        ProductObject[["type"]] <-
          self$`type`
      }
      if (!is.null(self$`u_model`)) {
        ProductObject[["u_model"]] <-
          self$`u_model`
      }
      if (!is.null(self$`u_sku`)) {
        ProductObject[["u_sku"]] <-
          self$`u_sku`
      }
      if (!is.null(self$`name`)) {
        ProductObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`description`)) {
        ProductObject[["description"]] <-
          self$`description`
      }
      if (!is.null(self$`short_description`)) {
        ProductObject[["short_description"]] <-
          self$`short_description`
      }
      if (!is.null(self$`price`)) {
        ProductObject[["price"]] <-
          self$`price`
      }
      if (!is.null(self$`advanced_price`)) {
        ProductObject[["advanced_price"]] <-
          lapply(self$`advanced_price`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`cost_price`)) {
        ProductObject[["cost_price"]] <-
          self$`cost_price`
      }
      if (!is.null(self$`unit_price`)) {
        ProductObject[["unit_price"]] <-
          self$`unit_price`
      }
      if (!is.null(self$`measure_unit`)) {
        ProductObject[["measure_unit"]] <-
          self$`measure_unit`
      }
      if (!is.null(self$`quantity`)) {
        ProductObject[["quantity"]] <-
          self$`quantity`
      }
      if (!is.null(self$`inventory`)) {
        ProductObject[["inventory"]] <-
          lapply(self$`inventory`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`group_items`)) {
        ProductObject[["group_items"]] <-
          lapply(self$`group_items`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`u_brand_id`)) {
        ProductObject[["u_brand_id"]] <-
          self$`u_brand_id`
      }
      if (!is.null(self$`u_brand`)) {
        ProductObject[["u_brand"]] <-
          self$`u_brand`
      }
      if (!is.null(self$`categories_ids`)) {
        ProductObject[["categories_ids"]] <-
          self$`categories_ids`
      }
      if (!is.null(self$`stores_ids`)) {
        ProductObject[["stores_ids"]] <-
          self$`stores_ids`
      }
      if (!is.null(self$`url`)) {
        ProductObject[["url"]] <-
          self$`url`
      }
      if (!is.null(self$`seo_url`)) {
        ProductObject[["seo_url"]] <-
          self$`seo_url`
      }
      if (!is.null(self$`meta_title`)) {
        ProductObject[["meta_title"]] <-
          self$`meta_title`
      }
      if (!is.null(self$`meta_keywords`)) {
        ProductObject[["meta_keywords"]] <-
          self$`meta_keywords`
      }
      if (!is.null(self$`meta_description`)) {
        ProductObject[["meta_description"]] <-
          self$`meta_description`
      }
      if (!is.null(self$`avail_sale`)) {
        ProductObject[["avail_sale"]] <-
          self$`avail_sale`
      }
      if (!is.null(self$`avail_view`)) {
        ProductObject[["avail_view"]] <-
          self$`avail_view`
      }
      if (!is.null(self$`is_virtual`)) {
        ProductObject[["is_virtual"]] <-
          self$`is_virtual`
      }
      if (!is.null(self$`is_downloadable`)) {
        ProductObject[["is_downloadable"]] <-
          self$`is_downloadable`
      }
      if (!is.null(self$`weight`)) {
        ProductObject[["weight"]] <-
          self$`weight`
      }
      if (!is.null(self$`weight_unit`)) {
        ProductObject[["weight_unit"]] <-
          self$`weight_unit`
      }
      if (!is.null(self$`sort_order`)) {
        ProductObject[["sort_order"]] <-
          self$`sort_order`
      }
      if (!is.null(self$`in_stock`)) {
        ProductObject[["in_stock"]] <-
          self$`in_stock`
      }
      if (!is.null(self$`backorders`)) {
        ProductObject[["backorders"]] <-
          self$`backorders`
      }
      if (!is.null(self$`manage_stock`)) {
        ProductObject[["manage_stock"]] <-
          self$`manage_stock`
      }
      if (!is.null(self$`is_stock_managed`)) {
        ProductObject[["is_stock_managed"]] <-
          self$`is_stock_managed`
      }
      if (!is.null(self$`on_sale`)) {
        ProductObject[["on_sale"]] <-
          self$`on_sale`
      }
      if (!is.null(self$`create_at`)) {
        ProductObject[["create_at"]] <-
          self$`create_at`$toSimpleType()
      }
      if (!is.null(self$`modified_at`)) {
        ProductObject[["modified_at"]] <-
          self$`modified_at`$toSimpleType()
      }
      if (!is.null(self$`tax_class_id`)) {
        ProductObject[["tax_class_id"]] <-
          self$`tax_class_id`
      }
      if (!is.null(self$`special_price`)) {
        ProductObject[["special_price"]] <-
          self$`special_price`$toSimpleType()
      }
      if (!is.null(self$`tier_price`)) {
        ProductObject[["tier_price"]] <-
          lapply(self$`tier_price`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`group_price`)) {
        ProductObject[["group_price"]] <-
          lapply(self$`group_price`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`images`)) {
        ProductObject[["images"]] <-
          lapply(self$`images`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`product_options`)) {
        ProductObject[["product_options"]] <-
          lapply(self$`product_options`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`u_upc`)) {
        ProductObject[["u_upc"]] <-
          self$`u_upc`
      }
      if (!is.null(self$`u_mpn`)) {
        ProductObject[["u_mpn"]] <-
          self$`u_mpn`
      }
      if (!is.null(self$`u_gtin`)) {
        ProductObject[["u_gtin"]] <-
          self$`u_gtin`
      }
      if (!is.null(self$`u_isbn`)) {
        ProductObject[["u_isbn"]] <-
          self$`u_isbn`
      }
      if (!is.null(self$`u_ean`)) {
        ProductObject[["u_ean"]] <-
          self$`u_ean`
      }
      if (!is.null(self$`related_products_ids`)) {
        ProductObject[["related_products_ids"]] <-
          self$`related_products_ids`
      }
      if (!is.null(self$`up_sell_products_ids`)) {
        ProductObject[["up_sell_products_ids"]] <-
          self$`up_sell_products_ids`
      }
      if (!is.null(self$`cross_sell_products_ids`)) {
        ProductObject[["cross_sell_products_ids"]] <-
          self$`cross_sell_products_ids`
      }
      if (!is.null(self$`dimensions_unit`)) {
        ProductObject[["dimensions_unit"]] <-
          self$`dimensions_unit`
      }
      if (!is.null(self$`width`)) {
        ProductObject[["width"]] <-
          self$`width`
      }
      if (!is.null(self$`height`)) {
        ProductObject[["height"]] <-
          self$`height`
      }
      if (!is.null(self$`length`)) {
        ProductObject[["length"]] <-
          self$`length`
      }
      if (!is.null(self$`discounts`)) {
        ProductObject[["discounts"]] <-
          lapply(self$`discounts`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`additional_fields`)) {
        ProductObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        ProductObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(ProductObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of Product
    #'
    #' @param input_json the JSON input
    #' @return the instance of Product
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`type`)) {
        self$`type` <- this_object$`type`
      }
      if (!is.null(this_object$`u_model`)) {
        self$`u_model` <- this_object$`u_model`
      }
      if (!is.null(this_object$`u_sku`)) {
        self$`u_sku` <- this_object$`u_sku`
      }
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`description`)) {
        self$`description` <- this_object$`description`
      }
      if (!is.null(this_object$`short_description`)) {
        self$`short_description` <- this_object$`short_description`
      }
      if (!is.null(this_object$`price`)) {
        self$`price` <- this_object$`price`
      }
      if (!is.null(this_object$`advanced_price`)) {
        self$`advanced_price` <- ApiClient$new()$deserializeObj(this_object$`advanced_price`, "array[ProductAdvancedPrice]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`cost_price`)) {
        self$`cost_price` <- this_object$`cost_price`
      }
      if (!is.null(this_object$`unit_price`)) {
        self$`unit_price` <- this_object$`unit_price`
      }
      if (!is.null(this_object$`measure_unit`)) {
        self$`measure_unit` <- this_object$`measure_unit`
      }
      if (!is.null(this_object$`quantity`)) {
        self$`quantity` <- this_object$`quantity`
      }
      if (!is.null(this_object$`inventory`)) {
        self$`inventory` <- ApiClient$new()$deserializeObj(this_object$`inventory`, "array[ProductInventory]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`group_items`)) {
        self$`group_items` <- ApiClient$new()$deserializeObj(this_object$`group_items`, "array[ProductGroupItem]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`u_brand_id`)) {
        self$`u_brand_id` <- this_object$`u_brand_id`
      }
      if (!is.null(this_object$`u_brand`)) {
        self$`u_brand` <- this_object$`u_brand`
      }
      if (!is.null(this_object$`categories_ids`)) {
        self$`categories_ids` <- ApiClient$new()$deserializeObj(this_object$`categories_ids`, "array[character]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`stores_ids`)) {
        self$`stores_ids` <- ApiClient$new()$deserializeObj(this_object$`stores_ids`, "array[character]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`url`)) {
        self$`url` <- this_object$`url`
      }
      if (!is.null(this_object$`seo_url`)) {
        self$`seo_url` <- this_object$`seo_url`
      }
      if (!is.null(this_object$`meta_title`)) {
        self$`meta_title` <- this_object$`meta_title`
      }
      if (!is.null(this_object$`meta_keywords`)) {
        self$`meta_keywords` <- this_object$`meta_keywords`
      }
      if (!is.null(this_object$`meta_description`)) {
        self$`meta_description` <- this_object$`meta_description`
      }
      if (!is.null(this_object$`avail_sale`)) {
        self$`avail_sale` <- this_object$`avail_sale`
      }
      if (!is.null(this_object$`avail_view`)) {
        self$`avail_view` <- this_object$`avail_view`
      }
      if (!is.null(this_object$`is_virtual`)) {
        self$`is_virtual` <- this_object$`is_virtual`
      }
      if (!is.null(this_object$`is_downloadable`)) {
        self$`is_downloadable` <- this_object$`is_downloadable`
      }
      if (!is.null(this_object$`weight`)) {
        self$`weight` <- this_object$`weight`
      }
      if (!is.null(this_object$`weight_unit`)) {
        self$`weight_unit` <- this_object$`weight_unit`
      }
      if (!is.null(this_object$`sort_order`)) {
        self$`sort_order` <- this_object$`sort_order`
      }
      if (!is.null(this_object$`in_stock`)) {
        self$`in_stock` <- this_object$`in_stock`
      }
      if (!is.null(this_object$`backorders`)) {
        self$`backorders` <- this_object$`backorders`
      }
      if (!is.null(this_object$`manage_stock`)) {
        self$`manage_stock` <- this_object$`manage_stock`
      }
      if (!is.null(this_object$`is_stock_managed`)) {
        self$`is_stock_managed` <- this_object$`is_stock_managed`
      }
      if (!is.null(this_object$`on_sale`)) {
        self$`on_sale` <- this_object$`on_sale`
      }
      if (!is.null(this_object$`create_at`)) {
        `create_at_object` <- A2CDateTime$new()
        `create_at_object`$fromJSON(jsonlite::toJSON(this_object$`create_at`, auto_unbox = TRUE, digits = NA))
        self$`create_at` <- `create_at_object`
      }
      if (!is.null(this_object$`modified_at`)) {
        `modified_at_object` <- A2CDateTime$new()
        `modified_at_object`$fromJSON(jsonlite::toJSON(this_object$`modified_at`, auto_unbox = TRUE, digits = NA))
        self$`modified_at` <- `modified_at_object`
      }
      if (!is.null(this_object$`tax_class_id`)) {
        self$`tax_class_id` <- this_object$`tax_class_id`
      }
      if (!is.null(this_object$`special_price`)) {
        `special_price_object` <- SpecialPrice$new()
        `special_price_object`$fromJSON(jsonlite::toJSON(this_object$`special_price`, auto_unbox = TRUE, digits = NA))
        self$`special_price` <- `special_price_object`
      }
      if (!is.null(this_object$`tier_price`)) {
        self$`tier_price` <- ApiClient$new()$deserializeObj(this_object$`tier_price`, "array[ProductTierPrice]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`group_price`)) {
        self$`group_price` <- ApiClient$new()$deserializeObj(this_object$`group_price`, "array[ProductGroupPrice]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`images`)) {
        self$`images` <- ApiClient$new()$deserializeObj(this_object$`images`, "array[Image]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`product_options`)) {
        self$`product_options` <- ApiClient$new()$deserializeObj(this_object$`product_options`, "array[ProductOption]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`u_upc`)) {
        self$`u_upc` <- this_object$`u_upc`
      }
      if (!is.null(this_object$`u_mpn`)) {
        self$`u_mpn` <- this_object$`u_mpn`
      }
      if (!is.null(this_object$`u_gtin`)) {
        self$`u_gtin` <- this_object$`u_gtin`
      }
      if (!is.null(this_object$`u_isbn`)) {
        self$`u_isbn` <- this_object$`u_isbn`
      }
      if (!is.null(this_object$`u_ean`)) {
        self$`u_ean` <- this_object$`u_ean`
      }
      if (!is.null(this_object$`related_products_ids`)) {
        self$`related_products_ids` <- ApiClient$new()$deserializeObj(this_object$`related_products_ids`, "array[character]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`up_sell_products_ids`)) {
        self$`up_sell_products_ids` <- ApiClient$new()$deserializeObj(this_object$`up_sell_products_ids`, "array[character]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`cross_sell_products_ids`)) {
        self$`cross_sell_products_ids` <- ApiClient$new()$deserializeObj(this_object$`cross_sell_products_ids`, "array[character]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`dimensions_unit`)) {
        self$`dimensions_unit` <- this_object$`dimensions_unit`
      }
      if (!is.null(this_object$`width`)) {
        self$`width` <- this_object$`width`
      }
      if (!is.null(this_object$`height`)) {
        self$`height` <- this_object$`height`
      }
      if (!is.null(this_object$`length`)) {
        self$`length` <- this_object$`length`
      }
      if (!is.null(this_object$`discounts`)) {
        self$`discounts` <- ApiClient$new()$deserializeObj(this_object$`discounts`, "array[Discount]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return Product in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of Product
    #'
    #' @param input_json the JSON input
    #' @return the instance of Product
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`type` <- this_object$`type`
      self$`u_model` <- this_object$`u_model`
      self$`u_sku` <- this_object$`u_sku`
      self$`name` <- this_object$`name`
      self$`description` <- this_object$`description`
      self$`short_description` <- this_object$`short_description`
      self$`price` <- this_object$`price`
      self$`advanced_price` <- ApiClient$new()$deserializeObj(this_object$`advanced_price`, "array[ProductAdvancedPrice]", loadNamespace("openapi"))
      self$`cost_price` <- this_object$`cost_price`
      self$`unit_price` <- this_object$`unit_price`
      self$`measure_unit` <- this_object$`measure_unit`
      self$`quantity` <- this_object$`quantity`
      self$`inventory` <- ApiClient$new()$deserializeObj(this_object$`inventory`, "array[ProductInventory]", loadNamespace("openapi"))
      self$`group_items` <- ApiClient$new()$deserializeObj(this_object$`group_items`, "array[ProductGroupItem]", loadNamespace("openapi"))
      self$`u_brand_id` <- this_object$`u_brand_id`
      self$`u_brand` <- this_object$`u_brand`
      self$`categories_ids` <- ApiClient$new()$deserializeObj(this_object$`categories_ids`, "array[character]", loadNamespace("openapi"))
      self$`stores_ids` <- ApiClient$new()$deserializeObj(this_object$`stores_ids`, "array[character]", loadNamespace("openapi"))
      self$`url` <- this_object$`url`
      self$`seo_url` <- this_object$`seo_url`
      self$`meta_title` <- this_object$`meta_title`
      self$`meta_keywords` <- this_object$`meta_keywords`
      self$`meta_description` <- this_object$`meta_description`
      self$`avail_sale` <- this_object$`avail_sale`
      self$`avail_view` <- this_object$`avail_view`
      self$`is_virtual` <- this_object$`is_virtual`
      self$`is_downloadable` <- this_object$`is_downloadable`
      self$`weight` <- this_object$`weight`
      self$`weight_unit` <- this_object$`weight_unit`
      self$`sort_order` <- this_object$`sort_order`
      self$`in_stock` <- this_object$`in_stock`
      self$`backorders` <- this_object$`backorders`
      self$`manage_stock` <- this_object$`manage_stock`
      self$`is_stock_managed` <- this_object$`is_stock_managed`
      self$`on_sale` <- this_object$`on_sale`
      self$`create_at` <- A2CDateTime$new()$fromJSON(jsonlite::toJSON(this_object$`create_at`, auto_unbox = TRUE, digits = NA))
      self$`modified_at` <- A2CDateTime$new()$fromJSON(jsonlite::toJSON(this_object$`modified_at`, auto_unbox = TRUE, digits = NA))
      self$`tax_class_id` <- this_object$`tax_class_id`
      self$`special_price` <- SpecialPrice$new()$fromJSON(jsonlite::toJSON(this_object$`special_price`, auto_unbox = TRUE, digits = NA))
      self$`tier_price` <- ApiClient$new()$deserializeObj(this_object$`tier_price`, "array[ProductTierPrice]", loadNamespace("openapi"))
      self$`group_price` <- ApiClient$new()$deserializeObj(this_object$`group_price`, "array[ProductGroupPrice]", loadNamespace("openapi"))
      self$`images` <- ApiClient$new()$deserializeObj(this_object$`images`, "array[Image]", loadNamespace("openapi"))
      self$`product_options` <- ApiClient$new()$deserializeObj(this_object$`product_options`, "array[ProductOption]", loadNamespace("openapi"))
      self$`u_upc` <- this_object$`u_upc`
      self$`u_mpn` <- this_object$`u_mpn`
      self$`u_gtin` <- this_object$`u_gtin`
      self$`u_isbn` <- this_object$`u_isbn`
      self$`u_ean` <- this_object$`u_ean`
      self$`related_products_ids` <- ApiClient$new()$deserializeObj(this_object$`related_products_ids`, "array[character]", loadNamespace("openapi"))
      self$`up_sell_products_ids` <- ApiClient$new()$deserializeObj(this_object$`up_sell_products_ids`, "array[character]", loadNamespace("openapi"))
      self$`cross_sell_products_ids` <- ApiClient$new()$deserializeObj(this_object$`cross_sell_products_ids`, "array[character]", loadNamespace("openapi"))
      self$`dimensions_unit` <- this_object$`dimensions_unit`
      self$`width` <- this_object$`width`
      self$`height` <- this_object$`height`
      self$`length` <- this_object$`length`
      self$`discounts` <- ApiClient$new()$deserializeObj(this_object$`discounts`, "array[Discount]", loadNamespace("openapi"))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to Product and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of Product
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# Product$unlock()
#
## Below is an example to define the print function
# Product$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# Product$lock()

