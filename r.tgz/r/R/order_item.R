#' Create a new OrderItem
#'
#' @description
#' OrderItem Class
#'
#' @docType class
#' @title OrderItem
#' @description OrderItem Class
#' @format An \code{R6Class} generator object
#' @field product_id  character [optional]
#' @field order_product_id  character [optional]
#' @field model  character [optional]
#' @field name  character [optional]
#' @field price  numeric [optional]
#' @field price_inc_tax  numeric [optional]
#' @field quantity  numeric [optional]
#' @field discount_amount  numeric [optional]
#' @field total_price  numeric [optional]
#' @field tax_percent  numeric [optional]
#' @field tax_value  numeric [optional]
#' @field tax_value_after_discount  numeric [optional]
#' @field options  list(\link{OrderItemOption}) [optional]
#' @field variant_id  character [optional]
#' @field weight_unit  character [optional]
#' @field weight  numeric [optional]
#' @field barcode  character [optional]
#' @field parent_order_product_id  character [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
OrderItem <- R6::R6Class(
  "OrderItem",
  public = list(
    `product_id` = NULL,
    `order_product_id` = NULL,
    `model` = NULL,
    `name` = NULL,
    `price` = NULL,
    `price_inc_tax` = NULL,
    `quantity` = NULL,
    `discount_amount` = NULL,
    `total_price` = NULL,
    `tax_percent` = NULL,
    `tax_value` = NULL,
    `tax_value_after_discount` = NULL,
    `options` = NULL,
    `variant_id` = NULL,
    `weight_unit` = NULL,
    `weight` = NULL,
    `barcode` = NULL,
    `parent_order_product_id` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new OrderItem class.
    #'
    #' @param product_id product_id
    #' @param order_product_id order_product_id
    #' @param model model
    #' @param name name
    #' @param price price
    #' @param price_inc_tax price_inc_tax
    #' @param quantity quantity
    #' @param discount_amount discount_amount
    #' @param total_price total_price
    #' @param tax_percent tax_percent
    #' @param tax_value tax_value
    #' @param tax_value_after_discount tax_value_after_discount
    #' @param options options
    #' @param variant_id variant_id
    #' @param weight_unit weight_unit
    #' @param weight weight
    #' @param barcode barcode
    #' @param parent_order_product_id parent_order_product_id
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`product_id` = NULL, `order_product_id` = NULL, `model` = NULL, `name` = NULL, `price` = NULL, `price_inc_tax` = NULL, `quantity` = NULL, `discount_amount` = NULL, `total_price` = NULL, `tax_percent` = NULL, `tax_value` = NULL, `tax_value_after_discount` = NULL, `options` = NULL, `variant_id` = NULL, `weight_unit` = NULL, `weight` = NULL, `barcode` = NULL, `parent_order_product_id` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`product_id`)) {
        if (!(is.character(`product_id`) && length(`product_id`) == 1)) {
          stop(paste("Error! Invalid data for `product_id`. Must be a string:", `product_id`))
        }
        self$`product_id` <- `product_id`
      }
      if (!is.null(`order_product_id`)) {
        if (!(is.character(`order_product_id`) && length(`order_product_id`) == 1)) {
          stop(paste("Error! Invalid data for `order_product_id`. Must be a string:", `order_product_id`))
        }
        self$`order_product_id` <- `order_product_id`
      }
      if (!is.null(`model`)) {
        if (!(is.character(`model`) && length(`model`) == 1)) {
          stop(paste("Error! Invalid data for `model`. Must be a string:", `model`))
        }
        self$`model` <- `model`
      }
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`price`)) {
        self$`price` <- `price`
      }
      if (!is.null(`price_inc_tax`)) {
        self$`price_inc_tax` <- `price_inc_tax`
      }
      if (!is.null(`quantity`)) {
        self$`quantity` <- `quantity`
      }
      if (!is.null(`discount_amount`)) {
        self$`discount_amount` <- `discount_amount`
      }
      if (!is.null(`total_price`)) {
        self$`total_price` <- `total_price`
      }
      if (!is.null(`tax_percent`)) {
        self$`tax_percent` <- `tax_percent`
      }
      if (!is.null(`tax_value`)) {
        self$`tax_value` <- `tax_value`
      }
      if (!is.null(`tax_value_after_discount`)) {
        self$`tax_value_after_discount` <- `tax_value_after_discount`
      }
      if (!is.null(`options`)) {
        stopifnot(is.vector(`options`), length(`options`) != 0)
        sapply(`options`, function(x) stopifnot(R6::is.R6(x)))
        self$`options` <- `options`
      }
      if (!is.null(`variant_id`)) {
        if (!(is.character(`variant_id`) && length(`variant_id`) == 1)) {
          stop(paste("Error! Invalid data for `variant_id`. Must be a string:", `variant_id`))
        }
        self$`variant_id` <- `variant_id`
      }
      if (!is.null(`weight_unit`)) {
        if (!(is.character(`weight_unit`) && length(`weight_unit`) == 1)) {
          stop(paste("Error! Invalid data for `weight_unit`. Must be a string:", `weight_unit`))
        }
        self$`weight_unit` <- `weight_unit`
      }
      if (!is.null(`weight`)) {
        self$`weight` <- `weight`
      }
      if (!is.null(`barcode`)) {
        if (!(is.character(`barcode`) && length(`barcode`) == 1)) {
          stop(paste("Error! Invalid data for `barcode`. Must be a string:", `barcode`))
        }
        self$`barcode` <- `barcode`
      }
      if (!is.null(`parent_order_product_id`)) {
        if (!(is.character(`parent_order_product_id`) && length(`parent_order_product_id`) == 1)) {
          stop(paste("Error! Invalid data for `parent_order_product_id`. Must be a string:", `parent_order_product_id`))
        }
        self$`parent_order_product_id` <- `parent_order_product_id`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return OrderItem as a base R list.
    #' @examples
    #' # convert array of OrderItem (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert OrderItem to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      OrderItemObject <- list()
      if (!is.null(self$`product_id`)) {
        OrderItemObject[["product_id"]] <-
          self$`product_id`
      }
      if (!is.null(self$`order_product_id`)) {
        OrderItemObject[["order_product_id"]] <-
          self$`order_product_id`
      }
      if (!is.null(self$`model`)) {
        OrderItemObject[["model"]] <-
          self$`model`
      }
      if (!is.null(self$`name`)) {
        OrderItemObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`price`)) {
        OrderItemObject[["price"]] <-
          self$`price`
      }
      if (!is.null(self$`price_inc_tax`)) {
        OrderItemObject[["price_inc_tax"]] <-
          self$`price_inc_tax`
      }
      if (!is.null(self$`quantity`)) {
        OrderItemObject[["quantity"]] <-
          self$`quantity`
      }
      if (!is.null(self$`discount_amount`)) {
        OrderItemObject[["discount_amount"]] <-
          self$`discount_amount`
      }
      if (!is.null(self$`total_price`)) {
        OrderItemObject[["total_price"]] <-
          self$`total_price`
      }
      if (!is.null(self$`tax_percent`)) {
        OrderItemObject[["tax_percent"]] <-
          self$`tax_percent`
      }
      if (!is.null(self$`tax_value`)) {
        OrderItemObject[["tax_value"]] <-
          self$`tax_value`
      }
      if (!is.null(self$`tax_value_after_discount`)) {
        OrderItemObject[["tax_value_after_discount"]] <-
          self$`tax_value_after_discount`
      }
      if (!is.null(self$`options`)) {
        OrderItemObject[["options"]] <-
          lapply(self$`options`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`variant_id`)) {
        OrderItemObject[["variant_id"]] <-
          self$`variant_id`
      }
      if (!is.null(self$`weight_unit`)) {
        OrderItemObject[["weight_unit"]] <-
          self$`weight_unit`
      }
      if (!is.null(self$`weight`)) {
        OrderItemObject[["weight"]] <-
          self$`weight`
      }
      if (!is.null(self$`barcode`)) {
        OrderItemObject[["barcode"]] <-
          self$`barcode`
      }
      if (!is.null(self$`parent_order_product_id`)) {
        OrderItemObject[["parent_order_product_id"]] <-
          self$`parent_order_product_id`
      }
      if (!is.null(self$`additional_fields`)) {
        OrderItemObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        OrderItemObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(OrderItemObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderItem
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderItem
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`product_id`)) {
        self$`product_id` <- this_object$`product_id`
      }
      if (!is.null(this_object$`order_product_id`)) {
        self$`order_product_id` <- this_object$`order_product_id`
      }
      if (!is.null(this_object$`model`)) {
        self$`model` <- this_object$`model`
      }
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`price`)) {
        self$`price` <- this_object$`price`
      }
      if (!is.null(this_object$`price_inc_tax`)) {
        self$`price_inc_tax` <- this_object$`price_inc_tax`
      }
      if (!is.null(this_object$`quantity`)) {
        self$`quantity` <- this_object$`quantity`
      }
      if (!is.null(this_object$`discount_amount`)) {
        self$`discount_amount` <- this_object$`discount_amount`
      }
      if (!is.null(this_object$`total_price`)) {
        self$`total_price` <- this_object$`total_price`
      }
      if (!is.null(this_object$`tax_percent`)) {
        self$`tax_percent` <- this_object$`tax_percent`
      }
      if (!is.null(this_object$`tax_value`)) {
        self$`tax_value` <- this_object$`tax_value`
      }
      if (!is.null(this_object$`tax_value_after_discount`)) {
        self$`tax_value_after_discount` <- this_object$`tax_value_after_discount`
      }
      if (!is.null(this_object$`options`)) {
        self$`options` <- ApiClient$new()$deserializeObj(this_object$`options`, "array[OrderItemOption]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`variant_id`)) {
        self$`variant_id` <- this_object$`variant_id`
      }
      if (!is.null(this_object$`weight_unit`)) {
        self$`weight_unit` <- this_object$`weight_unit`
      }
      if (!is.null(this_object$`weight`)) {
        self$`weight` <- this_object$`weight`
      }
      if (!is.null(this_object$`barcode`)) {
        self$`barcode` <- this_object$`barcode`
      }
      if (!is.null(this_object$`parent_order_product_id`)) {
        self$`parent_order_product_id` <- this_object$`parent_order_product_id`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return OrderItem in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderItem
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderItem
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`product_id` <- this_object$`product_id`
      self$`order_product_id` <- this_object$`order_product_id`
      self$`model` <- this_object$`model`
      self$`name` <- this_object$`name`
      self$`price` <- this_object$`price`
      self$`price_inc_tax` <- this_object$`price_inc_tax`
      self$`quantity` <- this_object$`quantity`
      self$`discount_amount` <- this_object$`discount_amount`
      self$`total_price` <- this_object$`total_price`
      self$`tax_percent` <- this_object$`tax_percent`
      self$`tax_value` <- this_object$`tax_value`
      self$`tax_value_after_discount` <- this_object$`tax_value_after_discount`
      self$`options` <- ApiClient$new()$deserializeObj(this_object$`options`, "array[OrderItemOption]", loadNamespace("openapi"))
      self$`variant_id` <- this_object$`variant_id`
      self$`weight_unit` <- this_object$`weight_unit`
      self$`weight` <- this_object$`weight`
      self$`barcode` <- this_object$`barcode`
      self$`parent_order_product_id` <- this_object$`parent_order_product_id`
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to OrderItem and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of OrderItem
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# OrderItem$unlock()
#
## Below is an example to define the print function
# OrderItem$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# OrderItem$lock()

