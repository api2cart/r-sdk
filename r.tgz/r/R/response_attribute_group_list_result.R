#' Create a new ResponseAttributeGroupListResult
#'
#' @description
#' ResponseAttributeGroupListResult Class
#'
#' @docType class
#' @title ResponseAttributeGroupListResult
#' @description ResponseAttributeGroupListResult Class
#' @format An \code{R6Class} generator object
#' @field group  list(\link{StoreAttributeGroup}) [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ResponseAttributeGroupListResult <- R6::R6Class(
  "ResponseAttributeGroupListResult",
  public = list(
    `group` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new ResponseAttributeGroupListResult class.
    #'
    #' @param group group
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`group` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`group`)) {
        stopifnot(is.vector(`group`), length(`group`) != 0)
        sapply(`group`, function(x) stopifnot(R6::is.R6(x)))
        self$`group` <- `group`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ResponseAttributeGroupListResult as a base R list.
    #' @examples
    #' # convert array of ResponseAttributeGroupListResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ResponseAttributeGroupListResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ResponseAttributeGroupListResultObject <- list()
      if (!is.null(self$`group`)) {
        ResponseAttributeGroupListResultObject[["group"]] <-
          lapply(self$`group`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`additional_fields`)) {
        ResponseAttributeGroupListResultObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        ResponseAttributeGroupListResultObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(ResponseAttributeGroupListResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ResponseAttributeGroupListResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ResponseAttributeGroupListResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`group`)) {
        self$`group` <- ApiClient$new()$deserializeObj(this_object$`group`, "array[StoreAttributeGroup]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ResponseAttributeGroupListResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ResponseAttributeGroupListResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ResponseAttributeGroupListResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`group` <- ApiClient$new()$deserializeObj(this_object$`group`, "array[StoreAttributeGroup]", loadNamespace("openapi"))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to ResponseAttributeGroupListResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ResponseAttributeGroupListResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ResponseAttributeGroupListResult$unlock()
#
## Below is an example to define the print function
# ResponseAttributeGroupListResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ResponseAttributeGroupListResult$lock()

