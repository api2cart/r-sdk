#' Create a new OrderCalculateItem
#'
#' @description
#' OrderCalculateItem Class
#'
#' @docType class
#' @title OrderCalculateItem
#' @description OrderCalculateItem Class
#' @format An \code{R6Class} generator object
#' @field product_id  character [optional]
#' @field sku  character [optional]
#' @field name  character [optional]
#' @field quantity  integer [optional]
#' @field price  numeric [optional]
#' @field price_inc_tax  numeric [optional]
#' @field tax_rate  numeric [optional]
#' @field unit_discount  numeric [optional]
#' @field weight  numeric [optional]
#' @field weight_unit  character [optional]
#' @field barcode  character [optional]
#' @field variant_id  character [optional]
#' @field bundle_product_id  character [optional]
#' @field options  list(\link{OrderItemOption}) [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
OrderCalculateItem <- R6::R6Class(
  "OrderCalculateItem",
  public = list(
    `product_id` = NULL,
    `sku` = NULL,
    `name` = NULL,
    `quantity` = NULL,
    `price` = NULL,
    `price_inc_tax` = NULL,
    `tax_rate` = NULL,
    `unit_discount` = NULL,
    `weight` = NULL,
    `weight_unit` = NULL,
    `barcode` = NULL,
    `variant_id` = NULL,
    `bundle_product_id` = NULL,
    `options` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new OrderCalculateItem class.
    #'
    #' @param product_id product_id
    #' @param sku sku
    #' @param name name
    #' @param quantity quantity
    #' @param price price
    #' @param price_inc_tax price_inc_tax
    #' @param tax_rate tax_rate
    #' @param unit_discount unit_discount
    #' @param weight weight
    #' @param weight_unit weight_unit
    #' @param barcode barcode
    #' @param variant_id variant_id
    #' @param bundle_product_id bundle_product_id
    #' @param options options
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`product_id` = NULL, `sku` = NULL, `name` = NULL, `quantity` = NULL, `price` = NULL, `price_inc_tax` = NULL, `tax_rate` = NULL, `unit_discount` = NULL, `weight` = NULL, `weight_unit` = NULL, `barcode` = NULL, `variant_id` = NULL, `bundle_product_id` = NULL, `options` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`product_id`)) {
        if (!(is.character(`product_id`) && length(`product_id`) == 1)) {
          stop(paste("Error! Invalid data for `product_id`. Must be a string:", `product_id`))
        }
        self$`product_id` <- `product_id`
      }
      if (!is.null(`sku`)) {
        if (!(is.character(`sku`) && length(`sku`) == 1)) {
          stop(paste("Error! Invalid data for `sku`. Must be a string:", `sku`))
        }
        self$`sku` <- `sku`
      }
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`quantity`)) {
        if (!(is.numeric(`quantity`) && length(`quantity`) == 1)) {
          stop(paste("Error! Invalid data for `quantity`. Must be an integer:", `quantity`))
        }
        self$`quantity` <- `quantity`
      }
      if (!is.null(`price`)) {
        self$`price` <- `price`
      }
      if (!is.null(`price_inc_tax`)) {
        self$`price_inc_tax` <- `price_inc_tax`
      }
      if (!is.null(`tax_rate`)) {
        self$`tax_rate` <- `tax_rate`
      }
      if (!is.null(`unit_discount`)) {
        self$`unit_discount` <- `unit_discount`
      }
      if (!is.null(`weight`)) {
        self$`weight` <- `weight`
      }
      if (!is.null(`weight_unit`)) {
        if (!(is.character(`weight_unit`) && length(`weight_unit`) == 1)) {
          stop(paste("Error! Invalid data for `weight_unit`. Must be a string:", `weight_unit`))
        }
        self$`weight_unit` <- `weight_unit`
      }
      if (!is.null(`barcode`)) {
        if (!(is.character(`barcode`) && length(`barcode`) == 1)) {
          stop(paste("Error! Invalid data for `barcode`. Must be a string:", `barcode`))
        }
        self$`barcode` <- `barcode`
      }
      if (!is.null(`variant_id`)) {
        if (!(is.character(`variant_id`) && length(`variant_id`) == 1)) {
          stop(paste("Error! Invalid data for `variant_id`. Must be a string:", `variant_id`))
        }
        self$`variant_id` <- `variant_id`
      }
      if (!is.null(`bundle_product_id`)) {
        if (!(is.character(`bundle_product_id`) && length(`bundle_product_id`) == 1)) {
          stop(paste("Error! Invalid data for `bundle_product_id`. Must be a string:", `bundle_product_id`))
        }
        self$`bundle_product_id` <- `bundle_product_id`
      }
      if (!is.null(`options`)) {
        stopifnot(is.vector(`options`), length(`options`) != 0)
        sapply(`options`, function(x) stopifnot(R6::is.R6(x)))
        self$`options` <- `options`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return OrderCalculateItem as a base R list.
    #' @examples
    #' # convert array of OrderCalculateItem (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert OrderCalculateItem to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      OrderCalculateItemObject <- list()
      if (!is.null(self$`product_id`)) {
        OrderCalculateItemObject[["product_id"]] <-
          self$`product_id`
      }
      if (!is.null(self$`sku`)) {
        OrderCalculateItemObject[["sku"]] <-
          self$`sku`
      }
      if (!is.null(self$`name`)) {
        OrderCalculateItemObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`quantity`)) {
        OrderCalculateItemObject[["quantity"]] <-
          self$`quantity`
      }
      if (!is.null(self$`price`)) {
        OrderCalculateItemObject[["price"]] <-
          self$`price`
      }
      if (!is.null(self$`price_inc_tax`)) {
        OrderCalculateItemObject[["price_inc_tax"]] <-
          self$`price_inc_tax`
      }
      if (!is.null(self$`tax_rate`)) {
        OrderCalculateItemObject[["tax_rate"]] <-
          self$`tax_rate`
      }
      if (!is.null(self$`unit_discount`)) {
        OrderCalculateItemObject[["unit_discount"]] <-
          self$`unit_discount`
      }
      if (!is.null(self$`weight`)) {
        OrderCalculateItemObject[["weight"]] <-
          self$`weight`
      }
      if (!is.null(self$`weight_unit`)) {
        OrderCalculateItemObject[["weight_unit"]] <-
          self$`weight_unit`
      }
      if (!is.null(self$`barcode`)) {
        OrderCalculateItemObject[["barcode"]] <-
          self$`barcode`
      }
      if (!is.null(self$`variant_id`)) {
        OrderCalculateItemObject[["variant_id"]] <-
          self$`variant_id`
      }
      if (!is.null(self$`bundle_product_id`)) {
        OrderCalculateItemObject[["bundle_product_id"]] <-
          self$`bundle_product_id`
      }
      if (!is.null(self$`options`)) {
        OrderCalculateItemObject[["options"]] <-
          lapply(self$`options`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`additional_fields`)) {
        OrderCalculateItemObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        OrderCalculateItemObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(OrderCalculateItemObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderCalculateItem
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderCalculateItem
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`product_id`)) {
        self$`product_id` <- this_object$`product_id`
      }
      if (!is.null(this_object$`sku`)) {
        self$`sku` <- this_object$`sku`
      }
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`quantity`)) {
        self$`quantity` <- this_object$`quantity`
      }
      if (!is.null(this_object$`price`)) {
        self$`price` <- this_object$`price`
      }
      if (!is.null(this_object$`price_inc_tax`)) {
        self$`price_inc_tax` <- this_object$`price_inc_tax`
      }
      if (!is.null(this_object$`tax_rate`)) {
        self$`tax_rate` <- this_object$`tax_rate`
      }
      if (!is.null(this_object$`unit_discount`)) {
        self$`unit_discount` <- this_object$`unit_discount`
      }
      if (!is.null(this_object$`weight`)) {
        self$`weight` <- this_object$`weight`
      }
      if (!is.null(this_object$`weight_unit`)) {
        self$`weight_unit` <- this_object$`weight_unit`
      }
      if (!is.null(this_object$`barcode`)) {
        self$`barcode` <- this_object$`barcode`
      }
      if (!is.null(this_object$`variant_id`)) {
        self$`variant_id` <- this_object$`variant_id`
      }
      if (!is.null(this_object$`bundle_product_id`)) {
        self$`bundle_product_id` <- this_object$`bundle_product_id`
      }
      if (!is.null(this_object$`options`)) {
        self$`options` <- ApiClient$new()$deserializeObj(this_object$`options`, "array[OrderItemOption]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return OrderCalculateItem in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderCalculateItem
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderCalculateItem
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`product_id` <- this_object$`product_id`
      self$`sku` <- this_object$`sku`
      self$`name` <- this_object$`name`
      self$`quantity` <- this_object$`quantity`
      self$`price` <- this_object$`price`
      self$`price_inc_tax` <- this_object$`price_inc_tax`
      self$`tax_rate` <- this_object$`tax_rate`
      self$`unit_discount` <- this_object$`unit_discount`
      self$`weight` <- this_object$`weight`
      self$`weight_unit` <- this_object$`weight_unit`
      self$`barcode` <- this_object$`barcode`
      self$`variant_id` <- this_object$`variant_id`
      self$`bundle_product_id` <- this_object$`bundle_product_id`
      self$`options` <- ApiClient$new()$deserializeObj(this_object$`options`, "array[OrderItemOption]", loadNamespace("openapi"))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to OrderCalculateItem and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of OrderCalculateItem
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# OrderCalculateItem$unlock()
#
## Below is an example to define the print function
# OrderCalculateItem$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# OrderCalculateItem$lock()

