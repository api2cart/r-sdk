#' Create a new ProductVariantAddBatch
#'
#' @description
#' ProductVariantAddBatch Class
#'
#' @docType class
#' @title ProductVariantAddBatch
#' @description ProductVariantAddBatch Class
#' @format An \code{R6Class} generator object
#' @field clear_cache  character [optional]
#' @field reindex  character [optional]
#' @field payload Contains an array of product variants objects. The list of properties may vary depending on the specific platform. list(\link{ProductVariantAddBatchPayloadInner})
#' @field idempotency_key A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong> character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductVariantAddBatch <- R6::R6Class(
  "ProductVariantAddBatch",
  public = list(
    `clear_cache` = NULL,
    `reindex` = NULL,
    `payload` = NULL,
    `idempotency_key` = NULL,

    #' @description
    #' Initialize a new ProductVariantAddBatch class.
    #'
    #' @param payload Contains an array of product variants objects. The list of properties may vary depending on the specific platform.
    #' @param clear_cache clear_cache. Default to FALSE.
    #' @param reindex reindex. Default to FALSE.
    #' @param idempotency_key A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong>
    #' @param ... Other optional arguments.
    initialize = function(`payload`, `clear_cache` = FALSE, `reindex` = FALSE, `idempotency_key` = NULL, ...) {
      if (!missing(`payload`)) {
        stopifnot(is.vector(`payload`), length(`payload`) != 0)
        sapply(`payload`, function(x) stopifnot(R6::is.R6(x)))
        self$`payload` <- `payload`
      }
      if (!is.null(`clear_cache`)) {
        if (!(is.logical(`clear_cache`) && length(`clear_cache`) == 1)) {
          stop(paste("Error! Invalid data for `clear_cache`. Must be a boolean:", `clear_cache`))
        }
        self$`clear_cache` <- `clear_cache`
      }
      if (!is.null(`reindex`)) {
        if (!(is.logical(`reindex`) && length(`reindex`) == 1)) {
          stop(paste("Error! Invalid data for `reindex`. Must be a boolean:", `reindex`))
        }
        self$`reindex` <- `reindex`
      }
      if (!is.null(`idempotency_key`)) {
        if (!(is.character(`idempotency_key`) && length(`idempotency_key`) == 1)) {
          stop(paste("Error! Invalid data for `idempotency_key`. Must be a string:", `idempotency_key`))
        }
        self$`idempotency_key` <- `idempotency_key`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductVariantAddBatch as a base R list.
    #' @examples
    #' # convert array of ProductVariantAddBatch (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductVariantAddBatch to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductVariantAddBatchObject <- list()
      if (!is.null(self$`clear_cache`)) {
        ProductVariantAddBatchObject[["clear_cache"]] <-
          self$`clear_cache`
      }
      if (!is.null(self$`reindex`)) {
        ProductVariantAddBatchObject[["reindex"]] <-
          self$`reindex`
      }
      if (!is.null(self$`payload`)) {
        ProductVariantAddBatchObject[["payload"]] <-
          lapply(self$`payload`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`idempotency_key`)) {
        ProductVariantAddBatchObject[["idempotency_key"]] <-
          self$`idempotency_key`
      }
      return(ProductVariantAddBatchObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductVariantAddBatch
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductVariantAddBatch
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`clear_cache`)) {
        self$`clear_cache` <- this_object$`clear_cache`
      }
      if (!is.null(this_object$`reindex`)) {
        self$`reindex` <- this_object$`reindex`
      }
      if (!is.null(this_object$`payload`)) {
        self$`payload` <- ApiClient$new()$deserializeObj(this_object$`payload`, "array[ProductVariantAddBatchPayloadInner]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`idempotency_key`)) {
        self$`idempotency_key` <- this_object$`idempotency_key`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductVariantAddBatch in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductVariantAddBatch
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductVariantAddBatch
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`clear_cache` <- this_object$`clear_cache`
      self$`reindex` <- this_object$`reindex`
      self$`payload` <- ApiClient$new()$deserializeObj(this_object$`payload`, "array[ProductVariantAddBatchPayloadInner]", loadNamespace("openapi"))
      self$`idempotency_key` <- this_object$`idempotency_key`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductVariantAddBatch and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
      # check the required field `payload`
      if (!is.null(input_json$`payload`)) {
        stopifnot(is.vector(input_json$`payload`), length(input_json$`payload`) != 0)
        tmp <- sapply(input_json$`payload`, function(x) stopifnot(R6::is.R6(x)))
      } else {
        stop(paste("The JSON input `", input, "` is invalid for ProductVariantAddBatch: the required field `payload` is missing."))
      }
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductVariantAddBatch
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      # check if the required `payload` is null
      if (is.null(self$`payload`)) {
        return(FALSE)
      }

      if (length(self$`payload`) > 250) {
        return(FALSE)
      }
      if (length(self$`payload`) < 1) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      # check if the required `payload` is null
      if (is.null(self$`payload`)) {
        invalid_fields["payload"] <- "Non-nullable required field `payload` cannot be null."
      }

      if (length(self$`payload`) > 250) {
        invalid_fields["payload"] <- "Invalid length for `payload`, number of items must be less than or equal to 250."
      }
      if (length(self$`payload`) < 1) {
        invalid_fields["payload"] <- "Invalid length for ``, number of items must be greater than or equal to 1."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductVariantAddBatch$unlock()
#
## Below is an example to define the print function
# ProductVariantAddBatch$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductVariantAddBatch$lock()

