#' Create a new BasketItem
#'
#' @description
#' BasketItem Class
#'
#' @docType class
#' @title BasketItem
#' @description BasketItem Class
#' @format An \code{R6Class} generator object
#' @field id  character [optional]
#' @field parent_id  character [optional]
#' @field product_id  character [optional]
#' @field variant_id  character [optional]
#' @field sku  character [optional]
#' @field name  character [optional]
#' @field price  numeric [optional]
#' @field tax  numeric [optional]
#' @field quantity  numeric [optional]
#' @field weight_unit  character [optional]
#' @field weight  numeric [optional]
#' @field options  list(\link{BasketItemOption}) [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
BasketItem <- R6::R6Class(
  "BasketItem",
  public = list(
    `id` = NULL,
    `parent_id` = NULL,
    `product_id` = NULL,
    `variant_id` = NULL,
    `sku` = NULL,
    `name` = NULL,
    `price` = NULL,
    `tax` = NULL,
    `quantity` = NULL,
    `weight_unit` = NULL,
    `weight` = NULL,
    `options` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new BasketItem class.
    #'
    #' @param id id
    #' @param parent_id parent_id
    #' @param product_id product_id
    #' @param variant_id variant_id
    #' @param sku sku
    #' @param name name
    #' @param price price
    #' @param tax tax
    #' @param quantity quantity
    #' @param weight_unit weight_unit
    #' @param weight weight
    #' @param options options
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `parent_id` = NULL, `product_id` = NULL, `variant_id` = NULL, `sku` = NULL, `name` = NULL, `price` = NULL, `tax` = NULL, `quantity` = NULL, `weight_unit` = NULL, `weight` = NULL, `options` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`parent_id`)) {
        if (!(is.character(`parent_id`) && length(`parent_id`) == 1)) {
          stop(paste("Error! Invalid data for `parent_id`. Must be a string:", `parent_id`))
        }
        self$`parent_id` <- `parent_id`
      }
      if (!is.null(`product_id`)) {
        if (!(is.character(`product_id`) && length(`product_id`) == 1)) {
          stop(paste("Error! Invalid data for `product_id`. Must be a string:", `product_id`))
        }
        self$`product_id` <- `product_id`
      }
      if (!is.null(`variant_id`)) {
        if (!(is.character(`variant_id`) && length(`variant_id`) == 1)) {
          stop(paste("Error! Invalid data for `variant_id`. Must be a string:", `variant_id`))
        }
        self$`variant_id` <- `variant_id`
      }
      if (!is.null(`sku`)) {
        if (!(is.character(`sku`) && length(`sku`) == 1)) {
          stop(paste("Error! Invalid data for `sku`. Must be a string:", `sku`))
        }
        self$`sku` <- `sku`
      }
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`price`)) {
        self$`price` <- `price`
      }
      if (!is.null(`tax`)) {
        self$`tax` <- `tax`
      }
      if (!is.null(`quantity`)) {
        self$`quantity` <- `quantity`
      }
      if (!is.null(`weight_unit`)) {
        if (!(is.character(`weight_unit`) && length(`weight_unit`) == 1)) {
          stop(paste("Error! Invalid data for `weight_unit`. Must be a string:", `weight_unit`))
        }
        self$`weight_unit` <- `weight_unit`
      }
      if (!is.null(`weight`)) {
        self$`weight` <- `weight`
      }
      if (!is.null(`options`)) {
        stopifnot(is.vector(`options`), length(`options`) != 0)
        sapply(`options`, function(x) stopifnot(R6::is.R6(x)))
        self$`options` <- `options`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return BasketItem as a base R list.
    #' @examples
    #' # convert array of BasketItem (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert BasketItem to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      BasketItemObject <- list()
      if (!is.null(self$`id`)) {
        BasketItemObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`parent_id`)) {
        BasketItemObject[["parent_id"]] <-
          self$`parent_id`
      }
      if (!is.null(self$`product_id`)) {
        BasketItemObject[["product_id"]] <-
          self$`product_id`
      }
      if (!is.null(self$`variant_id`)) {
        BasketItemObject[["variant_id"]] <-
          self$`variant_id`
      }
      if (!is.null(self$`sku`)) {
        BasketItemObject[["sku"]] <-
          self$`sku`
      }
      if (!is.null(self$`name`)) {
        BasketItemObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`price`)) {
        BasketItemObject[["price"]] <-
          self$`price`
      }
      if (!is.null(self$`tax`)) {
        BasketItemObject[["tax"]] <-
          self$`tax`
      }
      if (!is.null(self$`quantity`)) {
        BasketItemObject[["quantity"]] <-
          self$`quantity`
      }
      if (!is.null(self$`weight_unit`)) {
        BasketItemObject[["weight_unit"]] <-
          self$`weight_unit`
      }
      if (!is.null(self$`weight`)) {
        BasketItemObject[["weight"]] <-
          self$`weight`
      }
      if (!is.null(self$`options`)) {
        BasketItemObject[["options"]] <-
          lapply(self$`options`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`additional_fields`)) {
        BasketItemObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        BasketItemObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(BasketItemObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of BasketItem
    #'
    #' @param input_json the JSON input
    #' @return the instance of BasketItem
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`parent_id`)) {
        self$`parent_id` <- this_object$`parent_id`
      }
      if (!is.null(this_object$`product_id`)) {
        self$`product_id` <- this_object$`product_id`
      }
      if (!is.null(this_object$`variant_id`)) {
        self$`variant_id` <- this_object$`variant_id`
      }
      if (!is.null(this_object$`sku`)) {
        self$`sku` <- this_object$`sku`
      }
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`price`)) {
        self$`price` <- this_object$`price`
      }
      if (!is.null(this_object$`tax`)) {
        self$`tax` <- this_object$`tax`
      }
      if (!is.null(this_object$`quantity`)) {
        self$`quantity` <- this_object$`quantity`
      }
      if (!is.null(this_object$`weight_unit`)) {
        self$`weight_unit` <- this_object$`weight_unit`
      }
      if (!is.null(this_object$`weight`)) {
        self$`weight` <- this_object$`weight`
      }
      if (!is.null(this_object$`options`)) {
        self$`options` <- ApiClient$new()$deserializeObj(this_object$`options`, "array[BasketItemOption]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return BasketItem in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of BasketItem
    #'
    #' @param input_json the JSON input
    #' @return the instance of BasketItem
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`parent_id` <- this_object$`parent_id`
      self$`product_id` <- this_object$`product_id`
      self$`variant_id` <- this_object$`variant_id`
      self$`sku` <- this_object$`sku`
      self$`name` <- this_object$`name`
      self$`price` <- this_object$`price`
      self$`tax` <- this_object$`tax`
      self$`quantity` <- this_object$`quantity`
      self$`weight_unit` <- this_object$`weight_unit`
      self$`weight` <- this_object$`weight`
      self$`options` <- ApiClient$new()$deserializeObj(this_object$`options`, "array[BasketItemOption]", loadNamespace("openapi"))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to BasketItem and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of BasketItem
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# BasketItem$unlock()
#
## Below is an example to define the print function
# BasketItem$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# BasketItem$lock()

