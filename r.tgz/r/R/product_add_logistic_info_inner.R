#' Create a new ProductAddLogisticInfoInner
#'
#' @description
#' ProductAddLogisticInfoInner Class
#'
#' @docType class
#' @title ProductAddLogisticInfoInner
#' @description ProductAddLogisticInfoInner Class
#' @format An \code{R6Class} generator object
#' @field logistic_id  numeric
#' @field is_free  character [optional]
#' @field shipping_fee  numeric [optional]
#' @field size_id  numeric [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductAddLogisticInfoInner <- R6::R6Class(
  "ProductAddLogisticInfoInner",
  public = list(
    `logistic_id` = NULL,
    `is_free` = NULL,
    `shipping_fee` = NULL,
    `size_id` = NULL,

    #' @description
    #' Initialize a new ProductAddLogisticInfoInner class.
    #'
    #' @param logistic_id logistic_id
    #' @param is_free is_free
    #' @param shipping_fee shipping_fee
    #' @param size_id size_id
    #' @param ... Other optional arguments.
    initialize = function(`logistic_id`, `is_free` = NULL, `shipping_fee` = NULL, `size_id` = NULL, ...) {
      if (!missing(`logistic_id`)) {
        self$`logistic_id` <- `logistic_id`
      }
      if (!is.null(`is_free`)) {
        if (!(is.logical(`is_free`) && length(`is_free`) == 1)) {
          stop(paste("Error! Invalid data for `is_free`. Must be a boolean:", `is_free`))
        }
        self$`is_free` <- `is_free`
      }
      if (!is.null(`shipping_fee`)) {
        self$`shipping_fee` <- `shipping_fee`
      }
      if (!is.null(`size_id`)) {
        self$`size_id` <- `size_id`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductAddLogisticInfoInner as a base R list.
    #' @examples
    #' # convert array of ProductAddLogisticInfoInner (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductAddLogisticInfoInner to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductAddLogisticInfoInnerObject <- list()
      if (!is.null(self$`logistic_id`)) {
        ProductAddLogisticInfoInnerObject[["logistic_id"]] <-
          self$`logistic_id`
      }
      if (!is.null(self$`is_free`)) {
        ProductAddLogisticInfoInnerObject[["is_free"]] <-
          self$`is_free`
      }
      if (!is.null(self$`shipping_fee`)) {
        ProductAddLogisticInfoInnerObject[["shipping_fee"]] <-
          self$`shipping_fee`
      }
      if (!is.null(self$`size_id`)) {
        ProductAddLogisticInfoInnerObject[["size_id"]] <-
          self$`size_id`
      }
      return(ProductAddLogisticInfoInnerObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductAddLogisticInfoInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductAddLogisticInfoInner
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`logistic_id`)) {
        self$`logistic_id` <- this_object$`logistic_id`
      }
      if (!is.null(this_object$`is_free`)) {
        self$`is_free` <- this_object$`is_free`
      }
      if (!is.null(this_object$`shipping_fee`)) {
        self$`shipping_fee` <- this_object$`shipping_fee`
      }
      if (!is.null(this_object$`size_id`)) {
        self$`size_id` <- this_object$`size_id`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductAddLogisticInfoInner in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductAddLogisticInfoInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductAddLogisticInfoInner
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`logistic_id` <- this_object$`logistic_id`
      self$`is_free` <- this_object$`is_free`
      self$`shipping_fee` <- this_object$`shipping_fee`
      self$`size_id` <- this_object$`size_id`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductAddLogisticInfoInner and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
      # check the required field `logistic_id`
      if (!is.null(input_json$`logistic_id`)) {
      } else {
        stop(paste("The JSON input `", input, "` is invalid for ProductAddLogisticInfoInner: the required field `logistic_id` is missing."))
      }
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductAddLogisticInfoInner
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      # check if the required `logistic_id` is null
      if (is.null(self$`logistic_id`)) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      # check if the required `logistic_id` is null
      if (is.null(self$`logistic_id`)) {
        invalid_fields["logistic_id"] <- "Non-nullable required field `logistic_id` cannot be null."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductAddLogisticInfoInner$unlock()
#
## Below is an example to define the print function
# ProductAddLogisticInfoInner$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductAddLogisticInfoInner$lock()

