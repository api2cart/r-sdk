#' Create a new ProductAddShippingDetailsInner
#'
#' @description
#' ProductAddShippingDetailsInner Class
#'
#' @docType class
#' @title ProductAddShippingDetailsInner
#' @description ProductAddShippingDetailsInner Class
#' @format An \code{R6Class} generator object
#' @field shipping_type  character [optional]
#' @field shipping_service  character [optional]
#' @field shipping_cost  numeric [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductAddShippingDetailsInner <- R6::R6Class(
  "ProductAddShippingDetailsInner",
  public = list(
    `shipping_type` = NULL,
    `shipping_service` = NULL,
    `shipping_cost` = NULL,

    #' @description
    #' Initialize a new ProductAddShippingDetailsInner class.
    #'
    #' @param shipping_type shipping_type
    #' @param shipping_service shipping_service
    #' @param shipping_cost shipping_cost
    #' @param ... Other optional arguments.
    initialize = function(`shipping_type` = NULL, `shipping_service` = NULL, `shipping_cost` = NULL, ...) {
      if (!is.null(`shipping_type`)) {
        if (!(is.character(`shipping_type`) && length(`shipping_type`) == 1)) {
          stop(paste("Error! Invalid data for `shipping_type`. Must be a string:", `shipping_type`))
        }
        self$`shipping_type` <- `shipping_type`
      }
      if (!is.null(`shipping_service`)) {
        if (!(is.character(`shipping_service`) && length(`shipping_service`) == 1)) {
          stop(paste("Error! Invalid data for `shipping_service`. Must be a string:", `shipping_service`))
        }
        self$`shipping_service` <- `shipping_service`
      }
      if (!is.null(`shipping_cost`)) {
        self$`shipping_cost` <- `shipping_cost`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductAddShippingDetailsInner as a base R list.
    #' @examples
    #' # convert array of ProductAddShippingDetailsInner (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductAddShippingDetailsInner to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductAddShippingDetailsInnerObject <- list()
      if (!is.null(self$`shipping_type`)) {
        ProductAddShippingDetailsInnerObject[["shipping_type"]] <-
          self$`shipping_type`
      }
      if (!is.null(self$`shipping_service`)) {
        ProductAddShippingDetailsInnerObject[["shipping_service"]] <-
          self$`shipping_service`
      }
      if (!is.null(self$`shipping_cost`)) {
        ProductAddShippingDetailsInnerObject[["shipping_cost"]] <-
          self$`shipping_cost`
      }
      return(ProductAddShippingDetailsInnerObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductAddShippingDetailsInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductAddShippingDetailsInner
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`shipping_type`)) {
        self$`shipping_type` <- this_object$`shipping_type`
      }
      if (!is.null(this_object$`shipping_service`)) {
        self$`shipping_service` <- this_object$`shipping_service`
      }
      if (!is.null(this_object$`shipping_cost`)) {
        self$`shipping_cost` <- this_object$`shipping_cost`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductAddShippingDetailsInner in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductAddShippingDetailsInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductAddShippingDetailsInner
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`shipping_type` <- this_object$`shipping_type`
      self$`shipping_service` <- this_object$`shipping_service`
      self$`shipping_cost` <- this_object$`shipping_cost`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductAddShippingDetailsInner and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductAddShippingDetailsInner
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductAddShippingDetailsInner$unlock()
#
## Below is an example to define the print function
# ProductAddShippingDetailsInner$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductAddShippingDetailsInner$lock()

