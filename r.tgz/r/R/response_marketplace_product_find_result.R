#' Create a new ResponseMarketplaceProductFindResult
#'
#' @description
#' ResponseMarketplaceProductFindResult Class
#'
#' @docType class
#' @title ResponseMarketplaceProductFindResult
#' @description ResponseMarketplaceProductFindResult Class
#' @format An \code{R6Class} generator object
#' @field marketplace_products_count  integer [optional]
#' @field marketplace_product  list(\link{MarketplaceProduct}) [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ResponseMarketplaceProductFindResult <- R6::R6Class(
  "ResponseMarketplaceProductFindResult",
  public = list(
    `marketplace_products_count` = NULL,
    `marketplace_product` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new ResponseMarketplaceProductFindResult class.
    #'
    #' @param marketplace_products_count marketplace_products_count
    #' @param marketplace_product marketplace_product
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`marketplace_products_count` = NULL, `marketplace_product` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`marketplace_products_count`)) {
        if (!(is.numeric(`marketplace_products_count`) && length(`marketplace_products_count`) == 1)) {
          stop(paste("Error! Invalid data for `marketplace_products_count`. Must be an integer:", `marketplace_products_count`))
        }
        self$`marketplace_products_count` <- `marketplace_products_count`
      }
      if (!is.null(`marketplace_product`)) {
        stopifnot(is.vector(`marketplace_product`), length(`marketplace_product`) != 0)
        sapply(`marketplace_product`, function(x) stopifnot(R6::is.R6(x)))
        self$`marketplace_product` <- `marketplace_product`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ResponseMarketplaceProductFindResult as a base R list.
    #' @examples
    #' # convert array of ResponseMarketplaceProductFindResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ResponseMarketplaceProductFindResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ResponseMarketplaceProductFindResultObject <- list()
      if (!is.null(self$`marketplace_products_count`)) {
        ResponseMarketplaceProductFindResultObject[["marketplace_products_count"]] <-
          self$`marketplace_products_count`
      }
      if (!is.null(self$`marketplace_product`)) {
        ResponseMarketplaceProductFindResultObject[["marketplace_product"]] <-
          lapply(self$`marketplace_product`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`additional_fields`)) {
        ResponseMarketplaceProductFindResultObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        ResponseMarketplaceProductFindResultObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(ResponseMarketplaceProductFindResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ResponseMarketplaceProductFindResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ResponseMarketplaceProductFindResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`marketplace_products_count`)) {
        self$`marketplace_products_count` <- this_object$`marketplace_products_count`
      }
      if (!is.null(this_object$`marketplace_product`)) {
        self$`marketplace_product` <- ApiClient$new()$deserializeObj(this_object$`marketplace_product`, "array[MarketplaceProduct]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ResponseMarketplaceProductFindResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ResponseMarketplaceProductFindResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ResponseMarketplaceProductFindResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`marketplace_products_count` <- this_object$`marketplace_products_count`
      self$`marketplace_product` <- ApiClient$new()$deserializeObj(this_object$`marketplace_product`, "array[MarketplaceProduct]", loadNamespace("openapi"))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to ResponseMarketplaceProductFindResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ResponseMarketplaceProductFindResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ResponseMarketplaceProductFindResult$unlock()
#
## Below is an example to define the print function
# ResponseMarketplaceProductFindResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ResponseMarketplaceProductFindResult$lock()

