#' Create a new OrderPreestimateShippingList
#'
#' @description
#' OrderPreestimateShippingList Class
#'
#' @docType class
#' @title OrderPreestimateShippingList
#' @description OrderPreestimateShippingList Class
#' @format An \code{R6Class} generator object
#' @field warehouse_id This parameter is used for selecting a warehouse where you need to set/modify a product quantity. character [optional]
#' @field customer_id Retrieves orders specified by customer id character [optional]
#' @field customer_email Retrieves orders specified by customer email character [optional]
#' @field store_id Store Id character [optional]
#' @field shipp_address_1 Specifies first shipping address character [optional]
#' @field shipp_city Specifies shipping city character [optional]
#' @field shipp_postcode Specifies shipping postcode character [optional]
#' @field shipp_state Specifies shipping state code character [optional]
#' @field shipp_country Specifies shipping country code character
#' @field params Set this parameter in order to choose which entity fields you want to retrieve character [optional]
#' @field exclude Set this parameter in order to choose which entity fields you want to ignore. Works only if parameter `params` equal force_all character [optional]
#' @field idempotency_key A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong> character [optional]
#' @field order_item  list(\link{OrderPreestimateShippingListOrderItemInner})
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
OrderPreestimateShippingList <- R6::R6Class(
  "OrderPreestimateShippingList",
  public = list(
    `warehouse_id` = NULL,
    `customer_id` = NULL,
    `customer_email` = NULL,
    `store_id` = NULL,
    `shipp_address_1` = NULL,
    `shipp_city` = NULL,
    `shipp_postcode` = NULL,
    `shipp_state` = NULL,
    `shipp_country` = NULL,
    `params` = NULL,
    `exclude` = NULL,
    `idempotency_key` = NULL,
    `order_item` = NULL,

    #' @description
    #' Initialize a new OrderPreestimateShippingList class.
    #'
    #' @param shipp_country Specifies shipping country code
    #' @param order_item order_item
    #' @param warehouse_id This parameter is used for selecting a warehouse where you need to set/modify a product quantity.
    #' @param customer_id Retrieves orders specified by customer id
    #' @param customer_email Retrieves orders specified by customer email
    #' @param store_id Store Id
    #' @param shipp_address_1 Specifies first shipping address
    #' @param shipp_city Specifies shipping city
    #' @param shipp_postcode Specifies shipping postcode
    #' @param shipp_state Specifies shipping state code
    #' @param params Set this parameter in order to choose which entity fields you want to retrieve. Default to "force_all".
    #' @param exclude Set this parameter in order to choose which entity fields you want to ignore. Works only if parameter `params` equal force_all
    #' @param idempotency_key A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong>
    #' @param ... Other optional arguments.
    initialize = function(`shipp_country`, `order_item`, `warehouse_id` = NULL, `customer_id` = NULL, `customer_email` = NULL, `store_id` = NULL, `shipp_address_1` = NULL, `shipp_city` = NULL, `shipp_postcode` = NULL, `shipp_state` = NULL, `params` = "force_all", `exclude` = NULL, `idempotency_key` = NULL, ...) {
      if (!missing(`shipp_country`)) {
        if (!(is.character(`shipp_country`) && length(`shipp_country`) == 1)) {
          stop(paste("Error! Invalid data for `shipp_country`. Must be a string:", `shipp_country`))
        }
        self$`shipp_country` <- `shipp_country`
      }
      if (!missing(`order_item`)) {
        stopifnot(is.vector(`order_item`), length(`order_item`) != 0)
        sapply(`order_item`, function(x) stopifnot(R6::is.R6(x)))
        self$`order_item` <- `order_item`
      }
      if (!is.null(`warehouse_id`)) {
        if (!(is.character(`warehouse_id`) && length(`warehouse_id`) == 1)) {
          stop(paste("Error! Invalid data for `warehouse_id`. Must be a string:", `warehouse_id`))
        }
        self$`warehouse_id` <- `warehouse_id`
      }
      if (!is.null(`customer_id`)) {
        if (!(is.character(`customer_id`) && length(`customer_id`) == 1)) {
          stop(paste("Error! Invalid data for `customer_id`. Must be a string:", `customer_id`))
        }
        self$`customer_id` <- `customer_id`
      }
      if (!is.null(`customer_email`)) {
        if (!(is.character(`customer_email`) && length(`customer_email`) == 1)) {
          stop(paste("Error! Invalid data for `customer_email`. Must be a string:", `customer_email`))
        }
        self$`customer_email` <- `customer_email`
      }
      if (!is.null(`store_id`)) {
        if (!(is.character(`store_id`) && length(`store_id`) == 1)) {
          stop(paste("Error! Invalid data for `store_id`. Must be a string:", `store_id`))
        }
        self$`store_id` <- `store_id`
      }
      if (!is.null(`shipp_address_1`)) {
        if (!(is.character(`shipp_address_1`) && length(`shipp_address_1`) == 1)) {
          stop(paste("Error! Invalid data for `shipp_address_1`. Must be a string:", `shipp_address_1`))
        }
        self$`shipp_address_1` <- `shipp_address_1`
      }
      if (!is.null(`shipp_city`)) {
        if (!(is.character(`shipp_city`) && length(`shipp_city`) == 1)) {
          stop(paste("Error! Invalid data for `shipp_city`. Must be a string:", `shipp_city`))
        }
        self$`shipp_city` <- `shipp_city`
      }
      if (!is.null(`shipp_postcode`)) {
        if (!(is.character(`shipp_postcode`) && length(`shipp_postcode`) == 1)) {
          stop(paste("Error! Invalid data for `shipp_postcode`. Must be a string:", `shipp_postcode`))
        }
        self$`shipp_postcode` <- `shipp_postcode`
      }
      if (!is.null(`shipp_state`)) {
        if (!(is.character(`shipp_state`) && length(`shipp_state`) == 1)) {
          stop(paste("Error! Invalid data for `shipp_state`. Must be a string:", `shipp_state`))
        }
        self$`shipp_state` <- `shipp_state`
      }
      if (!is.null(`params`)) {
        if (!(is.character(`params`) && length(`params`) == 1)) {
          stop(paste("Error! Invalid data for `params`. Must be a string:", `params`))
        }
        self$`params` <- `params`
      }
      if (!is.null(`exclude`)) {
        if (!(is.character(`exclude`) && length(`exclude`) == 1)) {
          stop(paste("Error! Invalid data for `exclude`. Must be a string:", `exclude`))
        }
        self$`exclude` <- `exclude`
      }
      if (!is.null(`idempotency_key`)) {
        if (!(is.character(`idempotency_key`) && length(`idempotency_key`) == 1)) {
          stop(paste("Error! Invalid data for `idempotency_key`. Must be a string:", `idempotency_key`))
        }
        self$`idempotency_key` <- `idempotency_key`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return OrderPreestimateShippingList as a base R list.
    #' @examples
    #' # convert array of OrderPreestimateShippingList (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert OrderPreestimateShippingList to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      OrderPreestimateShippingListObject <- list()
      if (!is.null(self$`warehouse_id`)) {
        OrderPreestimateShippingListObject[["warehouse_id"]] <-
          self$`warehouse_id`
      }
      if (!is.null(self$`customer_id`)) {
        OrderPreestimateShippingListObject[["customer_id"]] <-
          self$`customer_id`
      }
      if (!is.null(self$`customer_email`)) {
        OrderPreestimateShippingListObject[["customer_email"]] <-
          self$`customer_email`
      }
      if (!is.null(self$`store_id`)) {
        OrderPreestimateShippingListObject[["store_id"]] <-
          self$`store_id`
      }
      if (!is.null(self$`shipp_address_1`)) {
        OrderPreestimateShippingListObject[["shipp_address_1"]] <-
          self$`shipp_address_1`
      }
      if (!is.null(self$`shipp_city`)) {
        OrderPreestimateShippingListObject[["shipp_city"]] <-
          self$`shipp_city`
      }
      if (!is.null(self$`shipp_postcode`)) {
        OrderPreestimateShippingListObject[["shipp_postcode"]] <-
          self$`shipp_postcode`
      }
      if (!is.null(self$`shipp_state`)) {
        OrderPreestimateShippingListObject[["shipp_state"]] <-
          self$`shipp_state`
      }
      if (!is.null(self$`shipp_country`)) {
        OrderPreestimateShippingListObject[["shipp_country"]] <-
          self$`shipp_country`
      }
      if (!is.null(self$`params`)) {
        OrderPreestimateShippingListObject[["params"]] <-
          self$`params`
      }
      if (!is.null(self$`exclude`)) {
        OrderPreestimateShippingListObject[["exclude"]] <-
          self$`exclude`
      }
      if (!is.null(self$`idempotency_key`)) {
        OrderPreestimateShippingListObject[["idempotency_key"]] <-
          self$`idempotency_key`
      }
      if (!is.null(self$`order_item`)) {
        OrderPreestimateShippingListObject[["order_item"]] <-
          lapply(self$`order_item`, function(x) x$toSimpleType())
      }
      return(OrderPreestimateShippingListObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderPreestimateShippingList
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderPreestimateShippingList
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`warehouse_id`)) {
        self$`warehouse_id` <- this_object$`warehouse_id`
      }
      if (!is.null(this_object$`customer_id`)) {
        self$`customer_id` <- this_object$`customer_id`
      }
      if (!is.null(this_object$`customer_email`)) {
        self$`customer_email` <- this_object$`customer_email`
      }
      if (!is.null(this_object$`store_id`)) {
        self$`store_id` <- this_object$`store_id`
      }
      if (!is.null(this_object$`shipp_address_1`)) {
        self$`shipp_address_1` <- this_object$`shipp_address_1`
      }
      if (!is.null(this_object$`shipp_city`)) {
        self$`shipp_city` <- this_object$`shipp_city`
      }
      if (!is.null(this_object$`shipp_postcode`)) {
        self$`shipp_postcode` <- this_object$`shipp_postcode`
      }
      if (!is.null(this_object$`shipp_state`)) {
        self$`shipp_state` <- this_object$`shipp_state`
      }
      if (!is.null(this_object$`shipp_country`)) {
        self$`shipp_country` <- this_object$`shipp_country`
      }
      if (!is.null(this_object$`params`)) {
        self$`params` <- this_object$`params`
      }
      if (!is.null(this_object$`exclude`)) {
        self$`exclude` <- this_object$`exclude`
      }
      if (!is.null(this_object$`idempotency_key`)) {
        self$`idempotency_key` <- this_object$`idempotency_key`
      }
      if (!is.null(this_object$`order_item`)) {
        self$`order_item` <- ApiClient$new()$deserializeObj(this_object$`order_item`, "array[OrderPreestimateShippingListOrderItemInner]", loadNamespace("openapi"))
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return OrderPreestimateShippingList in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderPreestimateShippingList
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderPreestimateShippingList
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`warehouse_id` <- this_object$`warehouse_id`
      self$`customer_id` <- this_object$`customer_id`
      self$`customer_email` <- this_object$`customer_email`
      self$`store_id` <- this_object$`store_id`
      self$`shipp_address_1` <- this_object$`shipp_address_1`
      self$`shipp_city` <- this_object$`shipp_city`
      self$`shipp_postcode` <- this_object$`shipp_postcode`
      self$`shipp_state` <- this_object$`shipp_state`
      self$`shipp_country` <- this_object$`shipp_country`
      self$`params` <- this_object$`params`
      self$`exclude` <- this_object$`exclude`
      self$`idempotency_key` <- this_object$`idempotency_key`
      self$`order_item` <- ApiClient$new()$deserializeObj(this_object$`order_item`, "array[OrderPreestimateShippingListOrderItemInner]", loadNamespace("openapi"))
      self
    },

    #' @description
    #' Validate JSON input with respect to OrderPreestimateShippingList and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
      # check the required field `shipp_country`
      if (!is.null(input_json$`shipp_country`)) {
        if (!(is.character(input_json$`shipp_country`) && length(input_json$`shipp_country`) == 1)) {
          stop(paste("Error! Invalid data for `shipp_country`. Must be a string:", input_json$`shipp_country`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for OrderPreestimateShippingList: the required field `shipp_country` is missing."))
      }
      # check the required field `order_item`
      if (!is.null(input_json$`order_item`)) {
        stopifnot(is.vector(input_json$`order_item`), length(input_json$`order_item`) != 0)
        tmp <- sapply(input_json$`order_item`, function(x) stopifnot(R6::is.R6(x)))
      } else {
        stop(paste("The JSON input `", input, "` is invalid for OrderPreestimateShippingList: the required field `order_item` is missing."))
      }
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of OrderPreestimateShippingList
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      # check if the required `shipp_country` is null
      if (is.null(self$`shipp_country`)) {
        return(FALSE)
      }

      # check if the required `order_item` is null
      if (is.null(self$`order_item`)) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      # check if the required `shipp_country` is null
      if (is.null(self$`shipp_country`)) {
        invalid_fields["shipp_country"] <- "Non-nullable required field `shipp_country` cannot be null."
      }

      # check if the required `order_item` is null
      if (is.null(self$`order_item`)) {
        invalid_fields["order_item"] <- "Non-nullable required field `order_item` cannot be null."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# OrderPreestimateShippingList$unlock()
#
## Below is an example to define the print function
# OrderPreestimateShippingList$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# OrderPreestimateShippingList$lock()

