#' Create a new Customer
#'
#' @description
#' Customer Class
#'
#' @docType class
#' @title Customer
#' @description Customer Class
#' @format An \code{R6Class} generator object
#' @field id  character [optional]
#' @field email  character [optional]
#' @field first_name  character [optional]
#' @field last_name  character [optional]
#' @field phone  character [optional]
#' @field created_time  \link{A2CDateTime} [optional]
#' @field modified_time  \link{A2CDateTime} [optional]
#' @field group  list(\link{CustomerGroup}) [optional]
#' @field login  character [optional]
#' @field last_login  \link{A2CDateTime} [optional]
#' @field birth_day  \link{A2CDateTime} [optional]
#' @field status  character [optional]
#' @field is_guest  character [optional]
#' @field news_letter_subscription  character [optional]
#' @field consents  list(\link{CustomerConsent}) [optional]
#' @field gender  character [optional]
#' @field stores_ids  list(character) [optional]
#' @field website  character [optional]
#' @field fax  character [optional]
#' @field company  character [optional]
#' @field ip_address  character [optional]
#' @field address_book  list(\link{CustomerAddress}) [optional]
#' @field lang_id  character [optional]
#' @field orders_count  integer [optional]
#' @field last_order_id  character [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
Customer <- R6::R6Class(
  "Customer",
  public = list(
    `id` = NULL,
    `email` = NULL,
    `first_name` = NULL,
    `last_name` = NULL,
    `phone` = NULL,
    `created_time` = NULL,
    `modified_time` = NULL,
    `group` = NULL,
    `login` = NULL,
    `last_login` = NULL,
    `birth_day` = NULL,
    `status` = NULL,
    `is_guest` = NULL,
    `news_letter_subscription` = NULL,
    `consents` = NULL,
    `gender` = NULL,
    `stores_ids` = NULL,
    `website` = NULL,
    `fax` = NULL,
    `company` = NULL,
    `ip_address` = NULL,
    `address_book` = NULL,
    `lang_id` = NULL,
    `orders_count` = NULL,
    `last_order_id` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new Customer class.
    #'
    #' @param id id
    #' @param email email
    #' @param first_name first_name
    #' @param last_name last_name
    #' @param phone phone
    #' @param created_time created_time
    #' @param modified_time modified_time
    #' @param group group
    #' @param login login
    #' @param last_login last_login
    #' @param birth_day birth_day
    #' @param status status
    #' @param is_guest is_guest
    #' @param news_letter_subscription news_letter_subscription
    #' @param consents consents
    #' @param gender gender
    #' @param stores_ids stores_ids
    #' @param website website
    #' @param fax fax
    #' @param company company
    #' @param ip_address ip_address
    #' @param address_book address_book
    #' @param lang_id lang_id
    #' @param orders_count orders_count
    #' @param last_order_id last_order_id
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `email` = NULL, `first_name` = NULL, `last_name` = NULL, `phone` = NULL, `created_time` = NULL, `modified_time` = NULL, `group` = NULL, `login` = NULL, `last_login` = NULL, `birth_day` = NULL, `status` = NULL, `is_guest` = NULL, `news_letter_subscription` = NULL, `consents` = NULL, `gender` = NULL, `stores_ids` = NULL, `website` = NULL, `fax` = NULL, `company` = NULL, `ip_address` = NULL, `address_book` = NULL, `lang_id` = NULL, `orders_count` = NULL, `last_order_id` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`email`)) {
        if (!(is.character(`email`) && length(`email`) == 1)) {
          stop(paste("Error! Invalid data for `email`. Must be a string:", `email`))
        }
        self$`email` <- `email`
      }
      if (!is.null(`first_name`)) {
        if (!(is.character(`first_name`) && length(`first_name`) == 1)) {
          stop(paste("Error! Invalid data for `first_name`. Must be a string:", `first_name`))
        }
        self$`first_name` <- `first_name`
      }
      if (!is.null(`last_name`)) {
        if (!(is.character(`last_name`) && length(`last_name`) == 1)) {
          stop(paste("Error! Invalid data for `last_name`. Must be a string:", `last_name`))
        }
        self$`last_name` <- `last_name`
      }
      if (!is.null(`phone`)) {
        if (!(is.character(`phone`) && length(`phone`) == 1)) {
          stop(paste("Error! Invalid data for `phone`. Must be a string:", `phone`))
        }
        self$`phone` <- `phone`
      }
      if (!is.null(`created_time`)) {
        stopifnot(R6::is.R6(`created_time`))
        self$`created_time` <- `created_time`
      }
      if (!is.null(`modified_time`)) {
        stopifnot(R6::is.R6(`modified_time`))
        self$`modified_time` <- `modified_time`
      }
      if (!is.null(`group`)) {
        stopifnot(is.vector(`group`), length(`group`) != 0)
        sapply(`group`, function(x) stopifnot(R6::is.R6(x)))
        self$`group` <- `group`
      }
      if (!is.null(`login`)) {
        if (!(is.character(`login`) && length(`login`) == 1)) {
          stop(paste("Error! Invalid data for `login`. Must be a string:", `login`))
        }
        self$`login` <- `login`
      }
      if (!is.null(`last_login`)) {
        stopifnot(R6::is.R6(`last_login`))
        self$`last_login` <- `last_login`
      }
      if (!is.null(`birth_day`)) {
        stopifnot(R6::is.R6(`birth_day`))
        self$`birth_day` <- `birth_day`
      }
      if (!is.null(`status`)) {
        if (!(is.character(`status`) && length(`status`) == 1)) {
          stop(paste("Error! Invalid data for `status`. Must be a string:", `status`))
        }
        self$`status` <- `status`
      }
      if (!is.null(`is_guest`)) {
        if (!(is.logical(`is_guest`) && length(`is_guest`) == 1)) {
          stop(paste("Error! Invalid data for `is_guest`. Must be a boolean:", `is_guest`))
        }
        self$`is_guest` <- `is_guest`
      }
      if (!is.null(`news_letter_subscription`)) {
        if (!(is.logical(`news_letter_subscription`) && length(`news_letter_subscription`) == 1)) {
          stop(paste("Error! Invalid data for `news_letter_subscription`. Must be a boolean:", `news_letter_subscription`))
        }
        self$`news_letter_subscription` <- `news_letter_subscription`
      }
      if (!is.null(`consents`)) {
        stopifnot(is.vector(`consents`), length(`consents`) != 0)
        sapply(`consents`, function(x) stopifnot(R6::is.R6(x)))
        self$`consents` <- `consents`
      }
      if (!is.null(`gender`)) {
        if (!(is.character(`gender`) && length(`gender`) == 1)) {
          stop(paste("Error! Invalid data for `gender`. Must be a string:", `gender`))
        }
        self$`gender` <- `gender`
      }
      if (!is.null(`stores_ids`)) {
        stopifnot(is.vector(`stores_ids`), length(`stores_ids`) != 0)
        sapply(`stores_ids`, function(x) stopifnot(is.character(x)))
        self$`stores_ids` <- `stores_ids`
      }
      if (!is.null(`website`)) {
        if (!(is.character(`website`) && length(`website`) == 1)) {
          stop(paste("Error! Invalid data for `website`. Must be a string:", `website`))
        }
        self$`website` <- `website`
      }
      if (!is.null(`fax`)) {
        if (!(is.character(`fax`) && length(`fax`) == 1)) {
          stop(paste("Error! Invalid data for `fax`. Must be a string:", `fax`))
        }
        self$`fax` <- `fax`
      }
      if (!is.null(`company`)) {
        if (!(is.character(`company`) && length(`company`) == 1)) {
          stop(paste("Error! Invalid data for `company`. Must be a string:", `company`))
        }
        self$`company` <- `company`
      }
      if (!is.null(`ip_address`)) {
        if (!(is.character(`ip_address`) && length(`ip_address`) == 1)) {
          stop(paste("Error! Invalid data for `ip_address`. Must be a string:", `ip_address`))
        }
        self$`ip_address` <- `ip_address`
      }
      if (!is.null(`address_book`)) {
        stopifnot(is.vector(`address_book`), length(`address_book`) != 0)
        sapply(`address_book`, function(x) stopifnot(R6::is.R6(x)))
        self$`address_book` <- `address_book`
      }
      if (!is.null(`lang_id`)) {
        if (!(is.character(`lang_id`) && length(`lang_id`) == 1)) {
          stop(paste("Error! Invalid data for `lang_id`. Must be a string:", `lang_id`))
        }
        self$`lang_id` <- `lang_id`
      }
      if (!is.null(`orders_count`)) {
        if (!(is.numeric(`orders_count`) && length(`orders_count`) == 1)) {
          stop(paste("Error! Invalid data for `orders_count`. Must be an integer:", `orders_count`))
        }
        self$`orders_count` <- `orders_count`
      }
      if (!is.null(`last_order_id`)) {
        if (!(is.character(`last_order_id`) && length(`last_order_id`) == 1)) {
          stop(paste("Error! Invalid data for `last_order_id`. Must be a string:", `last_order_id`))
        }
        self$`last_order_id` <- `last_order_id`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return Customer as a base R list.
    #' @examples
    #' # convert array of Customer (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert Customer to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      CustomerObject <- list()
      if (!is.null(self$`id`)) {
        CustomerObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`email`)) {
        CustomerObject[["email"]] <-
          self$`email`
      }
      if (!is.null(self$`first_name`)) {
        CustomerObject[["first_name"]] <-
          self$`first_name`
      }
      if (!is.null(self$`last_name`)) {
        CustomerObject[["last_name"]] <-
          self$`last_name`
      }
      if (!is.null(self$`phone`)) {
        CustomerObject[["phone"]] <-
          self$`phone`
      }
      if (!is.null(self$`created_time`)) {
        CustomerObject[["created_time"]] <-
          self$`created_time`$toSimpleType()
      }
      if (!is.null(self$`modified_time`)) {
        CustomerObject[["modified_time"]] <-
          self$`modified_time`$toSimpleType()
      }
      if (!is.null(self$`group`)) {
        CustomerObject[["group"]] <-
          lapply(self$`group`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`login`)) {
        CustomerObject[["login"]] <-
          self$`login`
      }
      if (!is.null(self$`last_login`)) {
        CustomerObject[["last_login"]] <-
          self$`last_login`$toSimpleType()
      }
      if (!is.null(self$`birth_day`)) {
        CustomerObject[["birth_day"]] <-
          self$`birth_day`$toSimpleType()
      }
      if (!is.null(self$`status`)) {
        CustomerObject[["status"]] <-
          self$`status`
      }
      if (!is.null(self$`is_guest`)) {
        CustomerObject[["is_guest"]] <-
          self$`is_guest`
      }
      if (!is.null(self$`news_letter_subscription`)) {
        CustomerObject[["news_letter_subscription"]] <-
          self$`news_letter_subscription`
      }
      if (!is.null(self$`consents`)) {
        CustomerObject[["consents"]] <-
          lapply(self$`consents`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`gender`)) {
        CustomerObject[["gender"]] <-
          self$`gender`
      }
      if (!is.null(self$`stores_ids`)) {
        CustomerObject[["stores_ids"]] <-
          self$`stores_ids`
      }
      if (!is.null(self$`website`)) {
        CustomerObject[["website"]] <-
          self$`website`
      }
      if (!is.null(self$`fax`)) {
        CustomerObject[["fax"]] <-
          self$`fax`
      }
      if (!is.null(self$`company`)) {
        CustomerObject[["company"]] <-
          self$`company`
      }
      if (!is.null(self$`ip_address`)) {
        CustomerObject[["ip_address"]] <-
          self$`ip_address`
      }
      if (!is.null(self$`address_book`)) {
        CustomerObject[["address_book"]] <-
          lapply(self$`address_book`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`lang_id`)) {
        CustomerObject[["lang_id"]] <-
          self$`lang_id`
      }
      if (!is.null(self$`orders_count`)) {
        CustomerObject[["orders_count"]] <-
          self$`orders_count`
      }
      if (!is.null(self$`last_order_id`)) {
        CustomerObject[["last_order_id"]] <-
          self$`last_order_id`
      }
      if (!is.null(self$`additional_fields`)) {
        CustomerObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        CustomerObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(CustomerObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of Customer
    #'
    #' @param input_json the JSON input
    #' @return the instance of Customer
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`email`)) {
        self$`email` <- this_object$`email`
      }
      if (!is.null(this_object$`first_name`)) {
        self$`first_name` <- this_object$`first_name`
      }
      if (!is.null(this_object$`last_name`)) {
        self$`last_name` <- this_object$`last_name`
      }
      if (!is.null(this_object$`phone`)) {
        self$`phone` <- this_object$`phone`
      }
      if (!is.null(this_object$`created_time`)) {
        `created_time_object` <- A2CDateTime$new()
        `created_time_object`$fromJSON(jsonlite::toJSON(this_object$`created_time`, auto_unbox = TRUE, digits = NA))
        self$`created_time` <- `created_time_object`
      }
      if (!is.null(this_object$`modified_time`)) {
        `modified_time_object` <- A2CDateTime$new()
        `modified_time_object`$fromJSON(jsonlite::toJSON(this_object$`modified_time`, auto_unbox = TRUE, digits = NA))
        self$`modified_time` <- `modified_time_object`
      }
      if (!is.null(this_object$`group`)) {
        self$`group` <- ApiClient$new()$deserializeObj(this_object$`group`, "array[CustomerGroup]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`login`)) {
        self$`login` <- this_object$`login`
      }
      if (!is.null(this_object$`last_login`)) {
        `last_login_object` <- A2CDateTime$new()
        `last_login_object`$fromJSON(jsonlite::toJSON(this_object$`last_login`, auto_unbox = TRUE, digits = NA))
        self$`last_login` <- `last_login_object`
      }
      if (!is.null(this_object$`birth_day`)) {
        `birth_day_object` <- A2CDateTime$new()
        `birth_day_object`$fromJSON(jsonlite::toJSON(this_object$`birth_day`, auto_unbox = TRUE, digits = NA))
        self$`birth_day` <- `birth_day_object`
      }
      if (!is.null(this_object$`status`)) {
        self$`status` <- this_object$`status`
      }
      if (!is.null(this_object$`is_guest`)) {
        self$`is_guest` <- this_object$`is_guest`
      }
      if (!is.null(this_object$`news_letter_subscription`)) {
        self$`news_letter_subscription` <- this_object$`news_letter_subscription`
      }
      if (!is.null(this_object$`consents`)) {
        self$`consents` <- ApiClient$new()$deserializeObj(this_object$`consents`, "array[CustomerConsent]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`gender`)) {
        self$`gender` <- this_object$`gender`
      }
      if (!is.null(this_object$`stores_ids`)) {
        self$`stores_ids` <- ApiClient$new()$deserializeObj(this_object$`stores_ids`, "array[character]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`website`)) {
        self$`website` <- this_object$`website`
      }
      if (!is.null(this_object$`fax`)) {
        self$`fax` <- this_object$`fax`
      }
      if (!is.null(this_object$`company`)) {
        self$`company` <- this_object$`company`
      }
      if (!is.null(this_object$`ip_address`)) {
        self$`ip_address` <- this_object$`ip_address`
      }
      if (!is.null(this_object$`address_book`)) {
        self$`address_book` <- ApiClient$new()$deserializeObj(this_object$`address_book`, "array[CustomerAddress]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`lang_id`)) {
        self$`lang_id` <- this_object$`lang_id`
      }
      if (!is.null(this_object$`orders_count`)) {
        self$`orders_count` <- this_object$`orders_count`
      }
      if (!is.null(this_object$`last_order_id`)) {
        self$`last_order_id` <- this_object$`last_order_id`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return Customer in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of Customer
    #'
    #' @param input_json the JSON input
    #' @return the instance of Customer
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`email` <- this_object$`email`
      self$`first_name` <- this_object$`first_name`
      self$`last_name` <- this_object$`last_name`
      self$`phone` <- this_object$`phone`
      self$`created_time` <- A2CDateTime$new()$fromJSON(jsonlite::toJSON(this_object$`created_time`, auto_unbox = TRUE, digits = NA))
      self$`modified_time` <- A2CDateTime$new()$fromJSON(jsonlite::toJSON(this_object$`modified_time`, auto_unbox = TRUE, digits = NA))
      self$`group` <- ApiClient$new()$deserializeObj(this_object$`group`, "array[CustomerGroup]", loadNamespace("openapi"))
      self$`login` <- this_object$`login`
      self$`last_login` <- A2CDateTime$new()$fromJSON(jsonlite::toJSON(this_object$`last_login`, auto_unbox = TRUE, digits = NA))
      self$`birth_day` <- A2CDateTime$new()$fromJSON(jsonlite::toJSON(this_object$`birth_day`, auto_unbox = TRUE, digits = NA))
      self$`status` <- this_object$`status`
      self$`is_guest` <- this_object$`is_guest`
      self$`news_letter_subscription` <- this_object$`news_letter_subscription`
      self$`consents` <- ApiClient$new()$deserializeObj(this_object$`consents`, "array[CustomerConsent]", loadNamespace("openapi"))
      self$`gender` <- this_object$`gender`
      self$`stores_ids` <- ApiClient$new()$deserializeObj(this_object$`stores_ids`, "array[character]", loadNamespace("openapi"))
      self$`website` <- this_object$`website`
      self$`fax` <- this_object$`fax`
      self$`company` <- this_object$`company`
      self$`ip_address` <- this_object$`ip_address`
      self$`address_book` <- ApiClient$new()$deserializeObj(this_object$`address_book`, "array[CustomerAddress]", loadNamespace("openapi"))
      self$`lang_id` <- this_object$`lang_id`
      self$`orders_count` <- this_object$`orders_count`
      self$`last_order_id` <- this_object$`last_order_id`
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to Customer and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of Customer
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# Customer$unlock()
#
## Below is an example to define the print function
# Customer$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# Customer$lock()

