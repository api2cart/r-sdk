#' Create a new GiftCard
#'
#' @description
#' GiftCard Class
#'
#' @docType class
#' @title GiftCard
#' @description GiftCard Class
#' @format An \code{R6Class} generator object
#' @field id  character [optional]
#' @field code  character [optional]
#' @field name  character [optional]
#' @field type  character [optional]
#' @field currency_code  character [optional]
#' @field amount  numeric [optional]
#' @field initial_amount  numeric [optional]
#' @field status  character [optional]
#' @field created_at  character [optional]
#' @field avail_to  character [optional]
#' @field free_product_ids  character [optional]
#' @field message  character [optional]
#' @field issuer_email  character [optional]
#' @field recipient_email  character [optional]
#' @field issuer_name  character [optional]
#' @field recipient_name  character [optional]
#' @field usage_history  list(\link{CouponHistory}) [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
GiftCard <- R6::R6Class(
  "GiftCard",
  public = list(
    `id` = NULL,
    `code` = NULL,
    `name` = NULL,
    `type` = NULL,
    `currency_code` = NULL,
    `amount` = NULL,
    `initial_amount` = NULL,
    `status` = NULL,
    `created_at` = NULL,
    `avail_to` = NULL,
    `free_product_ids` = NULL,
    `message` = NULL,
    `issuer_email` = NULL,
    `recipient_email` = NULL,
    `issuer_name` = NULL,
    `recipient_name` = NULL,
    `usage_history` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new GiftCard class.
    #'
    #' @param id id
    #' @param code code
    #' @param name name
    #' @param type type
    #' @param currency_code currency_code
    #' @param amount amount
    #' @param initial_amount initial_amount
    #' @param status status
    #' @param created_at created_at
    #' @param avail_to avail_to
    #' @param free_product_ids free_product_ids
    #' @param message message
    #' @param issuer_email issuer_email
    #' @param recipient_email recipient_email
    #' @param issuer_name issuer_name
    #' @param recipient_name recipient_name
    #' @param usage_history usage_history
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `code` = NULL, `name` = NULL, `type` = NULL, `currency_code` = NULL, `amount` = NULL, `initial_amount` = NULL, `status` = NULL, `created_at` = NULL, `avail_to` = NULL, `free_product_ids` = NULL, `message` = NULL, `issuer_email` = NULL, `recipient_email` = NULL, `issuer_name` = NULL, `recipient_name` = NULL, `usage_history` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`code`)) {
        if (!(is.character(`code`) && length(`code`) == 1)) {
          stop(paste("Error! Invalid data for `code`. Must be a string:", `code`))
        }
        self$`code` <- `code`
      }
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`type`)) {
        if (!(is.character(`type`) && length(`type`) == 1)) {
          stop(paste("Error! Invalid data for `type`. Must be a string:", `type`))
        }
        self$`type` <- `type`
      }
      if (!is.null(`currency_code`)) {
        if (!(is.character(`currency_code`) && length(`currency_code`) == 1)) {
          stop(paste("Error! Invalid data for `currency_code`. Must be a string:", `currency_code`))
        }
        self$`currency_code` <- `currency_code`
      }
      if (!is.null(`amount`)) {
        self$`amount` <- `amount`
      }
      if (!is.null(`initial_amount`)) {
        self$`initial_amount` <- `initial_amount`
      }
      if (!is.null(`status`)) {
        if (!(is.character(`status`) && length(`status`) == 1)) {
          stop(paste("Error! Invalid data for `status`. Must be a string:", `status`))
        }
        self$`status` <- `status`
      }
      if (!is.null(`created_at`)) {
        if (!(is.character(`created_at`) && length(`created_at`) == 1)) {
          stop(paste("Error! Invalid data for `created_at`. Must be a string:", `created_at`))
        }
        self$`created_at` <- `created_at`
      }
      if (!is.null(`avail_to`)) {
        if (!(is.character(`avail_to`) && length(`avail_to`) == 1)) {
          stop(paste("Error! Invalid data for `avail_to`. Must be a string:", `avail_to`))
        }
        self$`avail_to` <- `avail_to`
      }
      if (!is.null(`free_product_ids`)) {
        if (!(is.character(`free_product_ids`) && length(`free_product_ids`) == 1)) {
          stop(paste("Error! Invalid data for `free_product_ids`. Must be a string:", `free_product_ids`))
        }
        self$`free_product_ids` <- `free_product_ids`
      }
      if (!is.null(`message`)) {
        if (!(is.character(`message`) && length(`message`) == 1)) {
          stop(paste("Error! Invalid data for `message`. Must be a string:", `message`))
        }
        self$`message` <- `message`
      }
      if (!is.null(`issuer_email`)) {
        if (!(is.character(`issuer_email`) && length(`issuer_email`) == 1)) {
          stop(paste("Error! Invalid data for `issuer_email`. Must be a string:", `issuer_email`))
        }
        self$`issuer_email` <- `issuer_email`
      }
      if (!is.null(`recipient_email`)) {
        if (!(is.character(`recipient_email`) && length(`recipient_email`) == 1)) {
          stop(paste("Error! Invalid data for `recipient_email`. Must be a string:", `recipient_email`))
        }
        self$`recipient_email` <- `recipient_email`
      }
      if (!is.null(`issuer_name`)) {
        if (!(is.character(`issuer_name`) && length(`issuer_name`) == 1)) {
          stop(paste("Error! Invalid data for `issuer_name`. Must be a string:", `issuer_name`))
        }
        self$`issuer_name` <- `issuer_name`
      }
      if (!is.null(`recipient_name`)) {
        if (!(is.character(`recipient_name`) && length(`recipient_name`) == 1)) {
          stop(paste("Error! Invalid data for `recipient_name`. Must be a string:", `recipient_name`))
        }
        self$`recipient_name` <- `recipient_name`
      }
      if (!is.null(`usage_history`)) {
        stopifnot(is.vector(`usage_history`), length(`usage_history`) != 0)
        sapply(`usage_history`, function(x) stopifnot(R6::is.R6(x)))
        self$`usage_history` <- `usage_history`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return GiftCard as a base R list.
    #' @examples
    #' # convert array of GiftCard (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert GiftCard to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      GiftCardObject <- list()
      if (!is.null(self$`id`)) {
        GiftCardObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`code`)) {
        GiftCardObject[["code"]] <-
          self$`code`
      }
      if (!is.null(self$`name`)) {
        GiftCardObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`type`)) {
        GiftCardObject[["type"]] <-
          self$`type`
      }
      if (!is.null(self$`currency_code`)) {
        GiftCardObject[["currency_code"]] <-
          self$`currency_code`
      }
      if (!is.null(self$`amount`)) {
        GiftCardObject[["amount"]] <-
          self$`amount`
      }
      if (!is.null(self$`initial_amount`)) {
        GiftCardObject[["initial_amount"]] <-
          self$`initial_amount`
      }
      if (!is.null(self$`status`)) {
        GiftCardObject[["status"]] <-
          self$`status`
      }
      if (!is.null(self$`created_at`)) {
        GiftCardObject[["created_at"]] <-
          self$`created_at`
      }
      if (!is.null(self$`avail_to`)) {
        GiftCardObject[["avail_to"]] <-
          self$`avail_to`
      }
      if (!is.null(self$`free_product_ids`)) {
        GiftCardObject[["free_product_ids"]] <-
          self$`free_product_ids`
      }
      if (!is.null(self$`message`)) {
        GiftCardObject[["message"]] <-
          self$`message`
      }
      if (!is.null(self$`issuer_email`)) {
        GiftCardObject[["issuer_email"]] <-
          self$`issuer_email`
      }
      if (!is.null(self$`recipient_email`)) {
        GiftCardObject[["recipient_email"]] <-
          self$`recipient_email`
      }
      if (!is.null(self$`issuer_name`)) {
        GiftCardObject[["issuer_name"]] <-
          self$`issuer_name`
      }
      if (!is.null(self$`recipient_name`)) {
        GiftCardObject[["recipient_name"]] <-
          self$`recipient_name`
      }
      if (!is.null(self$`usage_history`)) {
        GiftCardObject[["usage_history"]] <-
          lapply(self$`usage_history`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`additional_fields`)) {
        GiftCardObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        GiftCardObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(GiftCardObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of GiftCard
    #'
    #' @param input_json the JSON input
    #' @return the instance of GiftCard
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`code`)) {
        self$`code` <- this_object$`code`
      }
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`type`)) {
        self$`type` <- this_object$`type`
      }
      if (!is.null(this_object$`currency_code`)) {
        self$`currency_code` <- this_object$`currency_code`
      }
      if (!is.null(this_object$`amount`)) {
        self$`amount` <- this_object$`amount`
      }
      if (!is.null(this_object$`initial_amount`)) {
        self$`initial_amount` <- this_object$`initial_amount`
      }
      if (!is.null(this_object$`status`)) {
        self$`status` <- this_object$`status`
      }
      if (!is.null(this_object$`created_at`)) {
        self$`created_at` <- this_object$`created_at`
      }
      if (!is.null(this_object$`avail_to`)) {
        self$`avail_to` <- this_object$`avail_to`
      }
      if (!is.null(this_object$`free_product_ids`)) {
        self$`free_product_ids` <- this_object$`free_product_ids`
      }
      if (!is.null(this_object$`message`)) {
        self$`message` <- this_object$`message`
      }
      if (!is.null(this_object$`issuer_email`)) {
        self$`issuer_email` <- this_object$`issuer_email`
      }
      if (!is.null(this_object$`recipient_email`)) {
        self$`recipient_email` <- this_object$`recipient_email`
      }
      if (!is.null(this_object$`issuer_name`)) {
        self$`issuer_name` <- this_object$`issuer_name`
      }
      if (!is.null(this_object$`recipient_name`)) {
        self$`recipient_name` <- this_object$`recipient_name`
      }
      if (!is.null(this_object$`usage_history`)) {
        self$`usage_history` <- ApiClient$new()$deserializeObj(this_object$`usage_history`, "array[CouponHistory]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return GiftCard in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of GiftCard
    #'
    #' @param input_json the JSON input
    #' @return the instance of GiftCard
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`code` <- this_object$`code`
      self$`name` <- this_object$`name`
      self$`type` <- this_object$`type`
      self$`currency_code` <- this_object$`currency_code`
      self$`amount` <- this_object$`amount`
      self$`initial_amount` <- this_object$`initial_amount`
      self$`status` <- this_object$`status`
      self$`created_at` <- this_object$`created_at`
      self$`avail_to` <- this_object$`avail_to`
      self$`free_product_ids` <- this_object$`free_product_ids`
      self$`message` <- this_object$`message`
      self$`issuer_email` <- this_object$`issuer_email`
      self$`recipient_email` <- this_object$`recipient_email`
      self$`issuer_name` <- this_object$`issuer_name`
      self$`recipient_name` <- this_object$`recipient_name`
      self$`usage_history` <- ApiClient$new()$deserializeObj(this_object$`usage_history`, "array[CouponHistory]", loadNamespace("openapi"))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to GiftCard and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of GiftCard
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# GiftCard$unlock()
#
## Below is an example to define the print function
# GiftCard$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# GiftCard$lock()

