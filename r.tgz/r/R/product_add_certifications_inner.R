#' Create a new ProductAddCertificationsInner
#'
#' @description
#' ProductAddCertificationsInner Class
#'
#' @docType class
#' @title ProductAddCertificationsInner
#' @description ProductAddCertificationsInner Class
#' @format An \code{R6Class} generator object
#' @field id Certification ID character
#' @field images Certification images list(\link{ProductAddCertificationsInnerImagesInner}) [optional]
#' @field files Certification files list(\link{ProductAddCertificationsInnerFilesInner}) [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductAddCertificationsInner <- R6::R6Class(
  "ProductAddCertificationsInner",
  public = list(
    `id` = NULL,
    `images` = NULL,
    `files` = NULL,

    #' @description
    #' Initialize a new ProductAddCertificationsInner class.
    #'
    #' @param id Certification ID
    #' @param images Certification images
    #' @param files Certification files
    #' @param ... Other optional arguments.
    initialize = function(`id`, `images` = NULL, `files` = NULL, ...) {
      if (!missing(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`images`)) {
        stopifnot(is.vector(`images`), length(`images`) != 0)
        sapply(`images`, function(x) stopifnot(R6::is.R6(x)))
        self$`images` <- `images`
      }
      if (!is.null(`files`)) {
        stopifnot(is.vector(`files`), length(`files`) != 0)
        sapply(`files`, function(x) stopifnot(R6::is.R6(x)))
        self$`files` <- `files`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductAddCertificationsInner as a base R list.
    #' @examples
    #' # convert array of ProductAddCertificationsInner (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductAddCertificationsInner to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductAddCertificationsInnerObject <- list()
      if (!is.null(self$`id`)) {
        ProductAddCertificationsInnerObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`images`)) {
        ProductAddCertificationsInnerObject[["images"]] <-
          lapply(self$`images`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`files`)) {
        ProductAddCertificationsInnerObject[["files"]] <-
          lapply(self$`files`, function(x) x$toSimpleType())
      }
      return(ProductAddCertificationsInnerObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductAddCertificationsInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductAddCertificationsInner
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`images`)) {
        self$`images` <- ApiClient$new()$deserializeObj(this_object$`images`, "array[ProductAddCertificationsInnerImagesInner]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`files`)) {
        self$`files` <- ApiClient$new()$deserializeObj(this_object$`files`, "array[ProductAddCertificationsInnerFilesInner]", loadNamespace("openapi"))
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductAddCertificationsInner in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductAddCertificationsInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductAddCertificationsInner
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`images` <- ApiClient$new()$deserializeObj(this_object$`images`, "array[ProductAddCertificationsInnerImagesInner]", loadNamespace("openapi"))
      self$`files` <- ApiClient$new()$deserializeObj(this_object$`files`, "array[ProductAddCertificationsInnerFilesInner]", loadNamespace("openapi"))
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductAddCertificationsInner and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
      # check the required field `id`
      if (!is.null(input_json$`id`)) {
        if (!(is.character(input_json$`id`) && length(input_json$`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", input_json$`id`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for ProductAddCertificationsInner: the required field `id` is missing."))
      }
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductAddCertificationsInner
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      # check if the required `id` is null
      if (is.null(self$`id`)) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      # check if the required `id` is null
      if (is.null(self$`id`)) {
        invalid_fields["id"] <- "Non-nullable required field `id` cannot be null."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductAddCertificationsInner$unlock()
#
## Below is an example to define the print function
# ProductAddCertificationsInner$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductAddCertificationsInner$lock()

