#' Create a new OrderReturnUpdate
#'
#' @description
#' OrderReturnUpdate Class
#'
#' @docType class
#' @title OrderReturnUpdate
#' @description OrderReturnUpdate Class
#' @format An \code{R6Class} generator object
#' @field return_id Return ID character
#' @field order_id Defines the order id character [optional]
#' @field store_id Store Id character [optional]
#' @field item_restock Boolean, whether or not to add the line items back to the store inventory. character [optional]
#' @field return_status_id Defines return request status character [optional]
#' @field return_reason_id Defines return request reason character [optional]
#' @field return_action_id Defines return request action character [optional]
#' @field staff_note Specifies staff note character [optional]
#' @field comment Specifies return comment character [optional]
#' @field message Customer-visible message attached to the return request (updated). character [optional]
#' @field send_notifications Send notifications to customer after order was created character [optional]
#' @field reject_reason Defines return reject reason character [optional]
#' @field return_action Defines return request action character [optional]
#' @field return_reason Defines return request reason character [optional]
#' @field is_online Indicates whether refund type is online character [optional]
#' @field fee_price Specifies refund's fee price numeric [optional]
#' @field shipping_price Specifies order's shipping price numeric [optional]
#' @field idempotency_key A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong> character [optional]
#' @field order_products  list(\link{OrderReturnUpdateOrderProductsInner})
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
OrderReturnUpdate <- R6::R6Class(
  "OrderReturnUpdate",
  public = list(
    `return_id` = NULL,
    `order_id` = NULL,
    `store_id` = NULL,
    `item_restock` = NULL,
    `return_status_id` = NULL,
    `return_reason_id` = NULL,
    `return_action_id` = NULL,
    `staff_note` = NULL,
    `comment` = NULL,
    `message` = NULL,
    `send_notifications` = NULL,
    `reject_reason` = NULL,
    `return_action` = NULL,
    `return_reason` = NULL,
    `is_online` = NULL,
    `fee_price` = NULL,
    `shipping_price` = NULL,
    `idempotency_key` = NULL,
    `order_products` = NULL,

    #' @description
    #' Initialize a new OrderReturnUpdate class.
    #'
    #' @param return_id Return ID
    #' @param order_products order_products
    #' @param order_id Defines the order id
    #' @param store_id Store Id
    #' @param item_restock Boolean, whether or not to add the line items back to the store inventory.. Default to FALSE.
    #' @param return_status_id Defines return request status
    #' @param return_reason_id Defines return request reason
    #' @param return_action_id Defines return request action
    #' @param staff_note Specifies staff note
    #' @param comment Specifies return comment
    #' @param message Customer-visible message attached to the return request (updated).
    #' @param send_notifications Send notifications to customer after order was created. Default to FALSE.
    #' @param reject_reason Defines return reject reason
    #' @param return_action Defines return request action
    #' @param return_reason Defines return request reason
    #' @param is_online Indicates whether refund type is online. Default to FALSE.
    #' @param fee_price Specifies refund's fee price
    #' @param shipping_price Specifies order's shipping price. Default to 0.
    #' @param idempotency_key A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong>
    #' @param ... Other optional arguments.
    initialize = function(`return_id`, `order_products`, `order_id` = NULL, `store_id` = NULL, `item_restock` = FALSE, `return_status_id` = NULL, `return_reason_id` = NULL, `return_action_id` = NULL, `staff_note` = NULL, `comment` = NULL, `message` = NULL, `send_notifications` = FALSE, `reject_reason` = NULL, `return_action` = NULL, `return_reason` = NULL, `is_online` = FALSE, `fee_price` = NULL, `shipping_price` = 0, `idempotency_key` = NULL, ...) {
      if (!missing(`return_id`)) {
        if (!(is.character(`return_id`) && length(`return_id`) == 1)) {
          stop(paste("Error! Invalid data for `return_id`. Must be a string:", `return_id`))
        }
        self$`return_id` <- `return_id`
      }
      if (!missing(`order_products`)) {
        stopifnot(is.vector(`order_products`), length(`order_products`) != 0)
        sapply(`order_products`, function(x) stopifnot(R6::is.R6(x)))
        self$`order_products` <- `order_products`
      }
      if (!is.null(`order_id`)) {
        if (!(is.character(`order_id`) && length(`order_id`) == 1)) {
          stop(paste("Error! Invalid data for `order_id`. Must be a string:", `order_id`))
        }
        self$`order_id` <- `order_id`
      }
      if (!is.null(`store_id`)) {
        if (!(is.character(`store_id`) && length(`store_id`) == 1)) {
          stop(paste("Error! Invalid data for `store_id`. Must be a string:", `store_id`))
        }
        self$`store_id` <- `store_id`
      }
      if (!is.null(`item_restock`)) {
        if (!(is.logical(`item_restock`) && length(`item_restock`) == 1)) {
          stop(paste("Error! Invalid data for `item_restock`. Must be a boolean:", `item_restock`))
        }
        self$`item_restock` <- `item_restock`
      }
      if (!is.null(`return_status_id`)) {
        if (!(is.character(`return_status_id`) && length(`return_status_id`) == 1)) {
          stop(paste("Error! Invalid data for `return_status_id`. Must be a string:", `return_status_id`))
        }
        self$`return_status_id` <- `return_status_id`
      }
      if (!is.null(`return_reason_id`)) {
        if (!(is.character(`return_reason_id`) && length(`return_reason_id`) == 1)) {
          stop(paste("Error! Invalid data for `return_reason_id`. Must be a string:", `return_reason_id`))
        }
        self$`return_reason_id` <- `return_reason_id`
      }
      if (!is.null(`return_action_id`)) {
        if (!(is.character(`return_action_id`) && length(`return_action_id`) == 1)) {
          stop(paste("Error! Invalid data for `return_action_id`. Must be a string:", `return_action_id`))
        }
        self$`return_action_id` <- `return_action_id`
      }
      if (!is.null(`staff_note`)) {
        if (!(is.character(`staff_note`) && length(`staff_note`) == 1)) {
          stop(paste("Error! Invalid data for `staff_note`. Must be a string:", `staff_note`))
        }
        self$`staff_note` <- `staff_note`
      }
      if (!is.null(`comment`)) {
        if (!(is.character(`comment`) && length(`comment`) == 1)) {
          stop(paste("Error! Invalid data for `comment`. Must be a string:", `comment`))
        }
        self$`comment` <- `comment`
      }
      if (!is.null(`message`)) {
        if (!(is.character(`message`) && length(`message`) == 1)) {
          stop(paste("Error! Invalid data for `message`. Must be a string:", `message`))
        }
        self$`message` <- `message`
      }
      if (!is.null(`send_notifications`)) {
        if (!(is.logical(`send_notifications`) && length(`send_notifications`) == 1)) {
          stop(paste("Error! Invalid data for `send_notifications`. Must be a boolean:", `send_notifications`))
        }
        self$`send_notifications` <- `send_notifications`
      }
      if (!is.null(`reject_reason`)) {
        if (!(is.character(`reject_reason`) && length(`reject_reason`) == 1)) {
          stop(paste("Error! Invalid data for `reject_reason`. Must be a string:", `reject_reason`))
        }
        self$`reject_reason` <- `reject_reason`
      }
      if (!is.null(`return_action`)) {
        if (!(is.character(`return_action`) && length(`return_action`) == 1)) {
          stop(paste("Error! Invalid data for `return_action`. Must be a string:", `return_action`))
        }
        self$`return_action` <- `return_action`
      }
      if (!is.null(`return_reason`)) {
        if (!(is.character(`return_reason`) && length(`return_reason`) == 1)) {
          stop(paste("Error! Invalid data for `return_reason`. Must be a string:", `return_reason`))
        }
        self$`return_reason` <- `return_reason`
      }
      if (!is.null(`is_online`)) {
        if (!(is.logical(`is_online`) && length(`is_online`) == 1)) {
          stop(paste("Error! Invalid data for `is_online`. Must be a boolean:", `is_online`))
        }
        self$`is_online` <- `is_online`
      }
      if (!is.null(`fee_price`)) {
        self$`fee_price` <- `fee_price`
      }
      if (!is.null(`shipping_price`)) {
        self$`shipping_price` <- `shipping_price`
      }
      if (!is.null(`idempotency_key`)) {
        if (!(is.character(`idempotency_key`) && length(`idempotency_key`) == 1)) {
          stop(paste("Error! Invalid data for `idempotency_key`. Must be a string:", `idempotency_key`))
        }
        self$`idempotency_key` <- `idempotency_key`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return OrderReturnUpdate as a base R list.
    #' @examples
    #' # convert array of OrderReturnUpdate (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert OrderReturnUpdate to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      OrderReturnUpdateObject <- list()
      if (!is.null(self$`return_id`)) {
        OrderReturnUpdateObject[["return_id"]] <-
          self$`return_id`
      }
      if (!is.null(self$`order_id`)) {
        OrderReturnUpdateObject[["order_id"]] <-
          self$`order_id`
      }
      if (!is.null(self$`store_id`)) {
        OrderReturnUpdateObject[["store_id"]] <-
          self$`store_id`
      }
      if (!is.null(self$`item_restock`)) {
        OrderReturnUpdateObject[["item_restock"]] <-
          self$`item_restock`
      }
      if (!is.null(self$`return_status_id`)) {
        OrderReturnUpdateObject[["return_status_id"]] <-
          self$`return_status_id`
      }
      if (!is.null(self$`return_reason_id`)) {
        OrderReturnUpdateObject[["return_reason_id"]] <-
          self$`return_reason_id`
      }
      if (!is.null(self$`return_action_id`)) {
        OrderReturnUpdateObject[["return_action_id"]] <-
          self$`return_action_id`
      }
      if (!is.null(self$`staff_note`)) {
        OrderReturnUpdateObject[["staff_note"]] <-
          self$`staff_note`
      }
      if (!is.null(self$`comment`)) {
        OrderReturnUpdateObject[["comment"]] <-
          self$`comment`
      }
      if (!is.null(self$`message`)) {
        OrderReturnUpdateObject[["message"]] <-
          self$`message`
      }
      if (!is.null(self$`send_notifications`)) {
        OrderReturnUpdateObject[["send_notifications"]] <-
          self$`send_notifications`
      }
      if (!is.null(self$`reject_reason`)) {
        OrderReturnUpdateObject[["reject_reason"]] <-
          self$`reject_reason`
      }
      if (!is.null(self$`return_action`)) {
        OrderReturnUpdateObject[["return_action"]] <-
          self$`return_action`
      }
      if (!is.null(self$`return_reason`)) {
        OrderReturnUpdateObject[["return_reason"]] <-
          self$`return_reason`
      }
      if (!is.null(self$`is_online`)) {
        OrderReturnUpdateObject[["is_online"]] <-
          self$`is_online`
      }
      if (!is.null(self$`fee_price`)) {
        OrderReturnUpdateObject[["fee_price"]] <-
          self$`fee_price`
      }
      if (!is.null(self$`shipping_price`)) {
        OrderReturnUpdateObject[["shipping_price"]] <-
          self$`shipping_price`
      }
      if (!is.null(self$`idempotency_key`)) {
        OrderReturnUpdateObject[["idempotency_key"]] <-
          self$`idempotency_key`
      }
      if (!is.null(self$`order_products`)) {
        OrderReturnUpdateObject[["order_products"]] <-
          lapply(self$`order_products`, function(x) x$toSimpleType())
      }
      return(OrderReturnUpdateObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderReturnUpdate
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderReturnUpdate
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`return_id`)) {
        self$`return_id` <- this_object$`return_id`
      }
      if (!is.null(this_object$`order_id`)) {
        self$`order_id` <- this_object$`order_id`
      }
      if (!is.null(this_object$`store_id`)) {
        self$`store_id` <- this_object$`store_id`
      }
      if (!is.null(this_object$`item_restock`)) {
        self$`item_restock` <- this_object$`item_restock`
      }
      if (!is.null(this_object$`return_status_id`)) {
        self$`return_status_id` <- this_object$`return_status_id`
      }
      if (!is.null(this_object$`return_reason_id`)) {
        self$`return_reason_id` <- this_object$`return_reason_id`
      }
      if (!is.null(this_object$`return_action_id`)) {
        self$`return_action_id` <- this_object$`return_action_id`
      }
      if (!is.null(this_object$`staff_note`)) {
        self$`staff_note` <- this_object$`staff_note`
      }
      if (!is.null(this_object$`comment`)) {
        self$`comment` <- this_object$`comment`
      }
      if (!is.null(this_object$`message`)) {
        self$`message` <- this_object$`message`
      }
      if (!is.null(this_object$`send_notifications`)) {
        self$`send_notifications` <- this_object$`send_notifications`
      }
      if (!is.null(this_object$`reject_reason`)) {
        self$`reject_reason` <- this_object$`reject_reason`
      }
      if (!is.null(this_object$`return_action`)) {
        self$`return_action` <- this_object$`return_action`
      }
      if (!is.null(this_object$`return_reason`)) {
        self$`return_reason` <- this_object$`return_reason`
      }
      if (!is.null(this_object$`is_online`)) {
        self$`is_online` <- this_object$`is_online`
      }
      if (!is.null(this_object$`fee_price`)) {
        self$`fee_price` <- this_object$`fee_price`
      }
      if (!is.null(this_object$`shipping_price`)) {
        self$`shipping_price` <- this_object$`shipping_price`
      }
      if (!is.null(this_object$`idempotency_key`)) {
        self$`idempotency_key` <- this_object$`idempotency_key`
      }
      if (!is.null(this_object$`order_products`)) {
        self$`order_products` <- ApiClient$new()$deserializeObj(this_object$`order_products`, "array[OrderReturnUpdateOrderProductsInner]", loadNamespace("openapi"))
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return OrderReturnUpdate in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderReturnUpdate
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderReturnUpdate
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`return_id` <- this_object$`return_id`
      self$`order_id` <- this_object$`order_id`
      self$`store_id` <- this_object$`store_id`
      self$`item_restock` <- this_object$`item_restock`
      self$`return_status_id` <- this_object$`return_status_id`
      self$`return_reason_id` <- this_object$`return_reason_id`
      self$`return_action_id` <- this_object$`return_action_id`
      self$`staff_note` <- this_object$`staff_note`
      self$`comment` <- this_object$`comment`
      self$`message` <- this_object$`message`
      self$`send_notifications` <- this_object$`send_notifications`
      self$`reject_reason` <- this_object$`reject_reason`
      self$`return_action` <- this_object$`return_action`
      self$`return_reason` <- this_object$`return_reason`
      self$`is_online` <- this_object$`is_online`
      self$`fee_price` <- this_object$`fee_price`
      self$`shipping_price` <- this_object$`shipping_price`
      self$`idempotency_key` <- this_object$`idempotency_key`
      self$`order_products` <- ApiClient$new()$deserializeObj(this_object$`order_products`, "array[OrderReturnUpdateOrderProductsInner]", loadNamespace("openapi"))
      self
    },

    #' @description
    #' Validate JSON input with respect to OrderReturnUpdate and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
      # check the required field `return_id`
      if (!is.null(input_json$`return_id`)) {
        if (!(is.character(input_json$`return_id`) && length(input_json$`return_id`) == 1)) {
          stop(paste("Error! Invalid data for `return_id`. Must be a string:", input_json$`return_id`))
        }
      } else {
        stop(paste("The JSON input `", input, "` is invalid for OrderReturnUpdate: the required field `return_id` is missing."))
      }
      # check the required field `order_products`
      if (!is.null(input_json$`order_products`)) {
        stopifnot(is.vector(input_json$`order_products`), length(input_json$`order_products`) != 0)
        tmp <- sapply(input_json$`order_products`, function(x) stopifnot(R6::is.R6(x)))
      } else {
        stop(paste("The JSON input `", input, "` is invalid for OrderReturnUpdate: the required field `order_products` is missing."))
      }
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of OrderReturnUpdate
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      # check if the required `return_id` is null
      if (is.null(self$`return_id`)) {
        return(FALSE)
      }

      # check if the required `order_products` is null
      if (is.null(self$`order_products`)) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      # check if the required `return_id` is null
      if (is.null(self$`return_id`)) {
        invalid_fields["return_id"] <- "Non-nullable required field `return_id` cannot be null."
      }

      # check if the required `order_products` is null
      if (is.null(self$`order_products`)) {
        invalid_fields["order_products"] <- "Non-nullable required field `order_products` cannot be null."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# OrderReturnUpdate$unlock()
#
## Below is an example to define the print function
# OrderReturnUpdate$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# OrderReturnUpdate$lock()

