#' Create a new ResponseWebhookCountResult
#'
#' @description
#' ResponseWebhookCountResult Class
#'
#' @docType class
#' @title ResponseWebhookCountResult
#' @description ResponseWebhookCountResult Class
#' @format An \code{R6Class} generator object
#' @field webhook_count  integer [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ResponseWebhookCountResult <- R6::R6Class(
  "ResponseWebhookCountResult",
  public = list(
    `webhook_count` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new ResponseWebhookCountResult class.
    #'
    #' @param webhook_count webhook_count
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`webhook_count` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`webhook_count`)) {
        if (!(is.numeric(`webhook_count`) && length(`webhook_count`) == 1)) {
          stop(paste("Error! Invalid data for `webhook_count`. Must be an integer:", `webhook_count`))
        }
        self$`webhook_count` <- `webhook_count`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ResponseWebhookCountResult as a base R list.
    #' @examples
    #' # convert array of ResponseWebhookCountResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ResponseWebhookCountResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ResponseWebhookCountResultObject <- list()
      if (!is.null(self$`webhook_count`)) {
        ResponseWebhookCountResultObject[["webhook_count"]] <-
          self$`webhook_count`
      }
      if (!is.null(self$`additional_fields`)) {
        ResponseWebhookCountResultObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        ResponseWebhookCountResultObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(ResponseWebhookCountResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ResponseWebhookCountResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ResponseWebhookCountResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`webhook_count`)) {
        self$`webhook_count` <- this_object$`webhook_count`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ResponseWebhookCountResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ResponseWebhookCountResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ResponseWebhookCountResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`webhook_count` <- this_object$`webhook_count`
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to ResponseWebhookCountResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ResponseWebhookCountResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ResponseWebhookCountResult$unlock()
#
## Below is an example to define the print function
# ResponseWebhookCountResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ResponseWebhookCountResult$lock()

