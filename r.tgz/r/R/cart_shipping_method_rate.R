#' Create a new CartShippingMethodRate
#'
#' @description
#' CartShippingMethodRate Class
#'
#' @docType class
#' @title CartShippingMethodRate
#' @description CartShippingMethodRate Class
#' @format An \code{R6Class} generator object
#' @field min_weight  character [optional]
#' @field max_weight  character [optional]
#' @field min_order_amount  character [optional]
#' @field max_order_amount  character [optional]
#' @field min_items_count  character [optional]
#' @field max_items_count  character [optional]
#' @field price  character [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
CartShippingMethodRate <- R6::R6Class(
  "CartShippingMethodRate",
  public = list(
    `min_weight` = NULL,
    `max_weight` = NULL,
    `min_order_amount` = NULL,
    `max_order_amount` = NULL,
    `min_items_count` = NULL,
    `max_items_count` = NULL,
    `price` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new CartShippingMethodRate class.
    #'
    #' @param min_weight min_weight
    #' @param max_weight max_weight
    #' @param min_order_amount min_order_amount
    #' @param max_order_amount max_order_amount
    #' @param min_items_count min_items_count
    #' @param max_items_count max_items_count
    #' @param price price
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`min_weight` = NULL, `max_weight` = NULL, `min_order_amount` = NULL, `max_order_amount` = NULL, `min_items_count` = NULL, `max_items_count` = NULL, `price` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`min_weight`)) {
        if (!(is.character(`min_weight`) && length(`min_weight`) == 1)) {
          stop(paste("Error! Invalid data for `min_weight`. Must be a string:", `min_weight`))
        }
        self$`min_weight` <- `min_weight`
      }
      if (!is.null(`max_weight`)) {
        if (!(is.character(`max_weight`) && length(`max_weight`) == 1)) {
          stop(paste("Error! Invalid data for `max_weight`. Must be a string:", `max_weight`))
        }
        self$`max_weight` <- `max_weight`
      }
      if (!is.null(`min_order_amount`)) {
        if (!(is.character(`min_order_amount`) && length(`min_order_amount`) == 1)) {
          stop(paste("Error! Invalid data for `min_order_amount`. Must be a string:", `min_order_amount`))
        }
        self$`min_order_amount` <- `min_order_amount`
      }
      if (!is.null(`max_order_amount`)) {
        if (!(is.character(`max_order_amount`) && length(`max_order_amount`) == 1)) {
          stop(paste("Error! Invalid data for `max_order_amount`. Must be a string:", `max_order_amount`))
        }
        self$`max_order_amount` <- `max_order_amount`
      }
      if (!is.null(`min_items_count`)) {
        if (!(is.character(`min_items_count`) && length(`min_items_count`) == 1)) {
          stop(paste("Error! Invalid data for `min_items_count`. Must be a string:", `min_items_count`))
        }
        self$`min_items_count` <- `min_items_count`
      }
      if (!is.null(`max_items_count`)) {
        if (!(is.character(`max_items_count`) && length(`max_items_count`) == 1)) {
          stop(paste("Error! Invalid data for `max_items_count`. Must be a string:", `max_items_count`))
        }
        self$`max_items_count` <- `max_items_count`
      }
      if (!is.null(`price`)) {
        if (!(is.character(`price`) && length(`price`) == 1)) {
          stop(paste("Error! Invalid data for `price`. Must be a string:", `price`))
        }
        self$`price` <- `price`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return CartShippingMethodRate as a base R list.
    #' @examples
    #' # convert array of CartShippingMethodRate (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert CartShippingMethodRate to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      CartShippingMethodRateObject <- list()
      if (!is.null(self$`min_weight`)) {
        CartShippingMethodRateObject[["min_weight"]] <-
          self$`min_weight`
      }
      if (!is.null(self$`max_weight`)) {
        CartShippingMethodRateObject[["max_weight"]] <-
          self$`max_weight`
      }
      if (!is.null(self$`min_order_amount`)) {
        CartShippingMethodRateObject[["min_order_amount"]] <-
          self$`min_order_amount`
      }
      if (!is.null(self$`max_order_amount`)) {
        CartShippingMethodRateObject[["max_order_amount"]] <-
          self$`max_order_amount`
      }
      if (!is.null(self$`min_items_count`)) {
        CartShippingMethodRateObject[["min_items_count"]] <-
          self$`min_items_count`
      }
      if (!is.null(self$`max_items_count`)) {
        CartShippingMethodRateObject[["max_items_count"]] <-
          self$`max_items_count`
      }
      if (!is.null(self$`price`)) {
        CartShippingMethodRateObject[["price"]] <-
          self$`price`
      }
      if (!is.null(self$`additional_fields`)) {
        CartShippingMethodRateObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        CartShippingMethodRateObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(CartShippingMethodRateObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of CartShippingMethodRate
    #'
    #' @param input_json the JSON input
    #' @return the instance of CartShippingMethodRate
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`min_weight`)) {
        self$`min_weight` <- this_object$`min_weight`
      }
      if (!is.null(this_object$`max_weight`)) {
        self$`max_weight` <- this_object$`max_weight`
      }
      if (!is.null(this_object$`min_order_amount`)) {
        self$`min_order_amount` <- this_object$`min_order_amount`
      }
      if (!is.null(this_object$`max_order_amount`)) {
        self$`max_order_amount` <- this_object$`max_order_amount`
      }
      if (!is.null(this_object$`min_items_count`)) {
        self$`min_items_count` <- this_object$`min_items_count`
      }
      if (!is.null(this_object$`max_items_count`)) {
        self$`max_items_count` <- this_object$`max_items_count`
      }
      if (!is.null(this_object$`price`)) {
        self$`price` <- this_object$`price`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return CartShippingMethodRate in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of CartShippingMethodRate
    #'
    #' @param input_json the JSON input
    #' @return the instance of CartShippingMethodRate
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`min_weight` <- this_object$`min_weight`
      self$`max_weight` <- this_object$`max_weight`
      self$`min_order_amount` <- this_object$`min_order_amount`
      self$`max_order_amount` <- this_object$`max_order_amount`
      self$`min_items_count` <- this_object$`min_items_count`
      self$`max_items_count` <- this_object$`max_items_count`
      self$`price` <- this_object$`price`
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to CartShippingMethodRate and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of CartShippingMethodRate
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# CartShippingMethodRate$unlock()
#
## Below is an example to define the print function
# CartShippingMethodRate$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# CartShippingMethodRate$lock()

