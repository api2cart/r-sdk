#' Create a new BasketLiveShippingServiceList200ResponseResult
#'
#' @description
#' BasketLiveShippingServiceList200ResponseResult Class
#'
#' @docType class
#' @title BasketLiveShippingServiceList200ResponseResult
#' @description BasketLiveShippingServiceList200ResponseResult Class
#' @format An \code{R6Class} generator object
#' @field live_shipping_services  list(\link{BasketLiveShippingService}) [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
BasketLiveShippingServiceList200ResponseResult <- R6::R6Class(
  "BasketLiveShippingServiceList200ResponseResult",
  public = list(
    `live_shipping_services` = NULL,

    #' @description
    #' Initialize a new BasketLiveShippingServiceList200ResponseResult class.
    #'
    #' @param live_shipping_services live_shipping_services
    #' @param ... Other optional arguments.
    initialize = function(`live_shipping_services` = NULL, ...) {
      if (!is.null(`live_shipping_services`)) {
        stopifnot(is.vector(`live_shipping_services`), length(`live_shipping_services`) != 0)
        sapply(`live_shipping_services`, function(x) stopifnot(R6::is.R6(x)))
        self$`live_shipping_services` <- `live_shipping_services`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return BasketLiveShippingServiceList200ResponseResult as a base R list.
    #' @examples
    #' # convert array of BasketLiveShippingServiceList200ResponseResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert BasketLiveShippingServiceList200ResponseResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      BasketLiveShippingServiceList200ResponseResultObject <- list()
      if (!is.null(self$`live_shipping_services`)) {
        BasketLiveShippingServiceList200ResponseResultObject[["live_shipping_services"]] <-
          lapply(self$`live_shipping_services`, function(x) x$toSimpleType())
      }
      return(BasketLiveShippingServiceList200ResponseResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of BasketLiveShippingServiceList200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of BasketLiveShippingServiceList200ResponseResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`live_shipping_services`)) {
        self$`live_shipping_services` <- ApiClient$new()$deserializeObj(this_object$`live_shipping_services`, "array[BasketLiveShippingService]", loadNamespace("openapi"))
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return BasketLiveShippingServiceList200ResponseResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of BasketLiveShippingServiceList200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of BasketLiveShippingServiceList200ResponseResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`live_shipping_services` <- ApiClient$new()$deserializeObj(this_object$`live_shipping_services`, "array[BasketLiveShippingService]", loadNamespace("openapi"))
      self
    },

    #' @description
    #' Validate JSON input with respect to BasketLiveShippingServiceList200ResponseResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of BasketLiveShippingServiceList200ResponseResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# BasketLiveShippingServiceList200ResponseResult$unlock()
#
## Below is an example to define the print function
# BasketLiveShippingServiceList200ResponseResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# BasketLiveShippingServiceList200ResponseResult$lock()

