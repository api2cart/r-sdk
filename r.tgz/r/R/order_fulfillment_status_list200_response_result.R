#' Create a new OrderFulfillmentStatusList200ResponseResult
#'
#' @description
#' OrderFulfillmentStatusList200ResponseResult Class
#'
#' @docType class
#' @title OrderFulfillmentStatusList200ResponseResult
#' @description OrderFulfillmentStatusList200ResponseResult Class
#' @format An \code{R6Class} generator object
#' @field order_fulfillment_statuses  list(\link{OrderFinancialStatusList200ResponseResultOrderFinancialStatusesInner}) [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
OrderFulfillmentStatusList200ResponseResult <- R6::R6Class(
  "OrderFulfillmentStatusList200ResponseResult",
  public = list(
    `order_fulfillment_statuses` = NULL,

    #' @description
    #' Initialize a new OrderFulfillmentStatusList200ResponseResult class.
    #'
    #' @param order_fulfillment_statuses order_fulfillment_statuses
    #' @param ... Other optional arguments.
    initialize = function(`order_fulfillment_statuses` = NULL, ...) {
      if (!is.null(`order_fulfillment_statuses`)) {
        stopifnot(is.vector(`order_fulfillment_statuses`), length(`order_fulfillment_statuses`) != 0)
        sapply(`order_fulfillment_statuses`, function(x) stopifnot(R6::is.R6(x)))
        self$`order_fulfillment_statuses` <- `order_fulfillment_statuses`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return OrderFulfillmentStatusList200ResponseResult as a base R list.
    #' @examples
    #' # convert array of OrderFulfillmentStatusList200ResponseResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert OrderFulfillmentStatusList200ResponseResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      OrderFulfillmentStatusList200ResponseResultObject <- list()
      if (!is.null(self$`order_fulfillment_statuses`)) {
        OrderFulfillmentStatusList200ResponseResultObject[["order_fulfillment_statuses"]] <-
          lapply(self$`order_fulfillment_statuses`, function(x) x$toSimpleType())
      }
      return(OrderFulfillmentStatusList200ResponseResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderFulfillmentStatusList200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderFulfillmentStatusList200ResponseResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`order_fulfillment_statuses`)) {
        self$`order_fulfillment_statuses` <- ApiClient$new()$deserializeObj(this_object$`order_fulfillment_statuses`, "array[OrderFinancialStatusList200ResponseResultOrderFinancialStatusesInner]", loadNamespace("openapi"))
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return OrderFulfillmentStatusList200ResponseResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderFulfillmentStatusList200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderFulfillmentStatusList200ResponseResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`order_fulfillment_statuses` <- ApiClient$new()$deserializeObj(this_object$`order_fulfillment_statuses`, "array[OrderFinancialStatusList200ResponseResultOrderFinancialStatusesInner]", loadNamespace("openapi"))
      self
    },

    #' @description
    #' Validate JSON input with respect to OrderFulfillmentStatusList200ResponseResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of OrderFulfillmentStatusList200ResponseResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# OrderFulfillmentStatusList200ResponseResult$unlock()
#
## Below is an example to define the print function
# OrderFulfillmentStatusList200ResponseResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# OrderFulfillmentStatusList200ResponseResult$lock()

