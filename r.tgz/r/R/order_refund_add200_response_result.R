#' Create a new OrderRefundAdd200ResponseResult
#'
#' @description
#' OrderRefundAdd200ResponseResult Class
#'
#' @docType class
#' @title OrderRefundAdd200ResponseResult
#' @description OrderRefundAdd200ResponseResult Class
#' @format An \code{R6Class} generator object
#' @field refund_id  character [optional]
#' @field additional_refund_ids  character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
OrderRefundAdd200ResponseResult <- R6::R6Class(
  "OrderRefundAdd200ResponseResult",
  public = list(
    `refund_id` = NULL,
    `additional_refund_ids` = NULL,

    #' @description
    #' Initialize a new OrderRefundAdd200ResponseResult class.
    #'
    #' @param refund_id refund_id
    #' @param additional_refund_ids additional_refund_ids
    #' @param ... Other optional arguments.
    initialize = function(`refund_id` = NULL, `additional_refund_ids` = NULL, ...) {
      if (!is.null(`refund_id`)) {
        if (!(is.character(`refund_id`) && length(`refund_id`) == 1)) {
          stop(paste("Error! Invalid data for `refund_id`. Must be a string:", `refund_id`))
        }
        self$`refund_id` <- `refund_id`
      }
      if (!is.null(`additional_refund_ids`)) {
        if (!(is.character(`additional_refund_ids`) && length(`additional_refund_ids`) == 1)) {
          stop(paste("Error! Invalid data for `additional_refund_ids`. Must be a string:", `additional_refund_ids`))
        }
        self$`additional_refund_ids` <- `additional_refund_ids`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return OrderRefundAdd200ResponseResult as a base R list.
    #' @examples
    #' # convert array of OrderRefundAdd200ResponseResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert OrderRefundAdd200ResponseResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      OrderRefundAdd200ResponseResultObject <- list()
      if (!is.null(self$`refund_id`)) {
        OrderRefundAdd200ResponseResultObject[["refund_id"]] <-
          self$`refund_id`
      }
      if (!is.null(self$`additional_refund_ids`)) {
        OrderRefundAdd200ResponseResultObject[["additional_refund_ids"]] <-
          self$`additional_refund_ids`
      }
      return(OrderRefundAdd200ResponseResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderRefundAdd200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderRefundAdd200ResponseResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`refund_id`)) {
        self$`refund_id` <- this_object$`refund_id`
      }
      if (!is.null(this_object$`additional_refund_ids`)) {
        self$`additional_refund_ids` <- this_object$`additional_refund_ids`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return OrderRefundAdd200ResponseResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderRefundAdd200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderRefundAdd200ResponseResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`refund_id` <- this_object$`refund_id`
      self$`additional_refund_ids` <- this_object$`additional_refund_ids`
      self
    },

    #' @description
    #' Validate JSON input with respect to OrderRefundAdd200ResponseResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of OrderRefundAdd200ResponseResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# OrderRefundAdd200ResponseResult$unlock()
#
## Below is an example to define the print function
# OrderRefundAdd200ResponseResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# OrderRefundAdd200ResponseResult$lock()

