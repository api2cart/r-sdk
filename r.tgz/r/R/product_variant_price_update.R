#' Create a new ProductVariantPriceUpdate
#'
#' @description
#' ProductVariantPriceUpdate Class
#'
#' @docType class
#' @title ProductVariantPriceUpdate
#' @description ProductVariantPriceUpdate Class
#' @format An \code{R6Class} generator object
#' @field id Defines the variant where the price has to be updated character [optional]
#' @field product_id Product id character [optional]
#' @field group_prices Defines variants's group prices list(\link{ProductPriceUpdateGroupPricesInner})
#' @field idempotency_key A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong> character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductVariantPriceUpdate <- R6::R6Class(
  "ProductVariantPriceUpdate",
  public = list(
    `id` = NULL,
    `product_id` = NULL,
    `group_prices` = NULL,
    `idempotency_key` = NULL,

    #' @description
    #' Initialize a new ProductVariantPriceUpdate class.
    #'
    #' @param group_prices Defines variants's group prices
    #' @param id Defines the variant where the price has to be updated
    #' @param product_id Product id
    #' @param idempotency_key A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong>
    #' @param ... Other optional arguments.
    initialize = function(`group_prices`, `id` = NULL, `product_id` = NULL, `idempotency_key` = NULL, ...) {
      if (!missing(`group_prices`)) {
        stopifnot(is.vector(`group_prices`), length(`group_prices`) != 0)
        sapply(`group_prices`, function(x) stopifnot(R6::is.R6(x)))
        self$`group_prices` <- `group_prices`
      }
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`product_id`)) {
        if (!(is.character(`product_id`) && length(`product_id`) == 1)) {
          stop(paste("Error! Invalid data for `product_id`. Must be a string:", `product_id`))
        }
        self$`product_id` <- `product_id`
      }
      if (!is.null(`idempotency_key`)) {
        if (!(is.character(`idempotency_key`) && length(`idempotency_key`) == 1)) {
          stop(paste("Error! Invalid data for `idempotency_key`. Must be a string:", `idempotency_key`))
        }
        self$`idempotency_key` <- `idempotency_key`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductVariantPriceUpdate as a base R list.
    #' @examples
    #' # convert array of ProductVariantPriceUpdate (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductVariantPriceUpdate to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductVariantPriceUpdateObject <- list()
      if (!is.null(self$`id`)) {
        ProductVariantPriceUpdateObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`product_id`)) {
        ProductVariantPriceUpdateObject[["product_id"]] <-
          self$`product_id`
      }
      if (!is.null(self$`group_prices`)) {
        ProductVariantPriceUpdateObject[["group_prices"]] <-
          lapply(self$`group_prices`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`idempotency_key`)) {
        ProductVariantPriceUpdateObject[["idempotency_key"]] <-
          self$`idempotency_key`
      }
      return(ProductVariantPriceUpdateObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductVariantPriceUpdate
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductVariantPriceUpdate
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`product_id`)) {
        self$`product_id` <- this_object$`product_id`
      }
      if (!is.null(this_object$`group_prices`)) {
        self$`group_prices` <- ApiClient$new()$deserializeObj(this_object$`group_prices`, "array[ProductPriceUpdateGroupPricesInner]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`idempotency_key`)) {
        self$`idempotency_key` <- this_object$`idempotency_key`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductVariantPriceUpdate in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductVariantPriceUpdate
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductVariantPriceUpdate
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`product_id` <- this_object$`product_id`
      self$`group_prices` <- ApiClient$new()$deserializeObj(this_object$`group_prices`, "array[ProductPriceUpdateGroupPricesInner]", loadNamespace("openapi"))
      self$`idempotency_key` <- this_object$`idempotency_key`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductVariantPriceUpdate and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
      # check the required field `group_prices`
      if (!is.null(input_json$`group_prices`)) {
        stopifnot(is.vector(input_json$`group_prices`), length(input_json$`group_prices`) != 0)
        tmp <- sapply(input_json$`group_prices`, function(x) stopifnot(R6::is.R6(x)))
      } else {
        stop(paste("The JSON input `", input, "` is invalid for ProductVariantPriceUpdate: the required field `group_prices` is missing."))
      }
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductVariantPriceUpdate
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      # check if the required `group_prices` is null
      if (is.null(self$`group_prices`)) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      # check if the required `group_prices` is null
      if (is.null(self$`group_prices`)) {
        invalid_fields["group_prices"] <- "Non-nullable required field `group_prices` cannot be null."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductVariantPriceUpdate$unlock()
#
## Below is an example to define the print function
# ProductVariantPriceUpdate$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductVariantPriceUpdate$lock()

