#' Create a new OrderAdd200ResponseResult
#'
#' @description
#' OrderAdd200ResponseResult Class
#'
#' @docType class
#' @title OrderAdd200ResponseResult
#' @description OrderAdd200ResponseResult Class
#' @format An \code{R6Class} generator object
#' @field order_id  character [optional]
#' @field id  character [optional]
#' @field customer_id  character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
OrderAdd200ResponseResult <- R6::R6Class(
  "OrderAdd200ResponseResult",
  public = list(
    `order_id` = NULL,
    `id` = NULL,
    `customer_id` = NULL,

    #' @description
    #' Initialize a new OrderAdd200ResponseResult class.
    #'
    #' @param order_id order_id
    #' @param id id
    #' @param customer_id customer_id
    #' @param ... Other optional arguments.
    initialize = function(`order_id` = NULL, `id` = NULL, `customer_id` = NULL, ...) {
      if (!is.null(`order_id`)) {
        if (!(is.character(`order_id`) && length(`order_id`) == 1)) {
          stop(paste("Error! Invalid data for `order_id`. Must be a string:", `order_id`))
        }
        self$`order_id` <- `order_id`
      }
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`customer_id`)) {
        if (!(is.character(`customer_id`) && length(`customer_id`) == 1)) {
          stop(paste("Error! Invalid data for `customer_id`. Must be a string:", `customer_id`))
        }
        self$`customer_id` <- `customer_id`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return OrderAdd200ResponseResult as a base R list.
    #' @examples
    #' # convert array of OrderAdd200ResponseResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert OrderAdd200ResponseResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      OrderAdd200ResponseResultObject <- list()
      if (!is.null(self$`order_id`)) {
        OrderAdd200ResponseResultObject[["order_id"]] <-
          self$`order_id`
      }
      if (!is.null(self$`id`)) {
        OrderAdd200ResponseResultObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`customer_id`)) {
        OrderAdd200ResponseResultObject[["customer_id"]] <-
          self$`customer_id`
      }
      return(OrderAdd200ResponseResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderAdd200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderAdd200ResponseResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`order_id`)) {
        self$`order_id` <- this_object$`order_id`
      }
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`customer_id`)) {
        self$`customer_id` <- this_object$`customer_id`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return OrderAdd200ResponseResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderAdd200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderAdd200ResponseResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`order_id` <- this_object$`order_id`
      self$`id` <- this_object$`id`
      self$`customer_id` <- this_object$`customer_id`
      self
    },

    #' @description
    #' Validate JSON input with respect to OrderAdd200ResponseResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of OrderAdd200ResponseResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# OrderAdd200ResponseResult$unlock()
#
## Below is an example to define the print function
# OrderAdd200ResponseResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# OrderAdd200ResponseResult$lock()

