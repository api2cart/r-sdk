#' Create a new TaxClassRate
#'
#' @description
#' TaxClassRate Class
#'
#' @docType class
#' @title TaxClassRate
#' @description TaxClassRate Class
#' @format An \code{R6Class} generator object
#' @field id  character [optional]
#' @field name  character [optional]
#' @field tax  numeric [optional]
#' @field tax_type  integer [optional]
#' @field tax_based_on  character [optional]
#' @field countries  list(\link{TaxClassCountries}) [optional]
#' @field cities  list(character) [optional]
#' @field address  list(character) [optional]
#' @field zip_codes  list(\link{TaxClassZipCodes}) [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
TaxClassRate <- R6::R6Class(
  "TaxClassRate",
  public = list(
    `id` = NULL,
    `name` = NULL,
    `tax` = NULL,
    `tax_type` = NULL,
    `tax_based_on` = NULL,
    `countries` = NULL,
    `cities` = NULL,
    `address` = NULL,
    `zip_codes` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new TaxClassRate class.
    #'
    #' @param id id
    #' @param name name
    #' @param tax tax
    #' @param tax_type tax_type
    #' @param tax_based_on tax_based_on
    #' @param countries countries
    #' @param cities cities
    #' @param address address
    #' @param zip_codes zip_codes
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `name` = NULL, `tax` = NULL, `tax_type` = NULL, `tax_based_on` = NULL, `countries` = NULL, `cities` = NULL, `address` = NULL, `zip_codes` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`tax`)) {
        self$`tax` <- `tax`
      }
      if (!is.null(`tax_type`)) {
        if (!(is.numeric(`tax_type`) && length(`tax_type`) == 1)) {
          stop(paste("Error! Invalid data for `tax_type`. Must be an integer:", `tax_type`))
        }
        self$`tax_type` <- `tax_type`
      }
      if (!is.null(`tax_based_on`)) {
        if (!(is.character(`tax_based_on`) && length(`tax_based_on`) == 1)) {
          stop(paste("Error! Invalid data for `tax_based_on`. Must be a string:", `tax_based_on`))
        }
        self$`tax_based_on` <- `tax_based_on`
      }
      if (!is.null(`countries`)) {
        stopifnot(is.vector(`countries`), length(`countries`) != 0)
        sapply(`countries`, function(x) stopifnot(R6::is.R6(x)))
        self$`countries` <- `countries`
      }
      if (!is.null(`cities`)) {
        stopifnot(is.vector(`cities`), length(`cities`) != 0)
        sapply(`cities`, function(x) stopifnot(is.character(x)))
        self$`cities` <- `cities`
      }
      if (!is.null(`address`)) {
        stopifnot(is.vector(`address`), length(`address`) != 0)
        sapply(`address`, function(x) stopifnot(is.character(x)))
        self$`address` <- `address`
      }
      if (!is.null(`zip_codes`)) {
        stopifnot(is.vector(`zip_codes`), length(`zip_codes`) != 0)
        sapply(`zip_codes`, function(x) stopifnot(R6::is.R6(x)))
        self$`zip_codes` <- `zip_codes`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return TaxClassRate as a base R list.
    #' @examples
    #' # convert array of TaxClassRate (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert TaxClassRate to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      TaxClassRateObject <- list()
      if (!is.null(self$`id`)) {
        TaxClassRateObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`name`)) {
        TaxClassRateObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`tax`)) {
        TaxClassRateObject[["tax"]] <-
          self$`tax`
      }
      if (!is.null(self$`tax_type`)) {
        TaxClassRateObject[["tax_type"]] <-
          self$`tax_type`
      }
      if (!is.null(self$`tax_based_on`)) {
        TaxClassRateObject[["tax_based_on"]] <-
          self$`tax_based_on`
      }
      if (!is.null(self$`countries`)) {
        TaxClassRateObject[["countries"]] <-
          lapply(self$`countries`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`cities`)) {
        TaxClassRateObject[["cities"]] <-
          self$`cities`
      }
      if (!is.null(self$`address`)) {
        TaxClassRateObject[["address"]] <-
          self$`address`
      }
      if (!is.null(self$`zip_codes`)) {
        TaxClassRateObject[["zip_codes"]] <-
          lapply(self$`zip_codes`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`additional_fields`)) {
        TaxClassRateObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        TaxClassRateObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(TaxClassRateObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of TaxClassRate
    #'
    #' @param input_json the JSON input
    #' @return the instance of TaxClassRate
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`tax`)) {
        self$`tax` <- this_object$`tax`
      }
      if (!is.null(this_object$`tax_type`)) {
        self$`tax_type` <- this_object$`tax_type`
      }
      if (!is.null(this_object$`tax_based_on`)) {
        self$`tax_based_on` <- this_object$`tax_based_on`
      }
      if (!is.null(this_object$`countries`)) {
        self$`countries` <- ApiClient$new()$deserializeObj(this_object$`countries`, "array[TaxClassCountries]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`cities`)) {
        self$`cities` <- ApiClient$new()$deserializeObj(this_object$`cities`, "array[character]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`address`)) {
        self$`address` <- ApiClient$new()$deserializeObj(this_object$`address`, "array[character]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`zip_codes`)) {
        self$`zip_codes` <- ApiClient$new()$deserializeObj(this_object$`zip_codes`, "array[TaxClassZipCodes]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return TaxClassRate in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of TaxClassRate
    #'
    #' @param input_json the JSON input
    #' @return the instance of TaxClassRate
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`name` <- this_object$`name`
      self$`tax` <- this_object$`tax`
      self$`tax_type` <- this_object$`tax_type`
      self$`tax_based_on` <- this_object$`tax_based_on`
      self$`countries` <- ApiClient$new()$deserializeObj(this_object$`countries`, "array[TaxClassCountries]", loadNamespace("openapi"))
      self$`cities` <- ApiClient$new()$deserializeObj(this_object$`cities`, "array[character]", loadNamespace("openapi"))
      self$`address` <- ApiClient$new()$deserializeObj(this_object$`address`, "array[character]", loadNamespace("openapi"))
      self$`zip_codes` <- ApiClient$new()$deserializeObj(this_object$`zip_codes`, "array[TaxClassZipCodes]", loadNamespace("openapi"))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to TaxClassRate and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of TaxClassRate
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# TaxClassRate$unlock()
#
## Below is an example to define the print function
# TaxClassRate$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# TaxClassRate$lock()

