#' Create a new OrderReturnAdd200ResponseResult
#'
#' @description
#' OrderReturnAdd200ResponseResult Class
#'
#' @docType class
#' @title OrderReturnAdd200ResponseResult
#' @description OrderReturnAdd200ResponseResult Class
#' @format An \code{R6Class} generator object
#' @field return_id  character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
OrderReturnAdd200ResponseResult <- R6::R6Class(
  "OrderReturnAdd200ResponseResult",
  public = list(
    `return_id` = NULL,

    #' @description
    #' Initialize a new OrderReturnAdd200ResponseResult class.
    #'
    #' @param return_id return_id
    #' @param ... Other optional arguments.
    initialize = function(`return_id` = NULL, ...) {
      if (!is.null(`return_id`)) {
        if (!(is.character(`return_id`) && length(`return_id`) == 1)) {
          stop(paste("Error! Invalid data for `return_id`. Must be a string:", `return_id`))
        }
        self$`return_id` <- `return_id`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return OrderReturnAdd200ResponseResult as a base R list.
    #' @examples
    #' # convert array of OrderReturnAdd200ResponseResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert OrderReturnAdd200ResponseResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      OrderReturnAdd200ResponseResultObject <- list()
      if (!is.null(self$`return_id`)) {
        OrderReturnAdd200ResponseResultObject[["return_id"]] <-
          self$`return_id`
      }
      return(OrderReturnAdd200ResponseResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderReturnAdd200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderReturnAdd200ResponseResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`return_id`)) {
        self$`return_id` <- this_object$`return_id`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return OrderReturnAdd200ResponseResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderReturnAdd200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderReturnAdd200ResponseResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`return_id` <- this_object$`return_id`
      self
    },

    #' @description
    #' Validate JSON input with respect to OrderReturnAdd200ResponseResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of OrderReturnAdd200ResponseResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# OrderReturnAdd200ResponseResult$unlock()
#
## Below is an example to define the print function
# OrderReturnAdd200ResponseResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# OrderReturnAdd200ResponseResult$lock()

