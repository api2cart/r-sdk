#' Create a new CategoryAdd200ResponseResult
#'
#' @description
#' CategoryAdd200ResponseResult Class
#'
#' @docType class
#' @title CategoryAdd200ResponseResult
#' @description CategoryAdd200ResponseResult Class
#' @format An \code{R6Class} generator object
#' @field category_id  character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
CategoryAdd200ResponseResult <- R6::R6Class(
  "CategoryAdd200ResponseResult",
  public = list(
    `category_id` = NULL,

    #' @description
    #' Initialize a new CategoryAdd200ResponseResult class.
    #'
    #' @param category_id category_id
    #' @param ... Other optional arguments.
    initialize = function(`category_id` = NULL, ...) {
      if (!is.null(`category_id`)) {
        if (!(is.character(`category_id`) && length(`category_id`) == 1)) {
          stop(paste("Error! Invalid data for `category_id`. Must be a string:", `category_id`))
        }
        self$`category_id` <- `category_id`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return CategoryAdd200ResponseResult as a base R list.
    #' @examples
    #' # convert array of CategoryAdd200ResponseResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert CategoryAdd200ResponseResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      CategoryAdd200ResponseResultObject <- list()
      if (!is.null(self$`category_id`)) {
        CategoryAdd200ResponseResultObject[["category_id"]] <-
          self$`category_id`
      }
      return(CategoryAdd200ResponseResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of CategoryAdd200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of CategoryAdd200ResponseResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`category_id`)) {
        self$`category_id` <- this_object$`category_id`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return CategoryAdd200ResponseResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of CategoryAdd200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of CategoryAdd200ResponseResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`category_id` <- this_object$`category_id`
      self
    },

    #' @description
    #' Validate JSON input with respect to CategoryAdd200ResponseResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of CategoryAdd200ResponseResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# CategoryAdd200ResponseResult$unlock()
#
## Below is an example to define the print function
# CategoryAdd200ResponseResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# CategoryAdd200ResponseResult$lock()

