#' Create a new Return
#'
#' @description
#' Return Class
#'
#' @docType class
#' @title Return
#' @description Return Class
#' @format An \code{R6Class} generator object
#' @field id  character [optional]
#' @field name  character [optional]
#' @field order_id  character [optional]
#' @field customer_id  character [optional]
#' @field store_id  character [optional]
#' @field created_at  character [optional]
#' @field modified_at  character [optional]
#' @field status  \link{ReturnStatus} [optional]
#' @field order_products  list(\link{ReturnOrderProduct}) [optional]
#' @field comment  character [optional]
#' @field staff_note  character [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
Return <- R6::R6Class(
  "Return",
  public = list(
    `id` = NULL,
    `name` = NULL,
    `order_id` = NULL,
    `customer_id` = NULL,
    `store_id` = NULL,
    `created_at` = NULL,
    `modified_at` = NULL,
    `status` = NULL,
    `order_products` = NULL,
    `comment` = NULL,
    `staff_note` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new Return class.
    #'
    #' @param id id
    #' @param name name
    #' @param order_id order_id
    #' @param customer_id customer_id
    #' @param store_id store_id
    #' @param created_at created_at
    #' @param modified_at modified_at
    #' @param status status
    #' @param order_products order_products
    #' @param comment comment
    #' @param staff_note staff_note
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `name` = NULL, `order_id` = NULL, `customer_id` = NULL, `store_id` = NULL, `created_at` = NULL, `modified_at` = NULL, `status` = NULL, `order_products` = NULL, `comment` = NULL, `staff_note` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`order_id`)) {
        if (!(is.character(`order_id`) && length(`order_id`) == 1)) {
          stop(paste("Error! Invalid data for `order_id`. Must be a string:", `order_id`))
        }
        self$`order_id` <- `order_id`
      }
      if (!is.null(`customer_id`)) {
        if (!(is.character(`customer_id`) && length(`customer_id`) == 1)) {
          stop(paste("Error! Invalid data for `customer_id`. Must be a string:", `customer_id`))
        }
        self$`customer_id` <- `customer_id`
      }
      if (!is.null(`store_id`)) {
        if (!(is.character(`store_id`) && length(`store_id`) == 1)) {
          stop(paste("Error! Invalid data for `store_id`. Must be a string:", `store_id`))
        }
        self$`store_id` <- `store_id`
      }
      if (!is.null(`created_at`)) {
        if (!(is.character(`created_at`) && length(`created_at`) == 1)) {
          stop(paste("Error! Invalid data for `created_at`. Must be a string:", `created_at`))
        }
        self$`created_at` <- `created_at`
      }
      if (!is.null(`modified_at`)) {
        if (!(is.character(`modified_at`) && length(`modified_at`) == 1)) {
          stop(paste("Error! Invalid data for `modified_at`. Must be a string:", `modified_at`))
        }
        self$`modified_at` <- `modified_at`
      }
      if (!is.null(`status`)) {
        stopifnot(R6::is.R6(`status`))
        self$`status` <- `status`
      }
      if (!is.null(`order_products`)) {
        stopifnot(is.vector(`order_products`), length(`order_products`) != 0)
        sapply(`order_products`, function(x) stopifnot(R6::is.R6(x)))
        self$`order_products` <- `order_products`
      }
      if (!is.null(`comment`)) {
        if (!(is.character(`comment`) && length(`comment`) == 1)) {
          stop(paste("Error! Invalid data for `comment`. Must be a string:", `comment`))
        }
        self$`comment` <- `comment`
      }
      if (!is.null(`staff_note`)) {
        if (!(is.character(`staff_note`) && length(`staff_note`) == 1)) {
          stop(paste("Error! Invalid data for `staff_note`. Must be a string:", `staff_note`))
        }
        self$`staff_note` <- `staff_note`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return Return as a base R list.
    #' @examples
    #' # convert array of Return (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert Return to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ReturnObject <- list()
      if (!is.null(self$`id`)) {
        ReturnObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`name`)) {
        ReturnObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`order_id`)) {
        ReturnObject[["order_id"]] <-
          self$`order_id`
      }
      if (!is.null(self$`customer_id`)) {
        ReturnObject[["customer_id"]] <-
          self$`customer_id`
      }
      if (!is.null(self$`store_id`)) {
        ReturnObject[["store_id"]] <-
          self$`store_id`
      }
      if (!is.null(self$`created_at`)) {
        ReturnObject[["created_at"]] <-
          self$`created_at`
      }
      if (!is.null(self$`modified_at`)) {
        ReturnObject[["modified_at"]] <-
          self$`modified_at`
      }
      if (!is.null(self$`status`)) {
        ReturnObject[["status"]] <-
          self$`status`$toSimpleType()
      }
      if (!is.null(self$`order_products`)) {
        ReturnObject[["order_products"]] <-
          lapply(self$`order_products`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`comment`)) {
        ReturnObject[["comment"]] <-
          self$`comment`
      }
      if (!is.null(self$`staff_note`)) {
        ReturnObject[["staff_note"]] <-
          self$`staff_note`
      }
      if (!is.null(self$`additional_fields`)) {
        ReturnObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        ReturnObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(ReturnObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of Return
    #'
    #' @param input_json the JSON input
    #' @return the instance of Return
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`order_id`)) {
        self$`order_id` <- this_object$`order_id`
      }
      if (!is.null(this_object$`customer_id`)) {
        self$`customer_id` <- this_object$`customer_id`
      }
      if (!is.null(this_object$`store_id`)) {
        self$`store_id` <- this_object$`store_id`
      }
      if (!is.null(this_object$`created_at`)) {
        self$`created_at` <- this_object$`created_at`
      }
      if (!is.null(this_object$`modified_at`)) {
        self$`modified_at` <- this_object$`modified_at`
      }
      if (!is.null(this_object$`status`)) {
        `status_object` <- ReturnStatus$new()
        `status_object`$fromJSON(jsonlite::toJSON(this_object$`status`, auto_unbox = TRUE, digits = NA))
        self$`status` <- `status_object`
      }
      if (!is.null(this_object$`order_products`)) {
        self$`order_products` <- ApiClient$new()$deserializeObj(this_object$`order_products`, "array[ReturnOrderProduct]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`comment`)) {
        self$`comment` <- this_object$`comment`
      }
      if (!is.null(this_object$`staff_note`)) {
        self$`staff_note` <- this_object$`staff_note`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return Return in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of Return
    #'
    #' @param input_json the JSON input
    #' @return the instance of Return
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`name` <- this_object$`name`
      self$`order_id` <- this_object$`order_id`
      self$`customer_id` <- this_object$`customer_id`
      self$`store_id` <- this_object$`store_id`
      self$`created_at` <- this_object$`created_at`
      self$`modified_at` <- this_object$`modified_at`
      self$`status` <- ReturnStatus$new()$fromJSON(jsonlite::toJSON(this_object$`status`, auto_unbox = TRUE, digits = NA))
      self$`order_products` <- ApiClient$new()$deserializeObj(this_object$`order_products`, "array[ReturnOrderProduct]", loadNamespace("openapi"))
      self$`comment` <- this_object$`comment`
      self$`staff_note` <- this_object$`staff_note`
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to Return and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of Return
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# Return$unlock()
#
## Below is an example to define the print function
# Return$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# Return$lock()

