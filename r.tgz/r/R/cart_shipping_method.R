#' Create a new CartShippingMethod
#'
#' @description
#' CartShippingMethod Class
#'
#' @docType class
#' @title CartShippingMethod
#' @description CartShippingMethod Class
#' @format An \code{R6Class} generator object
#' @field name  character [optional]
#' @field handling_fee  character [optional]
#' @field handling_enabled  character [optional]
#' @field handling_type  character [optional]
#' @field default_price  character [optional]
#' @field default_price_type  character [optional]
#' @field type  character [optional]
#' @field enabled  character [optional]
#' @field min_order_amount  character [optional]
#' @field rates  list(\link{CartShippingMethodRate}) [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
CartShippingMethod <- R6::R6Class(
  "CartShippingMethod",
  public = list(
    `name` = NULL,
    `handling_fee` = NULL,
    `handling_enabled` = NULL,
    `handling_type` = NULL,
    `default_price` = NULL,
    `default_price_type` = NULL,
    `type` = NULL,
    `enabled` = NULL,
    `min_order_amount` = NULL,
    `rates` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new CartShippingMethod class.
    #'
    #' @param name name
    #' @param handling_fee handling_fee
    #' @param handling_enabled handling_enabled
    #' @param handling_type handling_type
    #' @param default_price default_price
    #' @param default_price_type default_price_type
    #' @param type type
    #' @param enabled enabled
    #' @param min_order_amount min_order_amount
    #' @param rates rates
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`name` = NULL, `handling_fee` = NULL, `handling_enabled` = NULL, `handling_type` = NULL, `default_price` = NULL, `default_price_type` = NULL, `type` = NULL, `enabled` = NULL, `min_order_amount` = NULL, `rates` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`handling_fee`)) {
        if (!(is.character(`handling_fee`) && length(`handling_fee`) == 1)) {
          stop(paste("Error! Invalid data for `handling_fee`. Must be a string:", `handling_fee`))
        }
        self$`handling_fee` <- `handling_fee`
      }
      if (!is.null(`handling_enabled`)) {
        if (!(is.character(`handling_enabled`) && length(`handling_enabled`) == 1)) {
          stop(paste("Error! Invalid data for `handling_enabled`. Must be a string:", `handling_enabled`))
        }
        self$`handling_enabled` <- `handling_enabled`
      }
      if (!is.null(`handling_type`)) {
        if (!(is.character(`handling_type`) && length(`handling_type`) == 1)) {
          stop(paste("Error! Invalid data for `handling_type`. Must be a string:", `handling_type`))
        }
        self$`handling_type` <- `handling_type`
      }
      if (!is.null(`default_price`)) {
        if (!(is.character(`default_price`) && length(`default_price`) == 1)) {
          stop(paste("Error! Invalid data for `default_price`. Must be a string:", `default_price`))
        }
        self$`default_price` <- `default_price`
      }
      if (!is.null(`default_price_type`)) {
        if (!(is.character(`default_price_type`) && length(`default_price_type`) == 1)) {
          stop(paste("Error! Invalid data for `default_price_type`. Must be a string:", `default_price_type`))
        }
        self$`default_price_type` <- `default_price_type`
      }
      if (!is.null(`type`)) {
        if (!(is.character(`type`) && length(`type`) == 1)) {
          stop(paste("Error! Invalid data for `type`. Must be a string:", `type`))
        }
        self$`type` <- `type`
      }
      if (!is.null(`enabled`)) {
        if (!(is.character(`enabled`) && length(`enabled`) == 1)) {
          stop(paste("Error! Invalid data for `enabled`. Must be a string:", `enabled`))
        }
        self$`enabled` <- `enabled`
      }
      if (!is.null(`min_order_amount`)) {
        if (!(is.character(`min_order_amount`) && length(`min_order_amount`) == 1)) {
          stop(paste("Error! Invalid data for `min_order_amount`. Must be a string:", `min_order_amount`))
        }
        self$`min_order_amount` <- `min_order_amount`
      }
      if (!is.null(`rates`)) {
        stopifnot(is.vector(`rates`), length(`rates`) != 0)
        sapply(`rates`, function(x) stopifnot(R6::is.R6(x)))
        self$`rates` <- `rates`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return CartShippingMethod as a base R list.
    #' @examples
    #' # convert array of CartShippingMethod (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert CartShippingMethod to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      CartShippingMethodObject <- list()
      if (!is.null(self$`name`)) {
        CartShippingMethodObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`handling_fee`)) {
        CartShippingMethodObject[["handling_fee"]] <-
          self$`handling_fee`
      }
      if (!is.null(self$`handling_enabled`)) {
        CartShippingMethodObject[["handling_enabled"]] <-
          self$`handling_enabled`
      }
      if (!is.null(self$`handling_type`)) {
        CartShippingMethodObject[["handling_type"]] <-
          self$`handling_type`
      }
      if (!is.null(self$`default_price`)) {
        CartShippingMethodObject[["default_price"]] <-
          self$`default_price`
      }
      if (!is.null(self$`default_price_type`)) {
        CartShippingMethodObject[["default_price_type"]] <-
          self$`default_price_type`
      }
      if (!is.null(self$`type`)) {
        CartShippingMethodObject[["type"]] <-
          self$`type`
      }
      if (!is.null(self$`enabled`)) {
        CartShippingMethodObject[["enabled"]] <-
          self$`enabled`
      }
      if (!is.null(self$`min_order_amount`)) {
        CartShippingMethodObject[["min_order_amount"]] <-
          self$`min_order_amount`
      }
      if (!is.null(self$`rates`)) {
        CartShippingMethodObject[["rates"]] <-
          lapply(self$`rates`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`additional_fields`)) {
        CartShippingMethodObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        CartShippingMethodObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(CartShippingMethodObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of CartShippingMethod
    #'
    #' @param input_json the JSON input
    #' @return the instance of CartShippingMethod
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`handling_fee`)) {
        self$`handling_fee` <- this_object$`handling_fee`
      }
      if (!is.null(this_object$`handling_enabled`)) {
        self$`handling_enabled` <- this_object$`handling_enabled`
      }
      if (!is.null(this_object$`handling_type`)) {
        self$`handling_type` <- this_object$`handling_type`
      }
      if (!is.null(this_object$`default_price`)) {
        self$`default_price` <- this_object$`default_price`
      }
      if (!is.null(this_object$`default_price_type`)) {
        self$`default_price_type` <- this_object$`default_price_type`
      }
      if (!is.null(this_object$`type`)) {
        self$`type` <- this_object$`type`
      }
      if (!is.null(this_object$`enabled`)) {
        self$`enabled` <- this_object$`enabled`
      }
      if (!is.null(this_object$`min_order_amount`)) {
        self$`min_order_amount` <- this_object$`min_order_amount`
      }
      if (!is.null(this_object$`rates`)) {
        self$`rates` <- ApiClient$new()$deserializeObj(this_object$`rates`, "array[CartShippingMethodRate]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return CartShippingMethod in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of CartShippingMethod
    #'
    #' @param input_json the JSON input
    #' @return the instance of CartShippingMethod
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`name` <- this_object$`name`
      self$`handling_fee` <- this_object$`handling_fee`
      self$`handling_enabled` <- this_object$`handling_enabled`
      self$`handling_type` <- this_object$`handling_type`
      self$`default_price` <- this_object$`default_price`
      self$`default_price_type` <- this_object$`default_price_type`
      self$`type` <- this_object$`type`
      self$`enabled` <- this_object$`enabled`
      self$`min_order_amount` <- this_object$`min_order_amount`
      self$`rates` <- ApiClient$new()$deserializeObj(this_object$`rates`, "array[CartShippingMethodRate]", loadNamespace("openapi"))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to CartShippingMethod and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of CartShippingMethod
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# CartShippingMethod$unlock()
#
## Below is an example to define the print function
# CartShippingMethod$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# CartShippingMethod$lock()

