#' Create a new WebhookEvents200ResponseResultEventsInner
#'
#' @description
#' WebhookEvents200ResponseResultEventsInner Class
#'
#' @docType class
#' @title WebhookEvents200ResponseResultEventsInner
#' @description WebhookEvents200ResponseResultEventsInner Class
#' @format An \code{R6Class} generator object
#' @field webhook_name  character [optional]
#' @field entity  character [optional]
#' @field action  character [optional]
#' @field filterable_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
WebhookEvents200ResponseResultEventsInner <- R6::R6Class(
  "WebhookEvents200ResponseResultEventsInner",
  public = list(
    `webhook_name` = NULL,
    `entity` = NULL,
    `action` = NULL,
    `filterable_fields` = NULL,

    #' @description
    #' Initialize a new WebhookEvents200ResponseResultEventsInner class.
    #'
    #' @param webhook_name webhook_name
    #' @param entity entity
    #' @param action action
    #' @param filterable_fields filterable_fields
    #' @param ... Other optional arguments.
    initialize = function(`webhook_name` = NULL, `entity` = NULL, `action` = NULL, `filterable_fields` = NULL, ...) {
      if (!is.null(`webhook_name`)) {
        if (!(is.character(`webhook_name`) && length(`webhook_name`) == 1)) {
          stop(paste("Error! Invalid data for `webhook_name`. Must be a string:", `webhook_name`))
        }
        self$`webhook_name` <- `webhook_name`
      }
      if (!is.null(`entity`)) {
        if (!(is.character(`entity`) && length(`entity`) == 1)) {
          stop(paste("Error! Invalid data for `entity`. Must be a string:", `entity`))
        }
        self$`entity` <- `entity`
      }
      if (!is.null(`action`)) {
        if (!(is.character(`action`) && length(`action`) == 1)) {
          stop(paste("Error! Invalid data for `action`. Must be a string:", `action`))
        }
        self$`action` <- `action`
      }
      if (!is.null(`filterable_fields`)) {
        self$`filterable_fields` <- `filterable_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return WebhookEvents200ResponseResultEventsInner as a base R list.
    #' @examples
    #' # convert array of WebhookEvents200ResponseResultEventsInner (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert WebhookEvents200ResponseResultEventsInner to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      WebhookEvents200ResponseResultEventsInnerObject <- list()
      if (!is.null(self$`webhook_name`)) {
        WebhookEvents200ResponseResultEventsInnerObject[["webhook_name"]] <-
          self$`webhook_name`
      }
      if (!is.null(self$`entity`)) {
        WebhookEvents200ResponseResultEventsInnerObject[["entity"]] <-
          self$`entity`
      }
      if (!is.null(self$`action`)) {
        WebhookEvents200ResponseResultEventsInnerObject[["action"]] <-
          self$`action`
      }
      if (!is.null(self$`filterable_fields`)) {
        WebhookEvents200ResponseResultEventsInnerObject[["filterable_fields"]] <-
          self$`filterable_fields`
      }
      return(WebhookEvents200ResponseResultEventsInnerObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of WebhookEvents200ResponseResultEventsInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of WebhookEvents200ResponseResultEventsInner
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`webhook_name`)) {
        self$`webhook_name` <- this_object$`webhook_name`
      }
      if (!is.null(this_object$`entity`)) {
        self$`entity` <- this_object$`entity`
      }
      if (!is.null(this_object$`action`)) {
        self$`action` <- this_object$`action`
      }
      if (!is.null(this_object$`filterable_fields`)) {
        self$`filterable_fields` <- this_object$`filterable_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return WebhookEvents200ResponseResultEventsInner in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of WebhookEvents200ResponseResultEventsInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of WebhookEvents200ResponseResultEventsInner
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`webhook_name` <- this_object$`webhook_name`
      self$`entity` <- this_object$`entity`
      self$`action` <- this_object$`action`
      self$`filterable_fields` <- this_object$`filterable_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to WebhookEvents200ResponseResultEventsInner and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of WebhookEvents200ResponseResultEventsInner
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# WebhookEvents200ResponseResultEventsInner$unlock()
#
## Below is an example to define the print function
# WebhookEvents200ResponseResultEventsInner$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# WebhookEvents200ResponseResultEventsInner$lock()

