#' Create a new ProductVariantAddAttributesInner
#'
#' @description
#' ProductVariantAddAttributesInner Class
#'
#' @docType class
#' @title ProductVariantAddAttributesInner
#' @description ProductVariantAddAttributesInner Class
#' @format An \code{R6Class} generator object
#' @field attribute_name  character [optional]
#' @field attribute_value  character [optional]
#' @field attribute_price  numeric [optional]
#' @field attribute_weight  numeric [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ProductVariantAddAttributesInner <- R6::R6Class(
  "ProductVariantAddAttributesInner",
  public = list(
    `attribute_name` = NULL,
    `attribute_value` = NULL,
    `attribute_price` = NULL,
    `attribute_weight` = NULL,

    #' @description
    #' Initialize a new ProductVariantAddAttributesInner class.
    #'
    #' @param attribute_name attribute_name
    #' @param attribute_value attribute_value
    #' @param attribute_price attribute_price
    #' @param attribute_weight attribute_weight
    #' @param ... Other optional arguments.
    initialize = function(`attribute_name` = NULL, `attribute_value` = NULL, `attribute_price` = NULL, `attribute_weight` = NULL, ...) {
      if (!is.null(`attribute_name`)) {
        if (!(is.character(`attribute_name`) && length(`attribute_name`) == 1)) {
          stop(paste("Error! Invalid data for `attribute_name`. Must be a string:", `attribute_name`))
        }
        self$`attribute_name` <- `attribute_name`
      }
      if (!is.null(`attribute_value`)) {
        if (!(is.character(`attribute_value`) && length(`attribute_value`) == 1)) {
          stop(paste("Error! Invalid data for `attribute_value`. Must be a string:", `attribute_value`))
        }
        self$`attribute_value` <- `attribute_value`
      }
      if (!is.null(`attribute_price`)) {
        self$`attribute_price` <- `attribute_price`
      }
      if (!is.null(`attribute_weight`)) {
        self$`attribute_weight` <- `attribute_weight`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ProductVariantAddAttributesInner as a base R list.
    #' @examples
    #' # convert array of ProductVariantAddAttributesInner (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ProductVariantAddAttributesInner to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ProductVariantAddAttributesInnerObject <- list()
      if (!is.null(self$`attribute_name`)) {
        ProductVariantAddAttributesInnerObject[["attribute_name"]] <-
          self$`attribute_name`
      }
      if (!is.null(self$`attribute_value`)) {
        ProductVariantAddAttributesInnerObject[["attribute_value"]] <-
          self$`attribute_value`
      }
      if (!is.null(self$`attribute_price`)) {
        ProductVariantAddAttributesInnerObject[["attribute_price"]] <-
          self$`attribute_price`
      }
      if (!is.null(self$`attribute_weight`)) {
        ProductVariantAddAttributesInnerObject[["attribute_weight"]] <-
          self$`attribute_weight`
      }
      return(ProductVariantAddAttributesInnerObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductVariantAddAttributesInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductVariantAddAttributesInner
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`attribute_name`)) {
        self$`attribute_name` <- this_object$`attribute_name`
      }
      if (!is.null(this_object$`attribute_value`)) {
        self$`attribute_value` <- this_object$`attribute_value`
      }
      if (!is.null(this_object$`attribute_price`)) {
        self$`attribute_price` <- this_object$`attribute_price`
      }
      if (!is.null(this_object$`attribute_weight`)) {
        self$`attribute_weight` <- this_object$`attribute_weight`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ProductVariantAddAttributesInner in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ProductVariantAddAttributesInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of ProductVariantAddAttributesInner
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`attribute_name` <- this_object$`attribute_name`
      self$`attribute_value` <- this_object$`attribute_value`
      self$`attribute_price` <- this_object$`attribute_price`
      self$`attribute_weight` <- this_object$`attribute_weight`
      self
    },

    #' @description
    #' Validate JSON input with respect to ProductVariantAddAttributesInner and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ProductVariantAddAttributesInner
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ProductVariantAddAttributesInner$unlock()
#
## Below is an example to define the print function
# ProductVariantAddAttributesInner$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ProductVariantAddAttributesInner$lock()

