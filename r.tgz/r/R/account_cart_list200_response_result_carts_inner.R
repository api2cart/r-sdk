#' Create a new AccountCartList200ResponseResultCartsInner
#'
#' @description
#' AccountCartList200ResponseResultCartsInner Class
#'
#' @docType class
#' @title AccountCartList200ResponseResultCartsInner
#' @description AccountCartList200ResponseResultCartsInner Class
#' @format An \code{R6Class} generator object
#' @field id  character [optional]
#' @field url  character [optional]
#' @field store_key  character [optional]
#' @field cart_id  character [optional]
#' @field custom_label  character [optional]
#' @field bridge_version  character [optional]
#' @field total_calls  character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
AccountCartList200ResponseResultCartsInner <- R6::R6Class(
  "AccountCartList200ResponseResultCartsInner",
  public = list(
    `id` = NULL,
    `url` = NULL,
    `store_key` = NULL,
    `cart_id` = NULL,
    `custom_label` = NULL,
    `bridge_version` = NULL,
    `total_calls` = NULL,

    #' @description
    #' Initialize a new AccountCartList200ResponseResultCartsInner class.
    #'
    #' @param id id
    #' @param url url
    #' @param store_key store_key
    #' @param cart_id cart_id
    #' @param custom_label custom_label
    #' @param bridge_version bridge_version
    #' @param total_calls total_calls
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `url` = NULL, `store_key` = NULL, `cart_id` = NULL, `custom_label` = NULL, `bridge_version` = NULL, `total_calls` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`url`)) {
        if (!(is.character(`url`) && length(`url`) == 1)) {
          stop(paste("Error! Invalid data for `url`. Must be a string:", `url`))
        }
        self$`url` <- `url`
      }
      if (!is.null(`store_key`)) {
        if (!(is.character(`store_key`) && length(`store_key`) == 1)) {
          stop(paste("Error! Invalid data for `store_key`. Must be a string:", `store_key`))
        }
        self$`store_key` <- `store_key`
      }
      if (!is.null(`cart_id`)) {
        if (!(is.character(`cart_id`) && length(`cart_id`) == 1)) {
          stop(paste("Error! Invalid data for `cart_id`. Must be a string:", `cart_id`))
        }
        self$`cart_id` <- `cart_id`
      }
      if (!is.null(`custom_label`)) {
        if (!(is.character(`custom_label`) && length(`custom_label`) == 1)) {
          stop(paste("Error! Invalid data for `custom_label`. Must be a string:", `custom_label`))
        }
        self$`custom_label` <- `custom_label`
      }
      if (!is.null(`bridge_version`)) {
        if (!(is.character(`bridge_version`) && length(`bridge_version`) == 1)) {
          stop(paste("Error! Invalid data for `bridge_version`. Must be a string:", `bridge_version`))
        }
        self$`bridge_version` <- `bridge_version`
      }
      if (!is.null(`total_calls`)) {
        if (!(is.character(`total_calls`) && length(`total_calls`) == 1)) {
          stop(paste("Error! Invalid data for `total_calls`. Must be a string:", `total_calls`))
        }
        self$`total_calls` <- `total_calls`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return AccountCartList200ResponseResultCartsInner as a base R list.
    #' @examples
    #' # convert array of AccountCartList200ResponseResultCartsInner (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert AccountCartList200ResponseResultCartsInner to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      AccountCartList200ResponseResultCartsInnerObject <- list()
      if (!is.null(self$`id`)) {
        AccountCartList200ResponseResultCartsInnerObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`url`)) {
        AccountCartList200ResponseResultCartsInnerObject[["url"]] <-
          self$`url`
      }
      if (!is.null(self$`store_key`)) {
        AccountCartList200ResponseResultCartsInnerObject[["store_key"]] <-
          self$`store_key`
      }
      if (!is.null(self$`cart_id`)) {
        AccountCartList200ResponseResultCartsInnerObject[["cart_id"]] <-
          self$`cart_id`
      }
      if (!is.null(self$`custom_label`)) {
        AccountCartList200ResponseResultCartsInnerObject[["custom_label"]] <-
          self$`custom_label`
      }
      if (!is.null(self$`bridge_version`)) {
        AccountCartList200ResponseResultCartsInnerObject[["bridge_version"]] <-
          self$`bridge_version`
      }
      if (!is.null(self$`total_calls`)) {
        AccountCartList200ResponseResultCartsInnerObject[["total_calls"]] <-
          self$`total_calls`
      }
      return(AccountCartList200ResponseResultCartsInnerObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of AccountCartList200ResponseResultCartsInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of AccountCartList200ResponseResultCartsInner
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`url`)) {
        self$`url` <- this_object$`url`
      }
      if (!is.null(this_object$`store_key`)) {
        self$`store_key` <- this_object$`store_key`
      }
      if (!is.null(this_object$`cart_id`)) {
        self$`cart_id` <- this_object$`cart_id`
      }
      if (!is.null(this_object$`custom_label`)) {
        self$`custom_label` <- this_object$`custom_label`
      }
      if (!is.null(this_object$`bridge_version`)) {
        self$`bridge_version` <- this_object$`bridge_version`
      }
      if (!is.null(this_object$`total_calls`)) {
        self$`total_calls` <- this_object$`total_calls`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return AccountCartList200ResponseResultCartsInner in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of AccountCartList200ResponseResultCartsInner
    #'
    #' @param input_json the JSON input
    #' @return the instance of AccountCartList200ResponseResultCartsInner
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`url` <- this_object$`url`
      self$`store_key` <- this_object$`store_key`
      self$`cart_id` <- this_object$`cart_id`
      self$`custom_label` <- this_object$`custom_label`
      self$`bridge_version` <- this_object$`bridge_version`
      self$`total_calls` <- this_object$`total_calls`
      self
    },

    #' @description
    #' Validate JSON input with respect to AccountCartList200ResponseResultCartsInner and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of AccountCartList200ResponseResultCartsInner
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# AccountCartList200ResponseResultCartsInner$unlock()
#
## Below is an example to define the print function
# AccountCartList200ResponseResultCartsInner$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# AccountCartList200ResponseResultCartsInner$lock()

