#' Create a new ReturnReason
#'
#' @description
#' ReturnReason Class
#'
#' @docType class
#' @title ReturnReason
#' @description ReturnReason Class
#' @format An \code{R6Class} generator object
#' @field id  character [optional]
#' @field name  character [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ReturnReason <- R6::R6Class(
  "ReturnReason",
  public = list(
    `id` = NULL,
    `name` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new ReturnReason class.
    #'
    #' @param id id
    #' @param name name
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `name` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ReturnReason as a base R list.
    #' @examples
    #' # convert array of ReturnReason (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ReturnReason to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ReturnReasonObject <- list()
      if (!is.null(self$`id`)) {
        ReturnReasonObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`name`)) {
        ReturnReasonObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`additional_fields`)) {
        ReturnReasonObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        ReturnReasonObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(ReturnReasonObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ReturnReason
    #'
    #' @param input_json the JSON input
    #' @return the instance of ReturnReason
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ReturnReason in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ReturnReason
    #'
    #' @param input_json the JSON input
    #' @return the instance of ReturnReason
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`name` <- this_object$`name`
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to ReturnReason and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ReturnReason
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ReturnReason$unlock()
#
## Below is an example to define the print function
# ReturnReason$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ReturnReason$lock()

