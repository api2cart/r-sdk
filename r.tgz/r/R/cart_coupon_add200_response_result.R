#' Create a new CartCouponAdd200ResponseResult
#'
#' @description
#' CartCouponAdd200ResponseResult Class
#'
#' @docType class
#' @title CartCouponAdd200ResponseResult
#' @description CartCouponAdd200ResponseResult Class
#' @format An \code{R6Class} generator object
#' @field coupon_id  character [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
CartCouponAdd200ResponseResult <- R6::R6Class(
  "CartCouponAdd200ResponseResult",
  public = list(
    `coupon_id` = NULL,

    #' @description
    #' Initialize a new CartCouponAdd200ResponseResult class.
    #'
    #' @param coupon_id coupon_id
    #' @param ... Other optional arguments.
    initialize = function(`coupon_id` = NULL, ...) {
      if (!is.null(`coupon_id`)) {
        if (!(is.character(`coupon_id`) && length(`coupon_id`) == 1)) {
          stop(paste("Error! Invalid data for `coupon_id`. Must be a string:", `coupon_id`))
        }
        self$`coupon_id` <- `coupon_id`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return CartCouponAdd200ResponseResult as a base R list.
    #' @examples
    #' # convert array of CartCouponAdd200ResponseResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert CartCouponAdd200ResponseResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      CartCouponAdd200ResponseResultObject <- list()
      if (!is.null(self$`coupon_id`)) {
        CartCouponAdd200ResponseResultObject[["coupon_id"]] <-
          self$`coupon_id`
      }
      return(CartCouponAdd200ResponseResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of CartCouponAdd200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of CartCouponAdd200ResponseResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`coupon_id`)) {
        self$`coupon_id` <- this_object$`coupon_id`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return CartCouponAdd200ResponseResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of CartCouponAdd200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of CartCouponAdd200ResponseResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`coupon_id` <- this_object$`coupon_id`
      self
    },

    #' @description
    #' Validate JSON input with respect to CartCouponAdd200ResponseResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of CartCouponAdd200ResponseResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# CartCouponAdd200ResponseResult$unlock()
#
## Below is an example to define the print function
# CartCouponAdd200ResponseResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# CartCouponAdd200ResponseResult$lock()

