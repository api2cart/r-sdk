#' Create a new OrderStatusRefundItem
#'
#' @description
#' OrderStatusRefundItem Class
#'
#' @docType class
#' @title OrderStatusRefundItem
#' @description OrderStatusRefundItem Class
#' @format An \code{R6Class} generator object
#' @field product_id  character [optional]
#' @field variant_id  character [optional]
#' @field order_product_id  character [optional]
#' @field qty  numeric [optional]
#' @field refund  numeric [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
OrderStatusRefundItem <- R6::R6Class(
  "OrderStatusRefundItem",
  public = list(
    `product_id` = NULL,
    `variant_id` = NULL,
    `order_product_id` = NULL,
    `qty` = NULL,
    `refund` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new OrderStatusRefundItem class.
    #'
    #' @param product_id product_id
    #' @param variant_id variant_id
    #' @param order_product_id order_product_id
    #' @param qty qty
    #' @param refund refund
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`product_id` = NULL, `variant_id` = NULL, `order_product_id` = NULL, `qty` = NULL, `refund` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`product_id`)) {
        if (!(is.character(`product_id`) && length(`product_id`) == 1)) {
          stop(paste("Error! Invalid data for `product_id`. Must be a string:", `product_id`))
        }
        self$`product_id` <- `product_id`
      }
      if (!is.null(`variant_id`)) {
        if (!(is.character(`variant_id`) && length(`variant_id`) == 1)) {
          stop(paste("Error! Invalid data for `variant_id`. Must be a string:", `variant_id`))
        }
        self$`variant_id` <- `variant_id`
      }
      if (!is.null(`order_product_id`)) {
        if (!(is.character(`order_product_id`) && length(`order_product_id`) == 1)) {
          stop(paste("Error! Invalid data for `order_product_id`. Must be a string:", `order_product_id`))
        }
        self$`order_product_id` <- `order_product_id`
      }
      if (!is.null(`qty`)) {
        self$`qty` <- `qty`
      }
      if (!is.null(`refund`)) {
        self$`refund` <- `refund`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return OrderStatusRefundItem as a base R list.
    #' @examples
    #' # convert array of OrderStatusRefundItem (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert OrderStatusRefundItem to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      OrderStatusRefundItemObject <- list()
      if (!is.null(self$`product_id`)) {
        OrderStatusRefundItemObject[["product_id"]] <-
          self$`product_id`
      }
      if (!is.null(self$`variant_id`)) {
        OrderStatusRefundItemObject[["variant_id"]] <-
          self$`variant_id`
      }
      if (!is.null(self$`order_product_id`)) {
        OrderStatusRefundItemObject[["order_product_id"]] <-
          self$`order_product_id`
      }
      if (!is.null(self$`qty`)) {
        OrderStatusRefundItemObject[["qty"]] <-
          self$`qty`
      }
      if (!is.null(self$`refund`)) {
        OrderStatusRefundItemObject[["refund"]] <-
          self$`refund`
      }
      if (!is.null(self$`additional_fields`)) {
        OrderStatusRefundItemObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        OrderStatusRefundItemObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(OrderStatusRefundItemObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderStatusRefundItem
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderStatusRefundItem
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`product_id`)) {
        self$`product_id` <- this_object$`product_id`
      }
      if (!is.null(this_object$`variant_id`)) {
        self$`variant_id` <- this_object$`variant_id`
      }
      if (!is.null(this_object$`order_product_id`)) {
        self$`order_product_id` <- this_object$`order_product_id`
      }
      if (!is.null(this_object$`qty`)) {
        self$`qty` <- this_object$`qty`
      }
      if (!is.null(this_object$`refund`)) {
        self$`refund` <- this_object$`refund`
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return OrderStatusRefundItem in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of OrderStatusRefundItem
    #'
    #' @param input_json the JSON input
    #' @return the instance of OrderStatusRefundItem
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`product_id` <- this_object$`product_id`
      self$`variant_id` <- this_object$`variant_id`
      self$`order_product_id` <- this_object$`order_product_id`
      self$`qty` <- this_object$`qty`
      self$`refund` <- this_object$`refund`
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to OrderStatusRefundItem and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of OrderStatusRefundItem
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# OrderStatusRefundItem$unlock()
#
## Below is an example to define the print function
# OrderStatusRefundItem$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# OrderStatusRefundItem$lock()

