#' Create a new CartShippingZone
#'
#' @description
#' CartShippingZone Class
#'
#' @docType class
#' @title CartShippingZone
#' @description CartShippingZone Class
#' @format An \code{R6Class} generator object
#' @field id  character [optional]
#' @field code  character [optional]
#' @field name  character [optional]
#' @field country  character [optional]
#' @field country_iso2_codes  list(character) [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
CartShippingZone <- R6::R6Class(
  "CartShippingZone",
  public = list(
    `id` = NULL,
    `code` = NULL,
    `name` = NULL,
    `country` = NULL,
    `country_iso2_codes` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new CartShippingZone class.
    #'
    #' @param id id
    #' @param code code
    #' @param name name
    #' @param country country
    #' @param country_iso2_codes country_iso2_codes
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `code` = NULL, `name` = NULL, `country` = NULL, `country_iso2_codes` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`code`)) {
        if (!(is.character(`code`) && length(`code`) == 1)) {
          stop(paste("Error! Invalid data for `code`. Must be a string:", `code`))
        }
        self$`code` <- `code`
      }
      if (!is.null(`name`)) {
        if (!(is.character(`name`) && length(`name`) == 1)) {
          stop(paste("Error! Invalid data for `name`. Must be a string:", `name`))
        }
        self$`name` <- `name`
      }
      if (!is.null(`country`)) {
        if (!(is.character(`country`) && length(`country`) == 1)) {
          stop(paste("Error! Invalid data for `country`. Must be a string:", `country`))
        }
        self$`country` <- `country`
      }
      if (!is.null(`country_iso2_codes`)) {
        stopifnot(is.vector(`country_iso2_codes`), length(`country_iso2_codes`) != 0)
        sapply(`country_iso2_codes`, function(x) stopifnot(is.character(x)))
        self$`country_iso2_codes` <- `country_iso2_codes`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return CartShippingZone as a base R list.
    #' @examples
    #' # convert array of CartShippingZone (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert CartShippingZone to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      CartShippingZoneObject <- list()
      if (!is.null(self$`id`)) {
        CartShippingZoneObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`code`)) {
        CartShippingZoneObject[["code"]] <-
          self$`code`
      }
      if (!is.null(self$`name`)) {
        CartShippingZoneObject[["name"]] <-
          self$`name`
      }
      if (!is.null(self$`country`)) {
        CartShippingZoneObject[["country"]] <-
          self$`country`
      }
      if (!is.null(self$`country_iso2_codes`)) {
        CartShippingZoneObject[["country_iso2_codes"]] <-
          self$`country_iso2_codes`
      }
      if (!is.null(self$`additional_fields`)) {
        CartShippingZoneObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        CartShippingZoneObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(CartShippingZoneObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of CartShippingZone
    #'
    #' @param input_json the JSON input
    #' @return the instance of CartShippingZone
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`code`)) {
        self$`code` <- this_object$`code`
      }
      if (!is.null(this_object$`name`)) {
        self$`name` <- this_object$`name`
      }
      if (!is.null(this_object$`country`)) {
        self$`country` <- this_object$`country`
      }
      if (!is.null(this_object$`country_iso2_codes`)) {
        self$`country_iso2_codes` <- ApiClient$new()$deserializeObj(this_object$`country_iso2_codes`, "array[character]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return CartShippingZone in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of CartShippingZone
    #'
    #' @param input_json the JSON input
    #' @return the instance of CartShippingZone
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`code` <- this_object$`code`
      self$`name` <- this_object$`name`
      self$`country` <- this_object$`country`
      self$`country_iso2_codes` <- ApiClient$new()$deserializeObj(this_object$`country_iso2_codes`, "array[character]", loadNamespace("openapi"))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to CartShippingZone and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of CartShippingZone
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# CartShippingZone$unlock()
#
## Below is an example to define the print function
# CartShippingZone$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# CartShippingZone$lock()

