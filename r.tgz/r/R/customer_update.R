#' Create a new CustomerUpdate
#'
#' @description
#' CustomerUpdate Class
#'
#' @docType class
#' @title CustomerUpdate
#' @description CustomerUpdate Class
#' @format An \code{R6Class} generator object
#' @field id Entity id character [optional]
#' @field group_id Customer group_id character [optional]
#' @field group_ids Groups that will be assigned to a customer character [optional]
#' @field group Defines the group where the customer character [optional]
#' @field email Defines customer's email character [optional]
#' @field phone Defines customer's phone number character [optional]
#' @field first_name Defines customer's first name character [optional]
#' @field last_name Defines customer's last name character [optional]
#' @field birth_day Defines customer's birthday character [optional]
#' @field news_letter_subscription Defines whether the newsletter subscription is available for the user character [optional]
#' @field consents Defines consents to notifications list(\link{CustomerAddConsentsInner}) [optional]
#' @field tags Customer tags character [optional]
#' @field gender Defines customer's gender character [optional]
#' @field note The customer note. character [optional]
#' @field status Defines customer's status character [optional]
#' @field password Defines customer's unique password character [optional]
#' @field store_id Store Id character [optional]
#' @field idempotency_key A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong> character [optional]
#' @field address  list(\link{CustomerUpdateAddressInner}) [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
CustomerUpdate <- R6::R6Class(
  "CustomerUpdate",
  public = list(
    `id` = NULL,
    `group_id` = NULL,
    `group_ids` = NULL,
    `group` = NULL,
    `email` = NULL,
    `phone` = NULL,
    `first_name` = NULL,
    `last_name` = NULL,
    `birth_day` = NULL,
    `news_letter_subscription` = NULL,
    `consents` = NULL,
    `tags` = NULL,
    `gender` = NULL,
    `note` = NULL,
    `status` = NULL,
    `password` = NULL,
    `store_id` = NULL,
    `idempotency_key` = NULL,
    `address` = NULL,

    #' @description
    #' Initialize a new CustomerUpdate class.
    #'
    #' @param id Entity id
    #' @param group_id Customer group_id
    #' @param group_ids Groups that will be assigned to a customer
    #' @param group Defines the group where the customer
    #' @param email Defines customer's email
    #' @param phone Defines customer's phone number
    #' @param first_name Defines customer's first name
    #' @param last_name Defines customer's last name
    #' @param birth_day Defines customer's birthday
    #' @param news_letter_subscription Defines whether the newsletter subscription is available for the user
    #' @param consents Defines consents to notifications
    #' @param tags Customer tags
    #' @param gender Defines customer's gender
    #' @param note The customer note.
    #' @param status Defines customer's status
    #' @param password Defines customer's unique password
    #' @param store_id Store Id
    #' @param idempotency_key A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong>
    #' @param address address
    #' @param ... Other optional arguments.
    initialize = function(`id` = NULL, `group_id` = NULL, `group_ids` = NULL, `group` = NULL, `email` = NULL, `phone` = NULL, `first_name` = NULL, `last_name` = NULL, `birth_day` = NULL, `news_letter_subscription` = NULL, `consents` = NULL, `tags` = NULL, `gender` = NULL, `note` = NULL, `status` = NULL, `password` = NULL, `store_id` = NULL, `idempotency_key` = NULL, `address` = NULL, ...) {
      if (!is.null(`id`)) {
        if (!(is.character(`id`) && length(`id`) == 1)) {
          stop(paste("Error! Invalid data for `id`. Must be a string:", `id`))
        }
        self$`id` <- `id`
      }
      if (!is.null(`group_id`)) {
        if (!(is.character(`group_id`) && length(`group_id`) == 1)) {
          stop(paste("Error! Invalid data for `group_id`. Must be a string:", `group_id`))
        }
        self$`group_id` <- `group_id`
      }
      if (!is.null(`group_ids`)) {
        if (!(is.character(`group_ids`) && length(`group_ids`) == 1)) {
          stop(paste("Error! Invalid data for `group_ids`. Must be a string:", `group_ids`))
        }
        self$`group_ids` <- `group_ids`
      }
      if (!is.null(`group`)) {
        if (!(is.character(`group`) && length(`group`) == 1)) {
          stop(paste("Error! Invalid data for `group`. Must be a string:", `group`))
        }
        self$`group` <- `group`
      }
      if (!is.null(`email`)) {
        if (!(is.character(`email`) && length(`email`) == 1)) {
          stop(paste("Error! Invalid data for `email`. Must be a string:", `email`))
        }
        self$`email` <- `email`
      }
      if (!is.null(`phone`)) {
        if (!(is.character(`phone`) && length(`phone`) == 1)) {
          stop(paste("Error! Invalid data for `phone`. Must be a string:", `phone`))
        }
        self$`phone` <- `phone`
      }
      if (!is.null(`first_name`)) {
        if (!(is.character(`first_name`) && length(`first_name`) == 1)) {
          stop(paste("Error! Invalid data for `first_name`. Must be a string:", `first_name`))
        }
        self$`first_name` <- `first_name`
      }
      if (!is.null(`last_name`)) {
        if (!(is.character(`last_name`) && length(`last_name`) == 1)) {
          stop(paste("Error! Invalid data for `last_name`. Must be a string:", `last_name`))
        }
        self$`last_name` <- `last_name`
      }
      if (!is.null(`birth_day`)) {
        if (!(is.character(`birth_day`) && length(`birth_day`) == 1)) {
          stop(paste("Error! Invalid data for `birth_day`. Must be a string:", `birth_day`))
        }
        self$`birth_day` <- `birth_day`
      }
      if (!is.null(`news_letter_subscription`)) {
        if (!(is.logical(`news_letter_subscription`) && length(`news_letter_subscription`) == 1)) {
          stop(paste("Error! Invalid data for `news_letter_subscription`. Must be a boolean:", `news_letter_subscription`))
        }
        self$`news_letter_subscription` <- `news_letter_subscription`
      }
      if (!is.null(`consents`)) {
        stopifnot(is.vector(`consents`), length(`consents`) != 0)
        sapply(`consents`, function(x) stopifnot(R6::is.R6(x)))
        self$`consents` <- `consents`
      }
      if (!is.null(`tags`)) {
        if (!(is.character(`tags`) && length(`tags`) == 1)) {
          stop(paste("Error! Invalid data for `tags`. Must be a string:", `tags`))
        }
        self$`tags` <- `tags`
      }
      if (!is.null(`gender`)) {
        if (!(is.character(`gender`) && length(`gender`) == 1)) {
          stop(paste("Error! Invalid data for `gender`. Must be a string:", `gender`))
        }
        self$`gender` <- `gender`
      }
      if (!is.null(`note`)) {
        if (!(is.character(`note`) && length(`note`) == 1)) {
          stop(paste("Error! Invalid data for `note`. Must be a string:", `note`))
        }
        self$`note` <- `note`
      }
      if (!is.null(`status`)) {
        if (!(is.character(`status`) && length(`status`) == 1)) {
          stop(paste("Error! Invalid data for `status`. Must be a string:", `status`))
        }
        self$`status` <- `status`
      }
      if (!is.null(`password`)) {
        if (!(is.character(`password`) && length(`password`) == 1)) {
          stop(paste("Error! Invalid data for `password`. Must be a string:", `password`))
        }
        self$`password` <- `password`
      }
      if (!is.null(`store_id`)) {
        if (!(is.character(`store_id`) && length(`store_id`) == 1)) {
          stop(paste("Error! Invalid data for `store_id`. Must be a string:", `store_id`))
        }
        self$`store_id` <- `store_id`
      }
      if (!is.null(`idempotency_key`)) {
        if (!(is.character(`idempotency_key`) && length(`idempotency_key`) == 1)) {
          stop(paste("Error! Invalid data for `idempotency_key`. Must be a string:", `idempotency_key`))
        }
        self$`idempotency_key` <- `idempotency_key`
      }
      if (!is.null(`address`)) {
        stopifnot(is.vector(`address`), length(`address`) != 0)
        sapply(`address`, function(x) stopifnot(R6::is.R6(x)))
        self$`address` <- `address`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return CustomerUpdate as a base R list.
    #' @examples
    #' # convert array of CustomerUpdate (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert CustomerUpdate to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      CustomerUpdateObject <- list()
      if (!is.null(self$`id`)) {
        CustomerUpdateObject[["id"]] <-
          self$`id`
      }
      if (!is.null(self$`group_id`)) {
        CustomerUpdateObject[["group_id"]] <-
          self$`group_id`
      }
      if (!is.null(self$`group_ids`)) {
        CustomerUpdateObject[["group_ids"]] <-
          self$`group_ids`
      }
      if (!is.null(self$`group`)) {
        CustomerUpdateObject[["group"]] <-
          self$`group`
      }
      if (!is.null(self$`email`)) {
        CustomerUpdateObject[["email"]] <-
          self$`email`
      }
      if (!is.null(self$`phone`)) {
        CustomerUpdateObject[["phone"]] <-
          self$`phone`
      }
      if (!is.null(self$`first_name`)) {
        CustomerUpdateObject[["first_name"]] <-
          self$`first_name`
      }
      if (!is.null(self$`last_name`)) {
        CustomerUpdateObject[["last_name"]] <-
          self$`last_name`
      }
      if (!is.null(self$`birth_day`)) {
        CustomerUpdateObject[["birth_day"]] <-
          self$`birth_day`
      }
      if (!is.null(self$`news_letter_subscription`)) {
        CustomerUpdateObject[["news_letter_subscription"]] <-
          self$`news_letter_subscription`
      }
      if (!is.null(self$`consents`)) {
        CustomerUpdateObject[["consents"]] <-
          lapply(self$`consents`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`tags`)) {
        CustomerUpdateObject[["tags"]] <-
          self$`tags`
      }
      if (!is.null(self$`gender`)) {
        CustomerUpdateObject[["gender"]] <-
          self$`gender`
      }
      if (!is.null(self$`note`)) {
        CustomerUpdateObject[["note"]] <-
          self$`note`
      }
      if (!is.null(self$`status`)) {
        CustomerUpdateObject[["status"]] <-
          self$`status`
      }
      if (!is.null(self$`password`)) {
        CustomerUpdateObject[["password"]] <-
          self$`password`
      }
      if (!is.null(self$`store_id`)) {
        CustomerUpdateObject[["store_id"]] <-
          self$`store_id`
      }
      if (!is.null(self$`idempotency_key`)) {
        CustomerUpdateObject[["idempotency_key"]] <-
          self$`idempotency_key`
      }
      if (!is.null(self$`address`)) {
        CustomerUpdateObject[["address"]] <-
          lapply(self$`address`, function(x) x$toSimpleType())
      }
      return(CustomerUpdateObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of CustomerUpdate
    #'
    #' @param input_json the JSON input
    #' @return the instance of CustomerUpdate
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`id`)) {
        self$`id` <- this_object$`id`
      }
      if (!is.null(this_object$`group_id`)) {
        self$`group_id` <- this_object$`group_id`
      }
      if (!is.null(this_object$`group_ids`)) {
        self$`group_ids` <- this_object$`group_ids`
      }
      if (!is.null(this_object$`group`)) {
        self$`group` <- this_object$`group`
      }
      if (!is.null(this_object$`email`)) {
        self$`email` <- this_object$`email`
      }
      if (!is.null(this_object$`phone`)) {
        self$`phone` <- this_object$`phone`
      }
      if (!is.null(this_object$`first_name`)) {
        self$`first_name` <- this_object$`first_name`
      }
      if (!is.null(this_object$`last_name`)) {
        self$`last_name` <- this_object$`last_name`
      }
      if (!is.null(this_object$`birth_day`)) {
        self$`birth_day` <- this_object$`birth_day`
      }
      if (!is.null(this_object$`news_letter_subscription`)) {
        self$`news_letter_subscription` <- this_object$`news_letter_subscription`
      }
      if (!is.null(this_object$`consents`)) {
        self$`consents` <- ApiClient$new()$deserializeObj(this_object$`consents`, "array[CustomerAddConsentsInner]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`tags`)) {
        self$`tags` <- this_object$`tags`
      }
      if (!is.null(this_object$`gender`)) {
        self$`gender` <- this_object$`gender`
      }
      if (!is.null(this_object$`note`)) {
        self$`note` <- this_object$`note`
      }
      if (!is.null(this_object$`status`)) {
        self$`status` <- this_object$`status`
      }
      if (!is.null(this_object$`password`)) {
        self$`password` <- this_object$`password`
      }
      if (!is.null(this_object$`store_id`)) {
        self$`store_id` <- this_object$`store_id`
      }
      if (!is.null(this_object$`idempotency_key`)) {
        self$`idempotency_key` <- this_object$`idempotency_key`
      }
      if (!is.null(this_object$`address`)) {
        self$`address` <- ApiClient$new()$deserializeObj(this_object$`address`, "array[CustomerUpdateAddressInner]", loadNamespace("openapi"))
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return CustomerUpdate in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of CustomerUpdate
    #'
    #' @param input_json the JSON input
    #' @return the instance of CustomerUpdate
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`id` <- this_object$`id`
      self$`group_id` <- this_object$`group_id`
      self$`group_ids` <- this_object$`group_ids`
      self$`group` <- this_object$`group`
      self$`email` <- this_object$`email`
      self$`phone` <- this_object$`phone`
      self$`first_name` <- this_object$`first_name`
      self$`last_name` <- this_object$`last_name`
      self$`birth_day` <- this_object$`birth_day`
      self$`news_letter_subscription` <- this_object$`news_letter_subscription`
      self$`consents` <- ApiClient$new()$deserializeObj(this_object$`consents`, "array[CustomerAddConsentsInner]", loadNamespace("openapi"))
      self$`tags` <- this_object$`tags`
      self$`gender` <- this_object$`gender`
      self$`note` <- this_object$`note`
      self$`status` <- this_object$`status`
      self$`password` <- this_object$`password`
      self$`store_id` <- this_object$`store_id`
      self$`idempotency_key` <- this_object$`idempotency_key`
      self$`address` <- ApiClient$new()$deserializeObj(this_object$`address`, "array[CustomerUpdateAddressInner]", loadNamespace("openapi"))
      self
    },

    #' @description
    #' Validate JSON input with respect to CustomerUpdate and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of CustomerUpdate
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      if (length(self$`consents`) < 1) {
        return(FALSE)
      }

      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      if (length(self$`consents`) < 1) {
        invalid_fields["consents"] <- "Invalid length for ``, number of items must be greater than or equal to 1."
      }

      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# CustomerUpdate$unlock()
#
## Below is an example to define the print function
# CustomerUpdate$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# CustomerUpdate$lock()

