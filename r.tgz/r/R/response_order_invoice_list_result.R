#' Create a new ResponseOrderInvoiceListResult
#'
#' @description
#' ResponseOrderInvoiceListResult Class
#'
#' @docType class
#' @title ResponseOrderInvoiceListResult
#' @description ResponseOrderInvoiceListResult Class
#' @format An \code{R6Class} generator object
#' @field invoice_count  integer [optional]
#' @field invoice  list(\link{OrderInvoice}) [optional]
#' @field additional_fields  object [optional]
#' @field custom_fields  object [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
ResponseOrderInvoiceListResult <- R6::R6Class(
  "ResponseOrderInvoiceListResult",
  public = list(
    `invoice_count` = NULL,
    `invoice` = NULL,
    `additional_fields` = NULL,
    `custom_fields` = NULL,

    #' @description
    #' Initialize a new ResponseOrderInvoiceListResult class.
    #'
    #' @param invoice_count invoice_count
    #' @param invoice invoice
    #' @param additional_fields additional_fields
    #' @param custom_fields custom_fields
    #' @param ... Other optional arguments.
    initialize = function(`invoice_count` = NULL, `invoice` = NULL, `additional_fields` = NULL, `custom_fields` = NULL, ...) {
      if (!is.null(`invoice_count`)) {
        if (!(is.numeric(`invoice_count`) && length(`invoice_count`) == 1)) {
          stop(paste("Error! Invalid data for `invoice_count`. Must be an integer:", `invoice_count`))
        }
        self$`invoice_count` <- `invoice_count`
      }
      if (!is.null(`invoice`)) {
        stopifnot(is.vector(`invoice`), length(`invoice`) != 0)
        sapply(`invoice`, function(x) stopifnot(R6::is.R6(x)))
        self$`invoice` <- `invoice`
      }
      if (!is.null(`additional_fields`)) {
        self$`additional_fields` <- `additional_fields`
      }
      if (!is.null(`custom_fields`)) {
        self$`custom_fields` <- `custom_fields`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return ResponseOrderInvoiceListResult as a base R list.
    #' @examples
    #' # convert array of ResponseOrderInvoiceListResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert ResponseOrderInvoiceListResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      ResponseOrderInvoiceListResultObject <- list()
      if (!is.null(self$`invoice_count`)) {
        ResponseOrderInvoiceListResultObject[["invoice_count"]] <-
          self$`invoice_count`
      }
      if (!is.null(self$`invoice`)) {
        ResponseOrderInvoiceListResultObject[["invoice"]] <-
          lapply(self$`invoice`, function(x) x$toSimpleType())
      }
      if (!is.null(self$`additional_fields`)) {
        ResponseOrderInvoiceListResultObject[["additional_fields"]] <-
          self$`additional_fields`
      }
      if (!is.null(self$`custom_fields`)) {
        ResponseOrderInvoiceListResultObject[["custom_fields"]] <-
          self$`custom_fields`
      }
      return(ResponseOrderInvoiceListResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of ResponseOrderInvoiceListResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ResponseOrderInvoiceListResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`invoice_count`)) {
        self$`invoice_count` <- this_object$`invoice_count`
      }
      if (!is.null(this_object$`invoice`)) {
        self$`invoice` <- ApiClient$new()$deserializeObj(this_object$`invoice`, "array[OrderInvoice]", loadNamespace("openapi"))
      }
      if (!is.null(this_object$`additional_fields`)) {
        self$`additional_fields` <- this_object$`additional_fields`
      }
      if (!is.null(this_object$`custom_fields`)) {
        self$`custom_fields` <- this_object$`custom_fields`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return ResponseOrderInvoiceListResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of ResponseOrderInvoiceListResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of ResponseOrderInvoiceListResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`invoice_count` <- this_object$`invoice_count`
      self$`invoice` <- ApiClient$new()$deserializeObj(this_object$`invoice`, "array[OrderInvoice]", loadNamespace("openapi"))
      self$`additional_fields` <- this_object$`additional_fields`
      self$`custom_fields` <- this_object$`custom_fields`
      self
    },

    #' @description
    #' Validate JSON input with respect to ResponseOrderInvoiceListResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of ResponseOrderInvoiceListResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# ResponseOrderInvoiceListResult$unlock()
#
## Below is an example to define the print function
# ResponseOrderInvoiceListResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# ResponseOrderInvoiceListResult$lock()

