#' Create a new CustomerDelete200ResponseResult
#'
#' @description
#' CustomerDelete200ResponseResult Class
#'
#' @docType class
#' @title CustomerDelete200ResponseResult
#' @description CustomerDelete200ResponseResult Class
#' @format An \code{R6Class} generator object
#' @field delete_items  integer [optional]
#' @importFrom R6 R6Class
#' @importFrom jsonlite fromJSON toJSON
#' @export
CustomerDelete200ResponseResult <- R6::R6Class(
  "CustomerDelete200ResponseResult",
  public = list(
    `delete_items` = NULL,

    #' @description
    #' Initialize a new CustomerDelete200ResponseResult class.
    #'
    #' @param delete_items delete_items
    #' @param ... Other optional arguments.
    initialize = function(`delete_items` = NULL, ...) {
      if (!is.null(`delete_items`)) {
        if (!(is.numeric(`delete_items`) && length(`delete_items`) == 1)) {
          stop(paste("Error! Invalid data for `delete_items`. Must be an integer:", `delete_items`))
        }
        self$`delete_items` <- `delete_items`
      }
    },

    #' @description
    #' Convert to an R object. This method is deprecated. Use `toSimpleType()` instead.
    toJSON = function() {
      .Deprecated(new = "toSimpleType", msg = "Use the '$toSimpleType()' method instead since that is more clearly named. Use '$toJSONString()' to get a JSON string")
      return(self$toSimpleType())
    },

    #' @description
    #' Convert to a List
    #'
    #' Convert the R6 object to a list to work more easily with other tooling.
    #'
    #' @return CustomerDelete200ResponseResult as a base R list.
    #' @examples
    #' # convert array of CustomerDelete200ResponseResult (x) to a data frame
    #' \dontrun{
    #' library(purrr)
    #' library(tibble)
    #' df <- x |> map(\(y)y$toList()) |> map(as_tibble) |> list_rbind()
    #' df
    #' }
    toList = function() {
      return(self$toSimpleType())
    },

    #' @description
    #' Convert CustomerDelete200ResponseResult to a base R type
    #'
    #' @return A base R type, e.g. a list or numeric/character array.
    toSimpleType = function() {
      CustomerDelete200ResponseResultObject <- list()
      if (!is.null(self$`delete_items`)) {
        CustomerDelete200ResponseResultObject[["delete_items"]] <-
          self$`delete_items`
      }
      return(CustomerDelete200ResponseResultObject)
    },

    #' @description
    #' Deserialize JSON string into an instance of CustomerDelete200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of CustomerDelete200ResponseResult
    fromJSON = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      if (!is.null(this_object$`delete_items`)) {
        self$`delete_items` <- this_object$`delete_items`
      }
      self
    },

    #' @description
    #' To JSON String
    #' 
    #' @param ... Parameters passed to `jsonlite::toJSON`
    #' @return CustomerDelete200ResponseResult in JSON format
    toJSONString = function(...) {
      simple <- self$toSimpleType()
      json <- jsonlite::toJSON(simple, auto_unbox = TRUE, digits = NA, ...)
      return(as.character(jsonlite::minify(json)))
    },

    #' @description
    #' Deserialize JSON string into an instance of CustomerDelete200ResponseResult
    #'
    #' @param input_json the JSON input
    #' @return the instance of CustomerDelete200ResponseResult
    fromJSONString = function(input_json) {
      this_object <- jsonlite::fromJSON(input_json)
      self$`delete_items` <- this_object$`delete_items`
      self
    },

    #' @description
    #' Validate JSON input with respect to CustomerDelete200ResponseResult and throw an exception if invalid
    #'
    #' @param input the JSON input
    validateJSON = function(input) {
      input_json <- jsonlite::fromJSON(input)
    },

    #' @description
    #' To string (JSON format)
    #'
    #' @return String representation of CustomerDelete200ResponseResult
    toString = function() {
      self$toJSONString()
    },

    #' @description
    #' Return true if the values in all fields are valid.
    #'
    #' @return true if the values in all fields are valid.
    isValid = function() {
      TRUE
    },

    #' @description
    #' Return a list of invalid fields (if any).
    #'
    #' @return A list of invalid fields (if any).
    getInvalidFields = function() {
      invalid_fields <- list()
      invalid_fields
    },

    #' @description
    #' Print the object
    print = function() {
      print(jsonlite::prettify(self$toJSONString()))
      invisible(self)
    }
  ),
  # Lock the class to prevent modifications to the method or field
  lock_class = TRUE
)
## Uncomment below to unlock the class to allow modifications of the method or field
# CustomerDelete200ResponseResult$unlock()
#
## Below is an example to define the print function
# CustomerDelete200ResponseResult$set("public", "print", function(...) {
#   print(jsonlite::prettify(self$toJSONString()))
#   invisible(self)
# })
## Uncomment below to lock the class to prevent modifications to the method or field
# CustomerDelete200ResponseResult$lock()

